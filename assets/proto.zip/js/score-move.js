import{tierFor,TIERS}from"./score-band.js";import{DIAL_A0,DIAL_SWEEP,dialPath,dialPoint}from"./components.js";import{buzz}from"./motion.js";export const TICKS=TIERS.map(t=>t.min).filter(m=>m>0).sort((a,b)=>a-b);export const MOVE_DUR=1150;const ease=p=>1-Math.pow(1-p,4);const clamp=(n,lo,hi)=>Math.min(hi,Math.max(lo,n));const DONE=new Set;const FLIGHT=new Map;export function resetScoreMoves(){DONE.clear();FLIGHT.clear()}export function scoreMovePlayed(key){return DONE.has(key)}export function scoreMoveInFlight(key){return FLIGHT.has(key)}function sweepDefs(uid,{x1,y1,x2,y2}){return`<linearGradient id="smg${uid}" gradientUnits="userSpaceOnUse"
      x1="${x1.toFixed(1)}" y1="${y1.toFixed(1)}" x2="${x2.toFixed(1)}" y2="${y2.toFixed(1)}">
      <stop offset="0%" stop-color="var(--ring-a)"/>
      <stop offset="50%" stop-color="var(--ring-b)"/>
      <stop offset="100%" stop-color="var(--ring-c)"/>
    </linearGradient>`}const dialAxis=(cx,cy,r)=>({x1:cx-.71*r,y1:cy+.88*r,x2:cx+.24*r,y2:cy-r});function glows(from,to){return`<span class="sm-glow ${tierFor(from).cls}"></span>
    <span class="sm-glow sm-glow-to ${tierFor(to).cls}"></span>`}function span(a,b,{rotates}){return{len:Math.max(0,b-a),dasharray:dashAt(Math.max(0,b-a)),off:(rotates?0:-a).toFixed(2)}}const dashAt=len=>`${len.toFixed(2)} 100`;export function scoreMoveDial({from,to,size=168,stroke=12,uid="sm"}={}){const f=clamp(Number(from)||0,0,100);const t=clamp(Number(to)||0,0,100);const cx=size/2,cy=size/2;const r=(size-stroke)/2-6;const d=dialPath(cx,cy,r);const base=span(0,f,{rotates:true});const delta=span(f,t,{rotates:true});const tierT=tierFor(t);const tick=v=>{const deg=DIAL_A0+v/100*DIAL_SWEEP;const inner=r-stroke/2-1,outer=r+stroke/2+1;return`<line class="sm-tick${f>=v?" lit":""}" data-sm-tick="${v}"
      x1="${dialPoint(cx,cy,inner,deg).split(" ")[0]}" y1="${dialPoint(cx,cy,inner,deg).split(" ")[1]}"
      x2="${dialPoint(cx,cy,outer,deg).split(" ")[0]}" y2="${dialPoint(cx,cy,outer,deg).split(" ")[1]}"/>`};return`
  ${""}
  <div class="smove smove-dial" data-sm data-sm-from="${f}" data-sm-to="${t}">
    ${glows(f,t)}
    <svg class="sm-svg" width="${size}" height="${size}" viewBox="0 0 ${size} ${size}" aria-hidden="true">
      <defs>${sweepDefs(uid,dialAxis(cx,cy,r))}</defs>
      <path d="${d}" fill="none" stroke="var(--ring-track)" stroke-width="${stroke}" stroke-linecap="round"/>
      ${""}
      ${base.len>0?`<path class="sm-base" d="${d}" fill="none" stroke="url(#smg${uid})"
        stroke-width="${stroke}" stroke-linecap="round" opacity="0.45"
        pathLength="100" stroke-dasharray="${base.dasharray}" stroke-dashoffset="${base.off}"/>`:""}
      ${""}
      ${delta.len>0?`<path class="sm-delta" data-sm-arc d="${d}" fill="none" stroke="url(#smg${uid})"
        stroke-width="${stroke}" stroke-linecap="round"
        pathLength="100" stroke-dasharray="${delta.dasharray}"
        stroke-dashoffset="${delta.off}" data-sm-len="${delta.len.toFixed(2)}"
        transform="rotate(${(f/100*DIAL_SWEEP).toFixed(2)} ${cx} ${cy})"/>`:""}
      <g class="sm-ticks">${TICKS.map(tick).join("")}</g>
    </svg>
    <div class="sm-center">
      <span class="sm-num" data-sm-count="${t}">${t}</span>
      <span class="sm-of">/100</span>
      ${""}
      <span class="tier-chip sm-tier ${tierT.cls}" data-sm-tier data-sm-base="tier-chip sm-tier">${tierT.name}</span>
    </div>
  </div>`}export function scoreMoveBar({from,to,uid="smb",head=""}={}){const f=clamp(Number(from)||0,0,100);const t=clamp(Number(to)||0,0,100);const base=span(0,f,{rotates:false});const delta=span(f,t,{rotates:false});return`
  ${""}
  <div class="smove smove-bar" data-sm data-sm-from="${f}" data-sm-to="${t}">
    ${head?`<div class="sm-head">${head}</div>`:""}
    ${""}
    <svg class="sm-svg" viewBox="0 0 100 6" preserveAspectRatio="none" aria-hidden="true">
      <defs>${sweepDefs(uid,{x1:0,y1:3,x2:100,y2:3})}</defs>
      <line x1="0" y1="3" x2="100" y2="3" stroke="var(--ring-track)" stroke-width="4" stroke-linecap="butt"/>
      ${base.len>0?`<line class="sm-base" x1="0" y1="3" x2="100" y2="3" stroke="url(#smg${uid})"
        stroke-width="4" stroke-linecap="butt" opacity="0.45"
        pathLength="100" stroke-dasharray="${base.dasharray}" stroke-dashoffset="${base.off}"/>`:""}
      ${delta.len>0?`<line class="sm-delta" data-sm-arc x1="0" y1="3" x2="100" y2="3" stroke="url(#smg${uid})"
        stroke-width="4" stroke-linecap="butt"
        pathLength="100" stroke-dasharray="${delta.dasharray}"
        stroke-dashoffset="${delta.off}" data-sm-len="${delta.len.toFixed(2)}"/>`:""}
      <g class="sm-ticks">${TICKS.map(v=>`<line class="sm-tick${f>=v?" lit":""}" data-sm-tick="${v}"
        x1="${v}" y1="0" x2="${v}" y2="6" vector-effect="non-scaling-stroke"/>`).join("")}</g>
    </svg>
  </div>`}function setGlow(node,p){if(node.style.setProperty)node.style.setProperty("--sm-p",String(p));else node.style["--sm-p"]=String(p)}function settle(el,to){el.querySelectorAll("[data-sm-arc]").forEach(arc=>{arc.style.transition="none";arc.style.strokeDasharray=dashAt(parseFloat(arc.getAttribute("data-sm-len"))||0);arc.style.opacity=""});const num=el.querySelector("[data-sm-count]");if(num)num.textContent=String(Math.round(to));el.querySelectorAll("[data-sm-tick]").forEach(tk=>{if(to>=+tk.getAttribute("data-sm-tick"))tk.classList.add("lit")});setGlow(el,1);const chip=el.querySelector("[data-sm-tier]");if(chip)paintTier(chip,tierFor(to))}function paintTier(chip,t){const label=(chip.getAttribute("data-sm-tier")||"")+t.name;if(chip.textContent===label)return;chip.textContent=label;chip.className=`${chip.getAttribute("data-sm-base")||"tier-chip"} ${t.cls}`}export function playScoreMove(root,{key,from,to,haptic="reveal",onDone}={}){const el=!root?null:root.matches&&root.matches("[data-sm]")?root:root.querySelector("[data-sm]");if(!el)return false;const f=clamp(Number(from)||0,0,100);const t=clamp(Number(to)||0,0,100);const fin=()=>{if(typeof onDone==="function"){try{onDone()}catch{}}};const reduced=typeof matchMedia==="function"&&matchMedia("(prefers-reduced-motion: reduce)").matches;const spent=key?DONE.has(key):false;if(spent||t<=f||reduced){settle(el,t);if(key){DONE.add(key);FLIGHT.delete(key)}if(!spent&&reduced&&haptic)buzz(haptic);fin();return false}const now=typeof performance==="object"&&performance.now?performance.now():0;const held=key?FLIGHT.get(key):null;const t0=held?held.t0:now;const gen=(held?held.gen:0)+1;const rec0={t0,buzzed:held?held.buzzed:false,gen};if(key)FLIGHT.set(key,rec0);const arcs=Array.from(el.querySelectorAll("[data-sm-arc]")).map(arc=>({node:arc,len:parseFloat(arc.getAttribute("data-sm-len"))||0}));const num=el.querySelector("[data-sm-count]");const chip=el.querySelector("[data-sm-tier]");const ticks=Array.from(el.querySelectorAll("[data-sm-tick]"));const fromTier=tierFor(f);const crosses=tierFor(t).name!==fromTier.name;setGlow(el,0);const frame=nowT=>{const rec=key?FLIGHT.get(key):rec0;if(!rec||rec.gen!==gen)return;if(!el.isConnected)return;const p=clamp((nowT-t0)/MOVE_DUR,0,1);const e=ease(p);const cur=f+(t-f)*e;arcs.forEach(a=>{const len=a.len*e;a.node.style.strokeDasharray=dashAt(len);a.node.style.opacity=len>.2?"":"0"});if(num)num.textContent=String(Math.round(cur));setGlow(el,e);ticks.forEach(tk=>{if(cur>=+tk.getAttribute("data-sm-tick"))tk.classList.add("lit")});const curTier=tierFor(Math.round(cur));if(chip)paintTier(chip,curTier);if(haptic&&rec&&!rec.buzzed&&(crosses?curTier.name!==fromTier.name:p>=1)){rec.buzzed=true;buzz(haptic)}if(p<1){requestAnimationFrame(frame);return}if(key){DONE.add(key);FLIGHT.delete(key)}settle(el,t);fin()};if(typeof requestAnimationFrame==="function")frame(now);else{settle(el,t);if(key){DONE.add(key);FLIGHT.delete(key)}fin()}return true}
