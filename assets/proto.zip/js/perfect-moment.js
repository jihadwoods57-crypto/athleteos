import{buzz}from"./motion.js";import{animateRing}from"./components.js";import{overlayOpen}from"./overlay-guard.js";import{esc}from"./components.js";export const PM_PARTICLES=20;export const PM_LIFE_MS=3e3;export const PM_FADE_AT_MS=2600;export const PM_RETRY_MS=1200;const DIAL_START=120;const DIAL_SWEEP=300;let showing=false;function dialSvg(size,stroke,score){const c=size/2;const r=c-stroke;const pt=deg=>{const a=deg*Math.PI/180;return`${(c+Math.cos(a)*r).toFixed(2)} ${(c+Math.sin(a)*r).toFixed(2)}`};const d=`M ${pt(DIAL_START)} A ${r} ${r} 0 1 1 ${pt(DIAL_START+DIAL_SWEEP-360)}`;const off=Math.max(0,100-Number(score)).toFixed(1);const g=n=>(size*n).toFixed(1);return`<svg class="pm-dial" width="${size}" height="${size}" viewBox="0 0 ${size} ${size}" aria-hidden="true">
    <defs>
      <linearGradient id="pmgrad" gradientUnits="userSpaceOnUse" x1="${g(.2016)}" y1="${g(.8694)}" x2="${g(.6)}" y2="${g(.0806)}">
        <stop offset="0%" stop-color="var(--ring-a)"/>
        <stop offset="50%" stop-color="var(--ring-b)"/>
        <stop offset="100%" stop-color="var(--ring-c)"/>
      </linearGradient>
    </defs>
    <path d="${d}" fill="none" stroke="var(--ring-track)" stroke-width="${stroke}" stroke-linecap="round"/>
    ${""}
    <path class="ring-arc pm-arc" d="${d}" fill="none" stroke="url(#pmgrad)" stroke-width="${stroke}"
      stroke-linecap="round" pathLength="100" stroke-dasharray="100" stroke-dashoffset="100" data-off="${off}"/>
  </svg>`}function burstEl(doc){const b=doc.createElement("div");b.className="pm-burst";b.setAttribute("aria-hidden","true");const cols=["var(--ring-a)","var(--ring-b)","var(--ring-c)"];for(let i=0;i<PM_PARTICLES;i++){const p=doc.createElement("i");p.style.setProperty("--a",`${Math.round(360/PM_PARTICLES*i+(i%3?11:-8))}deg`);p.style.setProperty("--d",`${132+i%4*34}px`);p.style.setProperty("--c",cols[i%3]);p.style.setProperty("--z",`${.7+i%3*.25}`);p.style.setProperty("animation-delay",`${880+i%5*45}ms`);b.appendChild(p)}return b}export function playPerfectMoment(opts={}){const{slotLabel="",score=100,attempt=0}=opts;if(typeof document==="undefined"||!document.body)return false;if(showing)return false;if(overlayOpen(".pmoment")){if(attempt===0&&typeof setTimeout==="function"){setTimeout(()=>{playPerfectMoment({...opts,attempt:1})},PM_RETRY_MS);return true}return false}const reduce=typeof matchMedia==="function"&&matchMedia("(prefers-reduced-motion: reduce)").matches;const el=document.createElement("div");el.className="pmoment";el.setAttribute("role","status");el.setAttribute("aria-live","polite");const line=slotLabel?`${esc(String(slotLabel))} \xB7 `:"";el.innerHTML=`
    <div class="pm-glow" aria-hidden="true"></div>
    <div class="pm-stage">
      <div class="pm-core">
        ${dialSvg(248,12,score)}
        ${""}
        <div class="pm-read"><span class="pm-num" data-count="${Number(score)||0}">0</span></div>
      </div>
      <div class="pm-word">Perfect plate</div>
      <div class="pm-sub">${line}every point on the plate</div>
    </div>`;if(!reduce)el.appendChild(burstEl(document));document.body.appendChild(el);showing=true;try{animateRing(el)}catch{}buzz("celebrate");let done=false;const close=fast=>{if(done)return;done=true;try{document.removeEventListener("keydown",onKey)}catch{}clearTimeout(fadeT);clearTimeout(endT);el.classList.add("out");if(fast)el.classList.add("fast");setTimeout(()=>{try{el.remove()}catch{}showing=false},fast?200:400)};const onKey=e=>{if(e.key==="Escape"){e.preventDefault();close(true)}};document.addEventListener("keydown",onKey);el.addEventListener("click",()=>close(true));const fadeT=setTimeout(()=>{el.classList.add("out")},PM_FADE_AT_MS);const endT=setTimeout(()=>{try{el.remove()}catch{}showing=false;try{document.removeEventListener("keydown",onKey)}catch{}done=true},PM_LIFE_MS);return true}export function _resetPerfectMoment(){showing=false}
