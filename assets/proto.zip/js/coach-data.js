/* OnStandard Operator OS — shared data cache for BOTH operator roles.
   Every coach screen (coach-home, coach-roster, coach-insights, and the existing coach/trainer
   screens in screens/coach.js) reads the roster + activity + requirements-engine "extras" from
   HERE instead of keeping its own private copy — one fetch, one repaint, one honest state.

   A "book" is the set of people an operator is responsible for: a COACH's team or a TRAINER's
   practice. Both produce the identical row shape (roles.js projectRows), so every engine
   downstream (status, priority, inbox, insights) works on either without knowing which it got.
   What differs is CAPABILITY, not shape — see CAPS below.

   NOTE: this module deliberately does NOT import state.js. state.js imports FROM here, and
   closing that cycle makes RT undefined at module-eval time in an ESM WebView — an intermittent
   boot failure that reproduces on device and not in preview. The book kind is always passed in
   by the caller, never read off RT. */
import * as roles from './roles.js';
import { CATALOG, resolveRequirementSet, catalogFromItems, planStyleFromItems } from './requirements.js';
import { athleteStatus } from './status.js';
import { ON_STANDARD } from './score-band.js';
import { dateKey } from './fmt-date.js';
import { effectiveRoomLabel } from './rooms.js';

/** The plan style a TEAM STANDARD governs for one roster row, or null when none does (0142).
 *  Reuses the SAME resolveRequirementSet() call every status computation already makes — CD.extras.sets
 *  is loaded once for the whole book, so this costs nothing extra. Deliberately does NOT know
 *  about a per-athlete assignment (athlete_profiles.targets.style) or the athlete's own
 *  preference — those only exist on the ONE athlete a coach has opened (PROFILE.basics.targets /
 *  a dedicated preference fetch), never cheaply for a whole roster. */
export function governingPlanStyle(row) {
  if (!row || !CD.extras) return null;
  const set = resolveRequirementSet(CD.extras.sets, row.athleteId, resolvePos(row));
  const item = set ? planStyleFromItems(set.items) : null;
  return item ? item.style : null;
}

/* The position value a roster row resolves its standard against: the athlete's ASSIGNED room label
   (0101) when set, else their raw position. Unassigned (every athlete until a coach assigns) → raw
   position, byte-identical to before. */
export function resolvePos(row) {
  return effectiveRoomLabel(row.roomId, (CD.extras && CD.extras.rooms) || []) || row.position;
}

/* ---------- Trust Pass milestone (0196): who just earned a reward, from data already loaded ---
   `row.scoreHistory` is what buildRosterRow already carries — up to 7 days back plus today, the
   same window loadCoachRoster/loadTrainerBook fetch for the sparkline. No new query. */

/** Consecutive on-standard (score >= 80) days ending at the most recent entry in scoreHistory.
 *  Counting BACKWARD from the newest row and stopping at the first gap or sub-80 score means the
 *  result is a LOWER BOUND on the athlete's real streak, never an inflated one: a streak that
 *  started before this 7-day window is real but invisible here, and this function only ever
 *  under-counts, so a milestone that fires is always true.
 *
 *  A day with no ROW at all (never logged) must break the chain exactly like a sub-80 score does
 *  — "absent days count as misses" is the same rule the streak screen states outright, and a
 *  version of this that just skipped a gap in the dates would count two Tuesdays a week apart as
 *  adjacent. So each older row is required to be exactly one calendar day before the one after
 *  it; anything else ends the count right there. */
export function consecutiveOnStandard(scoreHistory) {
  const rows = (scoreHistory || []).slice().sort((a, b) => (a.date < b.date ? 1 : -1)); // newest first
  let n = 0;
  let expected = null;
  for (const r of rows) {
    if (!r || typeof r.score !== 'number' || r.score < ON_STANDARD) break;
    if (expected !== null && r.date !== expected) break;
    n++;
    const d = new Date(r.date + 'T00:00:00');
    d.setDate(d.getDate() - 1);
    expected = dateKey(d);
  }
  return n;
}

/** Clients who just crossed the reward milestone and hold no active pass, ranked by streak length
 *  (the athlete closest to earning a moment gets it). `passes` is the map fetchRosterPasses
 *  already returns for the roster's own trust-pass section.
 *
 *  `minStreak` default is 5, NOT the 14 days floated at design time — the roster fetch carries at
 *  most ~8 days of scoreHistory (7 back + today), so a 14-day threshold could never fire on data
 *  this screen actually has. 5 is the largest number the current window can prove without lying.
 *  Widening this needs widening the roster's own date fetch (roles.js loadCoachRoster /
 *  loadTrainerBook), which is a real product decision, not a default to guess past. */
export function passWorthy(rows, passesMap, minStreak = 5) {
  return (rows || [])
    .map((r) => ({ row: r, streak: consecutiveOnStandard(r.scoreHistory) }))
    .filter((x) => x.streak >= minStreak && !(passesMap || {})[x.row.athleteId])
    .sort((a, b) => b.streak - a.streak);
}

/* What an operator can actually DO with their book. Pure data, no imports.
   Every practice cap that is still 0 is 0 PERMANENTLY, by design — not a pending migration:
     · position rooms, staff scopes, practice/game-day patterns and 1-to-many broadcast are
       TEAM concepts. A trainer with 12 clients works 1:1, so rooms/staffRoles/weekPattern/
       announcements/recruiting have no practice equivalent to build.
     · trustPass is available to BOTH books as of 0196: grant_pass authorizes
       is_team_coach_of OR is_trainer_of, and trust_pass_policy carries a practice_id arm
       (0136's dual-owner shape) — see roster/pass-grant.js for the shared UI.
     · templates (0074 requirement_templates) was not one of 0136's six dual-owner tables;
       a practice writes its standard directly instead of browsing team template drafts.
   Everything migration-gated has landed: standards/assignments/interventions/notes/
   exceptions/groups (0136) and rollups (0137). */
const CAPS = {
  team: {
    roster: 1, activity: 1, inbox: 1, athleteProfile: 1, targets: 1, approvals: 1,
    interventions: 1, notes: 1, exceptions: 1, groups: 1, standards: 1, assignments: 1, rollups: 1,
    templates: 1,
    rooms: 1, staffRoles: 1, weekPattern: 1, announcements: 1, recruiting: 1, trustPass: 1,
    offers: 0, payments: 0, packages: 0,
  },
  practice: {
    roster: 1, activity: 1, inbox: 1, athleteProfile: 1, targets: 1, approvals: 1,
    // 0136 gave these six tables dual-owner (team_id | practice_id) columns, so a practice now
    // owns its own standards, assignments, interventions, notes, exceptions and groups.
    interventions: 1, notes: 1, exceptions: 1, groups: 1, standards: 1, assignments: 1,
    // requirement_templates (0074) was NOT one of 0136's six dual-owner tables — a practice
    // writes its standard directly instead of browsing team template drafts.
    templates: 0,
    // 0137 mirrors team_day_rollup/team_intervention_outcomes as practice_day_rollup/
    // practice_intervention_outcomes — Insights now reads real per-day-per-client history.
    rollups: 1,
    rooms: 0, staffRoles: 0, weekPattern: 0, announcements: 0, recruiting: 0, trustPass: 1,
    offers: 1, payments: 1, packages: 1,
  },
};
const EMPTY_EXTRAS = { sets: [], groups: [], exceptions: [], interventions: [], rooms: [], scope: null, myRole: null };

/* Operator book cache: null = not loaded (show loading), else { book, teams, rows, kind } from real
   data. Fetched once on mount, repainted via window.__render; the athletes' scores are their own
   real numbers (days.score), and a member with no day row today is honestly "No logs today". */
let ROSTER = null;
let rosterLoading = false;
let KIND = 'team';

/** Load the signed-in operator's book. `kind` is 'team' (coach) or 'practice' (trainer) and MUST
    be passed by the caller — see the no-state.js-import note at the top of this file.
    loadCoachRoster below keeps the old name and signature, so no existing caller moves. */
export async function loadBook(force, kind) {
  const k = kind || KIND || 'team';
  if (rosterLoading) return;
  if (ROSTER && ROSTER.kind === k && !force) return;
  rosterLoading = true;
  const prevKind = KIND;
  KIND = k;                                  // CD.caps must be right before loadExtras gates on it
  try {
    const r = k === 'practice' ? await roles.loadTrainerBook() : await roles.loadCoachRoster();
    // One book shape for both roles. `teams` is an ALIAS of the same array, not a copy — every
    // shipped coach screen reads CD.roster.teams[0].id, and keeping that binding live is what
    // makes this generalization a ~0-diff change on the coach side.
    r.book = k === 'practice' ? r.practices : r.teams;
    r.teams = r.book;
    r.kind = k;
    // Pending join requests (names before the link is active). The practice RPC returns
    // client_id/client_name; normalize to the athlete_* shape the inbox already renders, so one
    // template serves both books.
    const pending = [];
    // All books at once: a trainer with several practices was paying one round trip per book,
    // serially, before the inbox could paint its pending count. A null (FAILED) book must not
    // read as "no requests waiting" — but it also must not mark a good roster offline, so it
    // gets its own flag and the inbox keeps last-known instead of claiming "All caught up".
    const perBook = await Promise.all(r.book.map((b) =>
      (k === 'practice' ? roles.pendingPracticeRequests(b.id) : roles.pendingTeamRequests(b.id))));
    r.pendingFailed = perBook.some((reqs) => reqs === null);
    r.book.forEach((b, i) => {
      for (const q of (perBook[i] || [])) {
        pending.push(k === 'practice'
          ? { teamId: b.id, bookId: b.id, athlete_id: q.client_id, athlete_name: q.client_name, position: null }
          : { teamId: b.id, bookId: b.id, ...q });
      }
    });
    r.pending = (r.pendingFailed && ROSTER && ROSTER.kind === k && Array.isArray(ROSTER.pending) && ROSTER.pending.length)
      ? ROSTER.pending : pending;
    r.offline = false;
    ROSTER = r;
    // Coach OS core (0071): requirement sets, groups, exceptions, today's interventions, and
    // this staff member's own scope — best-effort, scoped to the first book (mirrors the rest
    // of this cache's single-book assumption). A failure here must NOT read as a roster outage:
    // it's isolated in its own try/catch so a good roster fetch never gets marked offline
    // because the extras fetch (a separate set of tables) had trouble.
    if (r.book.length) {
      try { await loadExtras(r.book[0].id); }
      catch { CD.extras = { ...EMPTY_EXTRAS }; }
    }
  } catch {
    // A fetch that actually threw (vs the lower layers' swallow-to-[]) must NOT leave the screen
    // stuck on "Loading…" forever — mark offline so the render shows a distinct, retryable state.
    ROSTER = { book: [], teams: [], rows: [], pending: [], offline: true, kind: k };
    KIND = prevKind === k ? prevKind : k;
  } finally {
    rosterLoading = false; // always clear so a retry can re-run
  }
  // The book just became ready (roster + extras) — or just FAILED. This deliberately runs on
  // failure too (we're past the catch), and screens rely on that: the offline/retry states
  // repaint on the same signal as the data.
  // No hash list here any more. Every hash this used to enumerate belonged to a screen that
  // declares an operator nav, and the list itself was the footgun: a screen whose hash was
  // missing never learned the load finished and hung on its loading state forever on direct
  // entry — coach-standards/-manage/-edit and coach-rooms all fell through it (audit
  // 2026-08-23), then coach-commitments after them. So coach-data ANNOUNCES, and the router
  // (the one module that knows which screen the hash resolves to) repaints iff the current
  // screen declares nav 'coach'/'trainer'/'operator' — the same declaration that gives it
  // operator chrome, so a new operator screen is covered the day it is written.
  try { window.dispatchEvent(new Event('onstd:book-arrival')); } catch { /* non-DOM harness */ }
  // Operator data just became ready (roster + extras). Re-run the notification sync so this
  // operator's device now schedules the OPERATOR plan from live roster status — the boot-time sync
  // (hydrateDay) ran before this fetch, when entriesFor() was still null and posted nothing.
  // syncNotifications itself routes to the operator branch only for a coach/trainer; harmless for
  // any other role. This is the ONLY data-arrival re-sync trigger an operator gets.
  try { if (window.__act && window.__act.syncNotifications) window.__act.syncNotifications(); }
  catch { /* best-effort — a sync failure never blocks the roster render */ }
}

/** The coach's book, by its original name and signature — every shipped coach screen still calls
    exactly this. Kept as a named export (not just an alias) so the coach path is impossible to
    break by changing loadBook's default. */
export async function loadCoachRoster(force) { return loadBook(force, 'team'); }
/** The trainer's book. Same cache, same engines, capability-reduced. */
export async function loadTrainerBook(force) { return loadBook(force, 'practice'); }
/** Which book an auth role owns. Takes the role as an ARGUMENT — this module must not import
    state.js (see the cycle note at the top), so every caller passes RT.authRole in. */
export const bookKindFor = (role) => (role === 'trainer' ? 'practice' : 'team');

/* Roster-wide activity feed (WS4a): recent meals across the team, newest first, with
   per-device unseen dots. Photos are real signed URLs (cached), never stock plates. */
let ACT = null;            // null = loading; { rows, photos: {mealId: url} }
let actLoading = false;
let actFetchedAt = 0;      // freshness window: a tab visit refetches, a repaint doesn't loop
export async function loadActivity(force) {
  if (actLoading) return;
  if (ACT && !force && Date.now() - actFetchedAt < 30000) return;
  actLoading = true;
  let failed = false;
  try {
    // Scope the read to the roster's athlete ids whenever the book is already loaded — both
    // mounts call loadActivity() from loadBook's .then, so it normally is (a second mount
    // racing an in-flight loadBook can still get here first; the fallback covers it). With ids
    // the fetch takes the 0214 RPC (or its index-friendly chunked fallback on a pre-0214
    // server) instead of the roster-less scan that can't use meals(athlete_id, day_date) and
    // sorts every recent meals row the caller can view (capacity audit F6 — this was the last
    // fetchTeamActivity caller still on that path). No ids yet, or an offline/empty book,
    // keeps today's unscoped read: same rows either way, RLS does the scoping.
    const ids = (ROSTER && Array.isArray(ROSTER.rows))
      ? ROSTER.rows.map((r) => r.athleteId).filter(Boolean) : [];
    const rows = await roles.fetchTeamActivity(roles.daysAgoISO(1), 20, ids.length ? ids : undefined);
    // null = FAILED. Keep the last-known feed rather than laundering the failure into an empty
    // one that reads as a genuinely quiet team. Previously rows.slice() below threw on null and
    // the catch did exactly that laundering.
    if (rows === null) {
      failed = true;
      ACT = ACT ? { ...ACT, failed: true } : { rows: [], photos: {}, failed: true };
    } else {
      const withPhotos = rows.slice(0, 10).filter(m => m.photo_path);
      const urls = await roles.signedMealPhotoUrls(withPhotos.map(m => m.photo_path));
      const photos = {};
      for (const m of withPhotos) { if (urls[m.photo_path]) photos[m.id] = urls[m.photo_path]; }
      ACT = { rows, photos, failed: false };
    }
  } catch { failed = true; ACT = ACT ? { ...ACT, failed: true } : { rows: [], photos: {}, failed: true }; }
  // A failure leaves the freshness stamp at 0 so the next visit retries immediately instead of
  // sitting on a known-bad cache for the full 30s window.
  finally { actLoading = false; actFetchedAt = failed ? 0 : Date.now(); }
  // '#coach-home' is the real Home tab route ('#coach' is only a legacy alias) — without it the
  // Live activity section sat on its skeleton until an unrelated tap repainted the screen.
  if (['#coach', '#coach-home', '#coach-inbox', '#trainer', '#trainer-inbox'].includes(location.hash)) window.__render();
}
export const actTime = (iso) => {
  const d = new Date(iso);
  if (isNaN(d)) return '';
  let h = d.getHours() % 12; if (h === 0) h = 12;
  return `${h}:${String(d.getMinutes()).padStart(2, '0')} ${d.getHours() < 12 ? 'AM' : 'PM'}`;
};

export const CD = {
  get roster() { return ROSTER; },
  get act() { return ACT; },
  get profile() { return PROFILE; },
  /** 'team' (coach) | 'practice' (trainer) — which kind of book is loaded. */
  get kind() { return KIND; },
  /* Operator noun vocabulary — shared screens must say "client"/"practice" to a trainer.
     Header-level VOCAB maps exist per screen; these cover body copy, sheets, and composers. */
  get noun() { return KIND === 'practice' ? 'client' : 'athlete'; },
  get nouns() { return KIND === 'practice' ? 'clients' : 'athletes'; },
  get bookWord() { return KIND === 'practice' ? 'practice' : 'team'; },
  /** What this operator can do with it. Coach caps are all 1, so no shipped coach screen
      needs to consult this; only new operator-shared surfaces do. */
  get caps() { return CAPS[KIND] || CAPS.team; },
  extras: null,
};

/** A team-owned write must never be attempted against a practice book: the id would be a practice
    uuid and the insert would violate the FK against teams — silently, because roles.js swallows
    the error and returns false. Call this before any capability-gated write. */
export function can(cap) { return !!(CD.caps && CD.caps[cap]); }

/** The id of the book currently loaded — a team uuid for a coach, a practice uuid for a trainer.
    Prefer this over reading CD.roster.teams[0].id, which reads as team-only but isn't. */
export function bookId() { return (ROSTER && ROSTER.book && ROSTER.book[0] && ROSTER.book[0].id) || null; }

/** Log an operator action against the CURRENT book — the ONE choke point for it.
    Since 0136 both books own their interventions (dual-owner team_id | practice_id), so this
    now resolves the right owner column instead of no-opping on a practice. It still returns a
    successful no-op when the capability is off, so a caller's real action (the push, the
    navigation) is never blocked by bookkeeping. */
export async function logBookIntervention(args) {
  if (!CD.caps.interventions) return true;
  const id = bookId();
  if (!id) return false;
  return roles.logIntervention({ ...args, teamId: id, book: KIND });
}

async function loadExtras(bookId) {
  const c = CD.caps;
  // Each fetch is capability-gated, and passes the book KIND so it reads the right owner column
  // (0136). The resulting SHAPE is identical either way — `sets` is [] not undefined — which is
  // what lets entriesFor stay untouched: resolveRequirementSet([]) is null, so a book with no
  // configured standard falls through to the built-in CATALOG. Asserted in operator.test.mjs.
  const [setsRaw, groupsRaw, exceptionsRaw, interventionsRaw, access, roomsRaw] = await Promise.all([
    c.standards ? roles.fetchRequirementSets(bookId, KIND) : [],
    c.groups ? roles.fetchCoachGroups(bookId, KIND) : [],
    c.exceptions ? roles.fetchActiveExceptions(bookId, KIND) : [],
    c.interventions ? roles.fetchTodayInterventions(bookId, KIND) : [],
    c.staffRoles ? roles.fetchMyStaffAccess(bookId) : null,
    c.rooms ? roles.fetchTeamRooms(bookId) : [],
  ]);
  /* null on any of these means the read FAILED, which is never the same as "none configured".
     Each keeps its last-known value (the pattern `sets` has used since 2026-08-12), so every
     consumer still receives an ARRAY and nothing downstream has to learn a new shape. That
     matters because these feed scoring-adjacent reads: a fabricated empty `exceptions` marks
     every excused athlete as failing the standard, and a fabricated empty `rooms` falls each
     athlete's label back to their raw position. `failed` is for the surfaces whose empty state
     is a written sentence rather than an absence. */
  const keep = (raw, field) => (raw === null ? ((CD.extras && CD.extras[field]) || []) : raw);
  const sets = keep(setsRaw, 'sets');
  const groups = keep(groupsRaw, 'groups');
  const exceptions = keep(exceptionsRaw, 'exceptions');
  const interventions = keep(interventionsRaw, 'interventions');
  const rooms = keep(roomsRaw, 'rooms');
  // Slice F: one read carries role + scope. `scope` keeps its pre-F shape for every existing
  // consumer; `myRole` is the client-side capability hint (staff-access.js) — the server
  // (0077/0078) is the real wall. `rooms` is T-04 slice 1 (position rooms, read-only here).
  CD.extras = {
    sets, groups, exceptions, interventions, rooms,
    failed: [setsRaw, groupsRaw, exceptionsRaw, interventionsRaw, roomsRaw].some(r => r === null),
    scope: access ? access.scope : null,
    myRole: access ? access.role : null,
  };
}

/* Which slice of the roster the coach is currently looking at (team / one position room /
   a saved group / one athlete) — persisted so it survives a tab switch or reopen. Defaults to
   the signed-in staff member's own position-room scope (0071 team_staff) when they have one,
   else the whole team. */
/* Namespaced PER BOOK. It used to be one key for every role, which meant a device that signed in
   as a coach (persisting {kind:'position', value:'LB'}) and later as a trainer inherited that
   scope — and since practice_roster hardcodes position: null, scopeFilter matched nothing and the
   trainer saw an EMPTY book with no error to explain it. */
const scopeKey = () => `onstd-scope-${KIND}-v1`;
export function getScope() {
  try { const j = JSON.parse(localStorage.getItem(scopeKey()) || 'null'); if (j && j.kind) return j; } catch { /* fresh */ }
  const s = CD.extras && CD.extras.scope;
  // Slice F: a comma-list position scope ('LB, WR' — a coordinator's side) can't seed a
  // single-room filter; default to 'team', which post-0078 is already server-narrowed to
  // exactly their responsibility — nothing over-shows.
  return s && s.kind === 'position' && !String(s.value || '').includes(',')
    ? { kind: 'position', value: s.value } : { kind: 'team', value: null };
}
export function setScope(scope) {
  try { localStorage.setItem(scopeKey(), JSON.stringify(scope)); } catch { /* in-memory only */ }
}

export function scopeFilter(rows, scope) {
  if (!scope || scope.kind === 'team') return rows;
  if (scope.kind === 'position') return rows.filter(r => (r.position || '').toUpperCase() === String(scope.value || '').toUpperCase());
  if (scope.kind === 'group') {
    const g = ((CD.extras && CD.extras.groups) || []).find(x => x.id === scope.value);
    const ids = new Set((g && g.athlete_ids) || []);
    return rows.filter(r => ids.has(r.athleteId));
  }
  if (scope.kind === 'athlete') return rows.filter(r => r.athleteId === scope.value);
  return rows;
}

/** Athlete-local minute-of-day + day-of-week from an IANA timezone (profiles.timezone, 0088), so
 *  coach-facing "overdue"/"due soon" is judged in the ATHLETE's day, not the coach's device clock
 *  (logic-audit P0-1). Null/absent tz or any failure → null and the caller falls back to the coach
 *  clock, so a pre-0088 roster or an athlete who hasn't captured a tz is completely unaffected.
 *  nowMs stays absolute (the coach's real instant); only the wall-clock projection changes. */
export function localClock(tz, nowMs) {
  if (!tz) return null;
  try {
    const p = new Intl.DateTimeFormat('en-US', {
      timeZone: tz, hour12: false, hour: '2-digit', minute: '2-digit', weekday: 'short',
    }).formatToParts(new Date(nowMs));
    const val = (t) => (p.find((x) => x.type === t) || {}).value;
    let h = parseInt(val('hour'), 10); if (h === 24) h = 0; // some engines emit 24 at midnight
    const m = parseInt(val('minute'), 10);
    const dow = { Sun: 0, Mon: 1, Tue: 2, Wed: 3, Thu: 4, Fri: 5, Sat: 6 }[val('weekday')];
    if (!isFinite(h) || !isFinite(m) || dow == null) return null;
    return { nowMin: h * 60 + m, nowDow: dow };
  } catch { return null; }
}

/** Scope-filtered [{ row, status }] for the given scope — the one place coach screens compute
    an athlete's live status. Pure w.r.t. this module's caches: resolves each athlete's governing
    requirement set (athlete > position > team > built-in CATALOG when no set is configured), then
    runs the pure status engine at each athlete's OWN local clock (their timezone; coach clock when
    none), so a coach in another timezone never sees a phantom "overdue". */
export function entriesFor(scope) {
  if (!ROSTER || !CD.extras) return null;   // still loading — screens render skeletons
  const now = new Date(); const nowMs = now.getTime();
  const coachMin = now.getHours() * 60 + now.getMinutes(); const coachDow = now.getDay();
  // Guarded the same way every other CD.extras consumer is: the `!CD.extras` check above only
  // proves the object exists, not that each field loaded. An unguarded .map here threw inside
  // entriesFor, which the inbox, roster, home and insights all render from.
  const excusedIds = new Set(((CD.extras && CD.extras.exceptions) || []).map(e => e.athlete_id));
  return scopeFilter(ROSTER.rows, scope).map((row) => {
    // resolveRequirementSet(sets, athleteId, position) → the governing SET row (or null), not a
    // reqs array — catalogFromItems maps its raw .items into the CATALOG-shaped requirements
    // athleteStatus expects. No configured set for this athlete → the built-in CATALOG governs.
    const set = resolveRequirementSet(CD.extras.sets, row.athleteId, resolvePos(row));
    const reqs = set ? catalogFromItems(set.items) : CATALOG;
    const lc = localClock(row.timezone, nowMs) || { nowMin: coachMin, nowDow: coachDow };
    return {
      row,
      status: athleteStatus({
        nowMin: lc.nowMin, nowMs, nowDow: lc.nowDow, row, reqs,
        excused: excusedIds.has(row.athleteId),
        needsReview: false, // slice D wires flagged-meal review state
      }),
      planStyle: set ? planStyleFromItems(set.items)?.style || null : null,
    };
  });
}

/* Per-athlete profile cache (Task 4): one athlete's day, recent meals + signed photos, trust
   pass, coach interventions/assignments/notes, and their live status (same engine
   entriesFor uses, resolved at THIS call's clock). Guarded like loadCoachRoster: a generation
   counter so a stale/superseded load can never clobber a newer one, and a thrown fetch degrades
   to { athleteId, offline: true } rather than leaving the screen stuck loading forever. */
let PROFILE = null, profileLoadingId = null, profileGen = 0;
export async function loadAthleteProfile(athleteId, force) {
  if (!athleteId) return;
  if (profileLoadingId === athleteId && !force) return;
  if (PROFILE && PROFILE.athleteId === athleteId && !force) return;
  const gen = ++profileGen; profileLoadingId = athleteId;
  try {
    // Load THIS operator's book, not always the coach one — a trainer calling loadCoachRoster
    // here would fetch teams they don't have and leave the profile without its row.
    if (!CD.roster) await loadBook(false, KIND);       // need the row + extras (sets/exceptions)
    const bookId = CD.roster && CD.roster.book[0] && CD.roster.book[0].id;
    const c = CD.caps;
    const since30 = roles.daysAgoISO(30);
    // interventions/notes are team-owned tables until 0136. Passing a PRACTICE id into them would
    // read nothing anyway (RLS), but gating keeps the intent explicit and the shape honest: a
    // trainer's profile simply has no notes/interventions section rather than a permanently empty one.
    const [day, meals, passRaw, interventions, assignments, notes, basics, weights] = await Promise.all([
      roles.fetchDay(athleteId, roles.todayISO()),
      roles.fetchRecentMeals(athleteId, since30),
      roles.fetchActivePass(athleteId),
      c.interventions ? roles.fetchAthleteInterventions(bookId, athleteId, since30, KIND) : [],
      c.assignments ? roles.fetchAthleteAssignments(athleteId, since30) : [],
      c.notes ? roles.fetchCoachNotes(bookId, athleteId, KIND) : [],
      roles.fetchAthleteBasics(athleteId), // base_goal/base_weight/targets → the score breakdown's nutrition config
      roles.fetchAthleteWeights(athleteId, 30), // 0103: empty map for weight-restricted roles — surfaces just go absent
    ]);
    // meals === null means the read FAILED — throwing here lands in the offline catch below,
    // which finally makes the "Can't reach their profile" state reachable instead of rendering
    // "No logs today yet — nothing to review" over an athlete who logged.
    if (meals === null) throw new Error('profile-fetch-failed');
    // Stitch today's weigh-in back onto the day row (current_weight left the direct grant).
    // Restricted roles get nothing here, so the activity "Weighed in" line and the breakdown's
    // weight simply don't exist for them — absence, never a blank or a fake.
    if (day && weights && weights.has(String(day.date))) day.current_weight = weights.get(String(day.date));
    const withPhotos = (meals || []).slice(0, 12).filter(m => m.photo_path);
    const photoUrls = await roles.signedMealPhotoUrls(withPhotos.map(m => m.photo_path));
    const photos = {};
    for (const m of withPhotos) { if (photoUrls[m.photo_path]) photos[m.id] = photoUrls[m.photo_path]; }
    const row = (CD.roster.rows || []).find(r => r.athleteId === athleteId) || null;
    const exceptions = ((CD.extras && CD.extras.exceptions) || []).filter(e => e.athlete_id === athleteId);
    // Mirrors entriesFor's own defensive style (`if (!ROSTER || !CD.extras) return null`):
    // status depends on CD.extras (requirement sets) being loaded — when it isn't, leave
    // status null rather than throwing into the offline catch below.
    let status = null;
    let set = null;
    if (row && CD.extras) {
      const now = new Date(); const nowMs = now.getTime();
      // Mirrors entriesFor's resolveRequirementSet → catalogFromItems shape exactly, including
      // its CATALOG fallback when no requirement set governs this athlete/position, and the same
      // athlete-local clock (their timezone; coach clock when none) so the profile header's status
      // agrees with the roster chip instead of drifting on the coach's device time.
      set = resolveRequirementSet(CD.extras.sets, row.athleteId, resolvePos(row));
      const reqs = set ? catalogFromItems(set.items) : CATALOG;
      const lc = localClock(row.timezone, nowMs)
        || { nowMin: now.getHours() * 60 + now.getMinutes(), nowDow: now.getDay() };
      status = athleteStatus({
        nowMin: lc.nowMin, nowMs, nowDow: lc.nowDow,
        row, reqs,
        excused: exceptions.length > 0, needsReview: false,
      });
    }
    if (gen !== profileGen) return;                    // a newer load superseded us
    // fetchActivePass returns {error} on a real failure, distinct from null ("no pass") — only
    // a row with an id is a real active pass, so an error object can never read as one.
    const pass = passRaw && passRaw.id ? passRaw : null;
    /* A failed SECTION is not a failed screen. meals === null already throws to the offline
       state above (the profile is meaningless without the day), but interventions/assignments/
       notes each own one section, so they degrade individually: the array stays empty and a
       `failedSections` flag lets the screen say it could not load that one instead of printing
       "No notes on this athlete yet" over notes that exist. */
    const failedSections = {
      interventions: interventions === null,
      assignments: assignments === null,
      notes: notes === null,
    };
    PROFILE = { athleteId, day, meals: meals || [], photos, pass,
      interventions: interventions || [], assignments: assignments || [], notes: notes || [],
      failedSections, exceptions, row, status, basics, offline: false,
      planStyle: set ? planStyleFromItems(set.items)?.style || null : null,
    };
    // Receipt moved to the screen's mount(), where a real viewer id (RT.userId/S.coachIdentity)
    // is actually available — this loader has no viewer identity to write, so a call here was
    // a silent no-op (markDayViewed short-circuits without viewerId). See coach.js coachAthlete.mount.
  } catch {
    // Fuller offline shape so screens can't crash indexing into missing collections.
    if (gen === profileGen) PROFILE = {
      athleteId, offline: true, meals: [], photos: {},
      interventions: [], assignments: [], notes: [], exceptions: [],
      failedSections: { interventions: true, assignments: true, notes: true },
    };
  } finally {
    if (gen === profileGen) profileLoadingId = null;
    if (location.hash === `#coach-athlete/${athleteId}`) window.__render();
  }
}
