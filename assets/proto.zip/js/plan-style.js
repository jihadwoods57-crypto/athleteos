/* OnStandard — nutrition PLAN STYLE (pure; no DOM, no state, no Date).
 *
 * A plan style is HOW MUCH STRUCTURE a person is held to, on one spectrum:
 *
 *   Structured  exact calorie/macro/timing targets — completion + adherence led.
 *   Guided      flexible ranges, meal quality, fueling guidance, light body-signal awareness.
 *   Intuitive   no calorie/macro surface for the athlete — hunger, fullness, satisfaction,
 *               energy, digestion, recovery and cravings; scored on AWARENESS, adequate
 *               fueling, hydration and consistency. Never on restriction.
 *
 * It is ORTHOGONAL to the goal-derived scoring profile (athlete/general/gain, scoringProfiles.ts):
 * the GOAL sets the direction (which way the calorie curve leans, what the targets are), the
 * STYLE sets the structure (how tightly that direction is measured, and what the athlete sees).
 * A `gain` athlete can be Guided; a `general` adult can be Structured. Full 3x3 matrix.
 *
 * ---------------------------------------------------------------------------------------------
 * THE INTEGRITY INVARIANT (do not break this — it is enforced by planStyleCaps.test.ts)
 * ---------------------------------------------------------------------------------------------
 * Migration 0193 clamps a written day score to an evidence ceiling built from the MAXIMUM weight
 * each component carries across all profiles (v2: nutrition 78 / recovery 12 / commitment 0 /
 * checkin 12). src/core/scoreIntegrity.ts derives the same bound from PROFILE_WEIGHTS. Neither
 * knows about styles, and neither should have to: NO style may push a component above its cap.
 *
 * Because the four weights must also sum to 1, the caps pin nutrition into [0.76, 0.78]:
 *   min nutrition = 1 - 0.12 - 0 - 0.12 = 0.76      max nutrition = 0.78 (its own cap)
 * The `athlete` and `gain` profiles sit at that 0.76 floor with recovery at its 0.12 cap, so they
 * have NO headroom — every style scores them on the same headline mix. That is fine and by
 * design: the real differentiation between styles lives in what the NUTRITION SUB-SCORE MEASURES
 * (see NUTRITION_PARTS), not in the headline mix. `general` spends its little slack pushing
 * nutrition to its own 0.78 cap instead, since commitment can no longer absorb it (weight 0).
 *
 * MIRROR of src/core/planStyle.ts — planStyleParity.test.ts asserts the two cannot drift.
 */

/* ---------------------------------------------------------------- keys + defaults */

export const STYLE_KEYS = ['structured', 'guided', 'intuitive'];

/** New accounts land here (founder decision: Guided is the default for most people). */
export const DEFAULT_STYLE = 'guided';
/** Accounts with pre-release history are grandfathered here — see resolvePlanStyle({ hasHistory }). */
export const LEGACY_STYLE = 'structured';

/** The onboarding answer -> recommended style. "not sure" is a real answer, not a null. */
export const STRUCTURE_ANSWERS = [
  { id: 'numbers', label: 'I want clear numbers and expectations', style: 'structured' },
  { id: 'flexible', label: 'I want guidance with flexibility', style: 'guided' },
  { id: 'signals', label: 'I want to focus on body signals', style: 'intuitive' },
  { id: 'unsure', label: "I'm not sure yet", style: 'guided' },
];

/** Map an onboarding structure answer to the style it recommends. Unknown -> the default. */
export function styleForStructureAnswer(answer) {
  const hit = STRUCTURE_ANSWERS.find((a) => a.id === answer);
  return hit ? hit.style : DEFAULT_STYLE;
}

/** Coerce anything to a known style key; unknown/absent -> null (callers decide the default). */
export function resolveStyleKey(x) {
  const k = String(x == null ? '' : x).trim().toLowerCase();
  return STYLE_KEYS.includes(k) ? k : null;
}

/* ---------------------------------------------------------------- weights */

/** Per-component ceiling, mirroring the 0193 evidence-ceiling slots. NOTHING may exceed these. */
export const WEIGHT_CAPS = { nutrition: 0.78, recovery: 0.12, commitment: 0, checkin: 0.12 };

/**
 * Headline mix per goal profile — v2. Two pillars the athlete sees, three slots the engine uses:
 *   nutrition — plates logged, protein to target, on time
 *   checkin   — a check-in was submitted TONIGHT (binary, guaranteed)
 *   recovery  — how those answers scored
 * `commitment` is 0: the end-of-day reflection is still captured and still shown to the coach, it
 * just no longer scores, so an honest "no" costs nothing and the coach's data gets truthful.
 */
export const PROFILE_WEIGHTS = {
  athlete: { nutrition: 0.76, recovery: 0.12, commitment: 0, checkin: 0.12 },
  general: { nutrition: 0.78, recovery: 0.10, commitment: 0, checkin: 0.12 },
  gain: { nutrition: 0.76, recovery: 0.12, commitment: 0, checkin: 0.12 },
};

/** The headline mix for a (style, profile). `style` is accepted and ignored — the signature is
 *  kept so no call site changes. An unknown profile falls back to athlete, so a bad value can
 *  never produce a weightless or over-weighted day. */
export function weightsFor(style, profile) {
  const p = profile === 'general' || profile === 'gain' ? profile : 'athlete';
  return PROFILE_WEIGHTS[p];
}

/** True when every component is within its cap AND the mix sums to 1 (within float slop).
 *  Exported so the caps test can sweep every preset and every override permutation. */
export function weightsWithinCaps(w) {
  if (!w) return false;
  const keys = ['nutrition', 'recovery', 'commitment', 'checkin'];
  let sum = 0;
  for (const k of keys) {
    const v = w[k];
    if (typeof v !== 'number' || !isFinite(v) || v < 0) return false;
    if (v > WEIGHT_CAPS[k] + 1e-9) return false;
    sum += v;
  }
  return Math.abs(sum - 1) < 1e-9;
}

/* ---------------------------------------------------------------- signals */

/** The body signals a style can track. `where` decides which surface captures it:
 *  'meal' = the 2-tap prompt after logging a plate; 'checkin' = a check-in field (ciConfig).
 *  `inverse` marks a signal whose HIGH value is the negative pole (like soreness today).
 *
 *  THE MEAL PROMPT IS GONE (2026-07-28). "How did this meal land?" sat between logging a plate and
 *  seeing the result — homework charged before the payoff — and it was cut. The three meal-where
 *  keys are kept here, and their historical answers still hydrate, because days already scored
 *  with them must keep reading back correctly. Nothing captures them going forward: knobsFor()
 *  forces them off. See awarenessScore for what that does to the number. */
export const SIGNAL_KEYS = [
  { key: 'hunger', label: 'Hunger before', where: 'meal', lo: 'Not hungry', hi: 'Very hungry' },
  { key: 'fullness', label: 'Fullness after', where: 'meal', lo: 'Still hungry', hi: 'Very full' },
  { key: 'satisfaction', label: 'Satisfaction', where: 'meal', lo: 'Not satisfied', hi: 'Very satisfied' },
  { key: 'digestion', label: 'Digestion', where: 'checkin', lo: 'Rough', hi: 'Comfortable' },
  { key: 'cravings', label: 'Cravings', where: 'checkin', lo: 'None', hi: 'Constant', inverse: true },
];

export const MEAL_SIGNAL_KEYS = SIGNAL_KEYS.filter((s) => s.where === 'meal').map((s) => s.key);
export const CHECKIN_SIGNAL_KEYS = SIGNAL_KEYS.filter((s) => s.where === 'checkin').map((s) => s.key);

/* ---------------------------------------------------------------- presets */

/**
 * Nutrition sub-score composition per style. Each column sums to 100; the result then rides the
 * headline nutrition weight above.
 *
 *   Structured  protein 40 + calorie adherence 25 + on-time meals 25 + hydration 10
 *   Guided      calorie-in-range 30 + protein-in-range 20 + consistency 25 + quality 15 + hydration 10
 *   Intuitive   fueling adequacy 40 + signal awareness 35 + hydration 25
 *
 * IMPORTANT — Structured's row is the CUSTOMIZATION STARTING POINT, not the default engine path.
 * By default Structured scores on `formula: 'legacy'`: the shipped per-goal-profile formula,
 * byte for byte (athlete protein 65 + meals 35; general cal 45 + protein 25 + meals 30; gain
 * floor 40 + protein 35 + meals 25). That identity is what grandfathers every existing account
 * (decision 8) — scoring hydration on Structured by default would move every one of their scores
 * on release day. A professional who customizes Structured opts INTO this composition, and the
 * row above is where they start from. See knobsFor().
 */
export const NUTRITION_PARTS = {
  structured: { protein: 40, calorie: 25, timing: 25, hydration: 10, quality: 0, awareness: 0 },
  guided: { protein: 20, calorie: 30, timing: 25, hydration: 10, quality: 15, awareness: 0 },
  intuitive: { protein: 0, calorie: 40, timing: 0, hydration: 25, quality: 0, awareness: 35 },
};

/** Which engine path scores the nutrition sub-score:
 *   'legacy' — the shipped per-goal-profile formula, untouched (Structured's default).
 *   'parts'  — the NUTRITION_PARTS composition above (Guided, Intuitive, customized Structured). */
export const FORMULAS = ['legacy', 'parts'];

/** The full knob set a style presets and a nutrition professional may override. */
export const PRESETS = {
  structured: {
    nutrition: {
      formula: 'legacy',                       // the shipped per-profile formula — see NUTRITION_PARTS
      calorie: 'exact', calorieBand: 0.1,
      protein: 'exact', proteinBand: 0.1,
      timingScored: true, hydrationScored: false, qualityScored: false, awarenessScored: false,
    },
    parts: NUTRITION_PARTS.structured,
    signals: { hunger: false, fullness: false, satisfaction: false, digestion: false, cravings: false },
    surface: { showCalories: true, showMacros: true, tone: 'targets' },
  },
  guided: {
    nutrition: {
      formula: 'parts',
      calorie: 'range', calorieBand: 0.12,
      protein: 'range', proteinBand: 0.15,
      timingScored: true, hydrationScored: false, qualityScored: true, awarenessScored: false,
    },
    parts: NUTRITION_PARTS.guided,
    // Meal-time signals are no longer captured anywhere — see SIGNAL_KEYS. Guided never scored
    // them (awarenessScored:false), so this is purely the prompt going away.
    signals: { hunger: false, fullness: false, satisfaction: false, digestion: false, cravings: false },
    surface: { showCalories: true, showMacros: true, tone: 'guidance' },
  },
  intuitive: {
    nutrition: {
      formula: 'parts',
      calorie: 'adequacy', calorieBand: 0,
      protein: 'off', proteinBand: 0,
      timingScored: false, hydrationScored: false, qualityScored: false, awarenessScored: true,
    },
    parts: NUTRITION_PARTS.intuitive,
    // Digestion and cravings still ride the check-in; the three meal-time ones are gone.
    signals: { hunger: false, fullness: false, satisfaction: false, digestion: true, cravings: true },
    surface: { showCalories: false, showMacros: false, tone: 'signals' },
  },
};

const clone = (o) => JSON.parse(JSON.stringify(o));
const num = (v, lo, hi, fallback) => (typeof v === 'number' && isFinite(v) && v >= lo && v <= hi ? v : fallback);

/** Re-normalize a parts object to sum to 100 (a pro override can leave it lopsided). Zero total
 *  is impossible to normalize, so it falls back to the style's own preset. */
function normalizeParts(parts, style) {
  const keys = ['protein', 'calorie', 'timing', 'hydration', 'quality', 'awareness'];
  const safe = {};
  let total = 0;
  for (const k of keys) {
    const v = num(parts && parts[k], 0, 100, 0);
    safe[k] = v; total += v;
  }
  if (total <= 0) return { ...NUTRITION_PARTS[style] };
  if (Math.abs(total - 100) < 1e-9) return safe;
  const out = {};
  for (const k of keys) out[k] = (safe[k] / total) * 100;
  return out;
}

/**
 * The effective knobs for a style, with an optional professional override patch applied.
 * Overrides are shallow-merged per section and every value is range-checked, so a malformed
 * override can widen or narrow the plan but can never produce an invalid engine input.
 * `parts` is re-normalized to 100 after merging.
 */
export function knobsFor(style, overrides) {
  const s = resolveStyleKey(style) || DEFAULT_STYLE;
  const base = clone(PRESETS[s]);
  const o = overrides && typeof overrides === 'object' ? overrides : null;
  if (o) {
    // A pro who customizes HOW nutrition is measured opts out of the legacy passthrough and into
    // the parts composition — otherwise their band/flag edits would be silently ignored by an
    // engine path that doesn't read them. An explicit `formula` always wins over this inference.
    const touchesComposition = !!(o.parts && typeof o.parts === 'object' && Object.keys(o.parts).length)
      || (o.nutrition && typeof o.nutrition === 'object' && [
        'calorie', 'protein', 'calorieBand', 'proteinBand',
        'timingScored', 'hydrationScored', 'qualityScored', 'awarenessScored',
      ].some((k) => o.nutrition[k] !== undefined));
    if (touchesComposition) base.nutrition.formula = 'parts';
    if (o.nutrition && typeof o.nutrition === 'object') {
      const n = o.nutrition;
      if (FORMULAS.includes(n.formula)) base.nutrition.formula = n.formula;
      if (['exact', 'range', 'adequacy', 'off'].includes(n.calorie)) base.nutrition.calorie = n.calorie;
      if (['exact', 'range', 'off'].includes(n.protein)) base.nutrition.protein = n.protein;
      base.nutrition.calorieBand = num(n.calorieBand, 0, 0.5, base.nutrition.calorieBand);
      base.nutrition.proteinBand = num(n.proteinBand, 0, 0.5, base.nutrition.proteinBand);
      for (const k of ['timingScored', 'hydrationScored', 'qualityScored', 'awarenessScored']) {
        if (typeof n[k] === 'boolean') base.nutrition[k] = n[k];
      }
    }
    if (o.parts && typeof o.parts === 'object') base.parts = { ...base.parts, ...o.parts };
    if (o.signals && typeof o.signals === 'object') {
      for (const { key } of SIGNAL_KEYS) if (typeof o.signals[key] === 'boolean') base.signals[key] = o.signals[key];
    }
    if (o.surface && typeof o.surface === 'object') {
      for (const k of ['showCalories', 'showMacros']) {
        if (typeof o.surface[k] === 'boolean') base.surface[k] = o.surface[k];
      }
      if (['targets', 'guidance', 'signals'].includes(o.surface.tone)) base.surface.tone = o.surface.tone;
    }
  }
  // The meal-time prompt no longer exists on any surface, so no style and no professional may ask
  // for those signals — an enabled-but-uncapturable signal would quietly zero an athlete's
  // awareness credit forever. This runs AFTER the override merge precisely so a stored pro config
  // from before the removal cannot resurrect a prompt that isn't there.
  for (const k of MEAL_SIGNAL_KEYS) base.signals[k] = false;
  // Hydration is off the app entirely — there is no way to log water, so scoring it would
  // silently cap every Guided/Intuitive athlete's nutrition score. Runs AFTER the override
  // merge so a stored pro config from before the removal cannot resurrect it.
  base.nutrition.hydrationScored = false;
  base.parts = normalizeParts(base.parts, s);
  // A part can only earn credit when its knob is on — otherwise a pro could weight `quality` on
  // a style that never measures it and silently cap the athlete's nutrition score below 100.
  if (!base.nutrition.timingScored) base.parts.timing = 0;
  if (!base.nutrition.hydrationScored) base.parts.hydration = 0;
  if (!base.nutrition.qualityScored) base.parts.quality = 0;
  if (!base.nutrition.awarenessScored) base.parts.awareness = 0;
  if (base.nutrition.protein === 'off') base.parts.protein = 0;
  if (base.nutrition.calorie === 'off') base.parts.calorie = 0;
  base.parts = normalizeParts(base.parts, s);
  base.style = s;
  base.customized = !!o && Object.keys(o).length > 0;
  return base;
}

/* ---------------------------------------------------------------- resolution + permission */

/** Who may DECIDE the style, by role. Everyone may always state a preference. */
export const STYLE_CONTROL = {
  athlete: 'preference',   // team athlete — the assigned coach/trainer/nutrition pro decides
  client: 'propose',       // trainer client — proposes; the trainer confirms or adjusts
  solo: 'self',            // independent adult — chooses freely
  parent: 'preference',
  coach: 'assign',
  trainer: 'assign',
  nutrition: 'assign',
};

export function styleControlFor(role) {
  return STYLE_CONTROL[role] || 'self';
}

/**
 * The ONE answer to "what style governs this person, who set it, and can they change it".
 * Precedence: team standard -> professional assignment -> self choice -> default.
 *
 *  - `teamStandard`  a requirement_sets item { style, overrides, setBy } — always wins, always locks.
 *  - `proAssignment` athlete_profiles.targets { style, styleOverrides, setBy } — a trainer/nutrition pro.
 *  - `selfChoice`    profiles.plan_style — only honored when the role may choose.
 *  - `preference`    profiles.plan_style_preference — ALWAYS carried through, even when locked.
 *                    This is what the pro's roster surfaces; a locked athlete is never a dead end.
 *  - `hasHistory`    true for an account that scored days before plan styles shipped -> grandfathered
 *                    onto `structured` (today's exact formula) rather than moved to the new default.
 */
export function resolvePlanStyle(input) {
  const i = input || {};
  const preference = resolveStyleKey(i.preference);
  const control = styleControlFor(i.role);

  const team = i.teamStandard && resolveStyleKey(i.teamStandard.style);
  if (team) {
    return {
      style: team, knobs: knobsFor(team, i.teamStandard.overrides),
      source: 'team', locked: true, lockedBy: i.teamStandard.setBy || null,
      canChoose: false, preference,
    };
  }

  const pro = i.proAssignment && resolveStyleKey(i.proAssignment.style);
  if (pro) {
    return {
      style: pro, knobs: knobsFor(pro, i.proAssignment.styleOverrides),
      source: 'pro', locked: control !== 'assign', lockedBy: i.proAssignment.setBy || null,
      canChoose: control === 'assign', preference,
    };
  }

  // A trainer client with no confirmed assignment runs on their own stated preference
  // PROVISIONALLY — they are not blocked waiting on the trainer, and the trainer sees it pending.
  if (control === 'propose' && preference) {
    return {
      style: preference, knobs: knobsFor(preference, null),
      source: 'preference', locked: false, lockedBy: null, canChoose: true, preference,
    };
  }

  const self = resolveStyleKey(i.selfChoice);
  if (self && (control === 'self' || control === 'assign')) {
    return {
      style: self, knobs: knobsFor(self, i.selfOverrides),
      source: 'self', locked: false, lockedBy: null, canChoose: true, preference,
    };
  }

  // Grandfather: an account that already has scored history keeps today's exact scoring.
  if (i.hasHistory) {
    return {
      style: LEGACY_STYLE, knobs: knobsFor(LEGACY_STYLE, null),
      source: 'legacy', locked: false, lockedBy: null, canChoose: control !== 'preference', preference,
    };
  }

  const fallback = (control === 'self' || control === 'propose') && preference ? preference : DEFAULT_STYLE;
  return {
    style: fallback, knobs: knobsFor(fallback, null),
    source: 'default', locked: control === 'preference', lockedBy: null,
    canChoose: control !== 'preference', preference,
  };
}

/* ---------------------------------------------------------------- adherence curves */

/**
 * Range credit (0..1) for a Guided target: FULL anywhere inside +/- band, then linear falloff to 0
 * at 4x the band. Wider and more forgiving than the Structured curve by construction — a range is
 * a range, not a tighter target. band <= 0 collapses to exact-match behavior.
 */
export function rangeAdherence(value, target, band) {
  if (!(target > 0)) return 0;
  const b = typeof band === 'number' && isFinite(band) && band > 0 ? band : 0;
  const dev = Math.abs(value - target) / target;
  if (dev <= b) return 1;
  const outer = b > 0 ? b * 4 : 0.3;
  if (dev >= outer) return 0;
  return (outer - dev) / (outer - b);
}

/**
 * Fueling adequacy (0..1) for Intuitive: full credit at or above 85% of the target, linear to 0
 * at 45%. Deliberately GENEROUS and strictly one-sided — eating more is NEVER penalized on a
 * style whose whole point is that food is not a debt. This is the only calorie-derived number
 * Intuitive scores, and it exists to catch genuine under-fueling, not to police intake.
 */
export function fuelingAdequacy(kcal, target) {
  if (!(target > 0)) return 0;
  const ratio = kcal / target;
  if (ratio >= 0.85) return 1;
  if (ratio <= 0.45) return 0;
  return (ratio - 0.45) / 0.4;
}

/**
 * Signal-awareness credit (0..1): did they NOTICE, not what they noticed.
 *
 * A 1/5 satisfaction scores exactly the same as a 5/5 — the value is never judged, only the act
 * of answering. Blends today (60%) with the trailing-week answer rate (40%) so a single skipped
 * day barely moves the number, which is what keeps an awareness practice from becoming another
 * streak to fail. `weekRate` absent -> today stands in for it (pure tests need no history).
 *
 * `answered` is the set of signal keys with a value today, from ANY surface.
 *
 * WHY THIS NOW RETURNS 1 FOR EVERYONE (2026-07-28). Awareness is 35 of Intuitive's 100 nutrition
 * points, and the meal prompt that earned most of them has been removed. Two ways to respond:
 * redistribute those 35 points across fueling and hydration, or let the credit stand.
 * Redistribution provably LOWERS scores — an athlete at cal 0.5 / hydration 1.0 who answered
 * every signal goes 80 -> 69 — and no athlete's number may drop for a change they didn't make.
 * So the credit stands, which is the same grandfathering rule that keeps Structured on the legacy
 * formula byte for byte.
 *
 * The enabled set is now scoped to meal-where signals, and knobsFor forces all of those off, so
 * this returns 1 by construction. Check-in signals are deliberately NOT counted here: digestion
 * and cravings already earn their credit inside the recovery sub-score (CI_KEYS in day.js), and
 * scoring them twice was always a quiet duplication.
 *
 * The consequence to own: for Intuitive athletes those 35 points are now free. That is the price
 * of the no-drop guarantee, and it is a founder call to revisit — not something to silently
 * "fix" by reweighting, which is exactly the score drop this avoids.
 */
export function awarenessScore(answered, knobs, weekRate) {
  const enabled = SIGNAL_KEYS
    .filter((s) => s.where === 'meal' && knobs && knobs.signals && knobs.signals[s.key])
    .map((s) => s.key);
  if (!enabled.length) return 1; // nothing to be aware of — never punish an empty config
  const set = answered instanceof Set ? answered : new Set(Array.isArray(answered) ? answered : []);
  let hit = 0;
  for (const k of enabled) if (set.has(k)) hit++;
  const today = hit / enabled.length;
  const week = typeof weekRate === 'number' && isFinite(weekRate) && weekRate >= 0 ? Math.min(1, weekRate) : today;
  return Math.max(0, Math.min(1, today * 0.6 + week * 0.4));
}

/** The signal keys with a real answer on this day, across both capture surfaces.
 *  `day.signals` is { slotKey: { hunger: n, fullness: n, satisfaction: n } } (meal prompt);
 *  check-in signals ride `day.ci` and only count when a check-in actually backs them. */
export function answeredSignals(day, checkinBacked) {
  const out = new Set();
  const bySlot = (day && day.signals) || {};
  for (const slot of Object.keys(bySlot)) {
    const v = bySlot[slot] || {};
    for (const k of MEAL_SIGNAL_KEYS) if (typeof v[k] === 'number' && isFinite(v[k])) out.add(k);
  }
  if (checkinBacked) {
    const ci = (day && day.ci) || {};
    for (const k of CHECKIN_SIGNAL_KEYS) if (typeof ci[k] === 'number' && isFinite(ci[k])) out.add(k);
  }
  return out;
}

/* ---------------------------------------------------------------- disclosure copy */

/** Plain-English disclosure — the athlete should never wonder what their number measures. */
export function styleLabel(style) {
  switch (resolveStyleKey(style) || DEFAULT_STYLE) {
    case 'structured':
      return {
        name: 'Structured',
        short: 'Clear numbers and expectations',
        how: 'Exact calorie, protein and meal-timing targets. Your score leans on completing them.',
      };
    case 'intuitive':
      return {
        name: 'Intuitive',
        short: 'Focused on body signals',
        // Copy follows the surfaces that actually exist: the meal-time hunger/fullness prompt is
        // gone, so promising it would be a lie. Digestion and cravings live in the check-in.
        how: 'No calorie or macro targets. Your score measures fueling enough and consistency, with digestion and cravings noticed in your check-in, never restriction.',
      };
    case 'guided':
    default:
      return {
        name: 'Guided',
        short: 'Guidance with flexibility',
        how: 'Flexible ranges instead of exact numbers, plus meal quality. Your score balances consistency, quality and flexibility.',
      };
  }
}

/** How a style's source reads on the athlete's own screen. */
export function styleSourceLabel(res, proNoun) {
  const who = proNoun || 'coach';
  if (!res) return '';
  if (res.source === 'team' || res.source === 'pro') return res.lockedBy ? `Set by ${res.lockedBy}` : `Set by your ${who}`;
  if (res.source === 'preference') return 'Your preference, pending confirmation';
  if (res.source === 'legacy') return 'Your original plan style';
  if (res.source === 'self') return 'You chose this';
  return 'Recommended for you';
}
