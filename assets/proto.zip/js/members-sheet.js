import{participantMeta,initialsFor}from"./chat-view.js";import{esc}from"./components.js";import{icon}from"./icons.js";import{hydrateAvatars}from"./avatar.js";import{overlayOpen}from"./overlay-guard.js";let overlay=null;let opener=null;function close(){if(!overlay)return;const o=overlay;overlay=null;o.classList.remove("on");setTimeout(()=>{try{o.remove()}catch{}},180);try{document.removeEventListener("keydown",onKey)}catch{}const back=opener;opener=null;if(back&&typeof back.focus==="function"){try{back.focus()}catch{}}}function onKey(e){if(e.key==="Escape"){close();return}if(e.key==="Tab"&&overlay){const f=overlay.querySelectorAll('button, [href], [tabindex]:not([tabindex="-1"])');if(!f.length)return;const first=f[0],last=f[f.length-1];if(!overlay.contains(document.activeElement)){e.preventDefault();first.focus()}else if(e.shiftKey&&document.activeElement===first){e.preventDefault();last.focus()}else if(!e.shiftKey&&document.activeElement===last){e.preventDefault();first.focus()}}}export function openMembersSheet(members){const list=Array.isArray(members)?members.filter(Boolean):[];if(!list.length||overlay||overlayOpen(".memsheet"))return;opener=document.activeElement&&document.activeElement!==document.body?document.activeElement:null;const rows=list.map(p=>{const meta=participantMeta(p.kind);const sub=p.self?"This is your log":meta.access;return`
      <div class="ms-row">
        <span class="ms-av ${esc(p.kind==="ai"?"ai":p.self?"self":"other")}"${p.kind!=="ai"&&p.id?` data-avatar-uid="${esc(p.id)}"`:""}>${p.kind==="ai"?icon(meta.ic,16):`<span data-avatar-fallback>${esc(initialsFor(p.name))}</span>`}</span>
        <span class="ms-txt">
          <span class="ms-name">${esc(p.name)}</span>
          <span class="ms-kind">${icon(meta.ic,12,'style="vertical-align:-2px;margin-right:1px"')} ${esc(p.self?"Athlete":meta.noun)} \xB7 ${esc(sub)}</span>
        </span>
      </div>`}).join("");const el=document.createElement("div");el.className="memsheet";el.innerHTML=`
    <div class="ms-card" role="dialog" aria-modal="true" aria-label="Who can see this conversation">
      <div class="ms-head">
        <div class="ms-title">In this conversation</div>
        <button class="ms-x" aria-label="Close">\xD7</button>
      </div>
      <div class="ms-list">${rows}</div>
      <div class="ms-foot">Anyone connected to your plan (coaches, trainers, parents, dietitians) appears here. Nobody else can read this.</div>
    </div>`;document.body.appendChild(el);overlay=el;hydrateAvatars(el);requestAnimationFrame(()=>el.classList.add("on"));document.addEventListener("keydown",onKey);el.querySelector(".ms-x").addEventListener("click",close);el.addEventListener("click",ev=>{if(ev.target===el)close()});try{el.querySelector(".ms-x").focus()}catch{}}
