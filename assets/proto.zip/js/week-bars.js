import{esc}from"./components.js";import{scoreBand,tierFor}from"./score-band.js";import{dateKey}from"./fmt-date.js";import{icon}from"./icons.js";export function calendarWeek(rows,todayKey,n=7){const byDay=new Map((rows||[]).map(r=>[String(r.day||r.date||"").slice(0,10),r.score]));const[y,m,d]=String(todayKey).split("-").map(Number);const out=[];for(let back=n-1;back>=0;back--){const dt=new Date(y,m-1,d-back);const key=dateKey(dt);const s=byDay.get(key);out.push({key,label:"SMTWTFS"[dt.getDay()],score:s==null?null:Number(s)})}return out}export function daysBetween(dayKey,todayKey){const k=s=>{const[y,m,d]=String(s||"").slice(0,10).split("-").map(Number);return Date.UTC(y,m-1,d)};const a=k(dayKey),b=k(todayKey);return Number.isFinite(a)&&Number.isFinite(b)?Math.round((b-a)/864e5):null}const bar=v=>`<div class="bar" style="height:${Math.max(0,Math.min(100,v))}%"></div>`;export function weekBars({scores=[],labels=[],cutIdx=-1,cutLabel="",gaps=false}={}){const spoken=scores.map((v,i)=>`${labels[i]||""} ${gaps&&v==null?"no log":v}`).join(", ");return`<div class="weekbars" role="img" aria-label="Last ${scores.length} days: ${spoken}. The standard is 80.${cutIdx!==-1?` ${esc(cutLabel)}.`:""}">
        ${scores.map((v,i)=>`
          ${i===cutIdx?`<div class="wb-cutover" aria-hidden="true" title="${esc(cutLabel)}"></div>`:""}
          <div class="wb b-${gaps&&v==null?"none":scoreBand(v)||"off"}${v==null?"":` t-${tierFor(v).cls}`}">
            <div class="track">${gaps&&v==null?"":bar(v)}</div>
            <span class="d">${labels[i]||""}</span>
          </div>`).join("")}
      </div>`}export function dayBars(days=[],{cutIdx=-1,cutLabel=""}={}){const spoken=days.map(d=>{const name=d.state==="today"?"today":new Date(`${d.key}T12:00:00`).toLocaleDateString("en-US",{weekday:"short"});if(d.state==="missed")return`${name} no log`;if(d.state==="before")return`${name} before you started`;if(d.score==null)return`${name} not scored yet`;return`${name} ${d.score}${d.state==="today"?" so far":""}`}).join(", ");return`<div class="weekbars pg-days" role="img" aria-label="Last ${days.length} days: ${esc(spoken)}. The standard is 80.${cutIdx!==-1?` ${esc(cutLabel)}.`:""}">
        ${days.map((d,i)=>{const cls=d.score!=null?tierFor(d.score).cls:"";const ink=cls&&cls!=="r"?` tier-ink ${cls}`:"";const top=d.state==="missed"?icon("x",12):d.score!=null?d.score:"";return`
          ${i===cutIdx?`<div class="wb-cutover" aria-hidden="true" title="${esc(cutLabel)}"></div>`:""}
          <div class="wb wb-${d.state}${cls?` t-${cls}`:""}" aria-hidden="true">
            <span class="wb-n${ink}">${top}</span>
            <div class="track">${d.score!=null?bar(d.score):""}</div>
            <span class="d">${d.state==="today"?"Today":esc(d.label||"")}</span>
          </div>`}).join("")}
      </div>`}
