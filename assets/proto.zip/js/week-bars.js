import{esc}from"./components.js";import{scoreBand,tierFor}from"./score-band.js";import{dateKey}from"./fmt-date.js";export function calendarWeek(rows,todayKey,n=7){const byDay=new Map((rows||[]).map(r=>[String(r.day||r.date||"").slice(0,10),r.score]));const[y,m,d]=String(todayKey).split("-").map(Number);const out=[];for(let back=n-1;back>=0;back--){const dt=new Date(y,m-1,d-back);const key=dateKey(dt);const s=byDay.get(key);out.push({key,label:"SMTWTFS"[dt.getDay()],score:s==null?null:Number(s)})}return out}export function daysBetween(dayKey,todayKey){const k=s=>{const[y,m,d]=String(s||"").slice(0,10).split("-").map(Number);return Date.UTC(y,m-1,d)};const a=k(dayKey),b=k(todayKey);return Number.isFinite(a)&&Number.isFinite(b)?Math.round((b-a)/864e5):null}export function weekBars({scores=[],labels=[],cutIdx=-1,cutLabel="",gaps=false}={}){const spoken=scores.map((v,i)=>`${labels[i]||""} ${gaps&&v==null?"no log":v}`).join(", ");return`<div class="weekbars" role="img" aria-label="Last ${scores.length} days: ${spoken}. The standard is 80.${cutIdx!==-1?` ${esc(cutLabel)}.`:""}">
        ${scores.map((v,i)=>`
          ${i===cutIdx?`<div class="wb-cutover" aria-hidden="true" title="${esc(cutLabel)}"></div>`:""}
          <div class="wb b-${gaps&&v==null?"none":scoreBand(v)||"off"}${v==null?"":` t-${tierFor(v).cls}`}">
            <div class="track">${gaps&&v==null?"":`<div class="bar" style="height:${Math.max(0,Math.min(100,v))}%"></div>`}</div>
            <span class="d">${labels[i]||""}</span>
          </div>`).join("")}
      </div>`}
