import{S,RT,act,roleProfileRoute}from"./state.js";import{icon}from"./icons.js";import{scoreColor}from"./score-band.js";export function esc(v){return String(v==null?"":v).replace(/&/g,"&amp;").replace(/</g,"&lt;").replace(/>/g,"&gt;").replace(/"/g,"&quot;").replace(/'/g,"&#39;")}export async function copyText(text){const t=String(text==null?"":text);if(!t)return false;try{if(navigator.clipboard&&navigator.clipboard.writeText){await navigator.clipboard.writeText(t);return true}}catch{}try{const ta=document.createElement("textarea");ta.value=t;ta.setAttribute("readonly","");ta.style.cssText="position:fixed;left:-9999px;top:0;opacity:0";document.body.appendChild(ta);ta.focus();ta.select();ta.setSelectionRange(0,t.length);const ok=document.execCommand("copy");ta.remove();return!!ok}catch{return false}}export function safeImg(v){const s=String(v==null?"":v);const ok=/^data:image\/(?:png|jpe?g|gif|webp);base64,[A-Za-z0-9+/=]+$/.test(s)||/^assets\/[\w./-]+$/.test(s)||/^https:\/\/[\w-]+\.supabase\.(?:co|in)\/storage\/v1\/[\w/.\-?=&%~]+$/.test(s);return ok?s:""}export function skeletonRows(n=3,label="Loading"){const row='<div class="sk-row"><div class="sk-dot"></div><div class="sk-lines"><div class="sk-line"></div><div class="sk-line sk-line-2"></div></div></div>';const sr=/^(loading|building|fetching|checking)\b/i.test(label)?label:`Loading ${label}`;return`<section class="card sk-card" role="status" aria-busy="true" aria-label="${esc(label)}" style="padding:6px 16px"><span class="sr-only">${esc(sr)}</span>${row.repeat(Math.max(1,n|0))}</section>`}export function emptyState({icon:ic="sparkle",title,body="",action=null,compact=false}={}){const a=action?`<div class="sd-cta"><button class="btn ghost sm" ${action.go?`data-go="${esc(action.go)}"`:""}${action.id?` id="${esc(action.id)}"`:""} style="width:auto;padding:0 18px">${esc(action.label)}</button></div>`:"";return`<section class="state-demo${compact?" compact":""}"><div class="sd-ic">${icon(ic,compact?18:24)}</div>
    <div class="sd-t">${esc(title)}</div>${body?`<div class="sd-s">${esc(body)}</div>`:""}${a}</section>`}export function sayStatus(el,msg,{error=false}={}){if(!el)return;el.textContent=msg==null?"":String(msg);el.setAttribute("role",error?"alert":"status");el.setAttribute("aria-live","polite");el.classList.toggle("is-error",!!error)}export function errorState({title="Couldn't load this",body="Reconnect and it loads right here. Nothing was lost.",retryId=null}={}){const a=retryId?`<div class="sd-cta"><button class="btn ghost sm" id="${esc(retryId)}" style="width:auto;padding:0 18px">${icon("wifiOff",15)} Try again</button></div>`:"";return`<section class="state-demo err-box" role="alert"><div class="sd-ic">${icon("wifiOff",24)}</div>
    <div class="sd-t">${esc(title)}</div><div class="sd-s">${esc(body)}</div>${a}</section>`}export function statusMsg({id=null,text="",style=""}={}){return`<span${id?` id="${esc(id)}"`:""} class="ls" role="status" aria-live="polite" style="${style}">${esc(text)}</span>`}export function alertMsg({id=null,text="",style=""}={}){return`<p${id?` id="${esc(id)}"`:""} class="ls" role="alert" style="${style}">${esc(text)}</p>`}export function segBar(done,total,label,extraStyle=""){const n=Math.max(0,total|0);const d=Math.max(0,Math.min(n,done|0));const cells=Array.from({length:n},(_,i)=>`<i class="${i<d?"on":""}"></i>`).join("");return`<div class="xsegs" role="img" aria-label="${esc(label)}"${extraStyle?` style="${extraStyle}"`:""}>${cells}</div>`}export function permissionState({title="Not your access",body="Your head coach can open this for you.",action=null}={}){const a=action?`<div class="sd-cta"><button class="btn ghost sm" ${action.go?`data-go="${esc(action.go)}"`:""}${action.id?` id="${esc(action.id)}"`:""} style="width:auto;padding:0 18px">${esc(action.label)}</button></div>`:"";return`<section class="state-demo"><div class="sd-ic">${icon("shield",24)}</div>
    <div class="sd-t">${esc(title)}</div><div class="sd-s">${esc(body)}</div>${a}</section>`}export function nonLiveBadge(){return`<span class="status-pill muted">${icon("image",12)} Gallery upload</span>`}export const DIAL_A0=120;export const DIAL_SWEEP=300;export function dialPoint(cx,cy,rad,deg){const a=deg*Math.PI/180;return`${(cx+Math.cos(a)*rad).toFixed(2)} ${(cy+Math.sin(a)*rad).toFixed(2)}`}export function dialPath(cx,cy,rad){return`M ${dialPoint(cx,cy,rad,DIAL_A0)} A ${rad.toFixed(2)} ${rad.toFixed(2)} 0 1 1 ${dialPoint(cx,cy,rad,DIAL_A0+DIAL_SWEEP-360)}`}export function scoreRing({score,size=338,stroke=20,showCenter=true,uid="r",delta=null,streak=null,tierName=null,tierCls="b",centerNum=false,possible=null,vt=null,notStarted=false}={}){if(!Number.isFinite(score)){console.warn("[components] scoreRing called without a numeric score:",score);score=0}const r=(size-stroke)/2-14;const rEcho=Math.max(0,r-stroke/2-8);const cx=size/2,cy=size/2;const dial=rad=>dialPath(cx,cy,rad);const off=(100-score).toFixed(1);const unstarted=score<6;const started=score>0;const arcLen=2*Math.PI*r*(DIAL_SWEEP/360);const beadGap=(arcLen/Math.max(10,Math.round(arcLen/(stroke*1.8)))).toFixed(2);const ceil=!unstarted&&possible!=null&&possible>score?{span:(possible-score).toFixed(1),rot:(score/100*DIAL_SWEEP).toFixed(2)}:null;const specW=Math.max(1.6,stroke*.375);const light=typeof document!=="undefined"&&document.documentElement.getAttribute("data-theme")==="light";const tipDeg=DIAL_A0+score/100*DIAL_SWEEP;const tipA=tipDeg*Math.PI/180;const tipX=cx+Math.cos(tipA)*r,tipY=cy+Math.sin(tipA)*r;const bezelR=Math.max(5,stroke*.875),coreR=Math.max(2.6,stroke*.5);const marker=score>=6?`
      <g class="ring-tip" opacity="1">
        ${""}
        ${light?`<circle cx="${tipX.toFixed(1)}" cy="${tipY.toFixed(1)}" r="${bezelR.toFixed(1)}" fill="#FFFFFF" stroke="#DBEAFE" stroke-width="1.5"/>
             <circle cx="${tipX.toFixed(1)}" cy="${tipY.toFixed(1)}" r="${coreR.toFixed(1)}" fill="#2563EB"/>`:`<circle cx="${tipX.toFixed(1)}" cy="${tipY.toFixed(1)}" r="${bezelR.toFixed(1)}" fill="#0F172A"/>
             <circle cx="${tipX.toFixed(1)}" cy="${tipY.toFixed(1)}" r="${coreR.toFixed(1)}" fill="url(#en${uid})"/>
             <circle cx="${(tipX-.3*coreR).toFixed(1)}" cy="${(tipY-.3*coreR).toFixed(1)}" r="${(coreR*.233).toFixed(2)}" fill="#FFFFFF" opacity="0.9"/>`}
      </g>`:"";const label=`Score ${Math.round(score)} out of 100${tierName?", "+tierName:""}`;return`
  <div class="ring-wrap" role="img" aria-label="${esc(label)}"${vt?` data-vt="${vt}"`:""} style="--ring-size:${size}px;aspect-ratio:1/1">
    <svg class="ring-svg" width="100%" height="100%" viewBox="0 0 ${size} ${size}" aria-hidden="true">
      <defs>
        ${""}
        <linearGradient id="g${uid}" gradientUnits="userSpaceOnUse"
          x1="${(cx-.71*r).toFixed(1)}" y1="${(cy+.88*r).toFixed(1)}" x2="${(cx+.24*r).toFixed(1)}" y2="${(cy-r).toFixed(1)}">
          <stop offset="0%" stop-color="var(--ring-a)"/>
          <stop offset="50%" stop-color="var(--ring-b)"/>
          <stop offset="100%" stop-color="var(--ring-c)"/>
        </linearGradient>
        ${""}
        ${""}
        ${""}
        <radialGradient id="en${uid}" cx="0.38" cy="0.32" r="1">
          <stop offset="0%" stop-color="#FFFFFF"/>
          <stop offset="70%" stop-color="#F2F7FF"/>
          <stop offset="100%" stop-color="#D8E4F5"/>
        </radialGradient>
      </defs>
      <!-- track: the mark's own glass track value (--ring-track, per theme); discrete beads
           below score 6 so an empty day reads as unstarted, not broken (no pathLength here: the
           bead spacing needs user units, and the spacing divides the arc exactly so a bead seats
           at both ends of the gauge) -->
      ${unstarted?`<path d="${dial(r)}" fill="none" stroke="var(--ring-track)" stroke-width="${(stroke*.55).toFixed(1)}" stroke-linecap="round" stroke-dasharray="0.001 ${beadGap}"/>`:`<path d="${dial(r)}" fill="none" stroke="var(--ring-track)" stroke-width="${stroke}" stroke-linecap="round"/>`}
      ${""}
      ${!light&&score>=6?`<path d="${dial(r)}" fill="none" stroke="rgba(255,255,255,0.06)"
        stroke-width="${(stroke*.58).toFixed(1)}" stroke-linecap="round"/>`:""}
      <!-- ceiling: sits between the track and the main band so the band's round cap paints over
           the seam. butt cap, not round: a round cap would bulge past the marker and read as
           a second competing band. animateRing() drives it like any other .ring-arc. -->
      ${ceil?`<path class="ring-arc ring-ceil" d="${dial(r)}" fill="none" stroke="url(#g${uid})"
        stroke-width="${stroke}" stroke-linecap="butt"
        pathLength="100" stroke-dasharray="${ceil.span} ${100-ceil.span}"
        stroke-dashoffset="0" data-off="0"
        transform="rotate(${ceil.rot} ${cx} ${cy})"/>`:""}
      <!-- main band (score > 0 only: at 0 its round cap painted a phantom dot at the 100% mark) -->
      ${started?`<path class="ring-arc" d="${dial(r)}" fill="none" stroke="url(#g${uid})"
        stroke-width="${stroke}" stroke-linecap="round"
        pathLength="100" stroke-dasharray="100" stroke-dashoffset="${off}" data-off="${off}"/>`:""}
      <!-- sheen: dial-lit's centered band gloss (see specW above); rides the band's own radius -->
      ${!light&&started?`<path class="ring-arc ring-spec" d="${dial(r)}" fill="none" stroke="#FFFFFF"
        stroke-width="${specW.toFixed(1)}" stroke-linecap="round" opacity="0.16"
        pathLength="100" stroke-dasharray="100" stroke-dashoffset="${off}" data-off="${off}"/>`:""}
      <!-- inner echo ring: the app-only flourish the founder kept (see rEcho above) -->
      ${rEcho>0&&started?`<path class="ring-arc ring-echo" d="${dial(rEcho)}" fill="none" stroke="url(#g${uid})"
        stroke-width="1.5" opacity="0.35"
        pathLength="100" stroke-dasharray="100" stroke-dashoffset="${off}" data-off="${off}"/>`:""}
      ${marker}
    </svg>
    ${showCenter?`<div class="ring-center">
      ${notStarted?`<span class="score" aria-hidden="true">&#8211;</span>`:`<span class="score${score>=100?" d3":""}" data-count="${score}">${score}</span>
      <span class="outof">/100</span>`}
      ${tierName?`<span class="tier-chip ${tierCls}">${tierName}</span>`:""}
    </div>`:""}
    ${centerNum?notStarted?`<div class="ring-center num"><span class="score" aria-hidden="true">&#8211;</span></div>`:`<div class="ring-center num"><span class="score${score>=100?" d3":""}" data-count="${score}">${score}</span></div>`:""}
  </div>`}export function animateRing(root){const reduceMotion=typeof matchMedia==="function"&&matchMedia("(prefers-reduced-motion: reduce)").matches;if(reduceMotion){root.querySelectorAll(".ring-arc").forEach(arc=>{arc.style.strokeDashoffset=arc.dataset.off});const tip2=root.querySelector(".ring-tip");if(tip2)tip2.style.opacity="1";const num2=root.querySelector("[data-count]");if(num2)num2.textContent=String(Math.round(+num2.dataset.count));return}root.querySelectorAll(".ring-arc").forEach(arc=>{arc.style.transition="stroke-dashoffset var(--dur-ring) var(--ease-out)";requestAnimationFrame(()=>requestAnimationFrame(()=>{arc.style.strokeDashoffset=arc.dataset.off}))});const tip=root.querySelector(".ring-tip");if(tip){tip.style.transition="opacity 600ms var(--ease-out)";setTimeout(()=>{tip.style.opacity="1"},1150)}setTimeout(()=>{root.querySelectorAll(".ring-wrap").forEach(w=>{if(w.isConnected)w.classList.add("flare")})},1250);const num=root.querySelector("[data-count]");if(num){const target=+num.dataset.count;const dur=1200;const t0=performance.now();const step=t=>{const p=Math.min(1,(t-t0)/dur);const e=1-Math.pow(1-p,3);num.textContent=Math.round(target*e);if(p<1)requestAnimationFrame(step)};requestAnimationFrame(step)}}export function animateFills(root){const reduceMotion=typeof matchMedia==="function"&&matchMedia("(prefers-reduced-motion: reduce)").matches;root.querySelectorAll("[data-fill]").forEach(el=>{const to=`${el.dataset.fill}%`;const wound=el.style.height==="0%";el.style.height=to;if(reduceMotion||!wound){el.style.transition="none";el.style.transform="";return}el.style.transformOrigin="bottom";el.style.transition="none";el.style.transform="scaleY(0)";if(typeof requestAnimationFrame==="function"){requestAnimationFrame(()=>requestAnimationFrame(()=>{el.style.transition="transform var(--dur-ring) var(--ease-out)";el.style.transform="scaleY(1)"}))}else{el.style.transform=""}});if(!reduceMotion)setTimeout(()=>{root.querySelectorAll(".cscol.done").forEach(c=>{if(c.isConnected)c.classList.add("flare")})},900);root.querySelectorAll("[data-cs-count]").forEach(el=>{const target=Number(el.dataset.csCount);const dec=Number(el.dataset.csDec)||0;if(!Number.isFinite(target))return;const paint=v=>{const[whole,frac]=v.toFixed(dec).split(".");el.textContent=whole.replace(/\B(?=(\d{3})+(?!\d))/g,",")+(frac?`.${frac}`:"")};if(reduceMotion){paint(target);return}const dur=1200,t0=performance.now();const step=t=>{const p=Math.min(1,(t-t0)/dur);paint(target*(1-Math.pow(1-p,3)));if(p<1)requestAnimationFrame(step)};if(typeof requestAnimationFrame==="function")requestAnimationFrame(step);else paint(target)})}export function logoMark(size=96,uid="lm"){const light=document.documentElement.getAttribute("data-theme")==="light";const track=light?"#DCE7FB":"rgba(255,255,255,0.16)";const tip=light?"#3B82F6":"#60A5FA";const bezel=light?'<circle cx="50" cy="18" r="10.5" fill="#FFFFFF" stroke="#DBEAFE" stroke-width="1.5"/>':'<circle cx="50" cy="18" r="10.5" fill="#0F172A"/>';const core=light?"#2563EB":"#FFFFFF";return`<svg width="${size}" height="${size}" viewBox="0 0 100 100" fill="none">
    <defs>
      <linearGradient id="dial${uid}" x1="26" y1="82" x2="58" y2="18" gradientUnits="userSpaceOnUse">
        <stop offset="0%" stop-color="#34D399"/>
        <stop offset="50%" stop-color="#22D3EE"/>
        <stop offset="100%" stop-color="${tip}"/>
      </linearGradient>
    </defs>
    <path d="M33 81.4 A34 34 0 1 1 67 81.4" stroke="${track}" stroke-width="12" stroke-linecap="round"/>
    <path d="M33 81.4 A34 34 0 0 1 50 18" stroke="url(#dial${uid})" stroke-width="12" stroke-linecap="round"/>
    ${bezel}
    <circle cx="50" cy="18" r="6" fill="${core}"/>
  </svg>`}let lastBellN=null;function bellBtn(n,extraStyle=""){const arrived=lastBellN!==null&&n>lastBellN;lastBellN=n;return`<div class="iconbtn${arrived?" bell-arrived":""}" data-go="notifications" role="button" aria-label="${n?`Notifications, ${n} unread`:"Notifications"}"${extraStyle?` style="${extraStyle}"`:""}>${icon("bell",20)}${n?`<span class="dot">${n>9?"9+":n}</span>`:""}</div>`}export function appHead(sub,extra){const n=S.unreadNotifs;return`<header class="apphead">
    <div class="apphead-id">
      <div class="greeting">${S.greeting},</div>
      <h1 class="name">${esc(S.athlete.first)}</h1>
      ${sub?`<div class="apphead-sub">${esc(sub)}</div>`:""}
    </div>
    <div class="actions">
      ${extra||""}
      ${bellBtn(n)}
      ${S.athlete.avatar&&safeImg(S.athlete.avatar)?`<div class="avatar" data-go="profile" aria-label="Your profile" style="background-image:url('${safeImg(S.athlete.avatar)}');background-size:cover;background-position:center"></div>`:`<div class="avatar" data-go="profile" aria-label="Your profile" data-avatar-uid="${esc(RT.userId||"")}" data-avatar-ver="${esc(RT.avatarVer||"")}"><span data-avatar-fallback>${esc(S.athlete.initials)}</span></div>`}
    </div>
  </header>`}export function backHead(title,sub,to="home",action=null){return`<div class="back-head">
    <div class="bk" data-back="${to}" role="button" aria-label="Back">${icon("back",20)}</div>
    <div class="bh-t"><h1 class="ht">${esc(title)}</h1>${sub?`<div class="hs">${esc(sub)}</div>`:""}</div>
    ${action?`<button type="button" class="bh-act" id="${esc(action.id)}" aria-label="${esc(action.label||"More")}" aria-expanded="false" aria-haspopup="true">${icon(action.icon||"more",20)}</button>`:""}
  </div>`}export function titleHead(title,sub){return`<div class="back-head">
    <div><h1 class="ht">${esc(title)}</h1>${sub?`<div class="hs">${esc(sub)}</div>`:""}</div>
  </div>`}export function avatarHead(title,sub,initials,greeting){const n=S.unreadNotifs;return`<div class="back-head" style="align-items:center">
    <div style="flex:1;min-width:0">${greeting?`<div class="hg">${esc(greeting)},</div>`:""}<h1 class="ht">${esc(title)}</h1>${sub?`<div class="hs">${esc(sub)}</div>`:""}</div>
    ${bellBtn(n,"margin-right:10px")}
    <div class="hd-avatar" role="button" tabindex="0" aria-label="Your profile and settings" data-go="${roleProfileRoute()}"
      data-avatar-uid="${esc(RT.userId||"")}" data-avatar-ver="${esc(RT.avatarVer||"")}"
      style="position:relative;width:40px;height:40px;border-radius:50%;background:var(--blue-surface);color:var(--blue-bright);border:1.5px solid var(--blue-border);display:grid;place-items:center;font-size:var(--t-sm);font-weight:800;letter-spacing:0.02em;flex:none;cursor:pointer"><span data-avatar-fallback>${esc(initials||"C")}</span>
      <span aria-hidden="true" style="position:absolute;right:-2px;bottom:-2px;width:16px;height:16px;border-radius:50%;background:var(--surface-3);border:1.5px solid var(--bg);display:grid;place-items:center;color:var(--text-2)">${icon("chevron",10)}</span>
    </div>
  </div>`}export function sparkline(hist){const pts=(hist||[]).filter(h2=>h2.score!=null).slice(-7);const w=34,h=16;const y=s=>h-s/100*h;const ref=`<line x1="0" y1="${y(80).toFixed(1)}" x2="${w}" y2="${y(80).toFixed(1)}" stroke="var(--hairline)" stroke-width="1" stroke-dasharray="2 3"/>`;let mark;if(pts.length===0){mark=`<line x1="0" y1="${(h-.75).toFixed(2)}" x2="${w}" y2="${(h-.75).toFixed(2)}" stroke="var(--text-3)" stroke-width="1.5" stroke-dasharray="2 3" opacity="0.55"/>`}else if(pts.length===1){mark=`<circle cx="${w/2}" cy="${y(pts[0].score).toFixed(1)}" r="2" fill="${scoreColor(pts[0].score)}"/>`}else{const xy=pts.map((p,i)=>`${(i/(pts.length-1)*w).toFixed(1)},${y(p.score).toFixed(1)}`).join(" ");mark=`<polyline points="${xy}" fill="none" stroke="${scoreColor(pts[pts.length-1].score)}" stroke-width="1.5" stroke-linejoin="round" stroke-linecap="round" opacity="0.9"/>`}return`<svg width="${w}" height="${h}" viewBox="0 0 ${w} ${h}" aria-hidden="true">${ref}${mark}</svg>`}export function composer({inputId="",sendId="",placeholder="",inputLabel=placeholder,sendLabel="Send",sendIcon="arrowUp",sendIconSize=17,sendStyle="",wrapStyle="",autocompleteOff=true,decorativeSend=false,attachId="",attachLabel="Attach a photo",aiId="",aiLabel="Ask the AI Nutritionist",atEnd=false}={}){const sendAttrs=`class="send"${sendId?` id="${sendId}"`:""}${sendStyle?` style="${sendStyle}"`:""}`;const sendEl=decorativeSend?`<span ${sendAttrs} aria-hidden="true">${icon(sendIcon,sendIconSize)}</span>`:`<button type="button" ${sendAttrs} aria-label="${esc(sendLabel)}">${icon(sendIcon,sendIconSize)}</button>`;const attachEl=attachId?`<button type="button" class="attach" id="${attachId}" aria-label="${esc(attachLabel)}">${icon("camera",18)}</button>
    <input type="file" accept="image/*" id="${attachId}-file" hidden aria-hidden="true" tabindex="-1" />`:"";const aiEl=aiId?`<button type="button" class="ai-ask" id="${aiId}" aria-label="${esc(aiLabel)}" title="${esc(aiLabel)}">${icon("sparkle",18)}</button>`:"";const idAttr=inputId?` id="${inputId}"`:"";const common=` placeholder="${esc(placeholder)}" aria-label="${esc(inputLabel)}"${autocompleteOff?' autocomplete="off"':""}`;const fieldEl=atEnd?`<textarea${idAttr} rows="1"${common} enterkeyhint="send" autocapitalize="sentences"></textarea>`:`<input${idAttr}${common} />`;return`<div class="composer${atEnd?" at-end":""}"${wrapStyle?` style="${wrapStyle}"`:""}>
    ${attachEl}
    <div class="field">
      ${fieldEl}
      ${aiEl}
      ${sendEl}
    </div>
  </div>`}export function collapseSection(id,title,count,inner,open){return`<details class="xcollapse" data-sec="${esc(id)}"${open?" open":""}>
    <summary class="xgrp xsum">${esc(title)}${count!=null?` \xB7 ${count}`:""}<span class="xchev">${icon("chevron",14)}</span></summary>
    <div class="xcollapse-body">${inner}</div>
  </details>`}export function mealMedia(hue="20",h=96){return`<div class="act-media" style="height:${h}px;background:
    radial-gradient(60% 80% at 50% 40%, hsl(${hue} 45% 22%), hsl(${+hue+30} 40% 12%));">
    <svg width="100%" height="100%" viewBox="0 0 156 ${h}" preserveAspectRatio="xMidYMid slice" aria-hidden="true" style="position:absolute;inset:0">
      <ellipse cx="78" cy="${h/2+6}" rx="46" ry="30" fill="hsl(${hue} 20% 90% / .08)"/>
      <circle cx="62" cy="${h/2}" r="16" fill="hsl(${hue} 55% 55% / .55)"/>
      <circle cx="92" cy="${h/2-6}" r="12" fill="hsl(${+hue+40} 60% 60% / .5)"/>
      <circle cx="94" cy="${h/2+12}" r="9" fill="hsl(${+hue+80} 55% 55% / .5)"/>
    </svg>
  </div>`}export function planStyleCard(style,{onChange=null,compact=false}={}){if(!style)return"";const pref=style.preferenceDiffers&&style.preferenceName?`<div class="ps-pref">Your preference: <b>${esc(style.preferenceName)}</b> \xB7 shared with ${esc(style.lockedBy||"your coach")}</div>`:"";const change=onChange&&style.canChoose?`<button class="btn ghost sm" data-go="${esc(onChange)}">Change</button>`:style.locked?`<span class="status-pill muted">Set for you</span>`:"";return`
  <section class="card ps-card" style="padding:14px 16px">
    <div style="display:flex;align-items:flex-start;justify-content:space-between;gap:10px">
      <div style="min-width:0">
        <div style="font-size:var(--t-eyebrow);font-weight:800;color:var(--text-3);letter-spacing:var(--track-eyebrow);text-transform:uppercase">Plan style</div>
        <div style="font-size:var(--t-lg);font-weight:800;margin-top:2px">${esc(style.name)}${style.customized?' <span style="font-size:var(--t-sm);font-weight:700;color:var(--text-3)">(customized)</span>':""}</div>
        <div style="font-size:var(--t-sm);font-weight:600;color:var(--text-2);margin-top:2px">${esc(style.sourceLabel)}</div>
      </div>
      ${change}
    </div>
    ${compact?"":`<div style="font-size:var(--t-sm);font-weight:600;color:var(--text-2);margin-top:10px;line-height:1.55">${esc(style.how)}</div>`}
    ${pref}
  </section>`}let EV_DISMISSED=false;export function emailVerifyBanner(){if(RT.emailVerified!==false||EV_DISMISSED)return"";return`<div class="lrow" id="ev-banner" style="margin:12px 0 10px;background:rgba(var(--amber-rgb),0.08);border:1px solid var(--amber-border);border-radius:var(--r-card-sm);padding:10px 11px;gap:10px">
    <div class="xico sm" style="background:rgba(var(--amber-rgb),0.18);color:var(--amber-bright);flex:none">${icon("mail",15)}</div>
    <div class="xr" style="cursor:default;min-width:0">
      <div class="xa">Verify your email</div>
      <div class="xb" id="ev-banner-msg">${esc(RT.email||"Confirm your address")}</div>
    </div>
    <button class="btn ghost sm" id="ev-resend" style="width:auto;padding:0 12px;height:28px;font-size:var(--t-xs);flex:none">Resend</button>
    <button class="ev-x" type="button" aria-label="Dismiss" id="ev-dismiss">${icon("x",14)}</button>
  </div>`}export function wireEmailVerifyBanner(root){const banner=root.querySelector("#ev-banner");if(!banner)return;const resend=banner.querySelector("#ev-resend");const dismiss=banner.querySelector("#ev-dismiss");const msg=banner.querySelector("#ev-banner-msg");const say=text=>{if(msg)msg.textContent=text};if(resend)resend.addEventListener("click",async()=>{if(resend.disabled)return;resend.disabled=true;const was=resend.textContent;resend.textContent="\u2026";const r=await act.requestEmailVerification();resend.disabled=false;resend.textContent=was;if(!r.ok){say(r.error);return}say(r.emailed?`Sent. Check ${esc(RT.email||"your inbox")}.`:"Saved. Check your inbox shortly.")});const doDismiss=()=>{EV_DISMISSED=true;if(window.__render)window.__render()};if(dismiss)dismiss.addEventListener("click",doDismiss)}
