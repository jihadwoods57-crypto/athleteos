import{esc,safeImg}from"./components.js";import{icon}from"./icons.js";import{overlayOpen}from"./overlay-guard.js";let overlay=null;let opener=null;let busy=false;const AUTO_SHOWN=new Set;export function autoShownFor(key){return AUTO_SHOWN.has(String(key))}export function markAutoShown(key){AUTO_SHOWN.add(String(key))}export function resetAutoShown(){AUTO_SHOWN.clear()}export function closeMealQuestions(){if(!overlay)return;const o=overlay;overlay=null;busy=false;o.classList.remove("on");setTimeout(()=>{try{o.remove()}catch{}},200);try{document.removeEventListener("keydown",onKey)}catch{}const back=opener;opener=null;if(back&&typeof back.focus==="function"){try{back.focus()}catch{}}}function onKey(e){if(e.key==="Escape"){closeMealQuestions();return}if(e.key==="Tab"&&overlay){const f=overlay.querySelectorAll('button, input, [href], [tabindex]:not([tabindex="-1"])');if(!f.length)return;const first=f[0],last=f[f.length-1];if(!overlay.contains(document.activeElement)){e.preventDefault();first.focus()}else if(e.shiftKey&&document.activeElement===first){e.preventDefault();last.focus()}else if(!e.shiftKey&&document.activeElement===last){e.preventDefault();first.focus()}}}export function openMealQuestions({questions,photo,slot,onAnswer,onSkip}={}){const qs=(Array.isArray(questions)?questions:[]).filter(Boolean).slice(0,3);if(!qs.length||overlay||overlayOpen(".mqsheet"))return false;opener=document.activeElement&&document.activeElement!==document.body?document.activeElement:null;const head=qs.length===1?"One quick thing":qs.length===2?"Two quick things":`${qs.length} quick things`;const img=photo?safeImg(photo):"";const el=document.createElement("div");el.className="mqsheet";el.innerHTML=`
    <div class="mqs-card" role="dialog" aria-modal="true" aria-labelledby="mqs-title">
      <div class="mqs-grab" aria-hidden="true"></div>
      <div class="mqs-head">
        ${img?'<div class="mqs-thumb" aria-hidden="true"></div>':`<div class="mqs-thumb ph" aria-hidden="true">${icon("sparkle",18)}</div>`}
        <div class="mqs-htxt">
          <h2 class="mqs-title" id="mqs-title">${esc(head)} and your ${esc(slot||"meal")} numbers are exact</h2>
          <div class="mqs-sub">A photo can't show what's under or off the plate. The camera got the rest.</div>
        </div>
        <button class="mqs-x" type="button" aria-label="Close, answer later">\xD7</button>
      </div>
      <div class="mqs-body">
        <div class="mq-list">
          ${qs.map((q,i)=>`
          <label class="mq-item">
            <div class="mq-q"><span class="mq-n">${i+1}</span><span>${esc(q)}</span></div>
            <input class="mq-input" data-qi="${i}" type="text" autocomplete="off" enterkeyhint="${i===qs.length-1?"done":"next"}"
              placeholder="Your answer" aria-label="${esc(q)}" />
          </label>`).join("")}
        </div>
      </div>
      <div class="mqs-foot">
        <button class="btn primary" id="mqs-go" type="button">${icon("check",18)} Get my result</button>
        <button class="mqs-skip" id="mqs-skip" type="button">Skip, just estimate</button>
      </div>
    </div>`;document.body.appendChild(el);overlay=el;if(img){const th=el.querySelector(".mqs-thumb");if(th)th.style.backgroundImage=`url("${img}")`}requestAnimationFrame(()=>el.classList.add("on"));document.addEventListener("keydown",onKey);const card=el.querySelector(".mqs-card");const inputs=()=>Array.from(el.querySelectorAll(".mq-input"));const answers=()=>{const a=[];inputs().forEach(x=>{a[+x.dataset.qi]=x.value.trim()});return a};const fail=msg=>{let err=el.querySelector("#mqs-err");if(!err){el.querySelector(".mqs-foot").insertAdjacentHTML("beforebegin",`<div id="mqs-err" class="mq-err" role="alert">${icon("x",14)} <span></span></div>`);err=el.querySelector("#mqs-err")}err.querySelector("span").textContent=msg};const finish=async(ans,handler)=>{if(busy)return;busy=true;const go=el.querySelector("#mqs-go");const skip=el.querySelector("#mqs-skip");if(go){go.disabled=true;go.innerHTML=`${icon("sparkle",18)} Reading your meal...`}if(skip)skip.disabled=true;try{const r=await handler(ans);if(r&&r.ok===false){busy=false;if(go){go.disabled=false;go.innerHTML=`${icon("check",18)} Get my result`}if(skip)skip.disabled=false;fail(r.error||"Couldn't send that. Check your connection and try again.");return}closeMealQuestions()}catch{busy=false;if(go){go.disabled=false;go.innerHTML=`${icon("check",18)} Get my result`}if(skip)skip.disabled=false;fail("Couldn't send that. Check your connection and try again.")}};el.querySelector(".mqs-x").addEventListener("click",closeMealQuestions);el.addEventListener("click",ev=>{if(ev.target===el)closeMealQuestions()});el.querySelector("#mqs-go").addEventListener("click",()=>finish(answers(),a=>onAnswer?onAnswer(a):null));el.querySelector("#mqs-skip").addEventListener("click",()=>finish([],()=>onSkip?onSkip():null));inputs().forEach((inp,i)=>inp.addEventListener("keydown",ev=>{if(ev.key!=="Enter")return;ev.preventDefault();const next=inputs()[i+1];if(next)next.focus();else el.querySelector("#mqs-go").click()}));try{card.focus()}catch{}return true}
