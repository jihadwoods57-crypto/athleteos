import{icon}from"../icons.js";import{RT,act}from"../state.js";import{backHead,esc}from"../components.js";import{loadVerificationConsent,verifyArrival}from"../commitment-data.js";const native=()=>typeof window!=="undefined"?window.OnStandardNative:null;export const locationNative=()=>{const n=native();return n&&n.location?n.location:null};let STATE=null;let PRESENCE_CAP=false;let AVAILABLE=null;let BUSY=false;let CONSENT=null;let CONSENT_ASKED=false;const withTimeout=(p,ms)=>new Promise((resolve,reject)=>{const t=setTimeout(()=>reject(new Error("native call timed out")),ms);p.then(v=>{clearTimeout(t);resolve(v)},e=>{clearTimeout(t);reject(e)})});const bullet=(ic,title,body)=>`
  <div class="lrow" role="listitem" style="align-items:flex-start;cursor:default">
    <div class="lic" style="background:var(--blue-surface);color:var(--blue-bright)">${icon(ic,16)}</div>
    <div class="lm"><div class="lt">${esc(title)}</div><div class="ls">${esc(body)}</div></div>
  </div>`;export default{tab:"home",render(){const needsGuardian=CONSENT===false;const optedOut=!!RT.locationOptOut;const on=STATE==="always"&&!optedOut;const partial=STATE==="when_in_use"&&!optedOut;const denied=STATE==="denied";return`
    ${backHead("Arrival check-in","How OnStandard confirms you showed up","home")}

    <section class="card pad">
      <div class="tt" style="font-size:15px">You tap once. Or you don\u2019t have to tap at all.</div>
      <div class="ts" style="padding-top:6px">Your coach schedules a practice at a place. OnStandard confirms your phone got there inside the window they set, so you never have to argue about whether you showed up.</div>
    </section>

    <h2 class="eyebrow">What actually happens</h2>
    <section class="card" role="list" style="padding:2px 16px">
      ${bullet("clock","Only around a scheduled commitment","Your location is checked only in the window your coach set for that one event. Outside that window nothing is watched at all.")}
      ${bullet("shield","Only a yes or no is recorded",PRESENCE_CAP?"Your phone reports two things: that you arrived, and, only if your coach set a stay time, whether you were still there when it ended. Never where you are. No coordinates leave your phone.":'Your phone compares itself to the place your coach picked and reports "arrived" or "couldn\u2019t confirm". No coordinates leave your phone and none are stored.')}
      ${bullet("eye","Only your coaching staff can see it","Your arrival time is visible to the staff responsible for you. There is no team list of who was late and no way for other athletes to see your record.")}
      ${""}
      ${bullet("toggle","You can turn it off whenever you want","Switch it off here or in your phone settings. You\u2019ll check in by tapping a button instead, and nothing you already earned is deleted.")}
    </section>

    ${AVAILABLE===false?`
    <div class="sidebox" style="margin-top:14px">
      <div class="req-icon b s38">${icon("bolt",19)}</div>
      <div>
        <div class="tt">Not available on this version</div>
        <div class="ts">Arrival check-in needs a newer build of the app. Until you update, you can check in by tapping the button on your commitment card. It counts exactly the same.</div>
      </div>
    </div>`:needsGuardian?`
    <div class="sidebox" style="margin-top:14px">
      <div class="req-icon a s38">${icon("user",19)}</div>
      <div>
        <div class="tt">A parent or guardian has to approve this first</div>
        <div class="ts">You're under 18, so OnStandard won't check your location until a guardian says yes, or your school records that they already have your family's consent on file. Until then you can still check in by tapping.</div>
      </div>
    </div>
    <div style="height:14px"></div>
    ${RT.consent&&RT.consent.guardianEmail?`
    <div class="ts center">Your parent is already linked (${esc(RT.consent.guardianEmail)}). They approve arrival check-in from their own OnStandard app, on your card under the Athletes tab.</div>
    `:`
    <button class="btn" id="lc-guardian" style="width:100%">${icon("message",18)} Invite a parent to OnStandard</button>
    <div style="height:10px"></div>
    <div class="ts center">Once they're linked, they approve arrival check-in from their own app. Nothing about your location is checked or stored until they do.</div>`}
    `:CONSENT===null?CONSENT_ASKED?`
    <div class="sidebox" style="margin-top:14px">
      <div class="req-icon a s38">${icon("bolt",19)}</div>
      <div>
        <div class="tt">Couldn\u2019t confirm your account just now</div>
        <div class="ts">We couldn\u2019t reach the server to check whether arrival check-in is set up for you, so nothing is switched on yet. You can still check in by tapping the button on your commitment card.</div>
      </div>
    </div>
    <div style="height:14px"></div>
    <button class="btn ghost" id="lc-consent-retry" style="width:100%">Try again</button>
    `:`
    <div style="height:14px"></div>
    <button class="btn" disabled style="width:100%">Checking your account\u2026</button>
    <div style="height:10px"></div>
    <div class="ts" style="text-align:center">One moment: confirming arrival check-in is available for you.</div>
    `:denied?`
    <div class="sidebox" style="margin-top:14px">
      <div class="req-icon a s38">${icon("target",19)}</div>
      <div>
        <div class="tt">Your phone is blocking location for OnStandard</div>
        <div class="ts">Location for this app is set to \u201CNever\u201D in your phone\u2019s settings, so automatic check-in can\u2019t run and asking again from here won\u2019t bring the prompt back. To turn it on: open your phone\u2019s Settings, find OnStandard, and set Location to \u201CAlways\u201D. Until then, check in by tapping the button on your commitment card. It counts exactly the same.</div>
      </div>
    </div>`:`
    <div style="height:14px"></div>
    <button class="btn ${on?"":"primary"}" id="lc-enable" style="width:100%" ${BUSY?"disabled":""}>
      ${icon(on?"check":"target",18)} ${on?"Automatic check-in is on":partial?"Allow it to work in the background":"Turn on arrival check-in"}
    </button>
    <div style="height:10px"></div>
    <div class="ts" style="text-align:center">${on?"You don\u2019t have to open the app. Arriving is enough.":partial?'Right now it only works while the app is open. Allowing "Always" means you never have to think about it.':'Your phone will ask next. Choosing "Always" is what lets it work at 5:43 AM without you opening anything.'}</div>
    ${on&&ARM_CAPPED?`
    <div class="sidebox mt">
      <div class="req-icon a s38">${icon("alert",19)}</div>
      <div>
        <div class="tt">Your phone is watching its limit of places</div>
        <div class="ts">You have more located events than your phone can watch at once, so the ones past the limit will not check themselves in. Tap the arrival button when you get to those. It counts exactly the same.</div>
      </div>
    </div>`:""}
    ${on||partial?`<div style="height:10px"></div>
      <button class="btn ghost" id="lc-off" style="width:100%">Turn it off</button>`:""}
    `}
    <div style="height:20px"></div>`},mount(root){const loc=locationNative();const rerender=()=>{if(root.isConnected&&window.__render)window.__render()};if(CONSENT!==true){loadVerificationConsent().then(ok=>{const first=!CONSENT_ASKED;CONSENT_ASKED=true;const prev=CONSENT;if(ok!==null)CONSENT=ok;if(first||CONSENT!==prev)rerender()})}if(!loc){AVAILABLE=false;STATE="unavailable"}else{withTimeout(loc.available(),8e3).then(r=>{const a=!!(r&&r.available);const s=r&&r.state||"unavailable";const p=!!(r&&r.presence);const changed=a!==AVAILABLE||s!==STATE||p!==PRESENCE_CAP;AVAILABLE=a;STATE=s;PRESENCE_CAP=p;if(changed)rerender()}).catch(()=>{if(AVAILABLE===null){AVAILABLE=false;STATE="unavailable";rerender()}})}const enable=root.querySelector("#lc-enable");if(enable)enable.addEventListener("click",async()=>{if(!loc||BUSY)return;BUSY=true;enable.disabled=true;enable.textContent="Asking\u2026";act.setLocationOptOut(false);try{STATE=await loc.request(true);if(STATE==="always"){const r=await withTimeout(loc.arm(),8e3);ARM_CAPPED=!!(r&&r.capped)}}catch{try{const r=await withTimeout(loc.available(),8e3);STATE=r&&r.state||STATE}catch{}}BUSY=false;window.__render&&window.__render()});const consentRetry=root.querySelector("#lc-consent-retry");if(consentRetry)consentRetry.addEventListener("click",async()=>{consentRetry.disabled=true;consentRetry.textContent="Checking\u2026";await refreshConsent();window.__render&&window.__render()});const off=root.querySelector("#lc-off");if(off)off.addEventListener("click",async()=>{if(!loc)return;off.disabled=true;off.textContent="Turning off\u2026";act.setLocationOptOut(true);try{await loc.disarm()}catch{}window.__render&&window.__render()});const guardian=root.querySelector("#lc-guardian");if(guardian)guardian.addEventListener("click",()=>{location.hash="#invite-parent"})}};let ARM_CAPPED=false;export function armCapped(){return ARM_CAPPED}export function armIfPermitted(){const loc=locationNative();if(!loc||RT.locationOptOut)return Promise.resolve(null);return loc.available().then(r=>r&&r.available&&r.state==="always"?loc.arm():null).then(r=>{if(r)ARM_CAPPED=!!r.capped;return r}).catch(()=>null)}export async function tapToVerify(instanceId){const loc=locationNative();if(!loc)return{within:false,recorded:false,reason:"Location is unavailable on this build"};let device;try{device=await withTimeout(loc.check(instanceId,false),15e3)}catch{return{within:false,recorded:false,reason:"Couldn\u2019t check right now"}}const within=!!(device&&device.within);const res=await verifyArrival(instanceId,"manual",within,device&&device.reason);if(!res.ok){const consent=/consent/i.test(res.error||"");return{within:false,recorded:false,reason:consent?"A parent has to approve arrival check-in first: nothing was recorded":"Couldn\u2019t record this. Check your signal and tap again"}}return{within,recorded:true,reason:device&&device.reason}}export function refreshConsent(){return loadVerificationConsent().then(ok=>{if(ok!==null)CONSENT=ok;return ok})}
