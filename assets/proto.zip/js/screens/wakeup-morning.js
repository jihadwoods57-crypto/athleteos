import{RT}from"../state.js";import{icon}from"../icons.js";import{backHead,esc,skeletonRows}from"../components.js";import{morningSummary,wakeClock,WAKEUP_TYPE}from"../wakeup-morning.js";import{VC,loadBoard}from"../commitment-data.js";import{boardRoute,ROLLCALL_OFF}from"../commitments.js";import{CD,bookId,loadBook}from"../coach-data.js";import*as roles from"../roles.js";function instanceOf(){return(VC.board||[]).find(i=>i.type===WAKEUP_TYPE)||null}function needRow(r){const why=r.verdict==="missed"?"Never answered":`${r.lateMin} minutes late`;const cls=r.verdict==="missed"?"r":"a";const initials=(r.name||"?").split(" ").map(w=>w[0]||"").join("").slice(0,2).toUpperCase();return`
  <div class="lrow wk-need">
    <div class="lic">${esc(initials)}</div>
    <div class="lm"><div class="lt">${esc(r.name)}</div><div class="ls wk-why ${cls}">${esc(why)}</div></div>
    <button type="button" class="btn ghost xs wk-nudge" data-nudge="${esc(r.athleteId||"")}" data-verdict="${esc(r.verdict||"")}">Ping</button>
  </div>`}const homeOf=()=>RT.authRole==="trainer"?"trainer":"coach-home";let LOADED=false;export default{nav:"operator",tab:"home",redirect(){if(ROLLCALL_OFF)return null;const inst=instanceOf();return inst?boardRoute(inst.instance_id,"missed"):null},render(){const inst=instanceOf();if(!inst&&!LOADED)return`${backHead("Roll call","Loading\u2026",homeOf())}${skeletonRows(4,"Loading this morning")}`;if(!inst){return`${backHead("This morning","",homeOf())}
      <div class="sidebox">
        <div class="req-icon muted s38">${icon("clock",17)}</div>
        <div><div class="tt">No wake-up was set</div>
        <div class="ts">Set one up and this fills in the next morning.</div></div>
      </div>
      <div class="wk-gap"></div>
      <button class="btn primary" data-go="rollcall-new">Set a roll call</button>`}const s=morningSummary(inst);const pct=s.total?Math.round(s.onTime/s.total*100):0;return`
    ${backHead("This morning",`${esc(inst.title||"Roll call")} \xB7 ${esc(inst.audience_label||"Everyone")}`,homeOf())}

    ${""}
    ${s.total?`<section class="wk-pulse">
      <div class="wk-k">Up on time</div>
      <div class="wk-num"><span class="wk-big">${s.onTime}</span><span class="wk-of">/${s.total}</span></div>
      <div class="wk-bar" role="img" aria-label="${s.total?`${s.onTime} up on time, ${s.late} late, ${s.missed} never answered`:"Nobody was scheduled"}">
        ${""}
        ${s.onTime?`<span class="wk-seg g" data-flex="${s.onTime}"></span>`:""}
        ${s.late?`<span class="wk-seg a" data-flex="${s.late}"></span>`:""}
        ${s.missed?`<span class="wk-seg r" data-flex="${s.missed}"></span>`:""}
      </div>
      ${s.firstUp?`<div class="wk-cap">${esc(s.firstUp.name)} was first up at ${esc(wakeClock(s.firstUp.atMin))}.</div>`:""}
    </section>`:""}

    ${""}
    ${!s.total?`
    <div class="sidebox">
      <div class="req-icon muted s38">${icon("clock",17)}</div>
      <div><div class="tt">Nobody was on this roll call</div>
      <div class="ts">No one was scheduled for this morning, so there is nothing to report. Check who it goes to on the full roll call.</div></div>
    </div>`:s.needsYou.length?`
    <h2 class="eyebrow">Needs you</h2>
    <section class="card rows">${s.needsYou.map(needRow).join("")}</section>`:`
    <div class="wk-gap"></div>
    <div class="sidebox">
      <div class="req-icon g s38">${icon("check",17)}</div>
      <div><div class="tt">Everyone answered</div>
      <div class="ts">${pct}% of the roster was up inside the window.</div></div>
    </div>`}

    ${""}
    <div class="wk-gap"></div>
    <section class="card rows">
      <div class="lrow" data-go="coach-commitments/${esc(inst.instance_id)}" role="button" tabindex="0">
        <div class="lic">${icon("clock",15)}</div>
        <div class="lm"><div class="lt">Open the full roll call</div>
          <div class="ls">Overrides, excuses, and recent mornings</div></div>
        ${icon("chevron",14,'class="ic-chevron"')}
      </div>
    </section>

    <div class="wk-gap"></div>
    `},async mount(root){const sizeBar=()=>root.querySelectorAll(".wk-seg[data-flex]").forEach(el=>{el.style.setProperty("flex",el.getAttribute("data-flex"))});sizeBar();if(!bookId()){await loadBook(false,CD.kind)}const id=bookId();if(id){await loadBoard(id,CD.kind);const first=!LOADED;LOADED=true;if(root.isConnected&&first)window.__render();sizeBar()}root.addEventListener("click",async e=>{const b=e.target.closest("[data-nudge]");if(!b||b.disabled)return;const who=b.getAttribute("data-nudge");if(!who)return;b.disabled=true;b.textContent="Sending";const late=b.getAttribute("data-verdict")==="late";const r=await roles.nudgePush(who,"Morning",late?"Your coach noticed you were late to roll call.":"Your coach noticed you missed roll call.");b.textContent=r&&r.ok!==false?"Sent":"Try again";if(!r||r.ok===false)b.disabled=false})}};
