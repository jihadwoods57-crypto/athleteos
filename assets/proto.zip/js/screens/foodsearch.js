import{S,RT,slotTitle}from"../state.js";import{icon}from"../icons.js";import{backHead,esc,composer}from"../components.js";import{fetchFoodByBarcode}from"../roles.js";import{planSlot}from"../plan-today.js";const afterPlan=r=>{if(r)window.__go("plan")};const DB=[{n:"Grilled chicken breast",p:31,c:0,f:4,kc:165,unit:"100g"},{n:"White rice, cooked",p:3,c:28,f:0,kc:130,unit:"1 cup"},{n:"Steak, sirloin",p:26,c:0,f:8,kc:183,unit:"100g"},{n:"Roasted potatoes",p:2,c:21,f:4,kc:130,unit:"1 cup"},{n:"Eggs, whole",p:6,c:0,f:5,kc:72,unit:"1 egg"},{n:"Greek yogurt, plain",p:17,c:6,f:1,kc:100,unit:"170g"},{n:"Oats, dry",p:5,c:27,f:3,kc:150,unit:"40g"},{n:"Banana",p:1,c:27,f:0,kc:105,unit:"1 med"},{n:"Chipotle chicken bowl",p:45,c:65,f:22,kc:650,unit:"1 bowl"},{n:"Protein shake",p:25,c:5,f:2,kc:140,unit:"1 scoop"},{n:"Green beans",p:2,c:8,f:0,kc:35,unit:"1 cup"},{n:"Tuna, canned",p:24,c:0,f:1,kc:108,unit:"1 can"}];export const foodSearch={tab:"camera",transient:true,hideTabs:true,render(){const slot=S.currentSlot;const slotName=slot?slotTitle(slot):"meal";return`
    ${backHead(`Plan a meal \xB7 ${slotName}`,"Build what you\u2019ll eat. Snap it when you eat to log it.","camera")}

    ${composer({inputId:"fs-input",placeholder:"Search foods\u2026",inputLabel:"Search foods",decorativeSend:true,sendIcon:"search",sendIconSize:18,sendStyle:"background:var(--surface-2);color:var(--text)",wrapStyle:"margin-top:2px"})}

    <section class="card fs-results" id="fs-results" aria-label="Foods"></section>

    <h2 class="eyebrow">Your plate <span class="link" id="fs-clear" role="button" tabindex="0" hidden>Clear</span></h2>
    <section class="card pad" id="fs-plate">
      <div class="fs-empty" id="fs-empty">Tap a food above to add it.</div>
      <div id="fs-items"></div>
      ${""}
      <div class="macro-row fs-totals" id="fs-totals" hidden>
        <div class="macro"${S.planStyle.showMacros?"":" hidden"}><div class="mv" id="t-p">0g</div><div class="mk">Protein</div></div>
        <div class="macro"${S.planStyle.showMacros?"":" hidden"}><div class="mv" id="t-c">0g</div><div class="mk">Carbs</div></div>
        <div class="macro"${S.planStyle.showMacros?"":" hidden"}><div class="mv" id="t-f">0g</div><div class="mk">Fat</div></div>
        <div class="macro"${S.planStyle.showCalories?"":" hidden"}><div class="mv" id="t-k">0</div><div class="mk">Calories</div></div>
      </div>
    </section>

    <h2 class="eyebrow">Other ways to plan</h2>
    <section class="card rows">
      <div class="lrow" data-go="barcode-scan">
        <div class="lic">${icon("barcode",17)}</div>
        <div class="lm"><div class="lt">Scan a barcode</div><div class="ls">Packaged food, exact from the maker's own data</div></div>
        ${icon("chevron",16,'class="chev-dim"')}
      </div>
      <div class="lrow" data-go="label-scan">
        <div class="lic">${icon("edit",17)}</div>
        <div class="lm"><div class="lt">Enter a nutrition label</div><div class="ls">Type the panel numbers. Exact, never estimated</div></div>
        ${icon("chevron",16,'class="chev-dim"')}
      </div>
    </section>

    ${!slot?`<div class="action-bar"><button class="btn ghost" data-back="home">All meals logged \xB7 Done</button></div>`:`<div class="action-bar"><button class="btn primary" id="fs-log" disabled>${icon("check",19)} <span id="fs-log-label">Plan ${esc(slotName)}</span></button></div>`}
    `},mount(root){const SLOT=S.currentSlot;const showNums=S.planStyle.showMacros||S.planStyle.showCalories;const input=root.querySelector("#fs-input");const results=root.querySelector("#fs-results");const items=root.querySelector("#fs-items");const totals=root.querySelector("#fs-totals");const empty=root.querySelector("#fs-empty");const logBtn=root.querySelector("#fs-log");const logLabel=root.querySelector("#fs-log-label");const clear=root.querySelector("#fs-clear");const slotName=SLOT?slotTitle(SLOT):"meal";const plate=[];const renderTotals=()=>{const sum=plate.reduce((a,x)=>({p:a.p+x.p*x.q,c:a.c+x.c*x.q,f:a.f+x.f*x.q,kc:a.kc+x.kc*x.q}),{p:0,c:0,f:0,kc:0});root.querySelector("#t-p").textContent=Math.round(sum.p)+"g";root.querySelector("#t-c").textContent=Math.round(sum.c)+"g";root.querySelector("#t-f").textContent=Math.round(sum.f)+"g";root.querySelector("#t-k").textContent=Math.round(sum.kc);totals.hidden=!(plate.length&&showNums);empty.hidden=!!plate.length;if(clear)clear.hidden=!plate.length;if(logBtn)logBtn.disabled=!plate.length;const n=plate.reduce((a,x)=>a+x.q,0);if(logLabel)logLabel.textContent=n?`Plan ${slotName} \xB7 ${n} item${n===1?"":"s"}`:`Plan ${slotName}`};const renderPlate=()=>{items.innerHTML=plate.map((x,i)=>`
        <div class="fs-item">
          <span class="fs-item-n">${esc(x.n)} <small>\xB7 ${esc(x.unit)}</small></span>
          <span class="chip" data-i="${i}" data-d="-1" role="button" tabindex="0" aria-label="One less ${esc(x.n)}">\u2212</span>
          <span class="fs-item-q">${x.q}</span>
          <span class="chip" data-i="${i}" data-d="1" role="button" tabindex="0" aria-label="One more ${esc(x.n)}">+</span>
        </div>`).join("");items.querySelectorAll(".chip").forEach(b=>b.addEventListener("click",()=>{const i=+b.dataset.i,d=+b.dataset.d;plate[i].q=Math.max(0,plate[i].q+d);if(plate[i].q===0)plate.splice(i,1);renderPlate();renderTotals()}));renderTotals();renderResults(input.value)};const renderResults=q=>{const hits=DB.filter(x=>x.n.toLowerCase().includes(q.toLowerCase())).slice(0,6);const qOf=f=>{const hit=plate.find(y=>y.n===f.n);return hit?hit.q:0};results.innerHTML=hits.length?hits.map((x,i)=>`
        <div class="lrow" data-add="${DB.indexOf(x)}" role="button" tabindex="0" aria-label="Add ${esc(x.n)}${qOf(x)?`, ${qOf(x)} on your plate`:""}">
          ${qOf(x)?`<div class="lic fs-in">${qOf(x)}</div>`:`<div class="lic">${icon("plus",16)}</div>`}
          <div class="lm"><div class="lt">${esc(x.n)}</div><div class="ls">${esc(x.unit)}${S.planStyle.showMacros?` \xB7 ${x.p}g protein`:""}${S.planStyle.showCalories?` \xB7 ${x.kc} kcal`:""}</div></div>
        </div>`).join(""):`<div class="fs-nomatch">No match for that. These are common foods; for anything else a photo or the nutrition label reads best.
            <button class="btn ghost sm fs-to-cam" id="fs-to-cam">${icon("camera",15)} Take a photo</button></div>`;const toCam=results.querySelector("#fs-to-cam");if(toCam)toCam.addEventListener("click",()=>window.__go(SLOT?`camera/${SLOT}`:"camera"));results.querySelectorAll("[data-add]").forEach(r=>r.addEventListener("click",()=>{const f=DB[+r.dataset.add];const hit=plate.find(x=>x.n===f.n);if(hit)hit.q+=1;else plate.push({...f,q:1});renderPlate()}))};if(logBtn)logBtn.addEventListener("click",()=>{if(!plate.length||!SLOT)return;const sum=plate.reduce((a,x)=>({p:a.p+x.p*x.q,kc:a.kc+x.kc*x.q}),{p:0,kc:0});const name=plate.map(x=>x.q>1?`${x.q} ${x.n}`:x.n).join(", ").slice(0,60);afterPlan(planSlot(SLOT,{name,protein:sum.p,kcal:sum.kc,source:"usual"}))});if(clear)clear.addEventListener("click",()=>{plate.length=0;renderPlate()});input.addEventListener("input",()=>renderResults(input.value));renderResults("");renderTotals()}};export const labelScan={tab:"camera",transient:true,hideTabs:true,render(){const slot=S.currentSlot;const slotName=slot?slotTitle(slot):"meal";const allergies=(RT.allergies||[]).filter(Boolean);const numField="width:100%;height:52px;border-radius:var(--r-card-sm);background:var(--surface-1);border:1.5px solid var(--hairline);color:var(--text);font-size:17px;font-weight:800;text-align:center;font-variant-numeric:tabular-nums";return`
    ${backHead("Plan from a label","Type the numbers off the panel. Snap it when you eat to log it.","camera")}

    ${allergies.length?`
    <div class="sidebox" style="border-color:var(--amber-border);background:rgba(var(--amber-rgb),0.08)">
      <div class="req-icon a s38" style="color:var(--amber-bright)">${icon("bell",17)}</div>
      <div><div class="tt">Check it against your restrictions</div>
      <div class="ts">You flagged ${esc(allergies.join(", "))}. Read the ingredients before you eat this.</div></div>
    </div>
    <div style="height:14px"></div>`:""}

    <h2 class="eyebrow">Per serving, off the panel</h2>
    <section class="card pad">
      <div style="display:grid;grid-template-columns:1fr 1fr;gap:12px">
        <div><div class="bk" style="margin-bottom:6px">Calories</div><input id="ls-kcal" type="number" inputmode="numeric" placeholder="0" aria-label="Calories" aria-describedby="ls-err" style="${numField}" /></div>
        <div><div class="bk" style="margin-bottom:6px">Protein (g)</div><input id="ls-p" type="number" inputmode="numeric" placeholder="0" aria-label="Protein (g)" aria-describedby="ls-err" style="${numField};color:var(--green-bright)" /></div>
        <div><div class="bk" style="margin-bottom:6px">Carbs (g)</div><input id="ls-c" type="number" inputmode="numeric" placeholder="0" aria-label="Carbs (g)" style="${numField}" /></div>
        <div><div class="bk" style="margin-bottom:6px">Fat (g)</div><input id="ls-f" type="number" inputmode="numeric" placeholder="0" aria-label="Fat (g)" style="${numField}" /></div>
      </div>
    </section>

    <h2 class="eyebrow">Servings you\u2019ll eat</h2>
    <div class="chip-row" id="serv" data-toggle-group>
      <span class="chip on" data-m="1">1</span>
      <span class="chip" data-m="1.5">1.5</span>
      <span class="chip" data-m="2">2</span>
      <span class="chip" data-m="3">3</span>
    </div>

    <div style="height:14px"></div>
    <div class="sidebox">
      <div class="req-icon b s38">${icon("shield",18)}</div>
      <div><div class="tt">Exact, because you read it</div>
      <div class="ts">You copy the numbers off the real panel; we just multiply by your servings. No guessing a packaged food, and no fake scan.</div></div>
    </div>

    <div id="ls-err" style="color:var(--red-bright);font-size:13px;font-weight:600;min-height:18px;margin-top:12px;text-align:center"></div>
    ${!slot?`<button class="btn ghost" data-back="home">All meals logged \xB7 Done</button>`:`<button class="btn primary" id="ls-log">${icon("check",19)} Plan for ${esc(slotName)}</button>`}
    <div style="height:10px"></div>
    `},async mount(root){const{wireToggles}=await import("./settings.js");wireToggles(root);let mult=1;root.querySelectorAll("#serv .chip").forEach(ch=>ch.addEventListener("click",()=>{mult=+ch.dataset.m||1}));const lsBtn=root.querySelector("#ls-log");const err=root.querySelector("#ls-err");const SLOT=S.currentSlot;if(lsBtn&&SLOT)lsBtn.addEventListener("click",()=>{const val=id=>Math.max(0,parseFloat(root.querySelector("#"+id).value)||0);const p=val("ls-p"),c=val("ls-c"),f=val("ls-f"),kcalIn=val("ls-kcal");["ls-kcal","ls-p"].forEach(id=>{const el=root.querySelector("#"+id);if(el)el.removeAttribute("aria-invalid")});if(p<=0&&kcalIn<=0){err.textContent="Enter at least the calories or protein from the label.";["ls-kcal","ls-p"].forEach(id=>{const el=root.querySelector("#"+id);if(el)el.setAttribute("aria-invalid","true")});return}const kcal=kcalIn>0?kcalIn:4*p+4*c+9*f;afterPlan(planSlot(SLOT,{name:"Packaged food (from the label)",protein:Math.round(p*mult),kcal:Math.round(kcal*mult),source:"usual"}))})}};export const barcodeScan={tab:"camera",transient:true,hideTabs:true,render(){const slot=S.currentSlot;const slotName=slot?slotTitle(slot):"meal";const showNums=S.planStyle.showMacros||S.planStyle.showCalories;const canLive=typeof window!=="undefined"&&"BarcodeDetector"in window;return`
    ${backHead(`Scan a barcode \xB7 ${slotName}`,"Packaged food, exact from the maker's own data","food-search")}

    ${canLive?`
    <section class="card" style="padding:0;overflow:hidden;position:relative">
      <video id="bc-video" autoplay playsinline muted style="width:100%;height:190px;object-fit:cover;display:block;background:#000"></video>
      <div style="position:absolute;left:0;right:0;bottom:0;padding:8px 12px;background:linear-gradient(transparent, rgba(0,0,0,0.65));color:#fff;font-size:12px;font-weight:700;text-align:center">Hold the bars inside the frame</div>
    </section>
    <div style="height:12px"></div>`:""}

    <h2 class="eyebrow">${canLive?"Or type the numbers":"Type the numbers under the bars"}</h2>
    <section class="card pad">
      <div style="display:flex;gap:10px">
        <input id="bc-digits" type="text" inputmode="numeric" autocomplete="off" placeholder="e.g. 038000138416" aria-label="Barcode digits"
          style="flex:1;min-width:0;height:52px;border-radius:var(--r-card-sm);background:var(--surface-1);border:1.5px solid var(--hairline);color:var(--text);font-size:17px;font-weight:800;text-align:center;font-variant-numeric:tabular-nums;letter-spacing:0.06em" />
        <button class="btn primary" id="bc-lookup" aria-label="Look up barcode" style="width:auto;padding:0 18px;height:52px;flex:none">${icon("search",18)}</button>
      </div>
      ${canLive?"":`<div style="font-size:11.5px;font-weight:600;color:var(--text-3);margin-top:8px;line-height:1.4">Live camera scanning isn't supported in this app's browser engine yet. The printed digits are the same code, so typing them is just as exact.</div>`}
    </section>

    <div id="bc-status" style="font-size:13px;font-weight:600;color:var(--text-3);min-height:20px;margin:10px 2px"></div>

    <div id="bc-result" style="display:none">
      <h2 class="eyebrow">Found</h2>
      <section class="card pad">
        <div class="tt" id="bc-name" style="font-size:15px"></div>
        <div class="ts" id="bc-serving" style="margin-top:2px"></div>
        <div class="macro-row" style="margin-top:12px${showNums?"":";display:none"}">
          <div class="macro"${S.planStyle.showMacros?"":" hidden"}><div class="mv" id="bc-p">0g</div><div class="mk">Protein</div></div>
          <div class="macro"${S.planStyle.showMacros?"":" hidden"}><div class="mv" id="bc-c">0g</div><div class="mk">Carbs</div></div>
          <div class="macro"${S.planStyle.showMacros?"":" hidden"}><div class="mv" id="bc-f">0g</div><div class="mk">Fat</div></div>
          <div class="macro"${S.planStyle.showCalories?"":" hidden"}><div class="mv" id="bc-k">0</div><div class="mk">Calories</div></div>
        </div>
        <h2 class="eyebrow" style="margin-top:14px">How much will you eat?</h2>
        <div class="chip-row" id="bc-grams" data-toggle-group>
          <span class="chip" data-g="50">50g</span>
          <span class="chip on" data-g="100">100g</span>
          <span class="chip" data-g="150">150g</span>
          <span class="chip" data-g="250">250g</span>
        </div>
        <div id="bc-attr" style="font-size:10.5px;font-weight:600;color:var(--text-3);margin-top:12px"></div>
      </section>
      <div style="height:14px"></div>
      ${slot?`<button class="btn primary" id="bc-log">${icon("check",19)} Plan for ${esc(slotName)}</button>`:`<button class="btn ghost" data-back="home">All meals logged \xB7 Done</button>`}
    </div>
    <div style="height:10px"></div>
    `},async mount(root){const{wireToggles}=await import("./settings.js");wireToggles(root);const SLOT=S.currentSlot;const status=root.querySelector("#bc-status");const digits=root.querySelector("#bc-digits");let found=null;let grams=100;let stream=null,scanTimer=null,busy=false;const paint=()=>{const box=root.querySelector("#bc-result");if(!found){box.style.display="none";return}const m=found.per100||{};const x=grams/100;root.querySelector("#bc-name").textContent=found.name;root.querySelector("#bc-serving").textContent=S.planStyle.showMacros||S.planStyle.showCalories?found.serving?`Label serving: ${found.serving} \xB7 numbers below are for your ${grams}g`:`Numbers below are for your ${grams}g`:found.serving?`Label serving: ${found.serving} \xB7 planning your ${grams}g`:`Planning your ${grams}g`;root.querySelector("#bc-p").textContent=Math.round((m.protein||0)*x)+"g";root.querySelector("#bc-c").textContent=Math.round((m.carbs||0)*x)+"g";root.querySelector("#bc-f").textContent=Math.round((m.fat||0)*x)+"g";root.querySelector("#bc-k").textContent=Math.round((m.kcal||0)*x);root.querySelector("#bc-attr").textContent=found.attribution?`Source: ${found.attribution}`:"";box.style.display="block"};const lookup=async code=>{if(busy)return;busy=true;status.textContent="Looking it up\u2026";const res=await fetchFoodByBarcode(code);busy=false;if(!res){found=null;paint();status.textContent=navigator.onLine===false?"You need a connection for a barcode lookup. The label screen works offline.":"No match for that code. Not every product is in the database. The label screen always works.";return}found=res;status.textContent="";paint()};root.querySelector("#bc-lookup").addEventListener("click",()=>{const code=(digits.value||"").replace(/\D/g,"");if(code.length<8){status.textContent="A barcode is at least 8 digits.";return}lookup(code)});digits.addEventListener("keydown",ev=>{if(ev.key==="Enter"&&!ev.isComposing)root.querySelector("#bc-lookup").click()});root.querySelectorAll("#bc-grams .chip").forEach(ch=>ch.addEventListener("click",()=>{root.querySelectorAll("#bc-grams .chip").forEach(c=>c.classList.remove("on"));ch.classList.add("on");grams=+ch.dataset.g||100;paint()}));const video=root.querySelector("#bc-video");const stop=()=>{if(scanTimer){clearInterval(scanTimer);scanTimer=null}if(stream){stream.getTracks().forEach(t=>t.stop());stream=null}};const logBtn=root.querySelector("#bc-log");if(logBtn&&SLOT)logBtn.addEventListener("click",()=>{if(!found)return;const m=found.per100||{},x=grams/100;stop();afterPlan(planSlot(SLOT,{name:`${found.name} (${grams}g)`,protein:(m.protein||0)*x,kcal:(m.kcal||0)*x,source:"usual"}))});if(video&&"BarcodeDetector"in window&&navigator.mediaDevices&&navigator.mediaDevices.getUserMedia){(async()=>{try{const det=new window.BarcodeDetector({formats:["ean_13","ean_8","upc_a","upc_e"]});stream=await navigator.mediaDevices.getUserMedia({video:{facingMode:"environment"}});video.srcObject=stream;scanTimer=setInterval(async()=>{if(busy||!stream)return;try{const codes=await det.detect(video);const hit=codes&&codes[0]&&(codes[0].rawValue||"").replace(/\D/g,"");if(hit&&hit.length>=8){digits.value=hit;if(navigator.vibrate){try{navigator.vibrate(12)}catch{}}lookup(hit)}}catch{}},350)}catch{const vf=video.closest("section");if(vf)vf.style.display="none"}})()}const onVis=()=>{if(document.visibilityState!=="visible"){stop();document.removeEventListener("visibilitychange",onVis)}};window.addEventListener("pagehide",stop,{once:true});document.addEventListener("visibilitychange",onVis);window.__screenCleanup=()=>{stop();document.removeEventListener("visibilitychange",onVis)}}};
