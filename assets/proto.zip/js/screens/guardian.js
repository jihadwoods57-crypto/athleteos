import{S,act}from"../state.js";import{icon}from"../icons.js";import{backHead,esc,alertMsg,statusMsg}from"../components.js";export function guardianWhyHtml(){return`<div class="sidebox">
      <div class="req-icon b s38">${icon("lock",17)}</div>
      <div><div class="tt">Why this exists</div>
      <div class="ts">You're under 18, so the law says a parent or guardian approves before your data leaves this phone. Everything you log still counts here. It just stays private until they say yes.</div></div>
    </div>`}export default{tab:"home",render(){const c=S.consent;if(!c.minor){return`
      ${backHead("Parent approval","Not needed for your account","home")}
      <div class="state-demo">
        <div class="sd-ic">${icon("shield",24)}</div>
        <div class="sd-t">You're all set</div>
        <div class="sd-s">Parent approval applies to athletes under 18. Your account syncs normally.</div>
        <div class="sd-cta"><button class="btn ghost sm" data-go="home">Back home</button></div>
      </div>
      <div style="height:10px"></div>`}if(c.status==="verified"){return`
      ${backHead("Parent approval","Approved","home")}
      <div class="state-demo" style="border-style:solid;border-color:var(--green-border)">
        <div class="sd-ic" style="background:var(--green-surface);color:var(--green-bright)">${icon("check",24)}</div>
        <div class="sd-t">Approved</div>
        <div class="sd-s">${c.guardianEmail?`${esc(c.guardianEmail)} approved your account.`:"Your parent or guardian approved your account."} Your day syncs and your coach can see it.</div>
        <div class="sd-cta"><button class="btn ghost sm" data-go="home">Back home</button></div>
      </div>
      <div style="height:10px"></div>`}if(c.status==="pending"){return`
      ${backHead("Parent approval","Waiting on your parent","home")}
      <div class="state-demo">
        <div class="sd-ic" style="background:rgba(var(--amber-rgb),0.16);color:var(--amber-bright)">${icon("clock",24)}</div>
        <div class="sd-t">Request sent</div>
        <div class="sd-s">We asked ${c.guardianEmail?esc(c.guardianEmail):"your parent"} to approve. Until they do, everything you log stays on this phone. Nothing is lost, and it all syncs the moment they say yes.</div>
      </div>
      <div style="height:14px"></div>
      <h2 class="eyebrow">Haven't heard back? Send a reminder, or fix the email.</h2>
      <input id="gd-email" class="ob-input" type="email" inputmode="email" autocomplete="email" aria-label="Parent or guardian email" aria-describedby="gd-err" autocapitalize="none" value="${esc(c.guardianEmail||"")}" placeholder="Parent or guardian email" />
      ${alertMsg({id:"gd-err",style:"color:var(--red);font-weight:600;min-height:18px;margin-top:10px;text-align:center"})}
      ${statusMsg({id:"gd-ok",style:"display:block;color:var(--green-bright);font-weight:600;text-align:center"})}
      <button class="btn ghost" id="gd-send">Send reminder</button>
      <div style="height:10px"></div>`}if(c.status==="revoked"){return`
      ${backHead("Parent approval","Approval was removed","home")}

      <div class="sidebox">
        <div class="req-icon s38" style="background:rgba(var(--red-rgb),0.16);color:var(--red-bright)">${icon("lock",17)}</div>
        <div><div class="tt">Your guardian removed approval</div>
        <div class="ts">${c.guardianEmail?esc(c.guardianEmail):"Your parent or guardian"} revoked consent, so your day stopped syncing and your coach can no longer see it. Everything you log now stays on this phone. Nothing you've already logged is lost. Ask them to approve again to reconnect.</div></div>
      </div>

      <div style="height:16px"></div>
      <h2 class="eyebrow">Send a new approval request</h2>
      <input id="gd-email" class="ob-input" type="email" inputmode="email" autocomplete="email" aria-label="Parent or guardian email" aria-describedby="gd-err" autocapitalize="none" value="${esc(c.guardianEmail||"")}" placeholder="Parent or guardian email" />
      ${alertMsg({id:"gd-err",style:"color:var(--red);font-weight:600;min-height:18px;margin-top:10px;text-align:center"})}
      ${statusMsg({id:"gd-ok",style:"display:block;color:var(--green-bright);font-weight:600;text-align:center"})}
      <button class="btn" id="gd-send">Ask for approval again</button>
      <div style="height:10px"></div>`}return`
    ${backHead("Parent approval","One step before your day can sync","home")}

    ${guardianWhyHtml()}

    <div style="height:16px"></div>
    <h2 class="eyebrow">Send the approval request</h2>
    <input id="gd-email" class="ob-input" type="email" inputmode="email" autocomplete="email" aria-label="Parent or guardian email" aria-describedby="gd-err" autocapitalize="none" placeholder="Parent or guardian email" />
    ${alertMsg({id:"gd-err",style:"color:var(--red);font-weight:600;min-height:18px;margin-top:10px;text-align:center"})}
    ${statusMsg({id:"gd-ok",style:"display:block;color:var(--green-bright);font-weight:600;text-align:center"})}
    <button class="btn" id="gd-send">Ask for approval</button>

    <div style="height:14px"></div>
    <div class="sidebox">
      <div class="req-icon b s38">${icon("shield",17)}</div>
      <div><div class="tt">What they see</div>
      <div class="ts">One email with one approve button. They never get your meals or photos. Approving just lets your score reach your coach.</div></div>
    </div>
    <div style="height:10px"></div>`},mount(root){const btn=root.querySelector("#gd-send");const input=root.querySelector("#gd-email");const err=root.querySelector("#gd-err");const ok=root.querySelector("#gd-ok");if(!btn||!input)return;const submit=async()=>{if(btn.disabled)return;if(err)err.textContent="";input.removeAttribute("aria-invalid");if(ok)ok.textContent="";btn.disabled=true;const was=btn.textContent;btn.textContent="Sending\u2026";const wasPending=(S.consent&&S.consent.status)==="pending";const r=await act.requestGuardianConsent(input.value);if(r.ok){if(r.emailed===false){if(err)err.textContent="Saved, but the email could not be sent yet. Try again in a bit, or reach support@onstandard.app.";input.setAttribute("aria-invalid","true");btn.disabled=false;btn.textContent=was;return}if(wasPending){if(ok)ok.textContent=`Reminder sent${input.value?" to "+input.value:""}.`;btn.disabled=false;btn.textContent=was}else{window.__render()}return}if(err)err.textContent=r.error||"Could not send. Try again.";input.setAttribute("aria-invalid","true");btn.disabled=false;btn.textContent=was};btn.addEventListener("click",submit);input.addEventListener("keydown",e=>{if(e.key==="Enter"&&!e.isComposing)submit()})}};
