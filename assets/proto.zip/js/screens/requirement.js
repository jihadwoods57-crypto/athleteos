import{S,RT}from"../state.js";import{icon}from"../icons.js";import{backHead,esc}from"../components.js";import{CATALOG,PROOF,IMPACT_LABEL,freqLabel,fmtMin,deriveAssigned,catalogFromItems}from"../requirements.js";import{DAY}from"../day.js";export default{tab:"home",render({sub}){const id=sub||"dinner";const assigned=RT.assigned.find(a=>a.id===id);const req=assigned?deriveAssigned(assigned):(S.scheduleCatalog||[]).find(r=>r.id===id)||CATALOG.find(r=>r.id===id)||catalogFromItems(RT.stdItems).find(r=>r.id===id);if(!req)return`${backHead("Requirement","Not found","plan")}
    <div class="state-demo">
      <div class="sd-ic">${icon("clipboard",26)}</div>
      <div class="sd-t">This requirement isn't on your Standard</div>
      <div class="sd-s">It may have been removed by your coach or already wrapped up. Your current rules and tasks live on your Plan.</div>
      <div class="sd-cta"><button class="btn primary" data-go="plan">${icon("clipboard",18)} Go to your Plan</button></div>
    </div>`;const proof=PROOF[req.proof]||PROOF.check;const impact=IMPACT_LABEL[req.impact.kind==="component"?req.impact.comp:req.impact.kind];const isStandingCheck=!assigned&&req.proof==="check";const checkDone=isStandingCheck&&!!(DAY.checkedTasks&&DAY.checkedTasks[id]);const done=assigned?assigned.done:checkDone;const stdItem=(RT.stdItems||[]).find(i=>i.id===id)||null;const isTraining=!assigned&&stdItem&&stdItem.kind==="lift";let actionBtn=assigned?done?`<div class="day-done"><div class="req-icon g" style="width:44px;height:44px">${icon("check",21)}</div>
           <div><div class="tt">Done. ${assigned.from} can see it.</div><div class="ts">Completed tonight.</div></div></div>`:`<button class="btn green" data-act="completeAssigned:${id}" data-then="requirement/${id}">${icon("check",19)} Mark Done \xB7 coach sees it</button>`:isStandingCheck?checkDone?`<button class="btn ghost" data-act="completeCheck:${id}" data-then="requirement/${id}" style="width:100%">${icon("check",19)} Done \xB7 coach sees it \xB7 tap to undo</button>`:`<button class="btn green" data-act="completeCheck:${id}" data-then="requirement/${id}">${icon("check",19)} Mark Done \xB7 coach sees it</button>`:`<button class="btn primary" data-go="${req.route||proof.route||"home"}">${icon(req.icon,19)} ${proof.verb} ${req.title}</button>`;const grace=typeof req.grace==="number"&&req.grace>0?req.grace:0;const scored=req.impact.kind==="component";const DONE_RULE={photo:{what:"A photo of the plate",late:`Logged inside the window scores in full${grace?`, plus ${grace} min grace`:""}. Late still counts, at half credit.`},form:{what:"The form submitted",late:"Submitted any time tonight counts in full."},scale:{what:"A weight entered",late:"It feeds your season trend, so a late entry costs nothing."},counter:{what:"The count reached",late:"Add to it any time before the deadline."},check:{what:"One tap to mark it done",late:assigned?"Your coach sees it either way.":"No deadline penalty."}};const doneRule=DONE_RULE[req.proof]||DONE_RULE.check;if(!scored)doneRule.late="Tracked, not scored. Logging late costs you nothing.";const gov=S.governingStandard;const fmtDate=iso=>{if(!iso)return null;const d=new Date(String(iso).length<=10?`${iso}T12:00:00`:iso);return isNaN(d.getTime())?null:d.toLocaleDateString(void 0,{month:"short",day:"numeric",year:"numeric"})};const provenance=assigned?{who:`Assigned by ${assigned.from||"your coach"}`,when:assigned.dueLabel||"One-time task"}:gov?{who:gov.setBy?`${gov.scopeLabel} by ${gov.setBy}`:gov.scopeLabel,when:gov.effectiveDate?`In effect since ${fmtDate(gov.effectiveDate)||gov.effectiveDate}`:gov.updatedAt?`Last changed ${fmtDate(gov.updatedAt)||gov.updatedAt}`:"In effect now"}:{who:"The OnStandard baseline",when:"Not replaced by a coach standard"};if(isTraining)actionBtn=checkDone?`<button class="btn ghost" data-go="log-training/${id}" style="width:100%">${icon("check",19)} Logged today \xB7 tap to update</button>`:`<button class="btn green" data-go="log-training/${id}">${icon("bolt",19)} Log this session</button>`;const freqText=req.required===false?"Optional \xB7 skipping is never a miss":freqLabel(req.freq);return`
    ${backHead(req.title,assigned?`Assigned by ${assigned.from}`:freqText,"home")}

    <section class="card" style="padding:6px 16px" role="list">
      <div class="lrow" role="listitem" style="cursor:default">
        <div class="lic">${icon("clock",17)}</div>
        ${""}
        <div class="lm"><div class="lt">${req.dueLabel||(req.window&&req.window.due!=null?`Due by ${fmtMin(req.window.due)}`:"No deadline")}</div>
        <div class="ls">${assigned?"One-time task":freqText}</div></div>
      </div>
      <div class="lrow" role="listitem" style="cursor:default">
        <div class="lic">${icon("camera",17)}</div>
        <div class="lm"><div class="lt">${proof.label}</div><div class="ls">How you prove it</div></div>
      </div>
      <div class="lrow" role="listitem" style="cursor:default">
        <div class="lic">${icon("target",17)}</div>
        <div class="lm"><div class="lt">${impact}</div><div class="ls">What it touches. No black boxes</div></div>
      </div>
      <div class="lrow" role="listitem" style="cursor:default">
        <div class="lic">${icon("check",17)}</div>
        <div class="lm"><div class="lt">${esc(doneRule.what)}</div><div class="ls">${esc(doneRule.late)}</div></div>
      </div>
      <div class="lrow" role="listitem" style="cursor:default">
        <div class="lic">${icon("bell",17)}</div>
        <div class="lm"><div class="lt">Reminders: ${req.reminder||"medium"}</div><div class="ls">Coach sets urgency; you set quiet hours</div></div>
      </div>
      ${provenance?`
      <div class="lrow" role="listitem" style="cursor:default">
        <div class="lic">${icon("shield",17)}</div>
        <div class="lm"><div class="lt">${esc(provenance.who)}</div><div class="ls">${esc(provenance.when)}</div></div>
      </div>`:""}
    </section>

    <h2 class="eyebrow">Why it's on your standard</h2>
    <div class="coachnote">
      ${(()=>{const who=assigned?assigned.from||"":S.coach.hasCoach&&S.coach.isNamed?S.coach.name:"";if(!who)return"";const init=who.split(/\s+/).filter(Boolean).slice(0,2).map(w=>w[0].toUpperCase()).join("");return`<div class="who"><div class="av">${esc(init)}</div><div><div class="nm">${esc(who)}</div><div class="rl">${assigned?"On this task":"On this requirement"}</div></div></div>`})()}
      ${req.note?`<p>\u201C${esc(req.note)}\u201D</p>`:""}
    </div>

    ${isTraining&&stdItem.desc?`
    <h2 class="eyebrow">The session</h2>
    <div class="coachnote"><p>${esc(stdItem.desc)}</p></div>`:""}

    <div style="height:18px"></div>
    ${actionBtn}
    <div style="height:10px"></div>
    `},mount(){if(window.__act)window.__act.seeAssigned()}};
