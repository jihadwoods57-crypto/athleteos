import{icon}from"../icons.js";import{shortDate,DAYS_LONG}from"../fmt-date.js";import{RT}from"../state.js";import{track,EVENTS}from"../analytics.js";import{backHead,esc,emptyState}from"../components.js";import{reveal}from"../motion.js";import{csStatus,csProgressLine,remainingLabel,progressPct,syncedLabel,metricLabel,sourceRule,paceToGoal,groupForAthlete,activeOn,completedLabel,fmtValue,unitNoun,toCanonical,toDisplay,isComplete,columnGeometry,streakOf,momentumOf}from"../connected-standards.js";import{CS,loadMine,loadMyDefs,submitManual,disputeResult,saveStandard,setStandardActive,todayISO}from"../connected-standard-data.js";import{standardsCard,standardsOfflineCard,mountStandardsCard,pillFor,column,standardRow,METRIC_ICON,countAttrs}from"./standards-card.js";export{standardsCard,standardsOfflineCard,mountStandardsCard};let DETAIL_TRIED=null;const DOW=["SUN","MON","TUE","WED","THU","FRI","SAT"];function periodLabel(iso,period){const d=new Date(String(iso)+"T12:00:00");if(Number.isNaN(d.getTime()))return"";return period==="week"?shortDate(d):DOW[d.getDay()]}function momentumCard(rows,current){const bars=momentumOf(rows,current.standard_id,7);if(bars.length<2)return"";const anyGap=bars.some(b=>b.cls==="gap");return`<section class="card pad">
    <h2 class="cs-eyebrow" style="margin-bottom:10px">LAST ${bars.length} ${current.period==="week"?"WEEKS":"DAYS"}</h2>
    <div class="cs-mom">
      <span class="tline"></span>
      ${bars.map(b=>`<b class="${b.cls}" style="height:${Math.max(4,b.pct)}%"></b>`).join("")}
    </div>
    <div class="cs-momlabs">${bars.map(b=>`<span>${esc(periodLabel(b.iso,current.period))}</span>`).join("")}</div>
    ${anyGap?`<div class="cs-p muted" style="margin-top:10px">A hatched bar is a period your device never reported. It never counts against you.</div>`:""}
  </section>`}function ruleCard(row){const surprising=!!row.deliberate_workout||!!row.workout_min_duration_min;const body=`<div class="cs-p">${esc(sourceRule(row.metric,row.deliberate_workout,row.workout_min_duration_min))}</div>
    <div class="cs-p muted" style="margin-top:6px">${esc(syncedLabel(row,void 0,todayISO()))}${row.verified_source?` \xB7 ${esc(sourceLabel(row.verified_source))}`:""}</div>
    ${row.note?`<div class="cs-p" style="margin-top:8px">${esc(row.note)}</div>`:""}
    ${row.owner_label?`<div class="cs-p muted" style="margin-top:6px">Set by ${esc(row.owner_label)}</div>`:""}`;if(surprising){return`<section class="card pad">
      <h2 class="cs-eyebrow" style="margin-bottom:8px">HOW THIS IS COUNTED</h2>
      ${body}
    </section>`}return`<details class="card pad xcollapse" data-sec="cs-rule">
    <summary class="xsum" style="display:flex;align-items:center;justify-content:space-between;cursor:pointer">
      <span class="cs-eyebrow">HOW THIS IS COUNTED</span>
      <span class="xchev">${icon("chevron",14)}</span>
    </summary>
    <div class="xcollapse-body" style="margin-top:10px">${body}</div>
  </details>`}export default{tab:"home",render({sub}){const row=CS.result(sub);if(!row){if(DETAIL_TRIED===sub){return`${backHead("Standard","","home")}
        ${emptyState({icon:"target",title:"This standard isn't here anymore",body:"It may have been turned off or replaced. Everything current is on your list.",action:{id:"cs-gone-list",label:"See your standards",go:"connected-standards"}})}`}return`${backHead("Standard","Loading\u2026","home")}
      <section class="card pad"><div class="cs-p">Loading your standard\u2026</div></section>`}const st=csStatus(row.status);const pace=paceToGoal(row,todayISO());const geo=columnGeometry(row,pace);const done=isComplete(row.status);const canManual=row.allow_manual&&!done&&row.status!=="excused";const canDispute=row.status==="missed"&&!row.disputed_at;const streak=streakOf(CS.mine,row.standard_id);const{shown,attrs}=countAttrs(row.progress,row.metric,row.display_unit);const value=geo.state==="unknown"?'<span class="cs-val dim">\u2014</span>':`<div class="cs-val"><span ${attrs}>${esc(shown)}</span>${geo.state==="partial"?'<span class="plus">+</span>':""}</div>`;const paceTone=done?"done":geo.behind?"behind":pace?"on":"";const paceText=geo.state==="unknown"?"Health access is off, so nothing is being counted.":geo.state==="partial"?`${esc(syncedLabel(row,void 0,todayISO()))}. This won\u2019t count against you.`:row.status==="missed"?`${esc(remainingLabel(row)||"")} short. The period is closed.`:row.status==="excused"?esc(row.excused_reason||"Excused by your coach"):done?esc(completedLabel(row)):pace?`${esc(pace.label)}${pace.needLabel?` \xB7 ${esc(pace.needLabel)}`:""}`:esc(remainingLabel(row)||"Target met");const foot=geo.state==="unknown"?`<div class="cs-foot gray"><div class="ic">${icon("wifiOff",14)}</div>
         <div class="tx">Reconnect your health data, or log this by hand below.</div></div>`:geo.state==="partial"?`<div class="cs-foot amber"><div class="ic">${icon("clock",14)}</div>
         <div class="tx">${row.allow_manual?"Your watch hasn\u2019t reported yet. Log it yourself below if it doesn\u2019t catch up.":"Your watch hasn\u2019t reported yet. If it never does, this reads as unreported, never as a miss."}</div></div>`:streak>=2?`<div class="cs-foot ${done?"green":""}"><div class="ic">${icon("flame",14)}</div>
         <div class="tx">${streak} ${row.period==="week"?"weeks":"days"} in a row</div></div>`:"";return`${backHead(row.title||"Standard",metricLabel(row.metric,row.deliberate_workout),"home")}

    <section class="card pad" id="cs-hero">
      <div class="cs-head" style="margin-bottom:13px">
        <h2 class="cs-eyebrow">${esc(row.period==="week"?"THIS WEEK":"TODAY")}</h2>
        <span class="status-pill ${pillFor(row.status)}">${esc(st.label)}</span>
      </div>
      <div class="cs-colrow">
        ${column(geo)}
        <div class="cs-colside">
          ${value}
          <div class="cs-of">of ${esc(fmtValue(row.target,row.metric,row.display_unit))} ${esc(unitNoun(row.metric,row.display_unit,row.target))}</div>
          <div class="cs-pace ${paceTone}">${paceText}</div>
        </div>
      </div>
      ${foot}
    </section>

    ${momentumCard(CS.mine,row)}

    ${ruleCard(row)}

    ${canManual?(()=>{const body=`<div class="cs-p muted cs-manual-p">Log it yourself. ${row.manual_requires_approval?"Your coach reviews manual entries before they count.":"It\u2019s recorded as reported rather than verified. Nobody assumes you\u2019re being dishonest."}</div>
      <input class="input" id="cs-note" aria-label="Anything your coach should know" aria-describedby="cs-manual-err" maxlength="200" placeholder="Note for your coach (optional)">
      <button class="btn cs-manual-btn" id="cs-manual">I did this</button>
      <div id="cs-manual-err" role="status" class="cs-p cs-err"></div>`;return geo.state==="unknown"||geo.state==="partial"?`<section class="card pad">
      <h2 class="cs-eyebrow cs-manual-h">WATCH NOT SYNCING?</h2>
      ${body}
    </section>`:`<details class="card pad xcollapse cs-manual">
      <summary class="xsum"><span class="cs-eyebrow">WATCH MISSED SOMETHING?</span><span class="xchev">${icon("chevron",14)}</span></summary>
      <div class="xcollapse-body cs-manual-body">${body}</div>
    </details>`})():""}

    ${row.manual_submitted_at?`<section class="card pad">
      <h2 class="cs-eyebrow" style="margin-bottom:6px">YOU REPORTED THIS</h2>
      <div class="cs-p">${esc(row.manual_note||"Logged by hand.")}</div>
    </section>`:""}

    ${canDispute?`<section class="card pad">
      <div class="cs-p muted" style="margin-bottom:10px">If this is wrong, say so. Your coach sees your note. Nothing changes automatically.</div>
      <input class="input" id="cs-dnote" aria-label="What actually happened" aria-describedby="cs-dispute-err" maxlength="200" placeholder="What actually happened">
      <button class="btn ghost" id="cs-dispute" style="margin-top:10px">This isn\u2019t right</button>
      <div id="cs-dispute-err" role="status" class="cs-p cs-err"></div>
    </section>`:""}

    ${row.disputed_at?`<section class="card pad">
      <div class="cs-p muted">You flagged this for your coach.</div>
    </section>`:""}

    ${row.source_kind==="personal"?`<section class="card rows">
      <div class="lrow" data-go="connected-standard-edit/${esc(row.standard_id)}">
        <div class="lic">${icon("edit",16)}</div>
        <div class="lm"><div class="lt">Edit this standard</div><div class="ls">Change the target, the days, or turn it off</div></div>
        ${icon("chevron",17,'class="chev-dim"')}
      </div>
    </section>`:""}

    <div class="cs-p muted" style="text-align:center;margin:14px 20px 24px">
      Separate from your daily score: this standard is tracked, not scored.
    </div>`},mount(root){const rerender=()=>loadMine(true).then(()=>{if(window.__render)window.__render()});const sub=location.hash.split("/")[1]||"";if(!CS.result(sub)&&DETAIL_TRIED!==sub){loadMine(true).then(()=>{DETAIL_TRIED=sub;if(window.__render)window.__render()})}const hero=root.querySelector("#cs-hero");const row=CS.result(sub);if(hero&&row){reveal(hero,{key:`cs:${row.result_id}:${row.status}:${row.progress}`,haptic:isComplete(row.status)?"reveal":null})}const manual=root.querySelector("#cs-manual");if(manual)manual.addEventListener("click",async()=>{if(manual.disabled)return;manual.disabled=true;manual.textContent="Saving\u2026";const r=CS.result(location.hash.split("/")[1]||"");const note=(root.querySelector("#cs-note")||{}).value||"";const res=await submitManual(r&&r.instance_id,note);if(res.ok){try{if(navigator.vibrate)navigator.vibrate(14)}catch{}track(EVENTS.CS_MANUAL,{metric:r&&r.metric,review:res.status==="awaiting_review"});rerender()}else{manual.disabled=false;manual.textContent="I did this";const err=root.querySelector("#cs-manual-err");if(err)err.textContent="That didn't save. Check your connection and try again.";const note2=root.querySelector("#cs-note");if(note2)note2.setAttribute("aria-invalid","true")}});const dispute=root.querySelector("#cs-dispute");if(dispute)dispute.addEventListener("click",async()=>{if(dispute.disabled)return;dispute.disabled=true;dispute.textContent="Sending\u2026";const r=CS.result(location.hash.split("/")[1]||"");const note=(root.querySelector("#cs-dnote")||{}).value||"";const res=await disputeResult(r&&r.result_id,note);if(res.ok){track(EVENTS.CS_DISPUTED,{metric:r&&r.metric});rerender()}else{dispute.disabled=false;dispute.textContent="This isn\u2019t right";const err=root.querySelector("#cs-dispute-err");if(err)err.textContent="Your note didn't send. Check your connection and try again.";const dnote=root.querySelector("#cs-dnote");if(dnote)dnote.setAttribute("aria-invalid","true")}})}};function sourceLabel(src){return src==="healthkit"?"Verified through Apple Health":src==="health_connect"?"Verified through Health Connect":src==="staff"?"Confirmed by your coach":"Reported by you"}let LIST_SIG=null;export const connectedStandardsList={tab:"profile",render(){const today=todayISO();const rows=activeOn(CS.mine,today);const{assigned,personal}=groupForAthlete(rows);const section=(title,list,empty)=>`
      <h2 class="xgrp">${esc(title)}</h2>
      ${list.length?`<section class="card" style="padding:2px 16px">${list.map(r=>standardRow(r,today)).join("")}</section>`:empty}`;const liveIds=new Set(personal.map(r=>r.standard_id));const resting=(CS.defs||[]).filter(d=>d&&d.active!==false&&!liveIds.has(d.id));const defRow=d=>`<div class="lrow" data-go="connected-standard-edit/${esc(d.id)}">
      <div class="lic">${icon(METRIC_ICON[d.metric]||"bolt",17)}</div>
      <div class="lm"><div class="lt">${esc(d.title||"Standard")}</div>
      <div class="ls">${esc(fmtValue(d.target_value,d.metric,d.display_unit))} ${esc(unitNoun(d.metric,d.display_unit,d.target_value))} \xB7 not on today's schedule</div></div>
      ${icon("chevron",17,'class="chev-dim"')}
    </div>`;return`${backHead("Activity standards","Verified from your device","profile")}
    ${section("From your coach",assigned,emptyState({icon:"target",title:"Nothing assigned right now",body:"When your coach sets an activity standard, it shows up here and on your Home screen.",compact:true}))}
    <h2 class="xgrp">Personal</h2>
    ${personal.length?`<section class="card rows">${personal.map(r=>standardRow(r,today)).join("")}</section>`:""}
    ${resting.length?`<section class="card rows">${resting.map(defRow).join("")}</section>`:""}
    ${""}
    ${!personal.length&&!resting.length?emptyState({icon:"bolt",title:"Set your own target",body:"Steps, distance, workouts or active minutes, checked against your watch, and yours alone.",action:{go:"connected-standard-edit",label:"Set a personal standard"},compact:true}):""}
    <div id="cs-connect-slot"></div>
    ${personal.length||resting.length?`<div style="padding:12px 20px">
      <button class="btn" id="cs-new">Set a personal standard</button>
    </div>`:""}
    <div style="height:20px"></div>`},mount(root){mountStandardsCard(root);const nu=root.querySelector("#cs-new");if(nu)nu.addEventListener("click",()=>{location.hash="#connected-standard-edit"});(async()=>{const slot=root.querySelector("#cs-connect-slot");if(!slot)return;const h=typeof window!=="undefined"&&window.OnStandardNative?window.OnStandardNative.health:null;if(!h)return;const ok=await h.available().catch(()=>false);if(!ok||!slot.isConnected)return;const on=await h.connected().catch(()=>false);slot.innerHTML=`<section class="card" style="padding:2px 16px">
        <div class="lrow" data-go="health-consent">
          <div class="lic" style="color:var(--blue-bright)">${icon("bolt",18)}</div>
          <div class="lm"><div class="lt">${on?"Apple Health connected":"Connect Apple Health"}</div>
          <div class="ls">${on?"Your standards verify themselves":"Let your standards check themselves"}</div></div>
          ${icon("chevron",17,'style="color:var(--text-3)"')}
        </div>
      </section>`})();Promise.all([loadMine(),loadMyDefs()]).then(([rows,defs])=>{const sig=rows.map(r=>`${r.result_id}:${r.status}:${r.progress}`).join("|")+"\xA7"+(defs||[]).map(d=>`${d.id}:${d.active}`).join("|");if(sig===LIST_SIG)return;LIST_SIG=sig;if(window.__render)window.__render()})}};const METRICS=[{key:"sleep_hours",label:"Sleep",unit:"h",preset:7.5},{key:"steps",label:"Steps",unit:"steps",preset:8e3},{key:"distance",label:"Distance",unit:"mi",preset:3},{key:"workouts",label:"Workouts",unit:"workouts",preset:4},{key:"workout_minutes",label:"Workout minutes",unit:"min",preset:150},{key:"active_minutes",label:"Active minutes",unit:"min",preset:30}];const DOW_INITIALS=["S","M","T","W","T","F","S"];const DOW_FULL=DAYS_LONG;const chip=(attr,on,label,multi,name)=>`
  <span class="${on?"on":""}" role="${multi?"checkbox":"radio"}" tabindex="0"
        aria-checked="${on?"true":"false"}"${name?` aria-label="${esc(name)}"`:""} ${attr}>${esc(label)}</span>`;let DRAFT=null;function blankDraft(){return{id:null,metric:"steps",display_unit:"steps",target:8e3,period:"day",repeat_days:[0,1,2,3,4,5,6],deliberate_workout:false,title:""}}function draftSentence(d){const noun=unitNoun(d.metric,d.display_unit,d.target||2);const cadence=d.period==="week"?"across the week":d.repeat_days.length===7?"a day, every day":`a day, ${d.repeat_days.length} ${d.repeat_days.length===1?"day":"days"} a week`;return`${noun} ${cadence}.`}function previewCard(d){return`<div style="padding:0 20px 11px"><div class="cs-prev">
    <div class="cscol live"><span class="fill"></span></div>
    <div>
      <div class="pv">${esc(fmtValue(toCanonical(d.target,d.metric,d.display_unit),d.metric,d.display_unit))}</div>
      <div class="pl"><span class="ps">${esc(draftSentence(d))}</span><br>Verified from your watch.</div>
    </div>
  </div></div>`}export const connectedStandardEdit={tab:"profile",render({sub}){if(sub&&!CS.def(sub)){return`${backHead("Edit standard","Loading\u2026","connected-standards")}
      <section class="card pad"><div class="cs-p">Loading your standard\u2026</div></section>`}if(!DRAFT||(sub?DRAFT.id!==sub:DRAFT.id!==null)){const def=sub?CS.def(sub):null;DRAFT=def?{id:def.id,metric:def.metric,display_unit:def.display_unit,target:toDisplay(def.target_value,def.metric,def.display_unit),period:def.period,repeat_days:def.repeat_days||[0,1,2,3,4,5,6],deliberate_workout:!!def.deliberate_workout,title:def.title||""}:blankDraft()}const d=DRAFT;const m=METRICS.find(x=>x.key===d.metric)||METRICS[0];return`${backHead(d.id?"Edit standard":"New standard","Your own target","connected-standards")}

    ${previewCard(d)}

    <section class="card pad">
      <div class="cs-knob">
        <div class="cs-knob-label" id="cs-lb-metric">WHAT YOU\u2019RE TRACKING</div>
        <div class="cs-seg" role="radiogroup" aria-labelledby="cs-lb-metric">${METRICS.map(x=>chip(`data-cs-metric="${esc(x.key)}"`,x.key===d.metric,x.label)).join("")}
        </div>
      </div>

      ${d.metric==="distance"?`<div class="cs-knob">
        <div class="cs-knob-label" id="cs-lb-counts">WHAT COUNTS</div>
        <div class="cs-seg" role="radiogroup" aria-labelledby="cs-lb-counts">
          ${chip('data-cs-delib="0"',!d.deliberate_workout,"Any walking or running")}
          ${chip('data-cs-delib="1"',!!d.deliberate_workout,"Recorded workouts only")}
        </div>
      </div>`:""}

      <div class="cs-knob">
        <label class="cs-knob-label" for="cs-target">TARGET</label>
        <input class="input" id="cs-target" type="number" inputmode="decimal" min="1"
               value="${esc(String(d.target))}" placeholder="${esc(String(m.preset))}">
        <div class="cs-p muted" style="margin-top:6px">${esc(unitNoun(d.metric,d.display_unit,2))} per ${d.period==="week"?"week":"day"}</div>
      </div>

      <div class="cs-knob">
        <div class="cs-knob-label" id="cs-lb-often">HOW OFTEN</div>
        <div class="cs-seg" role="radiogroup" aria-labelledby="cs-lb-often">
          ${chip('data-cs-period="day"',d.period==="day","Every day")}
          ${chip('data-cs-period="week"',d.period==="week","Across the week")}
        </div>
      </div>

      ${d.period==="day"?`<div class="cs-knob">
        <div class="cs-knob-label" id="cs-lb-days">WHICH DAYS</div>
        <div class="cs-seg" role="group" aria-labelledby="cs-lb-days">${DOW_INITIALS.map((lab,i)=>chip(`data-cs-dow="${i}"`,d.repeat_days.includes(i),lab,true,DOW_FULL[i])).join("")}
        </div>
      </div>`:""}

      <div class="cs-knob">
        <label class="cs-knob-label" for="cs-title">NAME IT (OPTIONAL)</label>
        <input class="input" id="cs-title" maxlength="60" value="${esc(d.title)}"
               placeholder="${esc(defaultTitle(d))}">
      </div>
    </section>

    <div style="padding:0 20px">
      <button class="btn" id="cs-save">${d.id?"Save changes":"Set this standard"}</button>
      ${d.id?`<button class="btn ghost" id="cs-del" style="margin-top:8px">Turn this off</button>`:""}
      <div class="cs-p muted" style="text-align:center;margin-top:12px">
        Personal standards are yours alone. Your coach doesn\u2019t see them.
      </div>
    </div>
    <div style="height:24px"></div>`},mount(root){const set=patch=>{DRAFT={...DRAFT,...patch};if(window.__render)window.__render()};root.querySelectorAll("[data-cs-metric]").forEach(el=>el.addEventListener("click",()=>{const key=el.getAttribute("data-cs-metric");const m=METRICS.find(x=>x.key===key)||METRICS[0];set({metric:key,display_unit:m.unit,target:m.preset,deliberate_workout:false})}));root.querySelectorAll("[data-cs-delib]").forEach(el=>el.addEventListener("click",()=>set({deliberate_workout:el.getAttribute("data-cs-delib")==="1"})));root.querySelectorAll("[data-cs-period]").forEach(el=>el.addEventListener("click",()=>set({period:el.getAttribute("data-cs-period")})));root.querySelectorAll("[data-cs-dow]").forEach(el=>el.addEventListener("click",()=>{const i=Number(el.getAttribute("data-cs-dow"));const days=DRAFT.repeat_days.includes(i)?DRAFT.repeat_days.filter(x=>x!==i):[...DRAFT.repeat_days,i].sort();set({repeat_days:days.length?days:DRAFT.repeat_days})}));const target=root.querySelector("#cs-target");if(target)target.addEventListener("input",()=>{DRAFT.target=Number(target.value)||0;const pv=root.querySelector(".cs-prev .pv");const ps=root.querySelector(".cs-prev .ps");if(pv)pv.textContent=fmtValue(toCanonical(DRAFT.target,DRAFT.metric,DRAFT.display_unit),DRAFT.metric,DRAFT.display_unit);if(ps)ps.textContent=draftSentence(DRAFT)});const title=root.querySelector("#cs-title");if(title)title.addEventListener("input",()=>{DRAFT.title=title.value});const save=root.querySelector("#cs-save");if(save)save.addEventListener("click",async()=>{if(save.disabled)return;const d=DRAFT;if(!(Number(d.target)>0)){save.textContent="Enter a target first";return}save.disabled=true;save.textContent="Saving\u2026";const uid=RT.userId||await currentUserId();if(!uid){save.disabled=false;save.textContent="Sign in to save this";return}const res=await saveStandard({id:d.id||void 0,owner_athlete:uid,audience_kind:"self",title:(d.title||"").trim()||defaultTitle(d),metric:d.metric,display_unit:d.display_unit,target_value:toCanonical(d.target,d.metric,d.display_unit),deliberate_workout:!!d.deliberate_workout,period:d.period,repeat_days:d.period==="day"?d.repeat_days:[0,1,2,3,4,5,6],allow_manual:true});if(res.ok){track(EVENTS.CS_PERSONAL_SET,{metric:d.metric,period:d.period});DRAFT=null;await loadMine(true);await loadMyDefs(true);location.hash="#connected-standards"}else{save.disabled=false;save.textContent="Couldn\u2019t save. Try again"}});const del=root.querySelector("#cs-del");if(del)del.addEventListener("click",async()=>{if(!DRAFT||!DRAFT.id||del.disabled)return;del.disabled=true;del.textContent="Turning off\u2026";const res=await setStandardActive(DRAFT.id,false);if(!res.ok){del.disabled=false;del.textContent="Turn this off";const save2=root.querySelector("#cs-save");if(save2)save2.textContent="Couldn\u2019t reach the server. Try again";return}DRAFT=null;await loadMyDefs(true);await loadMine(true);location.hash="#connected-standards"});loadMyDefs().then(()=>{const wantSub=location.hash.split("/")[1]||"";if(wantSub&&(!DRAFT||DRAFT.id!==wantSub)&&CS.def(wantSub)&&window.__render)window.__render()})}};function defaultTitle(d){const noun=unitNoun(d.metric,d.display_unit,2);if(d.metric==="steps")return d.period==="week"?"Weekly Steps":"Daily Steps";if(d.metric==="distance")return d.period==="week"?"Weekly Miles":"Daily Distance";if(d.metric==="workouts")return d.period==="week"?"Weekly Workouts":"Daily Workout";return d.period==="week"?`Weekly ${noun}`:`Daily ${noun}`}async function currentUserId(){try{const c=window.sb;if(!c)return null;const{data}=await c.auth.getUser();return data&&data.user&&data.user.id||null}catch{return null}}
