import{S,liveWeightPct}from"../state.js";import{DAY}from"../day.js";import{icon}from"../icons.js";import{esc,segBar}from"../components.js";import home,{pillTone}from"./home.js";const dayBackdrop=()=>{let html;try{html=home.render({backdrop:true})}catch{return""}return`<div class="sheet-backdrop" aria-hidden="true">${html.replace(/\s(?:data-(?:go|act|back|then|tour)|id|tabindex|role)="[^"]*"/g,"")}</div>`};export default{tab:"camera",hideTabs:true,bleed:true,transient:true,render(){const e=S.exec;const segs=segBar(e.met,e.total,`${e.met} of ${e.total} completed today`,"margin:0 2px 12px");const head=`<div class="hub-head"><span class="a" id="hub-head-a">${e.met} of ${e.total} completed</span><span class="b">${e.possible>e.score?`${e.score} \u2192 <em>up to ${e.possible}</em>`:`${e.score} \xB7 day complete`}</span></div>`;const issue=S.syncIssue;const syncRow=issue==="blocked"?`
      <div class="sheet-row" data-go="guardian">
        <div class="si" style="background:var(--amber-surface);color:var(--amber-bright)">${icon("lock",20)}</div>
        <div class="st"><div class="t">${S.consent.guardianEmail?"Waiting on your parent":"One step before your day syncs"}</div><div class="s">${S.consent.guardianEmail?"Everything you log is safe on this phone until they approve.":"You\u2019re under 18, so a parent approves before your day reaches your coach. Tap to send it."}</div></div>
        ${icon("chevron",16,'style="color:var(--text-3)"')}
      </div>`:issue==="error"?`
      <div class="sheet-row" style="cursor:default">
        <div class="si" style="background:var(--surface-2);color:var(--text-3)">${icon("wifiOff",20)}</div>
        <div class="st"><div class="t">Waiting to sync</div><div class="s">Your entry is saved and will upload automatically when you reconnect.</div></div>
      </div>`:"";if(e.celebration){return`
      ${dayBackdrop()}<div class="sheet-scrim" data-back="home"></div>
      <div class="sheet" role="dialog" aria-modal="true" aria-labelledby="hub-head-a">
        <div class="grab"></div>
        ${head}${segs}${syncRow}
        <div class="hub-celeb">
          <div class="n">${e.score}</div>
          <div style="font-size:var(--t-md);font-weight:800;margin-top:2px">${S.tier.name==="OnStandard"?"You're OnStandard.":"Every requirement is in."}</div>
          <div style="font-size:var(--t-sm);color:var(--text-2);margin-top:4px;line-height:1.5">${S.tier.name==="OnStandard"?`Every requirement is in. Day ${S.streakDays} locks at midnight.`:"Your score is final at midnight."}</div>
        </div>
        ${""}
        <h2 class="xgrp" style="margin:14px 2px 7px">Still want to log something?</h2>
        <div class="sheet-row" data-go="camera">
          <div class="si" style="background:var(--green-surface);color:var(--green-bright)">${icon("camera",20)}</div>
          <div class="st"><div class="t">Log an extra meal</div><div class="s">Beyond the standard. It still counts toward your quality.</div></div>
          ${icon("chevron",16,'style="color:var(--text-3)"')}
        </div>
        <div class="sheet-row" data-go="weight">
          <div class="si" style="background:var(--surface-2);color:var(--text-3)">${icon("scale",20)}</div>
          <div class="st"><div class="t">Log Weight</div><div class="s">Trend only \xB7 not scored</div></div>
        </div>
        <div class="cancel" data-back="home">Close</div>
      </div>`}const n=e.now;const CTA_ICON={form:"moonStar",scale:"scale",photo:"camera",counter:"droplet"};const VERB={form:"Complete",scale:"Log",photo:"Log",counter:"Add"};const isCheck=n?!n.proof||n.proof==="check":false;const heroIcon=n?isCheck?"check":CTA_ICON[n.proof]:"";const heroTitle=n?isCheck?`Mark ${esc(n.title)} done`:`${VERB[n.proof]} ${esc(n.title)}${n.state==="overdue"?" late":""}`:"";const od=n?n.state==="overdue":false;const missed=od&&n.color==="red";const closing=n?!od&&n.minsLeft!=null&&n.minsLeft<=45:false;const hue=n&&!od&&!closing?{g:"g",p:"p",b:"b",c:"c",muted:"b"}[n.accent]||"":"";const hero=n?`
      <div class="hub-hero ${missed?"red":hue}" data-go="${n.route}">
        <div class="xico">${icon(heroIcon,20)}</div>
        <div class="ht">
          <div class="a">${heroTitle}</div>
          <div class="b">${od?esc(n.sub):`${icon("clock",12)} ${n.countdown?`${esc(n.countdown)} \xB7 `:""}${esc(n.dueLabel)}`}</div>
        </div>
        ${icon("chevron",16,'style="color:var(--text-3)"')}
      </div>`:"";const weight=e.items.find(i=>i.id==="weight");const recovery=e.items.find(i=>i.id==="recovery");return`
    ${dayBackdrop()}<div class="sheet-scrim" data-back="home"></div>
    <div class="sheet" role="dialog" aria-modal="true" aria-labelledby="hub-head-a">
      <div class="grab"></div>
      ${head}${segs}${syncRow}
      ${hero}
      <h2 class="xgrp" style="margin:0 2px 7px">Quick logs</h2>
      ${weight&&!(e.now&&e.now.id==="weight")?`
      <div class="sheet-row" data-go="weight">
        <div class="si" style="background:${weight.state==="done"?"var(--green-surface);color:var(--green-bright)":"var(--surface-2);color:var(--text-3)"}">${icon(weight.state==="done"?"check":"scale",20)}</div>
        <div class="st"><div class="t">Log Weight</div><div class="s">${weight.state==="done"?"In for today \xB7 not scored":"Trend only \xB7 not scored"}</div></div>
      </div>`:""}
      ${DAY.dailyCommitment==null?`
      <div class="sheet-row" data-go="commitment">
        <div class="si" style="background:var(--blue-surface);color:var(--blue-bright)">${icon("target",19)}</div>
        <div class="st"><div class="t">Daily Commitment</div><div class="s">End-of-day reflection \xB7 doesn't change your score</div></div>
        <span class="status-pill muted">Open</span>
      </div>`:""}
      ${""}
      ${recovery&&!(e.now&&e.now.id==="recovery")?`
      <h2 class="xgrp" style="margin:4px 2px 7px">Forms &amp; check-ins</h2>
      <div class="sheet-row" data-go="${recovery.route}">
        <div class="si" style="background:${recovery.state==="done"?"var(--green-surface);color:var(--green-bright)":"rgba(var(--purple-rgb),0.22);color:var(--purple-bright)"}">${icon(recovery.state==="done"?"check":"moon",20)}</div>
        <div class="st"><div class="t">Recovery check-in</div><div class="s">${recovery.state==="done"?"Submitted tonight":`Before bed \xB7 20 seconds \xB7 Recovery ${liveWeightPct("checkin")+liveWeightPct("recovery")}%`}</div></div>
        <span class="status-pill ${pillTone(recovery.color)}">${recovery.pill}</span>
      </div>`:""}
      ${e.doneItems.length?`<div class="hub-fold" data-go="home">${icon("check",13)} ${e.doneItems.length} completed today \xB7 view on Home</div>`:""}
      <div class="cancel" data-back="home">Cancel</div>
    </div>`}};
