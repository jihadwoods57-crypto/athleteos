/* ============================================================
   OB2 · ATHLETE flow — route `oba` (2026-07 adaptive onboarding).
   Narrative spine: problem → why the current way fails → the
   answer → discovery → aha (their own numbers) → live meal demo
   → personalized plan → commitment → proof → connect/dob/account
   → coverage or plans → home.

   Ordering note (verified against js/router.js:164/181–185 before
   building): `oba` is listed in AUTH_ROUTES, and the router only
   bounces SIGNED-OUT users off non-auth routes — a signed-in user
   is never forced off an auth route. So ch4 keeps the spec order:
   connect → dob → account → covered/plans → destination, with the
   paywall/coverage step living AFTER account creation.

   Voice note: mealDemoSteps is called exactly once at module load,
   before any answers exist, so the demo runs in the default coach
   voice. Athletes whose only supporter is a trainer hear the
   trainer voice in the CLIENT flow (`obf`), which is built for
   that relationship.
   ============================================================ */
import { RT, act, computeScore } from '../state.js';
import { icon } from '../icons.js';
import { esc } from '../components.js';
import { dobFromParts, ageOn, normalizePressure, showConfirmPending } from '../ob-helpers.js';
import { commitButton, wireCommit } from '../ob-commit.js';
import { accountBody, wireAccount } from './ob-account.js';
import { track, EVENTS } from '../analytics.js';
import {
  defineFlow, saveProgressStep, choiceGrid, chipRow, scale10, meter, mirrorCard, simChip, countStat,
  phoneCard, testimonial, planCard, paywallVariant, PLANS, capture, structureStep, commitContinue,
} from '../ob2.js';
import { mealDemoSteps } from '../ob2-meal.js';
import { styleForStructureAnswer, styleLabel } from '../plan-style.js';

const R = 'oba';

const GOAL_LABEL = { gain: 'gain weight', lose: 'lose fat', maintain: 'maintain', performance: 'perform' };
const clamp10 = (v) => Math.max(0, Math.min(10, Number(v) || 0));

/* Final hand-off — copied from legacy onboarding step 7: biometric opt-in
   only when the native seam reports availability, else straight home. */
async function goDestination() {
  let bio = false;
  try {
    bio = window.OnStandardNative && window.OnStandardNative.biometrics
      ? await window.OnStandardNative.biometrics.available() : false;
  } catch { /* unavailable */ }
  window.__go(bio ? 'bio-optin' : 'home');
}

/* Hero screen shell (ch0 narrative beats). Accent spans live only here. */
const hero = (eyebrow, title, body, note = '') => `
  <div class="ob2-hero">
    <div class="h-eyebrow">${eyebrow}</div>
    <div class="h-title">${title}</div>
    <div class="h-body">${body}</div>
    ${note ? `<div class="h-note">${note}</div>` : ''}
  </div>`;

const steps = [

  /* ============================== ch0 · Discover ============================== */
  {
    id: 'why', ch: 0, cta: 'Continue',
    body: () => hero('The problem',
      'You train like it <span class="accent">matters.</span>',
      'Practice is two hours. The other twenty (what you eat, how you sleep, what you skip) are the hours that decide the depth chart.',
      'Most athletes lose those hours quietly.'),
  },
  {
    id: 'gap', ch: 0, cta: 'Continue',
    body: () => hero('Why it slips',
      'What gets seen <span class="accent">gets done.</span>',
      'Your coach sees effort at practice. Nobody sees the other twenty hours, so those hours drift, one skipped meal at a time.',
      'Willpower is not the problem. Visibility is.'),
  },
  {
    id: 'answer', ch: 0, cta: 'Show me',
    body: () => hero('The answer',
      'One number, <span class="accent">seen daily.</span>',
      'OnStandard builds one Daily Score from what you actually do (meals, sleep, check-ins) and puts it in front of the people who hold you to it.'),
  },
  {
    id: 'name', ch: 0, cta: 'Next',
    title: () => 'Start with the basics',
    sub: () => 'This is how your coach and team will recognize you.',
    body: (o) => `
      <input id="ob-first" class="ob-input" maxlength="40" placeholder="First name" aria-label="First name" autocomplete="given-name" autocapitalize="words" autocorrect="off" spellcheck="false" value="${esc(o.firstName || '')}" />
      <div style="height:12px"></div>
      <input id="ob-last" class="ob-input" maxlength="40" placeholder="Last name" aria-label="Last name" autocomplete="family-name" autocapitalize="words" autocorrect="off" spellcheck="false" value="${esc(o.lastName || '')}" />`,
    mount(root) {
      const first = root.querySelector('#ob-first'), last = root.querySelector('#ob-last');
      const btn = root.querySelector('#ob2-next');
      /* gateCta runs after this mount — data-gate-extra keeps it honest about the inputs. */
      if (btn) btn.setAttribute('data-gate-extra', '#ob-first.ok');
      const sync = () => {
        const f = first.value.trim(), l = last.value.trim();
        capture({ firstName: f, lastName: l, name: `${f} ${l}`.trim() });
        first.classList.toggle('ok', !!(f && l));
        if (btn) btn.disabled = !(f && l);
      };
      [first, last].forEach((el) => el.addEventListener('input', sync));
      sync();
    },
  },
  /* Age gate moved to ch0 (2026-08-25), right after the name. The flow used to collect
     eighteen screens of answers and a signed commitment before telling a 12-year-old none
     of it could be kept. The engine is data-driven, so the pair rides here unchanged. */
  {
    id: 'dob', ch: 0, cta: 'Next',
    next: (o) => (o.dobBlocked ? 'blocked' : 'sport'),
    title: () => 'Your birth date',
    sub: () => 'Asked once. It verifies you are old enough to use OnStandard.',
    body: (o) => {
      const [y, m, d] = o.dob ? String(o.dob).split('-') : ['', '', ''];
      return `
        <div class="dob-row">
          <input id="ob-dob-m" class="ob-input" type="text" inputmode="numeric" maxlength="2" placeholder="MM" aria-label="Birth month" value="${esc(m ? String(+m) : '')}" />
          <input id="ob-dob-d" class="ob-input" type="text" inputmode="numeric" maxlength="2" placeholder="DD" aria-label="Birth day" value="${esc(d ? String(+d) : '')}" />
          <input id="ob-dob-y" class="ob-input" type="text" inputmode="numeric" maxlength="4" placeholder="YYYY" aria-label="Birth year" value="${esc(y || '')}" />
        </div>
        <div id="ob-age-err" style="color:var(--amber-bright);font-size:var(--t-sm);font-weight:700;min-height:18px;margin-top:10px"></div>
        <div style="font-size:var(--t-sm);font-weight:600;color:var(--text-3);margin-top:6px;line-height:1.5">You must be 13 or older to use OnStandard.</div>`;
    },
    mount(root) {
      const dm = root.querySelector('#ob-dob-m'), dd = root.querySelector('#ob-dob-d'), dy = root.querySelector('#ob-dob-y');
      const errEl = root.querySelector('#ob-age-err');
      const btn = root.querySelector('#ob2-next');
      if (btn) btn.setAttribute('data-gate-extra', '#ob-dob-y.ok');
      const todayISO = () => {
        const t = new Date();
        return `${t.getFullYear()}-${String(t.getMonth() + 1).padStart(2, '0')}-${String(t.getDate()).padStart(2, '0')}`;
      };
      // Digits only. These are type="text" so `maxlength` actually clamps the year (number
      // inputs ignore maxlength entirely, which let a pasted "99999999" sail through).
      const digitsOnly = (el, max) => { const v = el.value.replace(/\D/g, '').slice(0, max); if (v !== el.value) el.value = v; };
      const sync = () => {
        const raw = !!(dm.value && dd.value && dy.value);
        const dob = dobFromParts(dm.value, dd.value, dy.value);
        const future = dob != null && dob > todayISO();
        const under13 = dob != null && !future && ageOn(dob, todayISO()) < 13;
        /* COPPA: the blocked step does the identity scrub on arrival. Scrubbing per keystroke
           here erased the typed name on transient under-13 reads while typing the year. */
        if (under13) capture({ dob: null, dobBlocked: true });
        else capture({ dob: (dob && !future) ? dob : null, dobBlocked: false });
        if (!btn) return;
        if (under13) {
          errEl.textContent = 'OnStandard is for ages 13 and up.';
          btn.setAttribute('data-go', `${R}/blocked`);
          dy.classList.add('ok');
          btn.disabled = false;
          return;
        }
        btn.setAttribute('data-go', `${R}/sport`);
        if (future) {
          // Genuinely just a typo (2030 instead of 2003), not the same thing as under-13, so
          // it must not route to the age-blocked screen.
          errEl.textContent = "That birth year hasn't happened yet.";
          dy.classList.remove('ok');
          btn.disabled = true;
        } else if (raw && !dob) {
          errEl.textContent = "That's not a valid date.";
          dy.classList.remove('ok');
          btn.disabled = true;
        } else {
          errEl.textContent = '';
          dy.classList.toggle('ok', !!dob);
          btn.disabled = !dob;
        }
      };
      dm.addEventListener('input', () => { digitsOnly(dm, 2); if (dm.value.length >= 2) dd.focus(); sync(); });
      dd.addEventListener('input', () => { digitsOnly(dd, 2); if (dd.value.length >= 2) dy.focus(); sync(); });
      dy.addEventListener('input', () => { digitsOnly(dy, 4); sync(); });
      sync();
    },
  },
  {
    id: 'blocked', ch: 0, noFoot: true, back: `${R}/dob`,
    when: (o) => !!o.dobBlocked,
    body: () => `
      <div class="standard-set" style="padding-bottom:6px">
        <div class="halo" style="background:radial-gradient(closest-side,rgba(148,163,184,0.20),transparent 75%)"><div class="core" style="background:var(--surface-2);color:var(--text-2)">${icon('lock', 32)}</div></div>
        <div class="ob-title" style="margin-top:18px">Not yet, but soon.</div>
        <div class="ob-sub" style="padding:0 8px">OnStandard is for athletes 13 and older. That's the law for apps like this, and we take it seriously. Come back on your 13th birthday. The Standard will be waiting.</div>
      </div>
      <div class="ob-foot" style="margin-top:auto">
        <button class="btn ghost" data-go="welcome">Back to start</button>
      </div>`,
    mount() {
      /* COPPA scrub happens HERE, on actually landing blocked. A corrected DOB clears the
         block; the name is re-entered via Back on the name step. */
      capture({ firstName: '', lastName: '', name: '' });
      track(EVENTS.AGE_BLOCKED);
    },
  },
  {
    id: 'sport', ch: 0, cta: 'Next',
    title: () => 'Your sport',
    sub: () => 'Position and level shape your plan.',
    body: (o) => `
      <div class="eyebrow" style="margin:8px 2px 10px">Sport</div>
      ${chipRow('sport', ['Football', 'Basketball', 'Baseball', 'Soccer', 'Track', 'Other'])}
      <div id="pos-wrap" style="display:${o.sport === 'Football' ? 'block' : 'none'}">
        <div style="height:16px"></div>
        <div class="eyebrow" style="margin:8px 2px 10px">Position</div>
        ${chipRow('position', ['QB', 'RB', 'WR', 'TE', 'OL', 'DL', 'LB', 'DB'], { req: false })}
      </div>
      <div style="height:16px"></div>
      <div class="eyebrow" style="margin:8px 2px 10px">Level</div>
      ${chipRow('level', ['Youth', 'High School', 'College', 'Pro'])}`,
    mount(root) {
      /* Positions exist for football only (legacy option set); switching away clears it. */
      const wrap = root.querySelector('#pos-wrap');
      const sportRow = root.querySelector('[data-obkey="sport"]');
      if (!wrap || !sportRow) return;
      sportRow.querySelectorAll('[data-val]').forEach((chp) => chp.addEventListener('click', () => {
        const football = chp.getAttribute('data-val') === 'Football';
        wrap.style.display = football ? 'block' : 'none';
        if (!football) {
          wrap.querySelectorAll('[data-val]').forEach((x) => x.classList.remove('on'));
          capture({ position: null });
        }
      }));
    },
  },
  {
    id: 'goal', ch: 0, cta: 'Next',
    title: () => 'What are we building?',
    sub: () => 'This decides how your nutrition gets scored. Your coach can adjust it.',
    body: () => choiceGrid('goal', [
      { v: 'gain', t: 'Gain weight', s: 'Calorie floor · protein heavy', ic: 'plus', tint: 'rgba(var(--green-rgb),0.18)', color: 'var(--green-bright)' },
      { v: 'lose', t: 'Lose fat', s: 'Calorie window · keep protein', ic: 'target', tint: 'rgba(var(--amber-rgb),0.18)', color: 'var(--amber-bright)' },
      { v: 'maintain', t: 'Maintain', s: 'Consistency over everything', ic: 'shield' },
      { v: 'performance', t: 'Perform', s: 'Fuel training · recover hard', ic: 'bolt', tint: 'rgba(var(--purple-rgb),0.18)', color: 'var(--purple-bright)' },
    ]),
  },
  /* 0142 — an independent athlete chooses their own plan style; a team athlete's answer
     still rides through as a preference their coach sees, but never overrides the
     standard (act.setPlanStyle / resolvePlanStyle enforce that regardless of this value). */
  structureStep({ mode: 'self' }),

  /* ============================== ch1 · See it ==============================
     Ordering (2026-07-23): the live meal demo used to sit at screen 12, behind seven
     discovery screens. It is the strongest thing the product does and it now runs at
     screen 7 — right after goal, which is the only answer the demo itself consumes.
     The remaining discovery (obstacles, supporters, the two ratings) moved BELOW the
     demo: seeing the analysis work earns the right to ask more, and every one of those
     answers is spent later (plan mirrors, aha meters) rather than up front. */

  /* Interactive meal demo — 5 steps (demo, demo-scan, demo-result, demo-score,
     demo-chat). Called once; coach voice by default (see header voice note). */
  ...mealDemoSteps({ route: R, voice: 'coach', computeScore }),

  {
    id: 'obstacle', ch: 1, cta: 'Next',
    title: () => 'Where do your hours leak?',
    sub: () => 'Pick everything that actually happens. Your plan targets these.',
    body: () => chipRow('obstacles', [
      'Late-night eating', 'Skipping meals', 'No plan', 'Nobody checks', 'Travel days', 'Cafeteria food',
    ], { multi: true }),
  },
  {
    id: 'support', ch: 1, cta: 'Next',
    title: () => 'Who holds you to it?',
    sub: () => 'These are the people your score can reach.',
    body: () => chipRow('supporters', [
      { v: 'coach', t: 'My coach' }, { v: 'trainer', t: 'A trainer' }, { v: 'parents', t: 'My parents' },
      { v: 'teammates', t: 'Teammates' }, { v: 'nobody', t: 'Nobody yet' },
    ], { multi: true }),
    /* "Nobody yet" is mutually exclusive with the real supporters — picking one clears the other. */
    mount(root) {
      const grid = root.querySelector('[data-obkey-multi="supporters"]');
      const nobody = grid && grid.querySelector('[data-val="nobody"]');
      if (!grid || !nobody) return;
      grid.addEventListener('click', (e) => {
        const chip = e.target.closest('[data-val]');
        if (!chip) return;
        const others = [...grid.querySelectorAll('[data-val]')].filter((c) => c !== nobody);
        if (chip === nobody && nobody.classList.contains('on')) others.forEach((c) => c.classList.remove('on'));
        else if (chip !== nobody && chip.classList.contains('on')) nobody.classList.remove('on');
        capture({ supporters: [...grid.querySelectorAll('[data-val].on')].map((c) => c.getAttribute('data-val')) });
      });
    },
  },

  {
    /* Two consecutive 1–10 screens were rating fatigue, and the second one ("how strong is
       your current accountability system") is founder language a 16-year-old doesn't parse.
       One screen, two scales, plain questions, and end-labels that actually fit what each
       scale measures. Keys are unchanged so every downstream read still works. */
    id: 'rate', ch: 1, cta: 'Next',
    title: () => 'Two quick reads',
    sub: () => 'Be honest. Both numbers come back on the next screen.',
    body: () => `
      ${scale10('goalImportance', { label: 'How much does this goal matter to you?', lo: 'Not much', hi: 'It’s everything' })}
      <div style="height:22px"></div>
      ${scale10('accountabilityRating', { label: 'When you skip a meal, does anyone notice?', lo: 'Nobody notices', hi: 'I always hear about it' })}`,
  },
  {
    id: 'aha', ch: 1, cta: 'Build my plan',
    title: () => 'The hours nobody sees',
    body: (o) => {
      const n = clamp10(o.goalImportance);
      const m = clamp10(o.accountabilityRating);
      /* The other five flows open their aha with a number the user's own answers produce
         (coach: roster × expectations × 7; client: 165 hours). The athlete's used to open
         with a self-rating comparison — a quiz, not an argument. Lead with the same kind of
         arithmetic the `why` screen set up, THEN land the personal gap. */
      const verdict = (!n && !m)
        ? 'Rate both scales on the previous screen. The gap between them is exactly what OnStandard closes.'
        : m >= n
          ? `You rated this goal <b>${n}/10</b> and you say people notice at <b>${m}/10</b>. Good. That only holds while someone is watching, and OnStandard makes it hold every day, on the record.`
          : `You rated this goal <b>${n}/10</b>, but when you skip, notice lands at <b>${m}/10</b>. That gap is where the 140 hours go, and it is exactly what OnStandard closes.`;
      return `
        ${countStat('140 hrs', 'a week between practices, where your goal is actually won or lost',
          '~20 unseen hours a day × 7 days')}
        <div style="height:18px"></div>
        <div class="ob2-gap">
          ${meter(n * 10, { value: String(n), label: 'The goal', uid: 'gap-g' })}
          ${meter(m * 10, { value: String(m), label: 'Gets noticed', uid: 'gap-s', muted: m < n })}
        </div>
        <div class="ob2-gap-verdict">${verdict}</div>`;
    },
  },

  /* ============================== ch2 · Your plan ============================== */
  {
    id: 'plan', ch: 2, cta: 'Build the habit',
    title: () => 'The system we’re building for you',
    sub: () => 'Assembled from your answers, nothing generic in it.',
    body: (o) => {
      const goal = GOAL_LABEL[o.goal] || 'your goal';
      const obs = Array.isArray(o.obstacles) && o.obstacles.length
        ? o.obstacles.map((x) => String(x).toLowerCase()).join(', ') : null;
      const supLabel = { coach: 'your coach', trainer: 'your trainer', parents: 'your parents', teammates: 'your teammates' };
      const sup = Array.isArray(o.supporters) ? o.supporters.filter((s) => s !== 'nobody') : [];
      const supNames = sup.length ? sup.map((s) => supLabel[s] || s).join(', ') : null;
      const style = styleLabel(styleForStructureAnswer(o.structurePref));
      return `
        ${mirrorCard('target', `You said <b>${esc(goal)}</b>, so every meal is scored against that goal, not a generic diet.`)}
        ${mirrorCard('clipboard', `Your plan style: <b>${esc(style.name)}</b>. ${esc(style.short)}. If you connect a coach, they can adjust this; you can always change it yourself in Settings.`)}
        ${obs ? mirrorCard('flame', `Your risk zone: <b>${esc(obs)}</b>. Reminders and check-ins aim exactly there.`) : ''}
        ${supNames
          ? mirrorCard('users', `Your circle: <b>${esc(supNames)}</b>. They see the score you earn; the invisible hours finally count.`)
          : mirrorCard('users', 'No circle yet. Your score still runs daily, and connecting a coach later takes one code.')}
        <div style="height:8px"></div>
        ${simChip('Example score: yours starts fresh and is earned')}
        <div style="display:flex;justify-content:center;padding:2px 0 12px">${meter(84, { value: '84', label: 'A day done right', uid: 'plan' })}</div>
        ${phoneCard('What runs daily', `
          <div class="comp-read">
            <div class="cr"><div class="ci ok">${icon('check', 13)}</div><div class="ck">Daily standard</div><div class="cv">Your meals and check-ins, scored into one number</div></div>
            <div class="cr"><div class="ci ok">${icon('check', 13)}</div><div class="ck">AI analysis</div><div class="cv">Every photo read in seconds: foods, portions, macros</div></div>
            <div class="cr"><div class="ci ok">${icon('check', 13)}</div><div class="ck">Your circle</div><div class="cv">The people you picked see the score, so effort gets seen</div></div>
          </div>`)}`;
    },
  },
  {
    id: 'habit', ch: 2, cta: 'I can do that',
    body: () => `
      <div class="ob2-habit" style="display:flex;flex-direction:column;justify-content:center;flex:1">
        <div class="hb">Before your first bite,<br /><span class="accent">take one photo.</span></div>
        <div class="hs">That is the whole habit. One photo starts the analysis, the score, and the streak. Everything else follows from it.</div>
      </div>`,
  },

  /* ============================== ch3 · Commit ============================== */
  {
    id: 'commit-q', ch: 3, cta: 'Next',
    title: () => 'What standard are you ready to hold yourself to?',
    sub: () => 'This sets how hard OnStandard pushes: reminder timing and intensity. You can change it any time.',
    body: () => choiceGrid('pressure', [
      { v: 'all-in', t: 'All in', s: 'Every meal, every day. Full reminders', ic: 'flame', tint: 'rgba(var(--amber-rgb),0.18)', color: 'var(--amber-bright)' },
      { v: 'steady', t: 'Steady', s: 'Main meals, honest weeks. Balanced reminders', ic: 'shield' },
      { v: 'building', t: 'Building', s: 'Start with one meal a day. Light touch', ic: 'plus', tint: 'rgba(var(--green-rgb),0.18)', color: 'var(--green-bright)' },
    ]),
  },
  {
    id: 'commit', ch: 3, noFoot: true,
    title: () => 'Sign it',
    body: (o) => {
      const committed = !!o.committedAt;
      const P = {
        'all-in': 'Every meal, every day.',
        steady: 'Main meals, honest weeks.',
        building: 'One meal a day, to start.',
      };
      return `
        <div class="ob2-habit">
          <div class="hb">${esc(P[o.pressure] || 'Your standard, daily.')}</div>
          <div class="hs">${esc(o.firstName ? `${o.firstName}, this` : 'This')} is the deal you are making with yourself. The score simply reports whether you kept it.</div>
        </div>
        <div style="height:24px"></div>
        ${committed ? commitContinue() : commitButton(false)}`;
    },
    mount(root, ctx) {
      const done = root.querySelector('#ob2-commit-next');
      if (done) { done.addEventListener('click', () => ctx.next()); return; }
      wireCommit(root, () => {
        const o = RT.ob || {};
        /* standard{} keeps persistence parity with the legacy contract step; pressure rides
           the one shared vocabulary (normalizePressure in ob-helpers.js). */
        capture({
          committedAt: new Date().toISOString(),
          standard: { mealsPerDay: (o.standard && o.standard.mealsPerDay) || 3, pressure: normalizePressure(o.pressure) },
        });
        ctx.next();
      });
    },
  },

  /* Peak-intent email capture — see saveProgressStep() in ob2.js. */
  saveProgressStep(3),

  /* ============================== ch4 · Start ============================== */
  {
    id: 'proof', ch: 4, cta: 'Next',
    title: () => 'It works when it’s seen',
    sub: () => 'Illustrative, not actual customers yet.',
    /* Launch placeholders — the founder swaps these for real customer quotes before release. */
    body: () => `
      ${testimonial({ quote: 'My coach stopped asking if I ate. He just checks the board. I put on 9 lb over the season without one nagging text.', name: 'Marcus', role: 'RB · high school senior', initials: 'M', stat: '+9 lb', statKey: 'in a season' })}
      ${testimonial({ quote: 'The photo takes five seconds. Knowing my trainer sees the score is what actually changed my weekends.', name: 'Dani', role: 'Soccer · college sophomore', initials: 'D', stat: '41 days', statKey: 'logging streak' })}`,
  },
  {
    id: 'connect', ch: 4, cta: 'Connect', skip: true,
    /* Reachable twice: once in the normal run (→ dob → account), and again from the
       paywall's "I have a code" link AFTER the account exists. In that second case the
       signup form is behind us — resolve straight back to the coverage screen the code
       just earned, or to plans if it didn't. (Same guard the client flow already had.) */
    next: () => (RT.userId
      ? (paywallVariant('athlete') === 'team_covered' ? 'covered' : 'plans')
      : 'account'),
    title: () => 'Got a team code?',
    sub: () => 'Your coach hands it out. It puts your score on their board from day one, and your team covers your access.',
    body: (o) => `
      <input id="tc-code" class="ob-input" placeholder="Team code" aria-label="Team code" autocapitalize="characters" autocorrect="off" spellcheck="false" maxlength="12" value="${esc(o.join && o.join.kind === 'team' ? o.join.code || '' : '')}" />
      <div id="tc-note" class="ob2-scan-note" style="text-align:left;min-height:18px">4–12 letters and numbers. No code? Skip. From Profile you can connect any time, or find a coach to hold you accountable.</div>`,
    mount(root) {
      const el = root.querySelector('#tc-code');
      const note = root.querySelector('#tc-note');
      const btn = root.querySelector('#ob2-next');
      const CODE_RE = /^[A-Z0-9]{4,12}$/;
      const HINT = '4–12 letters and numbers. No code? Skip. From Profile you can connect any time, or find a coach to hold you accountable.';
      if (btn) btn.setAttribute('data-gate-extra', '#tc-code.ok');
      /* A well-FORMED code is not a REAL code. Without this lookup a typo still flipped
         paywallVariant to team_covered, so the next screen promised "your team covers your
         access" for a code that redeems into nothing at persistOnboarding — the athlete
         landed in the app uncovered, having never been shown a plan. Debounced, best-effort:
         offline or directory-down keeps the code and the honest generic note. */
      let seq = 0, timer = null;
      const preview = (code) => {
        if (timer) clearTimeout(timer);
        const my = ++seq;
        timer = setTimeout(async () => {
          try {
            const { dir } = await import('../ob-directory.js');
            const { match } = await dir.previewCode(code);
            if (my !== seq || el.value.trim().toUpperCase() !== code) return; /* stale */
            if (match && match.kind === 'team') {
              capture({ join: { kind: 'team', code, teamId: match.id, teamName: match.name } });
              note.innerHTML = `Connected: <b>${esc(match.name || 'your team')}</b>`;
            } else {
              capture({ join: null });
              el.classList.remove('ok');
              note.textContent = 'That code didn’t match a team. Check it with your coach, or skip and connect later.';
              if (btn) btn.disabled = true;
            }
          } catch { /* directory unreachable — the code stays captured, note stays honest */ }
        }, 350);
      };
      const sync = () => {
        const v = el.value.toUpperCase().replace(/[^A-Z0-9]/g, '').slice(0, 12);
        if (el.value !== v) el.value = v;
        /* Client-flow mechanics (2026-08-25): empty means "no code" and Continue moves on;
           only a partial code disables. The old empty-disables gate made Skip the only way
           past a step most athletes legitimately have nothing to type into. */
        if (!v) {
          if (RT.ob && RT.ob.join && RT.ob.join.kind === 'team') capture({ join: null });
          el.classList.add('ok');
          note.textContent = HINT;
          if (btn) btn.disabled = false;
          return;
        }
        const ok = CODE_RE.test(v);
        /* An edited-away code must not leave a stale team join behind (it would
           flip the paywall to "covered" dishonestly). */
        capture({ join: ok ? { kind: 'team', code: v } : null });
        el.classList.toggle('ok', ok);
        if (btn) btn.disabled = !ok;
        if (!ok) { note.textContent = HINT; return; }
        note.textContent = 'Checking that code…';
        preview(v);
      };
      el.addEventListener('input', sync);
      sync();
    },
  },
  {
    id: 'account', ch: 4, noFoot: true,
    title: () => 'Your Standard is set.',
    sub: () => 'Create your account to save it. Your score, meals, and coach connection sync across devices.',
    body: () => `
      ${accountBody({ terms: 'ob' })}
      <div style="height:18px"></div>
      <div class="ob-foot" style="margin-top:auto">
        <button id="su-go" class="btn green" disabled>Create account &amp; Start</button>
      </div>`,
    mount(root, ctx) {
      wireAccount(root, {
        role: 'athlete',
        onSession: async (live) => {
          await act.persistOnboarding();
          if (live) {
            act.startDay0();
            // 0142 — apply the recommended plan style as both their self-choice and their
            // stated preference. Safe even for a team athlete: resolvePlanStyle's precedence
            // (team > pro > self) means a governing standard ignores this the moment one
            // exists, so this can never be how an athlete escapes a required standard.
            const o = RT.ob || {};
            if (o.structurePref) { try { await act.setPlanStyle(styleForStructureAnswer(o.structurePref)); } catch { /* best-effort */ } }
            /* Signed-in users may remain on `oba/*` (AUTH_ROUTES) — continue
               in-flow to the coverage/paywall step per the spec's ch4 order. */
            ctx.go(`${R}/${paywallVariant('athlete') === 'team_covered' ? 'covered' : 'plans'}`);
            return;
          }
          showConfirmPending(root, { email: RT.email });
        },
      });
    },
  },
  {
    id: 'covered', ch: 4, noFoot: true, next: () => null,
    when: () => paywallVariant('athlete') === 'team_covered',
    body: (o) => {
      const j = o.join || {};
      const code = j.code || '';
      /* Name the team when the directory confirmed it — a named team is proof the code
         actually resolved, not merely that it was well-formed. */
      const team = (j.teamName || '').trim();
      return `
        <div class="ob2-covered">
          <div class="halo"><div class="core">${icon('check', 34)}</div></div>
          <div class="ob-title" style="margin-top:18px">Covered by ${team ? esc(team) : 'your team'}</div>
          <div class="ob-sub" style="padding:0 8px">Your team code${code ? ` <b>${esc(code)}</b>` : ''} covers your access: no plans, no card, nothing to pay. Your coach's board is waiting for your first score.</div>
        </div>
        <div class="ob-foot" style="margin-top:auto">
          <button id="ob-enter" class="btn green">Enter OnStandard</button>
          <div class="ob2-scan-note">Today's standard is live. One photo starts it.</div>
        </div>`;
    },
    mount(root) {
      track(EVENTS.PAYWALL_VIEWED, { variant: 'team_covered' });
      root.querySelector('#ob-enter').addEventListener('click', goDestination);
    },
  },
  {
    id: 'plans', ch: 4, noFoot: true, next: () => null,
    when: () => paywallVariant('athlete') !== 'team_covered',
    title: () => 'Pick your plan',
    sub: () => 'The trial opens everything. Nothing charges today.',
    /* Annual-first, mirroring src/core/pricing.ts (revenue build 2026-07-04): annual is the
       framed default (saves ~2 months), one trust cue sits right above the price, and the
       auto-renew terms are disclosed on-screen. Selection is captured to RT.ob.{plan,cadence}
       as intent — billing is still go-live gated, nothing charges today. */
    body: (o) => {
      const cad = o.cadence || 'annual';
      const plan = o.plan || PLANS.individual[0].id;
      return `
      ${/* Deliberately NOT the Marcus quote from `proof` three screens back — the same
            words twice reads as one customer, not as proof. Launch placeholder either way. */''}
      <div class="ob2-scan-note">Illustrative, not actual customers yet.</div>
      ${testimonial({ quote: 'The photo takes five seconds. Knowing my trainer sees the score is what actually changed my weekends.', name: 'Dani', role: 'Soccer · college sophomore', initials: 'D', stat: '41 days', statKey: 'logging streak' })}
      <div class="ob2-cadence" role="tablist" aria-label="Billing period">
        <button class="cad ${cad === 'annual' ? 'on' : ''}" data-cad="annual" role="tab" aria-selected="${cad === 'annual'}">Annual<small>Save 30%</small></button>
        <button class="cad ${cad === 'monthly' ? 'on' : ''}" data-cad="monthly" role="tab" aria-selected="${cad === 'monthly'}">Monthly</button>
      </div>
      <div class="ob2-plans" id="ob-plans">
        ${PLANS.individual.map((p) => planCard({ ...p, cadence: cad, on: plan === p.id })).join('')}
      </div>
      <div style="height:16px"></div>
      <div class="ob-foot" style="margin-top:auto">
        <button id="ob-start" class="btn green">Start free, no card today</button>
        <div class="ob2-fine" id="ob-fine"></div>
        <div class="ob-textlink" style="padding-top:10px" data-go="${R}/connect">I have a code</div>
        <div class="ob2-scan-note">Today's standard is live. One photo starts it.</div>
      </div>`;
    },
    mount(root) {
      const o = () => (RT.ob || {});
      const cad = () => o().cadence || 'annual';
      const plan = () => o().plan || PLANS.individual[0].id;
      const fineFor = (c) => c === 'annual'
        ? 'Free for 7 days, then the yearly price. Cancel anytime in Settings before it ends.'
        : 'Free for 7 days, then the monthly price. Cancel anytime in Settings before it ends.';
      const render = () => {
        const list = root.querySelector('#ob-plans');
        list.innerHTML = PLANS.individual.map((p) => planCard({ ...p, cadence: cad(), on: plan() === p.id })).join('');
        list.querySelectorAll('.ob2-plan').forEach((el) => el.addEventListener('click', () => { capture({ plan: el.dataset.val }); track(EVENTS.PLAN_SELECTED, { plan: el.dataset.val, cadence: cad() }); render(); }));
        root.querySelectorAll('.ob2-cadence .cad').forEach((b) => {
          const on = b.dataset.cad === cad();
          b.classList.toggle('on', on); b.setAttribute('aria-selected', on);
        });
        root.querySelector('#ob-fine').textContent = fineFor(cad());
      };
      root.querySelectorAll('.ob2-cadence .cad').forEach((b) => b.addEventListener('click', () => { capture({ cadence: b.dataset.cad }); render(); }));
      /* Exposure: fire the moment the paywall is on screen — the report's non-negotiable for honest funnel math. */
      track(EVENTS.PAYWALL_VIEWED, { variant: paywallVariant('athlete'), cadence: cad() });
      render();
      root.querySelector('#ob-start').addEventListener('click', () => {
        /* Lock in the framed defaults if the user never tapped. Intent only — billing is go-live gated. */
        if (!o().plan) capture({ plan: PLANS.individual[0].id });
        if (!o().cadence) capture({ cadence: 'annual' });
        track(EVENTS.TRIAL_STARTED, { plan: plan(), cadence: cad() });
        goDestination();
      });
    },
  },
];

export const obAthlete = defineFlow({ route: R, steps });
