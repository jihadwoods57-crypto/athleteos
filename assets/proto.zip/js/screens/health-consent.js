import{icon}from"../icons.js";import{backHead,esc}from"../components.js";const native=()=>typeof window!=="undefined"?window.OnStandardNative:null;export const healthNative=()=>{const n=native();return n&&n.health?n.health:null};let AVAILABLE=null;let CONNECTED=false;let CONSENT=null;let IS_MINOR=null;let BUSY=false;let READING=null;async function probeReading(){const h=healthNative();if(!h||!h.readActivity){READING=false;return}const to=new Date;const from=new Date(to);from.setHours(0,0,0,0);const a=await h.readActivity(from.toISOString(),to.toISOString()).catch(()=>null);READING=!!(a&&(a.steps!=null||a.distanceMeters!=null||a.activeMinutes!=null||a.workouts&&a.workouts.length))}const bullet=(ic,title,body)=>`
  <div class="lrow" role="listitem" style="align-items:flex-start;cursor:default">
    <div class="lic" style="background:var(--blue-surface);color:var(--blue-bright)">${icon(ic,16)}</div>
    <div class="lm"><div class="lt">${esc(title)}</div><div class="ls">${esc(body)}</div></div>
  </div>`;async function probe(){const h=healthNative();AVAILABLE=h?await h.available().catch(()=>false):false;if(AVAILABLE&&h)CONNECTED=await h.connected().catch(()=>false);if(CONNECTED)await probeReading();const c=window.sb;if(!c)return;try{const{data:u}=await c.auth.getUser();const uid=u&&u.user&&u.user.id;if(!uid)return;const{data}=await c.rpc("has_health_consent",{p_athlete:uid});CONSENT=data===true;const{data:ap}=await c.from("athlete_profiles").select("base_age").eq("athlete_id",uid).maybeSingle();const age=ap&&ap.base_age;IS_MINOR=age==null?true:Number(age)<18}catch{}}export default{tab:"home",render(){const needsGuardian=IS_MINOR===true&&CONSENT!==true;return`${backHead("Connect Apple Health","Verify your standards automatically","connected-standards")}

    <section class="card pad">
      <div class="cs-h">Let your standards check themselves</div>
      <div class="cs-p" style="padding-top:6px">Your coach set an activity standard. With Health connected, OnStandard reads your totals and marks it complete on its own. No screenshots, no logging.</div>
    </section>

    <section class="card hc-card" role="list" style="padding:6px 16px">
      ${bullet("bolt","What OnStandard reads","Step count, walking and running distance, and workout totals, only for the standards assigned to you.")}
      ${bullet("shield","What your coach sees","How far you got toward the target they set, and whether it verified. Never your raw health data, your routes, or your history.")}
      ${bullet("clock","When it reads","While a standard is open, and once more after its deadline. Nothing is read on a day you have no standard.")}
      ${bullet("check","Your control","Turn it off any time: come back to this screen and tap Disconnect. Your phone's Health app can also cut access at any time.")}
    </section>

    ${CONSENT===null?`
      <section class="card pad hc-card"><div class="cs-p muted">Checking your account\u2026</div></section>`:needsGuardian?`
      <section class="card pad hc-card warn">
        <div class="cs-h">A parent or guardian has to approve this</div>
        <div class="cs-p" style="padding-top:6px">You\u2019re under 18, so we ask your guardian before reading any health data. Your own tap isn\u2019t enough, and the server enforces that too.</div>
        <button class="btn hc-act" data-go="guardian">Ask my guardian</button>
      </section>`:CONNECTED?READING===false?`
      <section class="card pad hc-card warn">
        <div class="cs-h">Connected, but nothing has come through</div>
        <div class="cs-p" style="padding-top:6px">Apple never tells an app which categories you allowed, so we checked instead: no activity has reached OnStandard yet. If you left anything unchecked on Apple's screen, open Health, then Sharing, then Apps, and switch OnStandard's categories on. Logging a standard by hand works either way.</div>
        <button class="btn ghost hc-act" id="hc-recheck">Check again</button>
        <button class="btn ghost hc-act tight" data-go="apple-health">How to turn categories on</button>
        <button class="btn ghost hc-act tight" id="hc-off">Disconnect</button>
      </section>`:`
      <section class="card pad hc-card good">
        <div class="cs-h">Connected</div>
        <div class="cs-p" style="padding-top:6px">Your standards are verifying themselves. You can disconnect any time.</div>
        <button class="btn ghost hc-act" id="hc-off">Disconnect</button>
      </section>`:AVAILABLE===false?`
      <section class="card pad hc-card"><div class="cs-p muted">Taking you back\u2026</div></section>`:`
      <div style="padding:12px 20px 0">
        <button class="btn" id="hc-go">Continue to Apple Health</button>
        <button class="btn ghost" data-go="connected-standards" style="margin-top:8px">Not now, I\u2019ll log manually</button>
      </div>`}

    <div class="cs-p muted" style="text-align:center;padding:14px 20px 24px">
      Connecting Health is separate from arrival check-ins. Turning one on doesn\u2019t turn on the other.
    </div>`},async mount(root){if(AVAILABLE===null||CONSENT===null){await probe();if(AVAILABLE===false){location.hash="#connected-standards";return}if(root.isConnected&&window.__render)window.__render();return}const go=root.querySelector("#hc-go");if(go)go.addEventListener("click",async()=>{if(BUSY)return;BUSY=true;go.disabled=true;go.textContent="Opening\u2026";try{const c=window.sb;const{data:u}=await c.auth.getUser();const uid=u&&u.user&&u.user.id;const{error}=await c.rpc("grant_health_consent",{p_athlete:uid,p_kind:"self"});if(error){BUSY=false;go.disabled=false;go.textContent="Couldn\u2019t save. Try again";return}const h=healthNative();const res=h&&h.connectScoped?await h.connectScoped(["activity"]).catch(()=>({connected:false})):{connected:false};CONNECTED=!!(res&&res.connected);CONSENT=true;if(!CONNECTED){try{const{error:revokeErr}=await c.rpc("revoke_health_consent",{p_athlete:uid});if(!revokeErr)CONSENT=false}catch{}}if(CONNECTED)await probeReading();if(CONNECTED&&h&&h.observeActivity)await h.observeActivity().catch(()=>false)}finally{BUSY=false;if(window.__render)window.__render()}});const recheck=root.querySelector("#hc-recheck");if(recheck)recheck.addEventListener("click",async()=>{recheck.disabled=true;recheck.textContent="Checking\u2026";await probeReading();if(window.__render)window.__render()});const off=root.querySelector("#hc-off");if(off)off.addEventListener("click",async()=>{off.disabled=true;off.textContent="Disconnecting\u2026";try{const c=window.sb;const{data:u}=await c.auth.getUser();const uid=u&&u.user&&u.user.id;await c.rpc("revoke_health_consent",{p_athlete:uid});CONNECTED=false;CONSENT=false;READING=null}catch{}if(window.__render)window.__render()})}};export function refreshHealthConsent(){AVAILABLE=null;CONSENT=null;CONNECTED=false;READING=null}
