import{S,RT,act}from"../state.js";import{icon}from"../icons.js";import{backHead,esc}from"../components.js";import{dir,CODE_RE}from"../ob-directory.js";let justJoined=null;let preview=null;const subCode=sub=>String(sub||"").match(/^[A-Za-z0-9]{4,12}$/)?String(sub).toUpperCase():"";export default{tab:"profile",render({sub}={}){const c=S.coach;if(c.hasCoach||justJoined){const wasPractice=justJoined==="practice"&&!c.hasCoach;const isTrainer=wasPractice||c.kind==="trainer";justJoined=null;preview=null;const title=c.isNamed?esc(c.name):isTrainer?"Connected to your trainer":esc(c.team||"Connected");const sub2=isTrainer?`${c.team?esc(c.team)+" now sees":"Your trainer now sees"} your recovery, readiness, and nutrition consistency.`:`${esc(c.team||"Your team")} now sees your daily score, requirement completion, meal logs, and check-ins.`;return`
      ${backHead(isTrainer?"Connect a Trainer":"Connect a Coach","Connected","profile")}
      <div class="state-demo" style="border-style:solid;border-color:var(--green-border)">
        <div class="sd-ic" style="background:var(--green-surface);color:var(--green-bright)">${icon("check",24)}</div>
        <div class="sd-t">${title}</div>
        <div class="sd-s">${sub2}</div>
      </div>
      ${isTrainer?"":'<div id="ap-slot"></div>'}
      ${!isTrainer&&RT.myRoomLabel?`
      <div class="lrow" style="cursor:default;margin-top:10px">
        <div class="lic" style="background:var(--blue-surface);color:var(--blue-bright)">${icon("users",17)}</div>
        <div class="lm"><div class="lt">Your room</div><div class="ls">${esc(RT.myRoomLabel)} \xB7 your standard follows this room</div></div>
      </div>`:""}
      ${""}
      <h2 class="eyebrow">Next</h2>
      <div class="lrow" data-go="plan">
        <div class="req-icon g s38">${icon("clipboard",17)}</div>
        <div class="lm"><div class="lt">See what ${c.isNamed?esc(c.name):isTrainer?"your trainer":"your coach"} set for you</div><div class="ls">Your requirements, targets, and when each one is due</div></div>
        ${icon("chevron",16,'class="req-chev"')}
      </div>
      <div class="lrow" data-go="home">
        <div class="req-icon b s38">${icon("camera",17)}</div>
        <div class="lm"><div class="lt">Log your first requirement</div><div class="ls">Your score starts moving with the first one</div></div>
        ${icon("chevron",16,'class="req-chev"')}
      </div>
      <div style="height:10px"></div>
      `}if(preview){const isTeam=preview.kind!=="practice";return`
      ${backHead("Confirm connection","Check this is your team before you join","connect")}
      <section class="card team-preview" style="margin-top:8px">
        <div class="tp-av">${esc((preview.name||"T").slice(0,2).toUpperCase())}</div>
        <div style="flex:1">
          <div style="font-size:16.5px;font-weight:800">${esc(preview.name||(isTeam?"Your team":"Your trainer"))}</div>
          ${preview.teamName?`<div style="font-size:12.5px;font-weight:600;color:var(--text-2);margin-top:2px">${esc(preview.teamName)}</div>`:""}
          <div style="font-size:11.5px;font-weight:700;color:var(--text-3);margin-top:3px">Code ${esc(preview.code)}</div>
        </div>
      </section>
      <div class="sidebox" style="margin-top:12px">
        <div class="req-icon b s38">${icon("eye",17)}</div>
        <div><div class="tt">What they'll see</div>
        <div class="ts">${isTeam?"This coach will see your score, requirements, meal logs, and check-ins.":"This trainer will see your recovery, readiness, and nutrition consistency."}</div></div>
      </div>
      <div id="cc-err" role="alert" aria-live="assertive" style="color:var(--red-bright);font-size:13px;font-weight:600;min-height:18px;margin-top:12px;text-align:center"></div>
      <button class="btn primary" id="cc-confirm">${icon("check",18)} Connect to ${esc(preview.name||"this team")}</button>
      <div style="height:8px"></div>
      <button class="btn ghost sm" id="cc-cancel">Not my team? Re-enter the code</button>
      <div style="height:10px"></div>
      `}return`
    ${backHead("Connect a coach or trainer","Enter the code they gave you","profile")}

    <div style="height:14px"></div>
    <input id="cc-code" class="ob-input" placeholder="Team or trainer code" aria-label="Coach or trainer code" aria-describedby="cc-err"
      autocapitalize="characters" autocorrect="off" spellcheck="false" enterkeyhint="go"
      value="${esc(subCode(sub))}"
      style="text-align:center;letter-spacing:0.2em;font-weight:800;text-transform:uppercase" />
    <div style="text-align:center;font-size:12.5px;font-weight:600;color:var(--text-3);margin-top:10px">Ask your coach or team group chat for the code. Trainer codes work here too.</div>
    <div id="cc-err" role="alert" aria-live="assertive" style="color:var(--red-bright);font-size:13px;font-weight:600;min-height:18px;margin-top:10px;text-align:center"></div>

    <div style="height:6px"></div>
    <button class="btn primary" id="cc-join" disabled style="opacity:.5">Continue</button>

    <div style="height:14px"></div>
    <div class="sidebox">
      <div class="req-icon b s38">${icon("shield",18)}</div>
      <div><div class="tt">Nothing is shared until you confirm</div>
      <div class="ts">You'll see exactly which team the code belongs to, and what they can see, before you join.</div></div>
    </div>
    <div style="height:10px"></div>
    `},mount(root){const apSlot=root.querySelector("#ap-slot");if(apSlot)void import("../alarm-primer.js").then(AP=>AP.mountAlarmPrimer(apSlot,{onTeam:true}),()=>{});const err=root.querySelector("#cc-err");const confirmBtn=root.querySelector("#cc-confirm");if(confirmBtn){confirmBtn.addEventListener("click",async()=>{if(confirmBtn.disabled||!preview)return;confirmBtn.disabled=true;confirmBtn.textContent="Connecting\u2026";const r=await act.joinByCode(preview.code);if(r.ok){justJoined=r.kind;window.__render();return}err.textContent=r.error||"Could not connect. Try again.";confirmBtn.disabled=false;confirmBtn.textContent="Connect"});const cancel=root.querySelector("#cc-cancel");if(cancel)cancel.addEventListener("click",()=>{preview=null;window.__render()});return}const input=root.querySelector("#cc-code");const btn=root.querySelector("#cc-join");if(!btn||!input)return;const normalize=()=>{const v=input.value.replace(/\s+/g,"").toUpperCase();if(v!==input.value)input.value=v;const ok=v.length>=4;btn.disabled=!ok;btn.style.opacity=ok?"1":".5"};input.addEventListener("input",normalize);input.addEventListener("paste",()=>setTimeout(normalize,0));normalize();const fail=m=>{err.textContent=m;input.setAttribute("aria-invalid","true")};const submit=async()=>{if(btn.disabled)return;err.textContent="";input.removeAttribute("aria-invalid");const code=input.value.replace(/\s+/g,"").toUpperCase();if(!code){fail("Enter the code first.");return}if(!CODE_RE.test(code)){fail("Codes are 4\u201312 letters and numbers. Check it and try again.");return}if(!navigator.onLine){err.textContent="You need a connection for this. Try again when you're online.";return}btn.disabled=true;const was=btn.textContent;btn.textContent="Checking\u2026";try{const{match}=await dir.previewCode(code);if(match){preview={code,kind:match.kind==="practice"?"practice":"team",name:match.name||(match.kind==="practice"?"Your trainer":"Your team"),teamName:match.kind==="practice"?match.trainer_name?`Trainer ${match.trainer_name}`:null:[match.coach_name?`Coach ${match.coach_name}`:null,match.school||null].filter(Boolean).join(" \xB7 ")||null};window.__render();return}fail("That code didn't match a team or practice. Check it with your coach and try again.")}catch{const r=await act.joinByCode(code);if(r.ok){justJoined=r.kind;window.__render();return}err.textContent=r.error||"Could not connect. Try again."}btn.disabled=false;btn.textContent=was};btn.addEventListener("click",submit);input.addEventListener("keydown",e=>{if(e.key==="Enter"&&!e.isComposing)submit()})}};
