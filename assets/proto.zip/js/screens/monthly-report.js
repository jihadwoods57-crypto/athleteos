import{backHead,esc,skeletonRows,errorState}from"../components.js";import{icon}from"../icons.js";import{S}from"../state.js";import*as roles from"../roles.js";import{buildMonthPayload}from"../monthly.js";import{track,EVENTS}from"../analytics.js";import{monthYear,shortDate}from"../fmt-date.js";import{shareScoreCard}from"../share-card.js";import{planById,effectiveMonthly,fmtPrice}from"../pricing.js";let CACHE={report:null,period:null,loaded:false,payload:null,paywallFired:false};function isLockedReport(report){return!!(report&&report.error&&/requires a plan/i.test(String(report.error)))}function lastCompletedPeriod(){const now=new Date;const prev=new Date(now.getFullYear(),now.getMonth()-1,1);return`${prev.getFullYear()}-${String(prev.getMonth()+1).padStart(2,"0")}`}function monthLabel(period){const[y,m]=String(period).split("-").map(Number);if(!y||!m)return period;return monthYear(new Date(y,m-1,1))}const dayLabel=iso=>shortDate(iso);async function load(force){if(CACHE.loaded&&!force)return;const period=lastCompletedPeriod();CACHE.period=period;try{const days=(S.history||[]).map(h=>({date:h.iso,score:h.score,weight:h.weight}));CACHE.payload=buildMonthPayload(days,period);CACHE.report=await roles.fetchMonthlyReport(period,CACHE.payload)}catch(e){CACHE.report={error:String(e&&e.message||e)}}CACHE.loaded=true;if(isLockedReport(CACHE.report)&&!CACHE.paywallFired){CACHE.paywallFired=true;track(EVENTS.PAYWALL_VIEWED,{variant:"monthly_locked",cadence:"annual"})}if(window.__render)window.__render()}function shareReport(report,period){void shareScoreCard({score:report&&report.avgScore!=null?report.avgScore:null,eyebrow:monthLabel(period),caption:"Average daily score",stats:[["Days logged",report&&report.loggedDays!=null?String(report.loggedDays):"\u2014"],["Best streak",report&&report.streakBest!=null?`${report.streakBest} days`:"\u2014"],["Best day",report&&report.bestDay?`${dayLabel(report.bestDay.date)} \xB7 ${report.bestDay.score}`:"\u2014"]]},"My OnStandard month")}function statBlock(k,v){return`<div class="stat"><div class="v">${esc(v)}</div><div class="k">${esc(k)}</div></div>`}function weightChangeStr(report){return report.weightStart!=null&&report.weightEnd!=null?`${report.weightEnd-report.weightStart>0?"+":""}${(report.weightEnd-report.weightStart).toFixed(1)} lb`:"\u2014"}function baseStatsBlock(report){return`
  <div class="base-stats">
    ${statBlock("Best day",report.bestDay?`${dayLabel(report.bestDay.date)} \xB7 ${report.bestDay.score}`:"\u2014")}
    ${statBlock("Worst day",report.worstDay?`${dayLabel(report.worstDay.date)} \xB7 ${report.worstDay.score}`:"\u2014")}
    ${statBlock("Weight change",weightChangeStr(report))}
    ${statBlock("Best streak",report.streakBest!=null?`${report.streakBest} day${report.streakBest===1?"":"s"}`:"\u2014")}
  </div>`}function lockedCard(payload,period){const report=payload||{};const monthWord=esc(monthLabel(period)).split(" ")[0];const plan=planById("individual");const trialLine=plan?`${plan.name}: free for ${plan.trialDays} days, then ${fmtPrice(effectiveMonthly(plan))}/mo billed annually. No card today.`:"Individual: free trial first. No card today.";return`
  <section class="card pad">
    <div class="bigstat"><span class="n">${report.avgScore!=null?report.avgScore:"\u2014"}</span><span class="d">Average score</span></div>
    <div style="font-size:13px;font-weight:600;color:var(--text-2);margin-top:2px">${esc(monthLabel(period))} \xB7 ${report.loggedDays||0} day${report.loggedDays===1?"":"s"} logged</div>
    ${report.loggedDays?`<div style="height:8px"></div><span class="status-pill g">Your month, already counted</span>`:""}
  </section>

  <div style="height:14px"></div>
  ${baseStatsBlock(report)}

  <div style="height:16px"></div>
  <h2 class="eyebrow">AI coach's read</h2>
  <section class="card pad mr-locked">
    <div class="mr-skel" aria-hidden="true">
      <div class="mr-skel-line" style="width:78%"></div>
      <div class="mr-skel-line" style="width:94%"></div>
      <div class="mr-skel-line" style="width:60%"></div>
    </div>
    <div class="mr-veil">
      <span class="status-pill b" style="display:inline-flex;align-items:center;gap:5px" aria-label="Premium, locked">${icon("lock",12)} Premium</span>
      <div class="mr-veil-t">A written read on your ${monthWord}</div>
      <div class="mr-veil-s">Your three biggest wins, one focus for next month, and a coach's-voice summary.</div>
    </div>
  </section>

  <div style="height:16px"></div>
  <h2 class="eyebrow">Unlock the full report</h2>
  <section class="card pad">
    <button class="btn primary" id="mr-trial" style="width:100%">Start free trial</button>
    <div style="text-align:center;font-size:11.5px;font-weight:600;color:var(--text-3);margin-top:8px;line-height:1.4">${esc(trialLine)}</div>
    <div class="mr-or">or unlock now</div>
    <div class="sidebox flat mr-coderow" data-go="redeem-code" role="button" aria-label="Redeem a sponsor code to unlock premium instantly">
      <div class="req-icon b s38">${icon("key",17)}</div>
      <div><div class="tt">Have a sponsor code?</div><div class="ts">Redeem it to unlock premium instantly</div></div>
    </div>
  </section>

  <div style="height:14px"></div>
  <div style="text-align:center;font-size:11.5px;font-weight:600;color:var(--text-3);padding:0 20px;line-height:1.4">Your stats are always yours. Premium adds the written coaching, not the numbers.</div>
  <div style="height:10px"></div>
  `}function reportBody(report,period){const wins=Array.isArray(report.wins)?report.wins:report.wins?[report.wins]:[];const focus=Array.isArray(report.focus)?report.focus:report.focus?[report.focus]:[];return`
  <section class="card pad">
    <div class="bigstat"><span class="n">${report.avgScore!=null?report.avgScore:"\u2014"}</span><span class="d">Average score</span></div>
    <div style="font-size:13px;font-weight:600;color:var(--text-2);margin-top:2px">${esc(monthLabel(period))} \xB7 ${report.loggedDays||0} day${report.loggedDays===1?"":"s"} logged</div>
  </section>

  <div style="height:14px"></div>
  ${baseStatsBlock(report)}

  ${report.headline||report.narrative?`
  <div style="height:16px"></div>
  <h2 class="eyebrow">AI coach's read</h2>
  <section class="card pad">
    ${report.headline?`<div style="font-size:16px;font-weight:800">${esc(report.headline)}</div>`:""}
    ${report.narrative?`<p style="font-size:13.5px;font-weight:600;color:var(--text-2);margin-top:8px;line-height:1.5">${esc(report.narrative)}</p>`:""}
  </section>`:""}

  ${wins.length?`
  <div style="height:14px"></div>
  <h2 class="eyebrow">Wins</h2>
  <section class="card pad" style="padding-top:8px;padding-bottom:8px" role="list">
    ${wins.map(w=>`<div class="lrow" role="listitem" style="cursor:default"><div class="lic">${icon("check",16)}</div><div class="lm"><div class="ls">${esc(w)}</div></div></div>`).join("")}
  </section>`:""}

  ${focus.length?`
  <div style="height:14px"></div>
  <h2 class="eyebrow">Focus for next month</h2>
  <section class="card pad" style="padding-top:8px;padding-bottom:8px" role="list">
    ${focus.map(f=>`<div class="lrow" role="listitem" style="cursor:default"><div class="lic">${icon("target",16)}</div><div class="lm"><div class="ls">${esc(f)}</div></div></div>`).join("")}
  </section>`:""}

  <div style="height:16px"></div>
  <button class="btn primary sm" id="mr-share" style="width:auto;padding:0 22px">${icon("share",16)} Share</button>
  <div style="height:10px"></div>
  `}export default{tab:"progress",render(){if(!CACHE.loaded){return`${backHead("Monthly report","Your month in review","progress")}
      ${skeletonRows(4,"Building your monthly report")}`}const report=CACHE.report;const period=CACHE.period;const locked=isLockedReport(report);return`${backHead("Monthly report",esc(monthLabel(period)),"progress")}
    ${locked?lockedCard(CACHE.payload,period):report&&!report.error?reportBody(report,period):`
      ${errorState({title:"Couldn't build your report",body:"Your month is safe. This is the connection, not your record. Try again in a moment.",retryId:"mr-retry"})}`}
    `},mount(root){load();const retry=root.querySelector("#mr-retry");if(retry)retry.addEventListener("click",()=>{CACHE.loaded=false;if(window.__render)window.__render();load(true)});const share=root.querySelector("#mr-share");if(share)share.addEventListener("click",()=>shareReport(CACHE.report,CACHE.period));const trial=root.querySelector("#mr-trial");if(trial)trial.addEventListener("click",()=>{track(EVENTS.PAYWALL_CTA?EVENTS.PAYWALL_CTA:EVENTS.TRIAL_STARTED,{plan:"individual",cadence:"annual",from:"monthly_locked"});if(window.__go)window.__go("paywall");else location.hash="#paywall"})}};
