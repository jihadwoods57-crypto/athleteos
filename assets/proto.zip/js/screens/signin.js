import{logoMark}from"../components.js";import{icon}from"../icons.js";import{RT,act,routeForRole}from"../state.js";import{socialAvailability,socialButtonHtml,socialSignIn,readIdentity,isNewIdentity,isFreshUser,noteSsoNew}from"../social-auth.js";const EMAIL_RE=/^[^\s@]+@[^\s@]+\.[^\s@]+$/;export default{hideTabs:true,render(){return`
    <div class="ob-nav si-nav"><button type="button" class="ob-back" data-go="welcome" aria-label="Back">${icon("chevron",18)}</button></div>
    <div class="si">
      <div class="si-logo">${logoMark(60,"welcome")}</div>
      <div class="si-mark"><span class="on">On</span>Standard</div>
      <h1 class="si-title">Welcome back</h1>
      <div class="si-sub">Continue building your standard.</div>

      <div class="si-form">
        <div class="si-field">
          <label class="si-label" for="si-email">Email</label>
          <div class="si-wrap">
            <span class="si-lead">${icon("mail",20)}</span>
            <input id="si-email" class="ob-input si-input" type="email" inputmode="email" autocomplete="username" autocapitalize="none" autocorrect="off" spellcheck="false" placeholder="name@email.com" aria-label="Email" aria-describedby="si-email-err" aria-invalid="false">
          </div>
          <div id="si-email-err" class="si-field-err" aria-live="polite"></div>
        </div>
        <div class="si-field">
          <div class="si-label-row"><label class="si-label" for="si-pass">Password</label><button type="button" class="si-forgot" data-go="reset">Forgot password?</button></div>
          <div class="si-wrap">
            <span class="si-lead">${icon("lock",20)}</span>
            <input id="si-pass" class="ob-input si-input" type="password" autocomplete="current-password" placeholder="Password" aria-label="Password" aria-describedby="si-err" aria-invalid="false">
            <button type="button" class="si-eye" id="si-eye" aria-label="Show password"><span class="eye-show">${icon("eye",20)}</span><span class="eye-hide">${icon("eyeOff",20)}</span></button>
          </div>
          <div id="si-caps" class="si-field-hint" style="display:none">Caps Lock is on</div>
        </div>
      </div>

      <div id="si-err" class="si-err" aria-live="polite"></div>

      <button id="si-go" class="btn primary si-cta"><span class="si-go-label">Sign in</span><span class="si-arrow" aria-hidden="true">${icon("arrowRight",18)}</span></button>

      <div class="si-social" id="si-social" style="display:none">
        <div class="si-or"><span></span>or<span></span></div>
        <div class="sso-wrap" id="si-sso"></div>
      </div>

      <div class="si-create">New to OnStandard? <button class="si-link" data-go="role">Create an account</button></div>
    </div>`},mount(root){const go=window.__go;const emailEl=root.querySelector("#si-email");const passEl=root.querySelector("#si-pass");const err=root.querySelector("#si-err");const emailErr=root.querySelector("#si-email-err");const caps=root.querySelector("#si-caps");const eye=root.querySelector("#si-eye");const btn=root.querySelector("#si-go");const label=root.querySelector(".si-go-label");if(RT.email&&!emailEl.value){emailEl.value=RT.email}if(emailEl.value){passEl.focus()}eye.addEventListener("click",()=>{const show=passEl.type==="password";passEl.type=show?"text":"password";eye.classList.toggle("on",show);eye.setAttribute("aria-label",show?"Hide password":"Show password")});const capsCheck=e=>{try{caps.style.display=e.getModifierState&&e.getModifierState("CapsLock")?"block":"none"}catch{}};passEl.addEventListener("keydown",capsCheck);passEl.addEventListener("keyup",capsCheck);passEl.addEventListener("blur",()=>{caps.style.display="none"});const setEmailErr=msg=>{emailErr.textContent=msg;emailEl.setAttribute("aria-invalid",msg?"true":"false")};const setErr=msg=>{err.textContent=msg;passEl.setAttribute("aria-invalid",msg?"true":"false");if(msg&&!(emailEl.value||"").trim())emailEl.setAttribute("aria-invalid","true")};emailEl.addEventListener("blur",()=>{const v=(emailEl.value||"").trim();setEmailErr(v&&!EMAIL_RE.test(v)?"Enter a valid email address.":"")});emailEl.addEventListener("focus",()=>{setEmailErr("")});const setLoading=on=>{btn.disabled=on;btn.classList.toggle("loading",on);label.textContent=on?"Signing in\u2026":"Sign in"};const submit=async()=>{if(btn.disabled)return;setErr("");const email=(emailEl.value||"").trim().toLowerCase();const password=passEl.value||"";if(!email||!password){setErr("Enter your email and password.");return}if(!EMAIL_RE.test(email)){setEmailErr("Enter a valid email address.");return}if(typeof navigator!=="undefined"&&navigator.onLine===false){setErr("You're offline. Check your connection and try again.");return}setLoading(true);const r=await act.signIn(email,password);if(r.ok){go(routeForRole(r.role))}else{setErr(r.error||"That didn't go through. Try again in a moment.");setLoading(false)}};btn.addEventListener("click",submit);emailEl.addEventListener("keydown",e=>{if(e.key==="Enter"&&!e.isComposing)submit()});passEl.addEventListener("keydown",e=>{if(e.key==="Enter"&&!e.isComposing)submit()});const wireSocial=async()=>{const avail=await socialAvailability();const wrap=root.querySelector("#si-sso");const social=root.querySelector("#si-social");if(!wrap||!social||!avail.apple)return;wrap.innerHTML=socialButtonHtml("apple","si")+(avail.google?socialButtonHtml("google","si"):"");social.style.display="block";wrap.querySelectorAll("button").forEach(sbtn=>sbtn.addEventListener("click",async()=>{if(sbtn.disabled)return;const provider=sbtn.id==="si-google"?"google":"apple";const label2=provider==="google"?"Google":"Apple";err.textContent="";sbtn.disabled=true;const r=await socialSignIn(provider);if(r.cancelled){sbtn.disabled=false;return}if(!r.user){err.textContent=label2+" sign-in didn't complete. Try email instead.";sbtn.disabled=false;return}const id=await readIdentity(r.user.id);const isNew=id.known?isNewIdentity(r.user,id.prof):isFreshUser(r.user);if(isNew){try{await window.sb.auth.signOut()}catch{}noteSsoNew(r.user.id,provider);go("role");return}if(!id.known){try{await window.sb.auth.signOut()}catch{}err.textContent="Couldn't load your account just now. Try again in a moment.";sbtn.disabled=false;return}await act._syncSession(r.user);const final=id.prof&&id.prof.primary_role||"athlete";act.setAuthRole(final);if(final==="athlete"){try{await act.checkAgeKnown()}catch{}}go(routeForRole(final))}))};void wireSocial()}};
