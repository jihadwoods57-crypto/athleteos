import{icon}from"../icons.js";import{esc}from"../components.js";import{csStatus,remainingLabel,syncedLabel,paceToGoal,activeOn,completedLabel,fmtValue,unitNoun,toDisplay,isComplete,columnGeometry}from"../connected-standards.js";import{todayISO}from"../connected-standard-data.js";export const PILL={green:"g",cyan:"b",blue:"b",purple:"p",amber:"a",red:"r",slate:"muted"};export const pillFor=status=>PILL[csStatus(status).tone]||"muted";export const METRIC_ICON={steps:"bolt",distance:"bolt",workouts:"bolt",workout_minutes:"clock",active_minutes:"clock"};export function column(geo,{mini=false}={}){const cls=["cscol",geo.state,mini?"mini":"",geo.behind?"behind":""].filter(Boolean).join(" ");if(geo.state==="unknown"){return`<div class="${cls}"><span class="qm" aria-hidden="true">?</span></div>`}return`<div class="${cls}">
    ${geo.state==="partial"?'<span class="hatch"></span>':""}
    <span class="fill" style="height:${geo.fillPct}%" data-fill="${geo.fillPct}"></span>
    ${geo.notchPct!=null?`<span class="notch" style="bottom:${geo.notchPct}%"></span>`:""}
  </div>`}export function countAttrs(value,metric,unit){const shown=fmtValue(value,metric,unit);const dec=(shown.split(".")[1]||"").length;return{shown,attrs:`data-cs-count="${toDisplay(value,metric,unit)}" data-cs-dec="${dec}"`}}export function standardRow(row,todayIso){const st=csStatus(row.status);const pace=paceToGoal(row,todayIso);const geo=columnGeometry(row,pace);const done=isComplete(row.status);const id=esc(row.result_id||"");const sub=done?esc(completedLabel(row)):row.status==="awaiting_sync"?"Your watch hasn\u2019t reported yet. This won\u2019t count against you":row.status==="disconnected"?"Health access is off. Reconnect or log it by hand":row.status==="awaiting_review"?"Sent to your coach for review":row.status==="excused"?esc(row.excused_reason||"Excused by your coach"):pace?`${esc(pace.label)}${pace.needLabel?` \xB7 ${esc(pace.needLabel)}`:""}`:esc(remainingLabel(row)||syncedLabel(row,void 0,todayIso));const progress=geo.state==="unknown"?"\u2014":`${esc(fmtValue(row.progress,row.metric,row.display_unit))}${geo.state==="partial"?"+":""}`;return`<div class="cs-srow" data-cs-open="${id}">
    ${column(geo,{mini:true})}
    <div class="mid">
      <div class="t">${esc(row.title||"Standard")}</div>
      <div class="n">${progress} <em>/ ${esc(fmtValue(row.target,row.metric,row.display_unit))} ${esc(unitNoun(row.metric,row.display_unit,row.target))}</em></div>
      <div class="m${geo.state==="partial"?" amber":""}">${sub}</div>
    </div>
    <span class="status-pill ${pillFor(row.status)}">${esc(st.label)}</span>
  </div>`}export function standardsCard(rows,todayIso){const today=activeOn(rows,todayIso||todayISO());if(!today.length)return"";return`<section class="card cs-card">
    <div class="cs-head">
      <h2 class="cs-eyebrow">TODAY\u2019S STANDARDS</h2>
      <span class="note">Tracked \xB7 not scored</span>
    </div>
    ${today.map(r=>standardRow(r,todayIso||todayISO())).join("")}
  </section>`}export function standardsOfflineCard(){return`<div class="xrow-item" style="border-color:var(--hairline)">
    <div class="xico sm" style="background:var(--surface-2);color:var(--text-3)">${icon("wifiOff",16)}</div>
    <div class="xr"><div class="xa">Activity standard isn\u2019t loading</div>
    <div class="xb">If your coach set one, it shows the moment you reconnect. Nothing is lost.</div></div>
    <button class="btn ghost sm" data-cs-retry style="width:auto;padding:0 14px;height:44px;flex:none">Try again</button>
  </div>`}export function mountStandardsCard(root){root.querySelectorAll("[data-cs-open]").forEach(el=>el.addEventListener("click",ev=>{if(ev.target.closest("button"))return;location.hash=`#connected-standard/${el.getAttribute("data-cs-open")}`}))}
