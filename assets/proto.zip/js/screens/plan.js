import{S,RT,act}from"../state.js";import{icon}from"../icons.js";import{esc,skeletonRows,errorState}from"../components.js";import{PROOF,freqLabel,fmtMin}from"../requirements.js";import{accentVar}from"../score-band.js";import{foodMemory}from"../food-memory-data.js";import{shortDateYear}from"../fmt-date.js";import{recentRows}from"../recent-meals.js";import{findRepeats,mealSignature,rankForRemaining,remainingToday}from"../food-memory.js";import{askSuggestions}from"../plan-ask.js";let FACTS={uid:null,rows:null};let GOAL_OPEN=false;const PLAN_SUBS=["overview","nutrition","requirements","memory"];const SUB_ALIAS={notes:"memory",schedule:"requirements",food:"memory"};function planSub(sub){const raw=sub||"overview";const t=SUB_ALIAS[raw]||raw;if(PLAN_SUBS.includes(t))return t;console.warn("[plan] unknown sub-tab",JSON.stringify(sub),"- showing Overview");return"overview"}function tabs(active){const T=[["overview","Today"],["nutrition","Nutrition"],["requirements","Requirements"],["memory","Food Memory"]];return`<div class="ptabs">${T.map(([k,l])=>`<div class="pt ${k===active?"on":""}" data-go="plan/${k}">${l}</div>`).join("")}<i class="pt-ink" aria-hidden="true"></i></div>`}let INK_AT=null;let INK_GEO=null;const INK_BASE=100;function placeInk(strip,on){if(!strip||!on)return;const ink=strip.querySelector(".pt-ink");if(!ink)return;const key=on.getAttribute("data-go")||"";const geo={left:on.offsetLeft,width:on.offsetWidth};if(!geo.width)return;const at=g=>`translateX(${g.left}px) scaleX(${g.width/INK_BASE})`;const travelling=INK_AT&&INK_AT!==key&&INK_GEO;if(travelling){ink.style.transition="none";ink.style.transform=at(INK_GEO);void ink.offsetWidth;ink.style.transition=""}else{ink.style.transition="none"}ink.style.transform=at(geo);if(!travelling){void ink.offsetWidth;ink.style.transition=""}INK_AT=key;INK_GEO=geo}const HEAD_SUBTITLE=(who,hasTargets)=>({set:hasTargets?`Targets set by your ${who}`:`Plan style set by your ${who}`,loading:"Loading your targets\u2026",offline:"Offline \xB7 targets return when you reconnect",unset:S.coach.hasCoach?`Your ${who} can set targets`:"Scored on the standard itself"});const fmtDate=iso=>shortDateYear(iso)||null;function goalPanel(){if(!GOAL_OPEN)return"";const g=S.planGoal;const rows=[];const row=(k,v)=>rows.push(`<div class="pl-gp-row"><div class="pl-gp-k">${esc(k)}</div><div class="pl-gp-v">${v}</div></div>`);row("Goal",esc(g.label||"Not set"));if(g.current!=null)row("Current",`${esc(String(g.current))} ${esc(g.unit)}`);if(g.target!=null)row("Target",`${esc(String(g.target))} ${esc(g.unit)}`);if(g.start!=null&&g.target!=null)row("Started at",`${esc(String(g.start))} ${esc(g.unit)}`);if(g.moved)row("Moved",`${esc(g.moved)}${g.pace?` \xB7 ${esc(g.pace)}`:""}`);if(g.startedOn)row("Tracking since",esc(fmtDate(g.startedOn)||g.startedOn));row("Set by",g.label?"You, at signup":"Nobody yet");if(g.targetsAreCoachSet)row("Targets",g.targetsSetBy?`Set by ${esc(g.targetsSetBy)}`:`Set by your ${esc(S.coach.noun)}`);else if(g.derivedProtein){const bits=[];if(S.planStyle.showMacros)bits.push(`${g.derivedProtein}g protein`);if(S.planStyle.showCalories&&g.derivedCalories)bits.push(`${g.derivedCalories} kcal`);if(bits.length)row("Targets",`From your goal \xB7 ${bits.join(", ")}`)}const note=g.strategy?`${esc(g.strategy)} Weight is tracked for the trend and never counts toward your daily score.`:"Pick a goal in your profile and OnStandard shapes your targets and scoring around it.";return`<div class="pl-goalpanel" id="pl-goal-panel">
    ${rows.join("")}
    <div class="pl-gp-note">${note}</div>
    <div style="margin-top:12px"><button class="btn ghost xs" data-go="profile" style="width:auto">Edit in profile</button></div>
  </div>`}function head(t){const goal=S.planGoalLabel;const sub=t==="requirements"?"Every rule of your standard":t==="memory"?"What OnStandard has learned":t==="nutrition"?"Targets and scoring":HEAD_SUBTITLE(S.coach.noun,S.planStyle.showMacros||S.planStyle.showCalories)[S.planTargetsState];const pill=goal?`<button type="button" class="pl-goalpill" id="pl-goal" aria-expanded="${GOAL_OPEN?"true":"false"}" aria-controls="pl-goal-panel">Goal \xB7 ${esc(goal)}<span class="cv">${icon("chevron",12)}</span></button>`:`<button type="button" class="pl-goalpill" data-go="profile">Set a goal<span class="cv">${icon("chevron",12)}</span></button>`;return`
  <h1 class="screen-title">Plan</h1>
  <div class="pl-head"><div class="pl-sub">${esc(sub)}</div>${pill}</div>
  ${goalPanel()}`}const loadingCard=()=>skeletonRows(2,"Loading your targets");const offlineCard=()=>errorState({title:"Can't reach your plan",body:"Your targets will show when you reconnect. Nothing is lost, and logging still counts in the meantime.",retryId:"plan-retry"});const PILL_ACCENT={green:"g",red:"r",gold:"a",gray:"muted",blue:"b",purple:"p"};function todayRows(){let e;try{e=S.exec}catch{return null}return e.items.map(i=>({id:i.id,title:i.title,icon:i.icon,color:i.color,pill:i.pill,accent:i.accent||"b",sub:i.sub||i.dueLabel,route:i.route,done:i.state==="done"||i.state==="done_late"}))}function todaySection(){const rows=todayRows();if(!rows||!rows.length)return"";const done=rows.filter(r=>r.done).length;return`
  <h2 class="eyebrow">Today \xB7 ${done} of ${rows.length} done <span class="link" data-go="plan/requirements">All rules</span></h2>
  <div class="pl-list">
    ${""}
    ${rows.map(r=>`
    <div class="pl-row tap" data-vt-row="req-${esc(r.route.replace(/[^A-Za-z0-9:_.-]/g,"_"))}" data-go="${esc(r.route)}">
      <div class="req-icon ${r.done?"g":r.color==="red"?"a":esc(r.accent==="muted"?"muted":r.accent)} s38">${icon(r.icon,18)}</div>
      <div class="plb">
        <div class="plt"><span class="nm">${esc(r.title)}</span></div>
        <div class="pls">${esc(r.sub)}</div>
      </div>
      <div class="plend"><span class="status-pill ${PILL_ACCENT[r.color]||"muted"}">${esc(r.pill)}</span></div>
    </div>`).join("")}
  </div>`}function nutritionSummary(){const state=S.planTargetsState;if(state==="loading")return`<h2 class="eyebrow">Nutrition today</h2>${loadingCard()}`;if(state==="offline")return`<h2 class="eyebrow">Nutrition today</h2>${offlineCard()}`;const PS=S.planStyle;const T=S.planTargets||{};const c=S.dayConsumed;const rem=remainingToday({proteinSoFar:c.protein,kcalSoFar:c.kcal,proteinTarget:PS.showMacros?T.protein:null,kcalTarget:PS.showCalories?T.calories:null});const cells=[];if(rem.kcal!=null)cells.push([String(rem.kcal),"Calories left"]);if(rem.protein!=null)cells.push(rem.protein>0?[`${rem.protein}g`,"Protein left"]:["Met","Protein",true]);const eyebrow=`<h2 class="eyebrow">What's left <span class="link" data-go="plan/nutrition">Targets</span></h2>`;if(cells.length<2){const line=cells.length?cells[0][2]?"Protein target met today.":`<b>${cells[0][0]}</b> ${cells[0][1].toLowerCase()} today.`:PS.showMacros||PS.showCalories?`No calorie or protein target set, so nothing is graded against a number.`:`Your plan tracks ${esc((S.trackedSignalLabels||[]).join(" \xB7 ")||"your check-in signals")} instead of numbers.`;return`${eyebrow}<div class="pl-standard" style="margin-top:0">${line}</div>`}return`${eyebrow}
  <div class="macro-row">
    ${cells.map(([v,k,met])=>met?`<div class="macro met"><div class="mv">${icon("check",22)}</div><div class="mk">${esc(k)} met</div></div>`:`<div class="macro"><div class="mv">${esc(v)}</div><div class="mk">${esc(k)}</div></div>`).join("")}
  </div>`}const activeItems=()=>{const fm=foodMemory(RT.userId);return fm?fm.items.filter(i=>i.status!=="archived"):null};const placesList=()=>{const fm=foodMemory(RT.userId);return fm?(fm.places||[]).filter(p=>p.status!=="archived"):[]};const savedSignature=it=>mealSignature(Array.isArray(it.items)&&it.items.length?it.items:[it.name]);let SUG={rows:null,itemsRef:null,handled:-1,val:[]};function suggestions(){const rows=recentRows(RT.userId);const fm=foodMemory(RT.userId);if(!rows||!fm)return[];const handled=(RT.fmHandled||[]).length;if(SUG.rows===rows&&SUG.itemsRef===fm.items&&SUG.handled===handled)return SUG.val;const items=fm.items.filter(i=>i.status!=="archived");SUG={rows,itemsRef:fm.items,handled,val:findRepeats(rows,new Set(items.map(savedSignature)),new Set(RT.fmHandled||[])).slice(0,2)};return SUG.val}const placeName=id=>{const p=placesList().find(x=>x.id===id);return p?p.name:null};const macroLine=it=>{const bits=[];if(S.planStyle.showMacros&&it.protein)bits.push(`${it.protein}g protein`);if(S.planStyle.showCalories&&it.kcal)bits.push(`${it.kcal} kcal`);if(!S.planStyle.showMacros&&!S.planStyle.showCalories)return"";return bits.join(" \xB7 ")||"\u2014"};function itemRow(it,{manage=false}={}){const pl=it.place_id?placeName(it.place_id):null;const check=it.verified_at?`<span style="color:var(--green-bright);flex:none;display:inline-flex" title="Verified by your ${esc(S.coach.noun)}">${icon("check",13)}</span>`:"";const meta=[esc(macroLine(it))||null,pl&&!manage?esc(pl):null,manage&&it.times_logged>1?`logged ${it.times_logged}\xD7`:null].filter(Boolean).join(" \xB7 ");const ic=it.kind==="supplement"?"bolt":it.kind==="food"?"grid":it.kind==="order"?"pin":"utensils";return`
  <div class="pl-row${manage?" tap":""}"${manage?` data-fm-edit="${esc(it.id)}"`:""}>
    <div class="req-icon b s38">${icon(ic,17)}</div>
    <div class="plb">
      <div class="plt"><span class="nm">${esc(it.name)}</span>${check}</div>
      <div class="pls">${meta}</div>
    </div>
    <div class="plend">${manage?icon("chevron",16,'style="color:var(--text-3)"'):`<button class="btn primary xs" data-fm-log="${esc(it.id)}" style="width:auto">Log</button>`}</div>
  </div>`}function suggestionCard(){const g=suggestions()[0];if(!g)return"";return`
  <div class="pl-sug">
    <div class="plb">
      <div class="plt"><span style="color:var(--blue-bright);display:inline-flex;flex:none">${icon("sparkle",15)}</span><span class="nm">Save this as a usual?</span></div>
      <div class="pls">${esc(g.name)} \xB7 ${S.planStyle.showMacros?`${g.protein}g protein \xB7 `:""}${S.planStyle.showCalories?`${g.kcal} kcal \xB7 `:""}eaten ${g.count}\xD7</div>
    </div>
    <div class="pl-sug-a">
      <button class="btn primary sm" data-fm-save-sug="${esc(g.signature)}" style="width:auto;padding:0 16px;height:44px">Save</button>
      <button class="btn ghost sm" data-fm-dismiss-sug="${esc(g.signature)}" style="width:auto;padding:0 14px;height:44px">No thanks</button>
    </div>
  </div>`}function usualsSection(){const items=activeItems();if(items===null)return"";const sug=suggestionCard();if(!items.length){return`<h2 class="eyebrow">Food Memory</h2>${sug}
    ${sug?"":`<div class="pl-standard" style="margin-top:0">Log like normal. When a meal repeats, OnStandard offers to remember it, then it's one tap to log.
      <span class="link" data-go="memory-edit/new" style="cursor:pointer">Add one yourself</span></div>`}`}const rem=remainingToday({proteinSoFar:S.dayConsumed.protein,kcalSoFar:S.dayConsumed.kcal,proteinTarget:S.planStyle.showMacros?(S.planTargets||{}).protein:null,kcalTarget:S.planStyle.showCalories?(S.planTargets||{}).calories:null});const top=rankForRemaining(items,rem,3).map(r=>r.item);return`
  <h2 class="eyebrow">Food Memory${items.length>top.length?` <span class="link" data-go="plan/memory">See all ${items.length}</span>`:""}</h2>
  ${sug}
  <div class="pl-list">${top.map(it=>itemRow(it)).join("")}</div>`}function askContext(){const T=S.planTargets||{};const PS=S.planStyle;return{hasCoach:S.coach.hasCoach,coachNoun:S.coach.noun,hasTargets:!!(PS.showMacros&&T.protein!=null)||!!(PS.showCalories&&T.calories!=null),places:placesList().map(p=>({name:p.name})),requirements:(S.scheduleCatalog||[]).map(r=>({id:r.id,title:r.title,scored:r.impact.kind==="component"})),nextSlot:(()=>{const slot=S.currentSlot;if(!slot)return null;const r=(S.scheduleCatalog||[]).find(x=>x.id===slot);return r?r.title:null})()}}function askSection(area){const linked=S.coach.hasCoach;const Who=S.coach.noun==="trainer"?"trainer":"coach";const tile=(go,ic,label)=>`
    <div class="pl-ask" data-go="${esc(go)}" role="button" tabindex="0">
      <span class="pa-i">${icon(ic,15)}</span>
      <span class="pa-t">${esc(label)}</span>
    </div>`;return`
  <div class="pl-asks${linked?" two":""}">
    ${tile(`plan-ask/${area}`,"sparkle","Ask OnStandard")}
    ${linked?tile("messages","message",`Ask your ${Who}`):""}
  </div>
  <div style="height:12px"></div>`}function legacyStylePrompt(){if(RT.planStylePromptSeen||S.planStyle.source!=="legacy")return"";return`
  <div class="lrow" id="ps-intro" style="margin-bottom:10px;background:var(--blue-surface);border:1px solid var(--blue-border);border-radius:var(--r-card-sm);padding:12px 13px;cursor:default">
    <div class="xico sm" style="background:rgba(var(--blue-rgb),0.22);color:var(--blue-bright)">${icon("sparkle",16)}</div>
    <div class="xr"><div class="xa">Your plan style: Structured</div>
    <div class="xb">OnStandard now supports Guided and Intuitive too: different ways of measuring the same standard. Your score hasn't changed.</div>
    <div style="display:flex;gap:8px;margin-top:8px">
      <button class="btn primary sm" id="ps-intro-explore" style="width:auto;padding:0 14px;height:32px">Explore styles</button>
      <button class="btn ghost sm" id="ps-intro-dismiss" style="width:auto;padding:0 14px;height:32px">Not now</button>
    </div></div>
  </div>`}const overview=()=>`
  ${legacyStylePrompt()}
  ${todaySection()}
  ${nutritionSummary()}
  ${usualsSection()}
  ${askSection("overview")}`;function targetsRow(){const state=S.planTargetsState;if(state==="loading")return loadingCard();if(state==="offline")return offlineCard();const T=S.planTargets||{};const PS=S.planStyle;if(!PS.showMacros&&!PS.showCalories)return"";if(T.protein==null&&T.calories==null&&T.weight==null&&S.weight.target==null)return"";const band=PS.knobs&&PS.knobs.nutrition;const asRange=(v,b)=>v==null?"\u2014":b>0?`${Math.round(v*(1-b))}\u2013${Math.round(v*(1+b))}`:String(v);const rangeMode=band&&(band.protein==="range"||band.calorie==="range");const cells=[];if(PS.showMacros&&T.protein!=null){cells.push([band&&band.protein==="range"?asRange(T.protein,band.proteinBand):`${T.protein}g`,`Protein${rangeMode?" range":""}`])}if(PS.showCalories&&T.calories!=null){cells.push([band&&band.calorie==="range"?asRange(T.calories,band.calorieBand):String(T.calories),`Calories${rangeMode?" range":""}`])}const w=T.weight!=null?T.weight:S.weight.target;if(w!=null)cells.push([`${w} lb`,"Target wt"]);if(!cells.length)return"";const mv=v=>`<div class="mv"${String(v).length>8?' style="font-size:14px;letter-spacing:-0.02em"':""}>${esc(String(v))}</div>`;return`<div class="macro-row${cells.length>=4?" four":""}">
    ${cells.map(([v,k])=>`<div class="macro">${mv(v)}<div class="mk">${esc(k)}</div></div>`).join("")}
  </div>
  ${rangeMode?`<div class="pl-standard">Anywhere in the range scores full credit.</div>`:""}`}function nutritionScoring(){const f=S.nutritionFormula;const pct=S.nutritionWeightPct;const PS=S.planStyle;const T=S.planTargets||{};const noNumbers=!PS.showMacros&&!PS.showCalories;const unset=!noNumbers&&T.protein==null&&T.calories==null;const lead=unset||noNumbers?`No targets set. Nutrition is still <b>${pct}%</b> of your score:`:`Nutrition is <b>${pct}%</b> of your score:`;const tracked=(S.trackedSignalLabels||[]).join(" \xB7 ");return`
  ${noNumbers&&tracked?`<div class="pl-standard" style="margin-top:0">Tracked instead: <b>${esc(tracked)}</b>.</div>`:""}
  <div class="pl-standard">${lead}</div>
  <div class="pl-qs" style="margin-top:8px">
    ${f.parts.map(p=>`<span class="bd-weight" style="padding:6px 11px">${esc(p.label)} \xB7 ${p.pct}%</span>`).join("")}
  </div>`}function planStyleRow(){const st=S.planStyle;if(!st)return"";const decider=st.lockedBy||(S.coach.hasCoach?`Your ${S.coach.noun}`:"Your coach");const action=st.canChoose?`<button class="btn ghost sm" data-go="plan-style" style="width:auto;padding:0 14px;height:34px">Change</button>`:icon("chevron",17,'class="chev-dim"');const sub=st.source==="preference"?`${esc(st.short)} \xB7 awaiting your ${esc(S.coach.noun)}'s confirmation`:st.canChoose?`${esc(st.short)} \xB7 ${esc(st.sourceLabel)}`:`${esc(st.short)} \xB7 ${esc(decider)} decides`;return`
  <h2 class="eyebrow">Plan style</h2>
  <div class="pl-list">
    <div class="pl-row"${st.canChoose?"":' data-go="plan-style"'}>
      <div class="req-icon b s38">${icon("target",17)}</div>
      <div class="plb">
        <div class="plt"><span class="nm">${esc(st.name)}${st.customized?" (customized)":""}</span></div>
        <div class="pls">${sub}</div>
      </div>
      <div class="plend">${action}</div>
    </div>
    ${st.preferenceDiffers&&st.preferenceName&&!st.canChoose?`
    <div class="pl-row">
      <div class="req-icon muted s38">${icon("message",16)}</div>
      <div class="plb">
        <div class="plt"><span class="nm">You asked for ${esc(st.preferenceName)}</span></div>
        <div class="pls">Shared with ${esc(st.lockedBy||decider.replace(/^Your /,"your "))}</div>
      </div>
    </div>`:""}
  </div>`}function nutritionRules(){const r=RT.restrictions||{};const blocks=[];const chips=(list,tone)=>list.map(x=>`<span class="bd-weight" ${tone?`style="color:var(--${tone})"`:""}>${esc(typeof x==="string"?x:`${x.name}${x.severity==="severe"?" \xB7 severe":""}`)}</span>`).join(" ");const block=(label,inner)=>blocks.push(`<div class="pl-row" style="display:block">
      <div class="pl-gp-k">${esc(label)}</div>
      <div style="display:flex;gap:6px;flex-wrap:wrap;margin-top:7px">${inner}</div></div>`);if(Array.isArray(r.allergies)&&r.allergies.length)block("Allergies",chips(r.allergies,"red-bright"));if(Array.isArray(r.intolerances)&&r.intolerances.length)block("Intolerances",chips(r.intolerances));if(Array.isArray(r.preferences)&&r.preferences.length)block("Preferences",chips(r.preferences));if(!blocks.length){return`<h2 class="eyebrow">Food rules</h2>
    <div class="pl-standard" style="margin-top:0">${S.coach.hasCoach?`No food rules set. Your ${esc(S.coach.noun)}'s guidance shows up here when they add it.`:"No food rules yet. Allergies and preferences you add in your profile show up here."}
    <span class="link" data-go="profile" style="cursor:pointer">Edit profile</span></div>`}return`<h2 class="eyebrow">Food rules</h2><div class="pl-list">${blocks.join("")}</div>`}const nutrition=()=>`
  ${S.planStyle.showMacros||S.planStyle.showCalories?`<h2 class="eyebrow">Your targets</h2>`:`<h2 class="eyebrow">What your plan tracks</h2>`}
  ${targetsRow()}
  ${nutritionScoring()}
  ${planStyleRow()}
  ${nutritionRules()}
  ${askSection("nutrition")}`;const CAT_ACCENT={Nutrition:"g",Recovery:"p"};const CAT_SHORT={Nutrition:"Nutrition",Recovery:"Recovery"};function scoredWeights(){const rows=(S.breakdown||[]).map(b=>({key:b.key,pct:b.weightPct}));if(!rows.length)return null;const sum=rows.reduce((a,b)=>a+b.pct,0);if(sum!==100){const big=rows.reduce((a,b)=>b.pct>a.pct?b:a,rows[0]);big.pct+=100-sum}return rows}function weightsStrip(){const rows=scoredWeights();if(!rows)return"";return`
  <h2 class="eyebrow">How your score is built</h2>
  <div class="macro-row">
    ${rows.map(r=>`<div class="macro"><div class="mv" style="color:${accentVar(CAT_ACCENT[r.key]||"b")}">${r.pct}%</div><div class="mk">${esc(CAT_SHORT[r.key]||r.key)}</div></div>`).join("")}
  </div>`}function reqRow(r,showFreq){const scored=r.impact.kind==="component";const tag=scored?CAT_SHORT[{nutrition:"Nutrition",recovery:"Recovery"}[r.impact.comp]]||r.impact.comp:"Not scored";const accent=scored?{nutrition:"g",recovery:"p"}[r.impact.comp]||"b":"";const due=r.window&&r.window.due!=null?r.window.label||`by ${fmtMin(r.window.due)}`:r.window&&r.window.label||"";const freq=showFreq?freqLabel(r.freq).replace(/^Required (weekly · |)/,""):"";const sub=[freq,due,PROOF[r.proof]?PROOF[r.proof].label:"One-tap check"].filter(Boolean).join(" \xB7 ");return`
  <div class="pl-row tap" data-go="requirement/${esc(r.id)}">
    <div class="req-icon ${esc(r.accent)} s38">${icon(r.icon,18)}</div>
    <div class="plb">
      <div class="plt"><span class="nm">${esc(r.title)}</span>${r.required===false?'<small style="color:var(--text-3);font-weight:700">optional</small>':""}</div>
      <div class="pls">${esc(sub)}</div>
    </div>
    <div class="plend"><span class="pl-tag ${accent}">${esc(tag)}</span>${icon("chevron",15,'style="color:var(--text-3)"')}</div>
  </div>`}function requirementsTab(){const cat=[...S.scheduleCatalog||[]];const byDue=(a,b)=>(a.window&&a.window.due||24*60)-(b.window&&b.window.due||24*60);const groups=[["Every day",cat.filter(r=>r.freq.type==="daily").sort(byDue),false],["Specific days",cat.filter(r=>r.freq.type==="days").sort(byDue),true],["Weekly",cat.filter(r=>r.freq.type==="weekly").sort(byDue),true],["Other",cat.filter(r=>!["daily","days","weekly"].includes(r.freq.type)).sort(byDue),true]].filter(([,rows])=>rows.length);const gov=S.governingStandard;const assigned=RT.assigned||[];return`
  ${weightsStrip()}
  ${groups.map(([label,rows,showFreq])=>`
    <div class="pl-grp">${esc(label)}</div>
    <div class="pl-list">${rows.map(r=>reqRow(r,showFreq)).join("")}</div>`).join("")}
  ${assigned.length?`
    <div class="pl-grp">From your ${esc(S.coach.noun)}</div>
    <div class="pl-list">${assigned.map(a=>`
      <div class="pl-row tap" data-go="requirement/${esc(a.id)}">
        <div class="req-icon ${a.done?"g":"b"} s38">${icon(a.icon||"clipboard",18)}</div>
        <div class="plb">
          <div class="plt"><span class="nm">${esc(a.title)}</span></div>
          <div class="pls">One-time \xB7 ${esc(a.dueLabel||"On your list")}</div>
        </div>
        <div class="plend"><span class="pl-tag b">Your plan</span>${icon("chevron",15,'style="color:var(--text-3)"')}</div>
      </div>`).join("")}</div>`:""}
  ${""}
  <div class="pl-grp">Who set this</div>
  <div class="pl-list">
    <div class="pl-row">
      <div class="req-icon muted s38">${icon("shield",18)}</div>
      <div class="plb">
        <div class="plt"><span class="nm">${gov?`${esc(gov.scopeLabel)}${gov.setBy?` by ${esc(gov.setBy)}`:""}`:"The OnStandard baseline"}</span></div>
        <div class="pls">${gov?gov.effectiveDate?`In effect since ${esc(fmtDate(gov.effectiveDate)||gov.effectiveDate)}`:"In effect now":S.coach.hasCoach?`Yours until your ${esc(S.coach.noun)} sets their own standard`:"The standard every athlete starts on"}</div>
      </div>
    </div>
  </div>
  ${askSection("requirements")}`}function memoryGroup(label,rows){if(!rows.length)return"";return`<div class="pl-grp">${esc(label)}</div><div class="pl-list">${rows.join("")}</div>`}export function factLabel(f){const kind=String(f&&f.kind||"");const raw=f&&f.value&&(f.value.name||f.value.value)||f&&f.value||"";const v=String(typeof raw==="object"?"":raw).slice(0,60);const PATTERN={portion_underread:"Your portions run bigger than a photo suggests",portion_overread:"Your portions run smaller than a photo suggests",cooks_with_oil:"You cook with oil",cooks_with_butter:"You cook with butter"};if(kind==="behavior_pattern")return PATTERN[v]||`Reading habit: ${v.replace(/_/g," ")}`;if(kind==="allergy")return`Allergy: ${v}`;if(kind==="dislike")return`You avoid ${v}`;if(kind==="favorite_food")return`You often eat ${v}`;if(kind==="favorite_restaurant")return`You often eat at ${v}`;if(kind==="meal_timing")return`Timing: ${v}`;return v||kind.replace(/_/g," ")}function memoryTab(){const items=activeItems();const places=placesList();const facts=(FACTS.uid===RT.userId&&Array.isArray(FACTS.rows)?FACTS.rows:[]).filter(f=>f&&f.status==="active");if(items===null){return`<h2 class="eyebrow">Food Memory</h2>${loadingCard()}${askSection("memory")}`}const isOrder=it=>it.kind==="order"||!!it.place_id;const meals=items.filter(it=>!isOrder(it)&&(it.kind==="meal"||!it.kind));const orders=items.filter(isOrder);const packaged=items.filter(it=>!isOrder(it)&&(it.kind==="food"||it.kind==="supplement"));const placesWithNothing=places.filter(p=>!orders.some(o=>o.place_id===p.id));const nothingAtAll=!items.length&&!places.length&&!facts.length;const orderRows=[];for(const p of places){const mine=orders.filter(o=>o.place_id===p.id);if(!mine.length)continue;orderRows.push(`<div class="pl-row" style="padding-bottom:4px;min-height:0"><div class="pl-gp-k">${esc(p.name)}</div></div>`);for(const o of mine)orderRows.push(itemRow(o,{manage:true}))}for(const o of orders.filter(x=>!x.place_id||!places.some(p=>p.id===x.place_id))){orderRows.push(itemRow(o,{manage:true}))}if(orderRows.length&&placesWithNothing.length){orderRows.push(`<div class="pl-row" style="min-height:0;padding:11px 0">
      <div class="req-icon muted" style="width:32px;height:32px;flex:none">${icon("pin",14)}</div>
      <div class="plb"><div class="pls">Also eaten at ${placesWithNothing.map(p=>esc(p.name)).join(", ")}, nothing saved yet</div></div>
    </div>`)}return`
  <h2 class="eyebrow">Food Memory <span class="link" data-go="memory-edit/new">+ Add</span></h2>
  ${suggestionCard()}
  ${nothingAtAll?`<div class="pl-standard" style="margin-top:0">Nothing learned yet. Log a meal three times and OnStandard offers to remember it${S.planStyle.showMacros?", numbers and all,":""} so logging it drops to one tap.</div>`:""}
  ${""}
  ${memoryGroup("Frequent meals",meals.map(it=>itemRow(it,{manage:true})))}
  ${memoryGroup("Restaurants & orders",orderRows)}
  ${memoryGroup("Packaged foods",packaged.map(it=>itemRow(it,{manage:true})))}
  ${facts.length?`<div class="pl-grp">Corrections</div>
    <div class="pl-list">${facts.slice(0,10).map(f=>`
      <div class="pl-row" style="min-height:0;padding:11px 0">
        <div class="req-icon muted" style="width:32px;height:32px;flex:none">${icon("sparkle",14)}</div>
        <div class="plb"><div class="pls" style="color:var(--text);font-weight:700;white-space:normal">${esc(factLabel(f))}</div></div>
      </div>`).join("")}</div>`:""}
  ${askSection("memory")}`}async function warmCaches(){const roles=await import("../roles.js");const rm=await import("../recent-meals.js");const fmd=await import("../food-memory-data.js");await Promise.all([fmd.warmFoodMemory(roles,RT.userId),rm.warmRecent(roles,RT.userId),(async()=>{if(FACTS.uid===RT.userId&&FACTS.rows)return;const rows=await roles.fetchMyMemoryFacts(RT.userId).catch(()=>null);if(Array.isArray(rows))FACTS={uid:RT.userId,rows}})()])}export default{tab:"plan",subs:PLAN_SUBS,resolveSub:planSub,render({sub}){const t=planSub(sub);const body=t==="nutrition"?nutrition():t==="requirements"?requirementsTab():t==="memory"?memoryTab():overview();return`${head(t)}${tabs(t)}<div class="pane">${body}</div>`},async mount(root,{sub}){if(sub&&!PLAN_SUBS.includes(sub)&&!SUB_ALIAS[sub]){location.replace("#plan");return}if(S.planTargetsState==="loading"){setTimeout(()=>{if(!root.isConnected||S.planTargetsState!=="loading")return;RT.profileOffline=true;RT.profileLoading=false;window.__render()},8e3)}const retry=root.querySelector("#plan-retry");if(retry)retry.addEventListener("click",async()=>{await act.retryProfile();window.__render()});const strip=root.querySelector(".ptabs");const on=strip&&strip.querySelector(".pt.on");if(strip)strip.classList.toggle("over",strip.scrollWidth>strip.clientWidth+1);if(strip&&on&&strip.scrollWidth>strip.clientWidth){const pad=14;const sr=strip.getBoundingClientRect();const or=on.getBoundingClientRect();const leftIn=or.left-sr.left+strip.scrollLeft;const rightIn=leftIn+or.width;if(rightIn+pad>strip.scrollLeft+strip.clientWidth)strip.scrollLeft=rightIn+pad-strip.clientWidth;else if(leftIn-pad<strip.scrollLeft)strip.scrollLeft=Math.max(0,leftIn-pad);const edge=()=>strip.classList.toggle("scrolled",strip.scrollLeft>3);edge();strip.addEventListener("scroll",edge,{passive:true})}placeInk(strip,on);const goalBtn=root.querySelector("#pl-goal");if(goalBtn)goalBtn.addEventListener("click",()=>{GOAL_OPEN=!GOAL_OPEN;window.__restate()});const explore=root.querySelector("#ps-intro-explore");const dismiss=root.querySelector("#ps-intro-dismiss");if(explore)explore.addEventListener("click",()=>{act.dismissPlanStylePrompt();window.__navigate("plan-style")});if(dismiss)dismiss.addEventListener("click",()=>{act.dismissPlanStylePrompt();window.__render()});root.addEventListener("click",async e=>{const el=e.target&&e.target.closest&&e.target.closest("[data-fm-log],[data-fm-edit],[data-fm-save-sug],[data-fm-dismiss-sug],[data-ask]");if(!el)return;if(el.dataset.ask){const{seedAsk}=await import("./plan-ask.js");seedAsk(el.dataset.ask);window.__go("plan-ask/"+planSub(sub));return}if(el.dataset.fmLog){if(act.stageSavedMeal(el.dataset.fmLog))location.hash="#meal-analysis";return}if(el.dataset.fmEdit){window.__go("memory-edit/"+el.dataset.fmEdit);return}if(el.dataset.fmSaveSug){const sug=suggestions().find(g=>g.signature===el.dataset.fmSaveSug);if(!sug)return;el.disabled=true;el.textContent="Saving\u2026";await act.saveMemorySuggestion(sug);await warmCaches().catch(()=>{});if(location.hash.startsWith("#plan"))window.__render();return}if(el.dataset.fmDismissSug){act.dismissMemorySuggestion(el.dataset.fmDismissSug);if(location.hash.startsWith("#plan"))window.__render()}});const loadedBefore=!!(foodMemory(RT.userId)&&recentRows(RT.userId));await warmCaches().catch(()=>{});const loadedAfter=!!(foodMemory(RT.userId)&&recentRows(RT.userId));if(!loadedBefore&&loadedAfter&&location.hash.startsWith("#plan"))window.__render()}};
