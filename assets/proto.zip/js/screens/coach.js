import{S,RT,act,fmtClock,nutritionConfigForGoal,liveWeightPct}from"../state.js";import{FILTERED_NOTE}from"../content-filter.js";import{openMembersSheet}from"../members-sheet.js";import{icon}from"../icons.js";import{accentVar,scoreColor,ON_STANDARD,qualityAccent,tierFor}from"../score-band.js";import{backHead,titleHead,avatarHead,esc,safeImg,composer,sparkline,emptyState,errorState,skeletonRows,emailVerifyBanner,wireEmailVerifyBanner,copyText,scoreRing,sayStatus,aiDisclaimer}from"../components.js";import{DAYS_SHORT,shortDate,weekdayLong,dateKey}from"../fmt-date.js";import{weekBars,calendarWeek,daysBetween}from"../week-bars.js";import{attachedPhoto,isPhotoOnly,wireComposerAttach,postChatMessage,bubblePhotoHtml,hydrateThreadPhotos}from"../chat-attach.js";import{coachSetupState,coachSetupSteps,isNutritionBook}from"./coach-home.js";import*as roles from"../roles.js";import{openingMessage,qualityBand,qualityReason,scoreRubric,reactionGroups,threadMessages,privateNotes,REACTION_EMOJI,applyMealCorrection,applyFoodRemoval,normalizeDetected}from"../meal-intel.js";import{mealReadHtml,wireReadControls}from"./meal.js";import{pastMealDetail}from"./trust.js";import{layoutThread,visibleThread,MUTED_HIDDEN_NOTE,authorName,initialsFor,isAnalysisUpdate,isAnalysisOpener,isEscalated,quotedFor,dayLabelOf,msgRowClass,timeSepHtml,deliveredHtml,msgTimeHtml,richText,isCorrectionReceipt,receiptCardHtml,reactionAnchor,replyQuote,replyQuoteHtml,replyTargetMeta,personText,workingLabel,participantList,participantSummary,AI_NAME,NIA_MARK,whoHtml,facesHtml,threadTitle}from"../chat-view.js";import{wireChatTimes}from"../chat-times.js";import{focusComposer}from"../keyboard.js";import{beginSend,endSend,takeFailed,justSent,noteSent,isSending,setAiWorking,setReply,replyOf,clearReply,paintReplyChip,noteArrivals,syncLive,syncJump,bindLive,wireThreadTaps,holdThread,followThread}from"../chat-live.js";import{openImageViewer}from"../image-viewer.js";import{overlayOpen}from"../overlay-guard.js";import{wireTapback}from"../tapback.js";import{CD,loadBook,bookKindFor,bookId as currentBookId,loadCoachRoster,loadActivity,loadAthleteProfile,entriesFor,localClock,logBookIntervention,resolvePos,seenMealSet}from"../coach-data.js";import{STATUS_META,statusColor,statusLabel}from"../status.js";import{teamCounts,shownScore}from"../team-count.js";import{openRosterFiltered}from"./coach-roster.js";import{everyone,people,audienceIds,audienceLabel,planSends,namesSummary,audienceHtml,wireAudience}from"../audience.js";import{CATALOG,PROOF,resolveRequirementSet,catalogFromItems,freqLabel,stdFromItems,fmtMin,planStyleFromItems}from"../requirements.js";import{STYLE_KEYS,styleLabel,knobsFor,resolveStyleKey}from"../plan-style.js";import{dayFromHistoryRow,minutesNow,MEAL_KEYS}from"../day.js";import{explainCategories}from"../breakdown-model.js";import{seedTemplates,templateLabel}from"../templates.js";import{canEditStandards,canViewWeight}from"../staff-access.js";import{categorizeInbox,inboxAlerts,countLabel,pageRows}from"../inbox.js";import{fmtWhen}from"../notif-feed.js";import{presetForStatus,tierForStatus,nudgeResultCopy,nudgedTodayFromInterventions}from"../nudge-presets.js";import{reasonKey}from"../priority.js";import{maybeStartTour}from"../tour.js";import{reveal}from"../motion.js";import{initialsOf}from"../initials.js";import{SPORT_POSITIONS}from"./profile.js";import{VC,loadBoard}from"../commitment-data.js";import{ROLLCALL_OFF}from"../commitments.js";import{hydrateAvatars}from"../avatar.js";import{ensureAiConsent,isConsentSkip,noteAiConsentRequired,aiOffForCoach}from"../ai-consent.js";const cap=s=>s?s.charAt(0).toUpperCase()+s.slice(1):s;export{loadCoachRoster};const ASSIGN={aud:everyone(),title:"",note:"",proof:"check",due:"tonight",done:null};const DUE_CHOICES={tonight:{label:"Tonight \xB7 9 PM",at:()=>{const d=new Date;d.setHours(21,0,0,0);return d}},tomorrow:{label:"Tomorrow \xB7 9 PM",at:()=>{const d=new Date;d.setDate(d.getDate()+1);d.setHours(21,0,0,0);return d}},none:{label:"No deadline",at:()=>null}};const PROOF_CHOICES=[["photo","camera","Photo"],["check","check","Check"],["scale","scale","Scale"],["form","clipboard","Form"]];const PROOF_WORD={photo:"Photo proof",check:"One tap to confirm",scale:"Weigh-in",form:"Short form"};const ASSIGN_SUGGEST={team:[["Extra shake after lift","photo"],["Foam roll 10 min","check"],["Hydrate: a gallon today","check"],["Stretch before bed","check"],["Weigh in before practice","scale"]],nutrition:[["Protein at every meal today","photo"],["Log dinner before 8 PM","photo"],["Hit your water goal","check"],["Weigh in tomorrow morning","scale"],["Add a vegetable to lunch","photo"]]};export function presetAssignAudience(ids){ASSIGN.aud=people(ids);ASSIGN.done=null}function assignLabel(rows,groups){const practice=CD.kind==="practice";return audienceLabel(ASSIGN.aud,rows,groups,{noun:CD.noun,nouns:CD.nouns,everyoneWord:practice?"all clients":"the whole team"})}function assignPreviewHtml(rows,groups){const title=(ASSIGN.title||"").trim();const due=DUE_CHOICES[ASSIGN.due]||DUE_CHOICES.none;const proof=PROOF_CHOICES.find(p=>p[0]===ASSIGN.proof)||PROOF_CHOICES[1];const note=(ASSIGN.note||"").trim();const n=audienceIds(ASSIGN.aud,rows,groups).length;return`<div class="lic">${icon(proof[1],17)}</div>
    <div class="lm">
      <div class="pv-t ${title?"":"empty"}">${title?esc(title):"Your task shows up here"}</div>
      <div class="pv-s">${ASSIGN.due==="none"?"No deadline":`Due ${esc(due.label.replace(" \xB7 "," "))}`} \xB7 ${PROOF_WORD[ASSIGN.proof]||"One tap to confirm"}</div>
      ${note?`<div class="pv-n">${esc(note)}</div>`:""}
      <div class="pv-from">From ${esc(S.operatorIdentity.handle)} \xB7 on ${n===1?"their list":`${n} lists`}, with a push each</div>
    </div>`}export const coachAssign={nav:"operator",tab:"create",pane:"detail",render({sub}={}){const rows=CD.roster?CD.roster.rows:[];const groups=CD.extras&&CD.extras.groups||[];const practice=CD.kind==="practice";if(sub&&!(ASSIGN.aud.kind==="athletes"&&ASSIGN.aud.ids.length===1&&ASSIGN.aud.ids[0]===sub)){ASSIGN.aud=people([sub]);ASSIGN.done=null}if(practice&&(ASSIGN.aud.kind==="position"||ASSIGN.aud.kind==="group"))ASSIGN.aud=everyone();const head=backHead("Assign",practice?"Put something on a client\u2019s plate":"Put something on someone\u2019s plate",practice?"trainer":"coach-home");if(CD.roster&&!CD.roster.offline&&!rows.length){return`${head}${emptyState({icon:"users",title:practice?"No clients yet":"No athletes yet",body:`Assignments go to the ${CD.nouns} on your ${practice?"book":"roster"}. Share your code and this opens up as they join.`,action:{label:practice?"Share client code":"Share athlete code",go:practice?"trainer-profile":"coach-profile/code"}})}`}if(ASSIGN.done){const d=ASSIGN.done;const who=d.names?esc(d.names):esc(d.label);return`${head}
      <section class="card as-done" role="status">
        <div class="ic">${icon(d.failed?"alert":"check",24)}</div>
        <div class="t">${d.sent?`Sent to ${d.sent}`:"Nothing sent"}</div>
        <div class="s">${d.sent?`\u201C${esc(d.title)}\u201D is on ${d.sent===1?"their list":"their lists"} now, with a push each. ${who}.`:""}</div>
        ${d.failed?`<div class="s warn">${d.sent?`Couldn\u2019t reach ${esc(d.failedNames||`${d.failed} ${d.failed===1?CD.noun:CD.nouns}`)}. Nothing was sent to them.`:esc(d.error||"Could not send. Try again.")}</div>`:""}
        <div class="acts">
          <button class="btn primary sm" id="as-again">${d.failed&&!d.sent?"Try again":"Assign another"}</button>
          <button class="btn ghost sm" data-go="${practice?"trainer-roster":"coach-roster"}">Back to the ${practice?"clients":"roster"}</button>
        </div>
      </section>`}const chip=(on,label,act2,arg)=>`<span class="chip ${on?"on":""}" role="radio" aria-checked="${on?"true":"false"}" tabindex="0" data-assign="${act2}${arg!=null?":"+esc(String(arg)):""}">${label}</span>`;const suggestions=ASSIGN_SUGGEST[isNutritionBook()?"nutrition":"team"];const n=audienceIds(ASSIGN.aud,rows,groups).length;return`
    ${head}

    <h2 class="eyebrow">Who</h2>
    ${audienceHtml(ASSIGN.aud,{rows,groups,practice,nouns:CD.nouns})}
    ${CD.roster===null?`<div class="ts mt">${practice?"Clients loading\u2026 everyone works right away.":"Roster loading\u2026 team-wide works right away."}</div>`:""}

    <h2 class="eyebrow" id="as-title-l">What</h2>
    <input id="as-title" class="ob-input" aria-labelledby="as-title-l" maxlength="80" placeholder="What are they doing?" value="${esc(ASSIGN.title||"")}" />
    <div class="chip-row as-sugg" aria-label="Quick titles">
      ${suggestions.map(([t,p])=>`<span class="chip ${(ASSIGN.title||"").trim()===t?"on":""}" role="button" tabindex="0" aria-pressed="${(ASSIGN.title||"").trim()===t?"true":"false"}" data-sugg="${esc(t)}" data-sugg-proof="${p}">${esc(t)}</span>`).join("")}
    </div>

    <h2 class="eyebrow">Proof</h2>
    <div class="chip-row" id="as-proof" role="radiogroup" aria-label="Proof">
      ${PROOF_CHOICES.map(([id,ic,label])=>chip(ASSIGN.proof===id,`${icon(ic,13)} ${label}`,"proof",id)).join("")}
    </div>

    <h2 class="eyebrow">Due</h2>
    <div class="chip-row" id="as-due" role="radiogroup" aria-label="Due">
      ${Object.entries(DUE_CHOICES).map(([id,d])=>chip(ASSIGN.due===id,d.label,"due",id)).join("")}
    </div>

    <h2 class="eyebrow" id="as-note-l">Note <span class="opt">\xB7 optional</span></h2>
    <input id="as-note" class="ob-input" aria-labelledby="as-note-l" maxlength="280" placeholder="Why it matters (they see this)" value="${esc(ASSIGN.note||"")}" />

    <h2 class="eyebrow">How it lands</h2>
    <section class="card as-preview" id="as-preview" aria-live="polite">${assignPreviewHtml(rows,groups)}</section>

    <div class="as-send">
      <button class="btn primary" id="as-send" ${n?"":"disabled"}>${icon("plus",18)} <span id="as-send-l">${n?`Send to ${esc(assignLabel(rows,groups))}`:`Pick who gets it`}</span></button>
      <div class="st" id="as-status"></div>
    </div>
    <div style="height:10px"></div>
    `},mount(root){loadBook(false,bookKindFor(RT.authRole));const rows=CD.roster?CD.roster.rows:[];const groups=CD.extras&&CD.extras.groups||[];const say=(msg,isErr)=>{const el=root.querySelector("#as-status");if(el)sayStatus(el,msg,{error:!!isErr})};const again=root.querySelector("#as-again");if(again){again.addEventListener("click",()=>{ASSIGN.done=null;window.__render()});return}const preview=()=>{const el=root.querySelector("#as-preview");if(el)el.innerHTML=assignPreviewHtml(rows,groups)};const sendBtn=root.querySelector("#as-send");const sendLabel=()=>{const n=audienceIds(ASSIGN.aud,rows,groups).length;const l=root.querySelector("#as-send-l");if(l)l.textContent=n?`Send to ${assignLabel(rows,groups)}`:"Pick who gets it";if(sendBtn)sendBtn.disabled=!n;preview()};wireAudience(root,ASSIGN.aud,{rows,groups,practice:CD.kind==="practice",nouns:CD.nouns,onChange:sendLabel});const titleEl=root.querySelector("#as-title");const noteEl=root.querySelector("#as-note");const syncSugg=()=>root.querySelectorAll("[data-sugg]").forEach(c=>{const on=(ASSIGN.title||"").trim()===c.getAttribute("data-sugg");c.classList.toggle("on",on);c.setAttribute("aria-pressed",on?"true":"false")});if(titleEl)titleEl.addEventListener("input",()=>{ASSIGN.title=titleEl.value;syncSugg();preview()});if(noteEl)noteEl.addEventListener("input",()=>{ASSIGN.note=noteEl.value;preview()});root.querySelectorAll("[data-sugg]").forEach(el=>el.addEventListener("click",()=>{ASSIGN.title=el.getAttribute("data-sugg")||"";if(titleEl)titleEl.value=ASSIGN.title;const p=el.getAttribute("data-sugg-proof");if(p&&PROOF_CHOICES.some(x=>x[0]===p)){ASSIGN.proof=p;syncRadios("as-proof","proof",p)}syncSugg();preview()}));const syncRadios=(groupId,act2,value)=>{root.querySelectorAll(`#${groupId} [data-assign]`).forEach(c=>{const on=c.getAttribute("data-assign")===`${act2}:${value}`;c.classList.toggle("on",on);c.setAttribute("aria-checked",on?"true":"false")})};root.querySelectorAll("[data-assign]").forEach(el=>el.addEventListener("click",()=>{const[act2,arg]=el.getAttribute("data-assign").split(":");if(act2==="proof"){ASSIGN.proof=arg;syncRadios("as-proof","proof",arg)}if(act2==="due"){ASSIGN.due=arg;syncRadios("as-due","due",arg)}preview()}));if(sendBtn)sendBtn.addEventListener("click",async()=>{const title=(ASSIGN.title||"").trim();if(title.length<2){say("Give it a name first. What are they doing?",true);if(titleEl)titleEl.focus();return}const teamId=currentBookId();if(!teamId){say("Your roster hasn\u2019t loaded yet. Give it a second and try again.",true);return}const liveRows=CD.roster?CD.roster.rows:rows;const liveGroups=CD.extras&&CD.extras.groups||groups;const sends=planSends(ASSIGN.aud,liveRows,liveGroups);if(!sends.length){say(`Pick who gets it first.`,true);return}const due=DUE_CHOICES[ASSIGN.due];const dueAt=due.at();const base={teamId,title,proof:ASSIGN.proof,dueAt:dueAt?dueAt.toISOString():null,dueLabel:dueAt?due.label.replace(" \xB7 "," "):null,note:(ASSIGN.note||"").trim()||null,kind:CD.kind};sendBtn.disabled=true;say(sends.length>1?`Sending to ${sends.length}\u2026`:"Sending\u2026");let sent=0,failed=0,error=null;const failedIds=[];for(const s of sends){const r=await roles.assignRequirement({...base,scopeKind:s.scopeKind,scopeValue:s.scopeValue});if(r.ok&&r.count)sent+=r.count;else{failed+=1;if(s.scopeKind==="athlete")failedIds.push(s.scopeValue);if(!error&&r.error)error=r.error}}sendBtn.disabled=false;if(!sent&&sends.length===1){say(error||(sends[0].scopeKind==="athlete"?"Could not send. Try again.":`No ${CD.nouns} matched. Check who you picked.`),true);return}const ids=audienceIds(ASSIGN.aud,liveRows,liveGroups);ASSIGN.done={sent,failed,error,title,label:assignLabel(liveRows,liveGroups),names:ASSIGN.aud.kind==="athletes"||ASSIGN.aud.kind==="group"?namesSummary(ids.filter(id=>!failedIds.includes(id)),liveRows,4):"",failedNames:failedIds.length?namesSummary(failedIds,liveRows,4):""};ASSIGN.title="";ASSIGN.note="";window.__render()})}};let MANAGE={id:null,open:false,busy:false,note:"",arm:false};let TGT=null;let tgtLoadingId=null;async function loadTargets(athleteId){if(!athleteId||tgtLoadingId===athleteId)return;if(TGT&&TGT.athleteId===athleteId)return;tgtLoadingId=athleteId;try{const[targets,basics,preference]=await Promise.all([roles.fetchAthleteTargets(athleteId),roles.fetchAthleteBasics(athleteId),roles.fetchAthletePlanPreference(athleteId)]);TGT={athleteId,targets:targets||{},basics:basics||null,preference:preference||null}}catch{TGT={athleteId,targets:{},basics:null,preference:null,offline:true}}finally{tgtLoadingId=null}if(location.hash.startsWith("#coach-plan"))window.__render()}function suggestTargets(targetWeight,baseWeight){const tw=+targetWeight||0;if(tw<80||tw>450)return null;const bw=+baseWeight||tw;const mode=tw>bw+5?"bulk":tw<bw-5?"cut":"hold";const protein=Math.round(tw*(mode==="cut"?1.2:mode==="bulk"?1.1:.9)/5)*5;const calories=Math.round(tw*(mode==="bulk"?17:mode==="cut"?13:15)/50)*50;const why=mode==="bulk"?`building to ${tw} lb. Surplus + 1.1g/lb protein`:mode==="cut"?`cutting to ${tw} lb. Deficit + 1.2g/lb to hold muscle`:`holding ${tw} lb. Maintenance + 0.9g/lb`;return{protein,calories,mode,why}}let SETS=null;let setsLoading=false;async function loadSets(force){const bookId=CD.roster&&CD.roster.book[0]&&CD.roster.book[0].id;if(!bookId||setsLoading)return;if(SETS&&SETS.bookId===bookId&&!force)return;setsLoading=true;try{const rows=await roles.fetchRequirementSets(bookId,CD.kind);if(rows===null){if(!(SETS&&SETS.bookId===bookId))SETS=null}else SETS={bookId,rows}}catch{SETS={bookId,rows:[]}}finally{setsLoading=false}if(location.hash.startsWith("#coach-plan"))window.__render()}let TP=null;let tpLoading=false;async function loadTrust(force){if(tpLoading)return;if(TP&&!force)return;const rows=CD.roster?CD.roster.rows.slice(0,12):[];tpLoading=true;try{const map=await roles.fetchRosterPasses(rows.map(r=>r.athleteId));if(map!==null)TP={map:map||{}}}catch{TP={map:{}}}finally{tpLoading=false}if(location.hash.startsWith("#coach-plan"))window.__render()}function teamGoverningPlanStyle(athleteId,position){if(!SETS||!SETS.rows||!SETS.rows.length)return null;const set=resolveRequirementSet(SETS.rows,athleteId,position,roles.todayISO());const item=set?planStyleFromItems(set.items):null;return item?item.style:null}const STYLE_ICON={structured:"clipboard",guided:"target",intuitive:"heart"};function planStyleSection(athleteId,who,targets){const teamStyle=teamGoverningPlanStyle(athleteId,TGT.basics&&TGT.basics.position);const assigned=resolveStyleKey(targets.style);const pref=TGT.preference?resolveStyleKey(TGT.preference):null;const effective=teamStyle||assigned;const prefLine=pref&&pref!==effective?`<div class="ps-pref">${esc(who.name.split(" ")[0])}'s preference: <b>${esc(styleLabel(pref).name)}</b>. Differs from ${effective?"what they're on":"the default"}.</div>`:pref?`<div class="ps-pref">${esc(who.name.split(" ")[0])}'s preference: <b>${esc(styleLabel(pref).name)}</b>. Matches what they're on.</div>`:"";if(teamStyle){const l=styleLabel(teamStyle);return`
    <section class="card" style="padding:14px 16px">
      <div style="display:flex;align-items:flex-start;justify-content:space-between;gap:10px">
        <div><div style="font-size:12px;font-weight:700;color:var(--text-3);letter-spacing:.02em">PLAN STYLE</div>
        <div style="font-size:17px;font-weight:800;margin-top:2px">${esc(l.name)}</div>
        <div style="font-size:12.5px;font-weight:600;color:var(--text-2);margin-top:2px">Set by your team standard</div></div>
        <button class="btn ghost sm" data-go="coach-plan" style="width:auto;padding:0 14px">Edit standard</button>
      </div>
      <div style="font-size:13px;font-weight:600;color:var(--text-2);margin-top:10px;line-height:1.55">${esc(l.how)}</div>
      ${prefLine}
    </section>
    <div style="height:12px"></div>`}const knobs=knobsFor(assigned||"guided",targets.styleOverrides);return`
  <section class="card" style="padding:14px 16px" id="ps-editor">
    <div style="font-size:12px;font-weight:700;color:var(--text-3);letter-spacing:.02em">PLAN STYLE</div>
    <div style="font-size:12.5px;font-weight:600;color:var(--text-2);margin-top:2px">${assigned?`Assigned by you`:"Not set. Pick one to start scoring their nutrition against it"}</div>
    <div style="display:flex;gap:8px;margin-top:12px" id="ps-pick">
      ${STYLE_KEYS.map(k=>{const l=styleLabel(k);const on=assigned===k;return`<div class="choice ${on?"on":""}" data-ps="${k}" role="button" style="flex:1;padding:12px 8px;text-align:center">
          <div class="cic" style="margin:0 auto 6px;background:var(--blue-surface);color:var(--blue-bright)">${icon(STYLE_ICON[k],16)}</div>
          <div class="ct" style="font-size:13px">${esc(l.name)}</div>
        </div>`}).join("")}
    </div>
    ${prefLine}
    <div id="ps-detail" style="margin-top:10px">${assigned?planStyleDetail(assigned,knobs):""}</div>
    <button class="btn primary sm" id="ps-apply" hidden>Apply to their plan</button>
    <div id="ps-status" style="font-size:12px;font-weight:600;color:var(--text-3);min-height:16px;margin-top:8px"></div>
  </section>
  <div style="height:12px"></div>`}function planStyleDetail(style,knobs){const n=knobs.nutrition;const CAL_OPTS=[["exact","Exact"],["range","Range"],["adequacy","Adequacy"]];const PRO_OPTS=[["exact","Exact"],["range","Range"],["off","Off"]];const seg=(key,opts,cur)=>`<div class="seg" data-psk="${key}" role="radiogroup" aria-label="${key==="calorie"?"Calories":"Protein"}" style="width:auto">${opts.map(([v,t])=>`<button type="button" class="${cur===v?"on":""}" role="radio" aria-checked="${cur===v?"true":"false"}" data-psv="${v}">${t}</button>`).join("")}</div>`;return`
  <div style="border-top:1px solid var(--hairline-soft);padding-top:10px">
    <div class="lrow" style="cursor:default;padding:6px 0"><div class="lm"><div class="lt" style="font-size:12.5px">Calories</div></div>${seg("calorie",CAL_OPTS,n.calorie)}</div>
    <div class="lrow" style="cursor:default;padding:6px 0"><div class="lm"><div class="lt" style="font-size:12.5px">Protein</div></div>${seg("protein",PRO_OPTS,n.protein)}</div>
    <div style="font-size:11.5px;font-weight:600;color:var(--text-3);margin-top:4px;line-height:1.4">${styleLabel(style).name} defaults shown. Change either, then Apply saves it just to this athlete.</div>
  </div>`}const setSummary=items=>{const meals=items.filter(i=>i.kind==="meal").length;const lift=items.find(i=>i.kind==="lift");const weigh=items.find(i=>i.kind==="weigh");const bits=[`${meals} meal${meals===1?"":"s"}`];if(lift)bits.push(lift.freq&&lift.freq.label?`lifts ${lift.freq.label}`:"lifts");if(weigh)bits.push(weigh.freq&&weigh.freq.type==="daily"?"weigh daily":`weigh ${weigh.freq&&weigh.freq.label||(weigh.freq&&Array.isArray(weigh.freq.days)?weighLabel(weigh.freq.days):"MWF")}`);return bits.join(" \xB7 ")};export const coachPlan={nav:"operator",tab:"roster",pane:"detail",render({sub}){const athleteId=sub;const who=rosterName(athleteId);const noun=CD.kind==="practice"?"trainer":"coach";const head=backHead("Nutrition targets",`${esc(who.name)} \xB7 ${noun} owns the plan`,athleteId?`coach-athlete/${esc(athleteId)}`:"coach-plan");if(!athleteId&&CD.kind==="practice"){const rows2=CD.roster?CD.roster.rows:null;const sets=SETS&&SETS.rows?SETS.rows:null;const practiceSet=sets&&sets.find(x=>x.scope_kind==="team");if(CD.roster&&CD.roster.offline){return`${titleHead("Plan","Your standard, client by client")}${errorState({title:"Can't reach your clients",body:"Your standard and their targets are safe. Reconnect and they load right here.",retryId:"plan-retry"})}`}return`
      ${titleHead("Plan","Your standard, client by client")}

      <h2 class="eyebrow">Standard \xB7 what every day asks</h2>
      ${sets===null&&rows2===null?skeletonRows(2,"Loading your standard"):`
      <section class="card" style="padding:6px 16px">
        <div class="lrow" data-go="coach-plan-set/team">
          <div class="lic" style="background:var(--surface-3);color:var(--text-2);font-weight:800;font-size:12px">CL</div>
          <div class="lm"><div class="lt">Your Client Standard${rows2&&rows2.length?` <small style="color:var(--text-3);font-weight:700">\xB7 ${rows2.length}</small>`:""}</div>
          <div class="ls">${practiceSet?esc(setSummary(practiceSet.items)):"Built-in \xB7 3 meals, recovery"}</div></div>
          ${practiceSet?'<span class="status-pill b">Custom</span>':""}
          ${icon("chevron",17,'style="color:var(--text-3)"')}
        </div>
      </section>`}

      <h2 class="eyebrow">Targets \xB7 per client</h2>
      ${rows2===null?skeletonRows(3,"Loading your clients"):rows2.length?`
      <section class="card" style="padding:6px 16px">
        ${rows2.slice(0,12).map(r=>`
        <div class="lrow" data-go="coach-plan/${esc(r.athleteId)}">
          <div class="lic">${icon("target",17)}</div>
          <div class="lm"><div class="lt">${esc(r.name)}</div>
          <div class="ls">Protein \xB7 calories \xB7 target weight</div></div>
          ${icon("chevron",17,'style="color:var(--text-3)"')}
        </div>`).join("")}
      </section>`:`
      ${emptyState({icon:"target",title:"No clients yet",body:"Per-client protein, calorie, and target-weight numbers open here the moment someone joins.",action:{label:"Invite a client",go:"trainer-profile"}})}`}

      ${""}
      <h2 class="eyebrow">Program</h2>
      <section class="card" style="padding:6px 16px">
        <div class="lrow" data-go="trust-pass-policy">
          <div class="lic" style="background:var(--green-surface);color:var(--green-bright)">${icon("shield",17)}</div>
          <div class="lm"><div class="lt">Trust Pass defaults</div><div class="ls">${(RT.passPolicy||{default_credits:3}).default_credits}-credit default \xB7 earned after ${(RT.passPolicy||{eligibility_days:7}).eligibility_days} photo-logged days</div></div>
          ${icon("chevron",17,'style="color:var(--text-3)"')}
        </div>
      </section>

      <div style="height:12px"></div>
      ${""}
      <div class="sidebox">
        <div class="req-icon b s38">${icon("lock",17)}</div>
        <div><div class="tt">Built for teams</div>
        <div class="ts">Position rooms are built around a team roster, and a practice is 1:1, so they don't apply here. Everything else on this page is yours.</div></div>
      </div>
      <div style="height:10px"></div>`}if(!athleteId){const rows2=CD.roster?CD.roster.rows:null;const positions=rows2?[...new Set(rows2.map(r=>(r.unit||"").trim().toUpperCase()).filter(Boolean))]:[];const sets=SETS&&SETS.rows?SETS.rows:null;const teamSet=sets&&sets.find(s=>s.scope_kind==="team");const teamCount=rows2?rows2.length:0;const setup=coachSetupState();const setupSteps=coachSetupSteps(setup);const todayISO=(()=>{const d=new Date;return`${d.getFullYear()}-${String(d.getMonth()+1).padStart(2,"0")}-${String(d.getDate()).padStart(2,"0")}`})();const upcoming=(sets||[]).filter(s=>s&&s.effective_date&&String(s.effective_date)>todayISO).sort((a,b)=>String(a.effective_date)<String(b.effective_date)?-1:1);const scopeLabelOf=s=>s.scope_kind==="team"?"Team standard":s.scope_kind==="position"?`${esc(String(s.scope_value||"").toUpperCase())} room`:"Athlete standard";const readinessCard=()=>{const openReq=setupSteps.required.filter(x=>!x.done);const openOpt=setupSteps.optional.filter(x=>!x.done);const stepRow=(x,req)=>`
          <div class="lrow" ${x.go?`data-go="${esc(x.go)}" style="cursor:pointer"`:'style="cursor:default;opacity:0.75"'}>
            <div class="lic" style="${req?"background:var(--amber-surface);color:var(--amber-bright)":"background:var(--surface-3);color:var(--text-3)"}">${icon(req?"bolt":"clipboard",16)}</div>
            <div class="lm"><div class="lt">${esc(x.t)}</div><div class="ls">${esc(x.s)}</div></div>
            ${x.go?icon("chevron",17,'style="color:var(--text-3)"'):`<span style="font-size:10px;font-weight:800;letter-spacing:0.05em;text-transform:uppercase;color:var(--text-3)">Soon</span>`}
          </div>`;const shown=[...openReq.map(x=>stepRow(x,true)),...setup.ready?openOpt.slice(0,2).map(x=>stepRow(x,false)):[]];const line=setup.ready?`<div style="display:flex;align-items:center;gap:7px;font-size:12px;font-weight:800;color:var(--green-bright)">${icon("check",14)} Required setup complete</div>`:`<div style="font-size:12px;font-weight:800;color:var(--amber-bright)">${setup.requiredDone} of ${setup.requiredTotal} required steps done</div>`;return`
        <h2 class="eyebrow">Readiness</h2>
        <section class="card" style="padding:${shown.length?"11px 16px 6px":"13px 16px"};${setup.ready?"":"background:var(--amber-surface);border-color:var(--amber-border)"}">
          ${line}
          ${shown.length?`<div style="height:8px"></div>${shown.join("")}`:setup.ready?`<div style="font-size:11.5px;font-weight:600;color:var(--text-3);margin-top:3px">Everything's set. Invite athletes and your command center fills in live.</div>`:""}
        </section>`};const roomCard=pos=>{const s=sets&&sets.find(x=>x.scope_kind==="position"&&String(x.scope_value||"").trim().toUpperCase()===pos);const n=rows2?rows2.filter(r=>(r.unit||"").trim().toUpperCase()===pos).length:0;return`
        <div class="lrow" data-go="coach-plan-set/position/${esc(pos)}">
          <div class="lic" style="background:var(--blue-surface);color:var(--blue-bright);font-weight:800;font-size:12px">${esc(pos.slice(0,2))}</div>
          <div class="lm"><div class="lt">${esc(pos)} room <small style="color:var(--text-3);font-weight:700">\xB7 ${n}</small></div>
          <div class="ls">${s?esc(setSummary(s.items)):"Inherits team standard"}</div></div>
          ${s?'<span class="status-pill b">Custom</span>':""}
          ${icon("chevron",17,'style="color:var(--text-3)"')}
        </div>`};const planSub=isNutritionBook()?"Your fueling program, room by room":"Your program, room by room";if(CD.roster&&CD.roster.offline){return`${titleHead("Plan",planSub)}${errorState({title:"Can't reach your program",body:"Your standards, rooms, and targets are safe. Reconnect and they load right here.",retryId:"plan-retry"})}`}return`
      ${titleHead("Plan",planSub)}

      ${readinessCard()}

      <h2 class="eyebrow">Standards \xB7 what every day asks</h2>
      ${sets===null&&rows2===null?skeletonRows(3,"Loading your program"):`
      <section class="card" style="padding:6px 16px">
        <div class="lrow" data-go="coach-plan-set/team">
          <div class="lic" style="background:var(--surface-3);color:var(--text-2);font-weight:800;font-size:12px">TM</div>
          <div class="lm"><div class="lt">Your Team Standard${teamCount?` <small style="color:var(--text-3);font-weight:700">\xB7 ${teamCount}</small>`:""}</div>
          <div class="ls">${teamSet?esc(setSummary(teamSet.items)):"Built-in \xB7 3 meals, recovery"}</div></div>
          ${teamSet?'<span class="status-pill b">Custom</span>':""}
          ${icon("chevron",17,'style="color:var(--text-3)"')}
        </div>
        ${positions.map(roomCard).join("")}
      </section>
      ${positions.length===0?`<div style="font-size:12px;font-weight:600;color:var(--text-3);margin:8px 2px 0;line-height:1.4">Rooms appear as athletes with positions join. The team standard covers everyone until then.${rows2&&!rows2.length?` <span data-go="coach-profile/code" style="color:var(--blue-bright);font-weight:800;cursor:pointer">Invite athletes</span>`:""}</div>`:""}`}

      <h2 class="eyebrow">Upcoming changes</h2>
      ${sets===null?skeletonRows(1,"Loading scheduled changes"):upcoming.length?`
      <section class="card" style="padding:6px 16px">
        ${upcoming.map(s=>`
        <div class="lrow" data-go="coach-plan-set/${s.scope_kind==="position"?`position/${esc(String(s.scope_value||"").toUpperCase())}`:"team"}">
          <div class="lic" style="background:var(--amber-surface);color:var(--amber-bright)">${icon("bolt",16)}</div>
          <div class="lm"><div class="lt">${scopeLabelOf(s)} <small style="color:var(--text-3);font-weight:700">\xB7 ${esc(setSummary(s.items))}</small></div>
          <div class="ls">Takes effect ${esc(String(s.effective_date))} \xB7 earlier days stay unchanged</div></div>
          ${icon("chevron",17,'style="color:var(--text-3)"')}
        </div>`).join("")}
      </section>`:`
      <div style="font-size:12px;font-weight:600;color:var(--text-3);margin:0 2px 2px;line-height:1.4">No scheduled changes. Publish a standard with a future date and it lists here. Today's scoring stays untouched.</div>`}

      <h2 class="eyebrow">Targets \xB7 per athlete</h2>
      ${rows2&&rows2.length?`
      <section class="card" style="padding:6px 16px">
        ${rows2.slice(0,6).map(r=>`
        <div class="lrow" data-go="coach-plan/${esc(r.athleteId)}">
          <div class="lic">${icon("target",17)}</div>
          <div class="lm"><div class="lt">${esc(r.name)}${r.unit?` <small style="color:var(--text-3);font-weight:700">\xB7 ${esc(r.unit)}</small>`:""}</div>
          <div class="ls">Protein \xB7 calories \xB7 target weight</div></div>
          ${icon("chevron",17,'style="color:var(--text-3)"')}
        </div>`).join("")}
      </section>
      ${rows2.length>6?`<div style="font-size:var(--t-xs);font-weight:600;color:var(--text-3);margin:6px 2px 0">Showing 6 of ${rows2.length}</div>
      <button class="btn ghost sm" data-go="coach-roster" style="width:auto;padding:0 16px;margin-top:6px">All ${rows2.length} athletes</button>`:""}`:`
      ${emptyState({icon:"target",title:"No athletes yet",body:"Per-athlete protein, calorie, and target-weight numbers open here the moment your team joins.",action:{label:"Invite athletes",go:"coach-profile/code"}})}`}

      <h2 class="eyebrow">Trust passes \xB7 camera-free rewards</h2>
      ${rows2&&rows2.length?`
      <section class="card" style="padding:6px 16px">
        ${rows2.slice(0,6).map(r=>{const pass=TP&&TP.map?TP.map[r.athleteId]:void 0;const active=!!pass;const sub2=TP===null?"Checking\u2026":!active?`No pass \xB7 needs ${(RT.passPolicy||{eligibility_days:7}).eligibility_days} photo-logged days`:pass.credits_total==null?`Window \xB7 through ${esc(pass.covers_until)}`:`${esc(String(pass.credits_total))} credits \xB7 expires ${esc(pass.expires_on)}`;return`
        <div class="lrow" style="cursor:default">
          <div class="lic" style="${active?"background:var(--green-surface);color:var(--green-bright)":""}">${icon("shield",17)}</div>
          <div class="lm"><div class="lt">${esc(r.name)}</div>
          <div class="ls">${sub2}</div></div>
          ${active?`<button class="btn ghost danger micro" data-tp="end:${esc(r.athleteId)}" style="width:auto">End</button>`:`<button class="btn ghost micro" data-go="pass-grant/${esc(r.athleteId)}" style="width:auto">Grant</button>`}
        </div>`}).join("")}
        <div id="tp-plan-status" style="font-size:11.5px;font-weight:600;color:var(--text-3);min-height:14px;padding:2px 2px 8px"></div>
      </section>
      ${rows2.length>6?`<div style="font-size:var(--t-xs);font-weight:600;color:var(--text-3);margin:6px 2px 0">Showing 6 of ${rows2.length}</div>
      <button class="btn ghost sm" data-go="coach-roster" style="width:auto;padding:0 16px;margin-top:6px">All ${rows2.length} athletes</button>`:""}`:`
      ${emptyState({icon:"shield",title:"No trust passes yet",body:`A pass is earned after ${(RT.passPolicy||{eligibility_days:7}).eligibility_days} photo-logged days. Invite athletes to start the clock.`,action:{label:"Invite athletes",go:"coach-profile/code"}})}`}

      <h2 class="eyebrow">Program</h2>
      <section class="card" style="padding:6px 16px">
        <div class="lrow" data-go="coach-voice">
          <div class="lic nia-av">${NIA_MARK}</div>
          <div class="lm"><div class="lt">${AI_NAME} \xB7 OnStandard Nutritionist</div><div class="ls">${RT.coachVoice?"Tuned to your voice. Never invents":`Set how ${AI_NAME} talks to your athletes`}</div></div>
          <span class="status-pill ${RT.coachVoice&&RT.coachVoice.enabled!==false?"g":"muted"}">${RT.coachVoice&&RT.coachVoice.enabled!==false?"On":"Off"}</span>
          ${icon("chevron",17,'style="color:var(--text-3);margin-left:8px"')}
        </div>
        <div class="lrow" data-go="trust-pass-policy">
          <div class="lic" style="background:var(--green-surface);color:var(--green-bright)">${icon("shield",17)}</div>
          <div class="lm"><div class="lt">Trust Pass defaults</div><div class="ls">${(RT.passPolicy||{default_credits:3,eligibility_days:7}).default_credits}-credit default \xB7 earned after ${(RT.passPolicy||{eligibility_days:7}).eligibility_days} photo-logged days</div></div>
          ${icon("chevron",17,'style="color:var(--text-3)"')}
        </div>
        <div class="lrow" data-go="week-pattern">
          <div class="lic" style="background:rgba(var(--blue-rgb),0.14);color:var(--blue-bright)">${icon("clock",17)}</div>
          <div class="lm"><div class="lt">Training week</div><div class="ls">${(()=>{const p=Array.isArray(RT.weekPattern)?RT.weekPattern:[];const rest=p.filter(d=>d==="rest").length;return rest?`${7-rest} training \xB7 ${rest} rest`:"Every day training"})()}</div></div>
          ${icon("chevron",17,'style="color:var(--text-3)"')}
        </div>
        <div class="lrow" data-go="coach-rooms">
          <div class="lic" style="background:rgba(var(--blue-rgb),0.14);color:var(--blue-bright)">${icon("users",17)}</div>
          <div class="lm"><div class="lt">Position rooms</div><div class="ls">${(()=>{const n=(CD.extras&&CD.extras.rooms||[]).length;return n?`${n} room${n===1?"":"s"}`:"Group your roster by position"})()}</div></div>
          ${icon("chevron",17,'style="color:var(--text-3)"')}
        </div>
        <div class="lrow" data-go="team-diet">
          <div class="lic" style="background:var(--red-surface);color:var(--red)">${icon("bell",17)}</div>
          <div class="lm"><div class="lt">Team dietary sheet</div><div class="ls">Allergies &amp; restrictions across the roster</div></div>
          ${icon("chevron",17,'style="color:var(--text-3)"')}
        </div>
      </section>
      <div style="height:10px"></div>
      `}if(!TGT||TGT.athleteId!==athleteId){return`${head}${skeletonRows(3,"Loading their targets")}`}if(TGT.offline){return`${head}${errorState({title:"Couldn't load their targets",body:"Their plan is safe. Reconnect and it loads right here.",retryId:"tgt-retry"})}`}const t=TGT.targets||{};const planStyleCard=planStyleSection(athleteId,who,t);const seeWeight=CD.kind==="practice"||canViewWeight(CD.extras&&CD.extras.myRole);const unset=t.protein==null&&t.calories==null&&(!seeWeight||t.weight==null);const rows=[["Protein","tg-protein",t.protein!=null?t.protein:180,"g",5,20,400],["Calories","tg-calories",t.calories!=null?t.calories:2400,"kcal",50,800,8e3],...seeWeight?[["Target weight","tg-weight",t.weight!=null?t.weight:180,"lb",1,80,450]]:[]];return`
    ${head}

    ${planStyleCard}

    <h2 class="eyebrow">Targets${unset?" \xB7 not set yet":""}</h2>
    ${unset?`<div style="font-size:12px;font-weight:600;color:var(--text-3);margin:-4px 2px 8px;line-height:1.4">Starting points, not saved. Adjust and Save to set ${esc(who.name.split(" ")[0])}'s real targets.</div>`:""}
    <section class="card" style="padding:6px 16px">
      ${""}
      ${rows.map(([k,id,v,u,step,lo,hi])=>`
        <div class="lrow" style="cursor:default">
          <div class="lm"><div class="lt">${k}${u?` <small style="color:var(--text-3);font-weight:700">${u}</small>`:""}</div></div>
          <button class="btn sm" data-step="${id}" data-d="-1" data-s="${step}" style="flex:none;width:44px" aria-label="Decrease ${k.toLowerCase()}">\u2212</button>
          <input type="number" inputmode="numeric" class="input" id="${id}" min="${lo}" max="${hi}" step="${step}" value="${v}" style="width:90px;text-align:center" aria-label="${k}" />
          <button class="btn sm" data-step="${id}" data-d="1" data-s="${step}" style="flex:none;width:44px" aria-label="Increase ${k.toLowerCase()}">+</button>
        </div>`).join("")}
    </section>
    ${seeWeight?`
    <div style="height:12px"></div>
    <section class="card" style="padding:12px 16px">
      <div style="display:flex;align-items:center;gap:10px">
        <div class="req-icon b" style="width:34px;height:34px;flex:none">${icon("target",16)}</div>
        <div style="flex:1"><div style="font-size:13.5px;font-weight:800">Suggested from the target weight</div>
        <div id="sg-why" style="font-size:11.5px;font-weight:600;color:var(--text-3);margin-top:1px">Set the target weight above, then tap Suggest.</div></div>
        <button class="btn ghost sm" id="sg-btn" style="width:auto;padding:0 14px;height:32px">Suggest</button>
      </div>
      <div id="sg-out" style="display:none;margin-top:10px;padding-top:10px;border-top:1px solid var(--hairline-soft)">
        <div style="display:flex;align-items:baseline;gap:14px">
          <div><span id="sg-protein" style="font-size:19px;font-weight:800;font-variant-numeric:tabular-nums">\u2014</span><span style="font-size:11px;font-weight:700;color:var(--text-3)"> g protein</span></div>
          <div><span id="sg-calories" style="font-size:19px;font-weight:800;font-variant-numeric:tabular-nums">\u2014</span><span style="font-size:11px;font-weight:700;color:var(--text-3)"> kcal</span></div>
          <button class="btn primary sm" id="sg-use" style="width:auto;padding:0 16px;height:32px;margin-left:auto">Use these</button>
        </div>
        <div style="font-size:11px;font-weight:600;color:var(--text-3);margin-top:6px">Open math, not a black box. You approve, then Save writes it.</div>
      </div>
    </section>`:`
    <div style="height:12px"></div>
    <div class="sidebox">
      <div class="req-icon s38">${icon("lock",17)}</div>
      <div><div class="tt">Weight targets are managed by allowed roles</div>
      <div class="ts">Your role sets protein and calorie targets. Body-weight data and the weight target are visible to the head coach, athletic trainer, and S&amp;C coach.</div></div>
    </div>`}

    <div style="height:14px"></div>
    <div class="sidebox">
      <div class="req-icon b s38">${icon("shield",17)}</div>
      <div><div class="tt">${cap(noun)} owns the numbers</div>
      <div class="ts">Saving sets their targets. Their score is unaffected.</div></div>
    </div>

    <div style="height:16px"></div>
    <button class="btn primary" id="save-targets">${icon("check",19)} Save targets</button>
    <div id="tg-status" style="text-align:center;font-size:13px;font-weight:600;color:var(--text-3);min-height:18px;margin-top:10px"></div>
    <div style="height:10px"></div>
    `},mount(root,{sub}){loadBook(false,bookKindFor(RT.authRole)).then(()=>{if(CD.caps.standards)loadSets();if(!sub&&CD.caps.trustPass)loadTrust()});const planRetry=root.querySelector("#plan-retry");if(planRetry)planRetry.addEventListener("click",()=>{planRetry.disabled=true;loadBook(true,bookKindFor(RT.authRole)).then(()=>{if(CD.caps.standards)loadSets(true);window.__render()})});root.querySelectorAll("[data-tp]").forEach(b=>b.addEventListener("click",async()=>{const[,id]=b.getAttribute("data-tp").split(":");const status2=root.querySelector("#tp-plan-status");const say=(msg,isErr)=>{if(status2)sayStatus(status2,msg,{error:!!isErr})};b.disabled=true;say("Ending\u2026");const ok=await roles.endPass(id);if(!ok){b.disabled=false;say("Could not end it. Try again.",true);return}say("Ended.");await loadTrust(true)}));if(!sub)return;loadTargets(sub);const tgtRetry=root.querySelector("#tgt-retry");if(tgtRetry)tgtRetry.addEventListener("click",()=>{tgtRetry.disabled=true;TGT=null;loadTargets(sub)});root.querySelectorAll("[data-step]").forEach(b=>b.addEventListener("click",()=>{const el=root.querySelector("#"+b.getAttribute("data-step"));if(!el)return;const step=+b.getAttribute("data-s")||1;const lo=+el.min||0,hi=+el.max||9999;const cur=parseInt(el.value,10);el.value=Math.max(lo,Math.min(hi,(isFinite(cur)?cur:lo)+step*+b.dataset.d))}));const sgBtn=root.querySelector("#sg-btn");if(sgBtn){let sg=null;sgBtn.addEventListener("click",()=>{const tw=parseInt((root.querySelector("#tg-weight")||{}).value,10)||0;const bw=TGT&&TGT.basics&&TGT.basics.base_weight;sg=suggestTargets(tw,bw);const why=root.querySelector("#sg-why"),out=root.querySelector("#sg-out");if(!sg){if(why)why.textContent="Set a real target weight first (80\u2013450 lb).";return}if(why)why.textContent=`${sg.why}${bw?` \xB7 current ${Math.round(bw)} lb`:""}`;if(out)out.style.display="";const p=root.querySelector("#sg-protein"),k=root.querySelector("#sg-calories");if(p)p.textContent=sg.protein;if(k)k.textContent=sg.calories});const use=root.querySelector("#sg-use");if(use)use.addEventListener("click",()=>{if(!sg)return;const pEl=root.querySelector("#tg-protein"),kEl=root.querySelector("#tg-calories");if(pEl)pEl.value=sg.protein;if(kEl)kEl.value=sg.calories})}const save=root.querySelector("#save-targets");const status=root.querySelector("#tg-status");if(save)save.addEventListener("click",async()=>{const num=(id,lo,hi,dflt)=>{const el=root.querySelector("#"+id);const v=parseInt(el&&el.value,10);return Math.max(lo,Math.min(hi,isFinite(v)?v:dflt))};save.disabled=true;if(status)status.textContent="Saving\u2026";const payload={protein:num("tg-protein",20,400,180),calories:num("tg-calories",800,8e3,2400)};if(root.querySelector("#tg-weight"))payload.weight=num("tg-weight",80,450,180);const ok=await roles.coachSetGoals(sub,payload);if(ok){if(status)status.textContent="Saved to their plan.";TGT=null;setTimeout(()=>{location.hash=`#coach-athlete/${sub}`},600)}else{save.disabled=false;if(status)status.textContent="Could not save. Check the connection."}});const psEditor=root.querySelector("#ps-editor");if(psEditor){const psStatus=root.querySelector("#ps-status");const psApply=root.querySelector("#ps-apply");const psSay=(msg,bad)=>{if(psStatus){psStatus.style.color=bad?"var(--red)":"var(--text-3)";psStatus.textContent=msg}};const storedStyle=TGT&&TGT.targets?resolveStyleKey(TGT.targets.style):null;const storedOverrides=TGT&&TGT.targets&&TGT.targets.styleOverrides||null;const arm=()=>{if(psApply)psApply.hidden=false;psSay("")};const selectedStyle=()=>{const on=psEditor.querySelector("[data-ps].on");return on?on.getAttribute("data-ps"):null};const draftOverrides=style=>{const detail=root.querySelector("#ps-detail");const calBtn=detail&&detail.querySelector('[data-psk="calorie"] button.on');const proBtn=detail&&detail.querySelector('[data-psk="protein"] button.on');if(!calBtn&&!proBtn)return null;const def=knobsFor(style,null).nutrition;const out={};if(calBtn&&calBtn.getAttribute("data-psv")!==def.calorie)out.calorie=calBtn.getAttribute("data-psv");if(proBtn&&proBtn.getAttribute("data-psv")!==def.protein)out.protein=proBtn.getAttribute("data-psv");return Object.keys(out).length?{nutrition:out}:null};const wireDetailToggles=()=>{root.querySelectorAll("#ps-detail [data-psk] button").forEach(b=>b.addEventListener("click",()=>{b.parentElement.querySelectorAll("button").forEach(x=>{x.classList.toggle("on",x===b);x.setAttribute("aria-checked",x===b?"true":"false")});arm()}))};psEditor.querySelectorAll("[data-ps]").forEach(el=>el.addEventListener("click",()=>{const style=el.getAttribute("data-ps");psEditor.querySelectorAll("[data-ps]").forEach(x=>x.classList.toggle("on",x===el));const detail=root.querySelector("#ps-detail");if(detail){detail.innerHTML=planStyleDetail(style,knobsFor(style,style===storedStyle?storedOverrides:null));wireDetailToggles()}arm()}));if(psApply)psApply.addEventListener("click",async()=>{const style=selectedStyle();if(!style)return;psApply.disabled=true;psSay("Saving\u2026");const ok=await roles.setAthletePlanStyle(sub,style,draftOverrides(style));psApply.disabled=false;if(ok){psSay("Saved to their plan.");TGT=null;loadTargets(sub)}else psSay("Could not save. Check the connection.",true)});wireDetailToggles()}}};const LIFT_DAYS={1:[2],2:[2,4],3:[1,3,5],4:[1,2,4,5],5:[1,2,3,4,5],6:[1,2,3,4,5,6],7:[0,1,2,3,4,5,6]};const MEAL_NAMES=["Breakfast","Lunch","Dinner","Snack","Meal 5","Meal 6"];const MEAL_WINDOWS=[{open:420,due:570},{open:720,due:840},{open:1080,due:1230},{due:1290},{due:1320},{due:1350}];let KNOB=null;const DOW_SHORT=DAYS_SHORT;const DOW_1=["S","M","T","W","T","F","S"];function weighLabel(days){const d=(Array.isArray(days)?days:[]).filter(x=>x>=0&&x<=6).sort((a,b)=>a-b);if(!d.length)return"No days set";if(d.length===7)return"Every day";return d.map(x=>DOW_SHORT[x]).join(" / ")}export function knobsFromItems(items){const mealItems=items.filter(i=>i.kind==="meal");const lift=items.find(i=>i.kind==="lift");const weigh=items.find(i=>i.kind==="weigh");const meals=Math.min(6,Math.max(1,mealItems.length));const slice=mealItems.slice(0,meals);const weighDaily=!!(weigh&&weigh.freq&&weigh.freq.type==="daily");return{meals,lifts:lift?Math.min(7,lift.freq&&lift.freq.days&&lift.freq.days.length||3):0,liftTitle:lift&&lift.title&&lift.title!=="Lift session"?lift.title:"",liftDesc:lift&&lift.desc?lift.desc:"",weigh:weigh?weighDaily?"daily":"custom":"off",weighDays:weigh&&weigh.freq&&Array.isArray(weigh.freq.days)?weigh.freq.days.slice():[1,3,5],photoProof:mealItems.length?mealItems.every(m=>m.proof==="photo"):true,mealProofs:slice.map(m=>m.proof==="check"?"check":"photo"),mealDayTypes:slice.map(m=>m.dayType==="training"||m.dayType==="rest"?m.dayType:"any"),mealNames:slice.map((m,i)=>m.title||MEAL_NAMES[i]),mealWins:slice.map((m,i)=>m.window&&m.window.due!=null?{...m.window}:{...MEAL_WINDOWS[i]}),grace:typeof(mealItems[0]||{}).grace==="number"?mealItems[0].grace:0,latePolicy:(mealItems[0]||{}).latePolicy==="full"||(mealItems[0]||{}).latePolicy==="none"?mealItems[0].latePolicy:"half",coachReview:!!(mealItems[0]||{}).coachReview,snackOptional:mealItems.length>=4&&(!!(mealItems[3]||{}).snack||!!(mealItems[2]||{}).snack)}}function resolveMeals(k){let names,wins;if(Array.isArray(k.mealNames)&&k.mealNames.length===k.meals&&Array.isArray(k.mealWins)&&k.mealWins.length===k.meals){names=k.mealNames;wins=k.mealWins}else if(k.meals===1){names=["Daily meal"];wins=[{open:720,due:1230}]}else if(k.meals===2){names=["Breakfast","Dinner"];wins=[MEAL_WINDOWS[0],MEAL_WINDOWS[2]]}else{names=MEAL_NAMES.slice(0,k.meals);wins=MEAL_WINDOWS.slice(0,k.meals)}const proofs=Array.from({length:k.meals},(_,i)=>{const p=Array.isArray(k.mealProofs)?k.mealProofs[i]:k.photoProof===false?"check":"photo";return p==="check"?"check":"photo"});const dayTypes=Array.from({length:k.meals},(_,i)=>{const d=Array.isArray(k.mealDayTypes)?k.mealDayTypes[i]:"any";return d==="training"||d==="rest"?d:"any"});return{names,wins,proofs,dayTypes}}export function itemsFromKnobs(k){const items=[];const{names,wins,proofs,dayTypes}=resolveMeals(k);const grace=Math.min(240,Math.max(0,+k.grace||0));const latePolicy=k.latePolicy==="full"||k.latePolicy==="none"?k.latePolicy:null;names.forEach((t,i)=>{const meal={id:`meal-${i+1}`,title:String(t||MEAL_NAMES[i]||`Meal ${i+1}`).slice(0,40),kind:"meal",proof:proofs[i],freq:{type:"daily"},window:{...wins[i]}};if(grace>0)meal.grace=grace;if(latePolicy)meal.latePolicy=latePolicy;if(k.coachReview)meal.coachReview=true;if(dayTypes[i]==="training"||dayTypes[i]==="rest")meal.dayType=dayTypes[i];if(k.snackOptional&&k.meals>=4&&i===3)meal.snack=true;items.push(meal)});if(k.lifts>0){const lift={id:"lift",title:k.liftTitle&&String(k.liftTitle).trim()?String(k.liftTitle).trim().slice(0,80):`Lift session`,kind:"lift",proof:"check",freq:{type:"days",days:LIFT_DAYS[k.lifts],label:`${k.lifts}\xD7 / week`},window:{due:1230,label:"After training"}};if(k.liftDesc&&String(k.liftDesc).trim())lift.desc=String(k.liftDesc).trim().slice(0,400);items.push(lift)}if(k.weigh!=="off"){const daily=k.weigh==="daily";const days=daily?null:[...new Set((k.weighDays||[]).filter(x=>x>=0&&x<=6))].sort((a,b)=>a-b);if(daily||days&&days.length)items.push({id:"weight",title:"Morning Weight",kind:"weigh",proof:"scale",freq:daily?{type:"daily"}:{type:"days",days,label:weighLabel(days)},window:{due:540}})}items.push({id:"recovery",title:"Recovery check-in",kind:"recovery",proof:"form",freq:{type:"daily"},window:{due:1410,label:"Before bed"}});return items}export function previewFromKnobs(k){const items=itemsFromKnobs(k);const std=stdFromItems(items);return std?{std,items}:null}let TPL=null;let tplLoading=false;let SHOW_TPL_SAVE=false;let SHOW_TPL_MANAGE=false;let TPL_RENAMING=null;let TPL_BUSY=false;async function loadTemplates(force){if(!CD.caps.templates)return;const teamId=CD.roster&&CD.roster.book[0]&&CD.roster.book[0].id;if(!teamId||tplLoading)return;if(TPL&&TPL.teamId===teamId&&!force)return;tplLoading=true;try{const rows=await roles.fetchRequirementTemplates(teamId);if(rows===null)return;if(rows.length===0&&teamId){for(const s of seedTemplates()){await roles.saveRequirementTemplate(teamId,s.name,s.kind,s.items)}TPL={teamId,rows:await roles.fetchRequirementTemplates(teamId)||[]}}else{TPL={teamId,rows}}}catch{TPL={teamId,rows:[]}}finally{tplLoading=false}if(location.hash.startsWith("#coach-plan"))window.__render()}export const coachPlanSet={nav:"operator",tab:"roster",render({sub}){const[kind,...restVal]=(sub||"team").split("/");const rawVal=restVal.length?restVal.join("/"):void 0;const value=rawVal?decodeURIComponent(rawVal).toUpperCase():null;const key=`${kind}:${value||""}`;const scopeName=kind==="team"?CD.kind==="practice"?"Your Client Standard":"Your Team Standard":`${value} room`;const sets=SETS&&SETS.rows?SETS.rows:[];const existing=sets.find(s=>s.scope_kind===kind&&String(s.scope_value||"").trim().toUpperCase()===(value||"").toUpperCase())||(kind==="team"?sets.find(s=>s.scope_kind==="team"):null);if(!KNOB||KNOB.key!==key){KNOB=existing?{key,...knobsFromItems(existing.items)}:{key,meals:3,lifts:0,weigh:"custom",weighDays:[1,3,5],photoProof:true}}if(CD.kind!=="practice"&&CD.extras&&!canEditStandards(CD.extras.myRole)){const preview=previewFromKnobs(KNOB);return`
      ${backHead(scopeName,"View only. Standards are set by the head coach","coach-plan")}
      <div class="sidebox">
        <div class="req-icon b s38">${icon("eye",17)}</div>
        <div><div class="tt">The standard, as your athletes see it</div>
        <div class="ts">Editing standards is for the head coach, coordinators, and the nutritionist. Ask the head coach if your role should change.</div></div>
      </div>
      ${preview?`
      <section class="card" style="padding:6px 16px">
        ${preview.std.slots.map(slot=>{const title=preview.std.titles[slot]||cap(slot);const due=preview.std.deadlines[slot];return`
        <div class="lrow" style="cursor:default">
          <div class="lm"><div class="lt">${esc(title)}</div>
          <div class="ls">${due!=null?`Due by ${fmtMin(due)}`:"No deadline set"}</div></div>
        </div>`}).join("")}
        <div style="font-size:11.5px;font-weight:600;color:var(--text-3);padding:8px 2px 4px">${preview.std.mealsRequired} meal${preview.std.mealsRequired===1?"":"s"} make the day's nutrition score.</div>
      </section>`:""}
      <div style="height:10px"></div>`}const chip=(on,label,act2,arg)=>`<span class="std-chip ${on?"on":""}" data-knob="${act2}:${arg}">${label}</span>`;const sw=on=>`<div class="std-switch ${on?"on":""}" aria-hidden="true"></div>`;const swRow=(title,subLabel,act2,on)=>`
      <div class="std-switch-row" role="switch" tabindex="0" aria-checked="${on?"true":"false"}" aria-label="${title}" aria-describedby="std-sw-${act2}-sub" data-knob="${act2}:toggle">
        <div class="std-sw-m"><div class="std-sw-t">${title}</div><div class="std-sw-s" id="std-sw-${act2}-sub">${subLabel}</div></div>
        ${sw(on)}
      </div>`;const modHead=(ic,cls,title,subLabel,val)=>`
      <div class="std-mod-head">
        <div class="std-mod-ic ${cls}">${icon(ic,18)}</div>
        <div class="std-mod-tt"><div class="std-mod-t">${title}</div>${subLabel?`<div class="std-mod-s">${subLabel}</div>`:""}</div>
        ${val?`<div class="std-mod-val">${val}</div>`:""}
      </div>`;const sumChip=(ic,html)=>`<span class="std-sum">${icon(ic,13)}${html}</span>`;const toHM=m=>`${String(Math.floor(m/60)).padStart(2,"0")}:${String(m%60).padStart(2,"0")}`;const{names,wins,proofs,dayTypes}=resolveMeals(KNOB);const hasRestPattern=Array.isArray(RT.weekPattern)&&RT.weekPattern.some(d=>d==="rest");const PREV_IC={breakfast:"breakfast",lunch:"lunch",dinner:"dinner",snack:"snack"};return`
    ${backHead(scopeName,kind==="team"?CD.kind==="practice"?"The starting standard for clients without an override":"The starting standard for athletes without an override":`Overrides your team standard for ${esc(value)}`,"coach-plan")}
    <div class="std-wrap">

      <div class="std-summary">
        ${sumChip("utensils",`<b>${KNOB.meals}</b> meal${KNOB.meals===1?"":"s"}`)}
        ${KNOB.photoProof?sumChip("camera","Photo proof"):""}
        ${KNOB.weigh!=="off"?sumChip("scale",KNOB.weigh==="daily"?"Daily weigh":`${weighLabel(KNOB.weighDays)} weigh`):""}
        ${sumChip("moon","Recovery")}
      </div>

      <section class="std-mod">
        ${modHead("utensils","std-ic-g","Meals","The meals that count toward the daily score",`${KNOB.meals}/day`)}
        <div class="std-lbl">Meals per day</div>
        <div class="std-count">${[1,2,3,4,5,6].map(n=>chip(KNOB.meals===n,String(n),"meals",n)).join("")}</div>
        <div class="std-lbl mt">Names, windows &amp; proof \xB7 these drive due-soon, overdue &amp; reminders</div>
        ${names.map((t,i)=>`
        <div class="std-meal-card">
          <div class="std-meal">
            <input class="mname std-name" data-meal="${i}" maxlength="40" value="${esc(t)}" aria-label="Meal ${i+1} name" />
            <button type="button" class="std-proof-pill ${proofs[i]==="check"?"check":""}" data-mealproof="${i}" aria-label="Meal ${i+1} proof: ${proofs[i]==="check"?"tap to check":"photo required"}">${icon(proofs[i]==="check"?"check":"camera",14)} ${proofs[i]==="check"?"Check":"Photo"}</button>
          </div>
          <div class="std-meal-times">
            <input type="time" class="mwin std-time" data-meal="${i}" data-edge="open" value="${wins[i].open!=null?toHM(wins[i].open):""}" aria-label="Meal ${i+1} opens" />
            <span class="std-arrow">\u2192</span>
            <input type="time" class="mwin std-time" data-meal="${i}" data-edge="due" value="${toHM(wins[i].due)}" aria-label="Meal ${i+1} due" />
          </div>
          ${hasRestPattern?`<div class="std-daytype">
            ${["any","training","rest"].map(dt=>`<span class="std-daychip ${dayTypes[i]===dt?"on":""}" data-mealday="${i}:${dt}">${dt==="any"?"Every day":dt==="training"?"Training only":"Rest only"}</span>`).join("")}
          </div>`:""}
        </div>`).join("")}
        <div class="std-switch-row" style="margin-top:8px" role="switch" tabindex="0" aria-checked="${proofs.every(p=>p==="photo")?"true":"false"}" aria-label="Photo proof on every meal" aria-describedby="std-sw-photo-sub" data-knob="photo:toggle">
          <div class="std-sw-m"><div class="std-sw-t">Photo proof on every meal</div><div class="std-sw-s" id="std-sw-photo-sub">Sets all meals at once. Tweak any one above. Off = tap-to-check.</div></div>
          ${sw(proofs.every(p=>p==="photo"))}
        </div>
        ${hasRestPattern?"":`<div class="std-help" style="margin-top:6px">${icon("info",12)} Want meals that only apply on training or rest days? <span class="link" data-go="week-pattern">Set your training week</span> first.</div>`}
        ${KNOB.meals>=4?swRow("Snack is optional","Loggable for bonus, but never counts against the score","snack",KNOB.snackOptional):""}
      </section>

      <section class="std-mod">
        ${modHead("clock","std-ic-b","Timing &amp; late credit","How grace and lateness change a meal\u2019s score")}
        <div class="std-lbl">Grace window</div>
        <div class="std-chips">${[0,15,30,60].map(n=>chip((KNOB.grace||0)===n,n===0?"None":`${n} min`,"grace",n)).join("")}</div>
        <div class="std-lbl mt">Late meals earn</div>
        <div class="std-seg accent">
          ${["half","full","none"].map(p=>`<button class="${(KNOB.latePolicy||"half")===p?"on":""}" data-knob="late:${p}">${p==="half"?"Half":p==="full"?"Full":"None"}</button>`).join("")}
        </div>
        <div class="std-help">A meal logged within grace counts on time. Past it, the late policy sets the credit.</div>
      </section>

      <section class="std-mod">
        ${modHead("bolt","std-ic-a","Training &amp; body","Lifting cadence and weigh-in schedule")}
        <div class="std-lbl">Lift sessions / week</div>
        <div class="std-chips">${[0,1,2,3,4,5,6,7].map(n=>chip(KNOB.lifts===n,n===0?"Off":String(n),"lifts",n)).join("")}</div>
        ${KNOB.lifts>0?`
        <div class="std-lbl mt">Session name <span style="color:var(--text-3);font-weight:600">\xB7 optional</span></div>
        <input class="ob-input lift-title" aria-label="Session name" maxlength="80" placeholder="e.g. Lower Body A" value="${esc(KNOB.liftTitle||"")}" />
        <div class="std-lbl mt">What to do <span style="color:var(--text-3);font-weight:600">\xB7 optional</span></div>
        <textarea class="ob-input lift-desc" aria-label="What to do" maxlength="400" rows="2" style="min-height:56px;resize:vertical" placeholder="Squat 3\xD75, RDL 3\xD78, lunges, core">${esc(KNOB.liftDesc||"")}</textarea>
        <div class="std-help">Your athletes see this on their training day and log a quick note against it. Tracked, not scored.</div>`:""}
        <div class="std-lbl mt">Weigh-ins \xB7 season trend, tracked not scored</div>
        <div class="std-chips">${chip(KNOB.weigh==="off","Off","weigh","off")}${chip(KNOB.weigh==="daily","Daily","weigh","daily")}${chip(KNOB.weigh==="custom","Specific days","weigh","custom")}</div>
        ${KNOB.weigh==="custom"?`<div class="std-weighdays">${[0,1,2,3,4,5,6].map(d=>`<span class="std-daychip ${(KNOB.weighDays||[]).includes(d)?"on":""}" data-weighday="${d}" role="button" aria-label="${DOW_SHORT[d]}${(KNOB.weighDays||[]).includes(d)?" selected":""}">${DOW_1[d]}</span>`).join("")}</div>
        <div class="std-help">${(KNOB.weighDays||[]).length?esc(weighLabel(KNOB.weighDays)):"Pick at least one day, or switch to Off."}</div>`:""}
      </section>

      <section class="std-mod">
        ${modHead("moon","std-ic-p","Recovery","Part of the standard. Every athlete closes the day")}
        <div class="std-help">The nightly check-in is ${liveWeightPct("checkin")+liveWeightPct("recovery")}% of the score. You set what it asks; you don't set whether it counts.</div>
        ${swRow("Coach review on meals","Flag each logged meal for your review","review",KNOB.coachReview)}
      </section>

      ${CD.caps.templates?`
      <section class="std-mod">
        ${modHead("clipboard","std-ic-b","Templates","Start from a proven draft, or save this one")}
        ${SHOW_TPL_MANAGE?`
        <div class="std-tpl-manage">
          ${""}
          ${(TPL&&TPL.rows?TPL.rows:[]).map(t=>TPL_RENAMING===t.id?`
          <div class="lrow" data-vt-row="tpl-${esc(t.id)}" style="cursor:default;gap:8px;padding-left:0">
            <input class="std-name tpl-rename-input" data-tpl-rename-input="${esc(t.id)}" maxlength="40" value="${esc(t.name)}" style="flex:1" aria-label="Rename ${esc(t.name)}" ${TPL_BUSY?"disabled":""} />
            <button class="btn sm" data-tpl-rename-save="${esc(t.id)}" style="width:auto;padding:0 12px;height:34px" ${TPL_BUSY?"disabled":""}>Save</button>
            <button class="btn ghost sm" data-tpl-rename-cancel="1" style="width:auto;padding:0 12px;height:34px" ${TPL_BUSY?"disabled":""}>Cancel</button>
          </div>`:`
          <div class="lrow" data-vt-row="tpl-${esc(t.id)}" style="cursor:default;padding-left:0">
            <div class="lm"><div class="lt">${esc(t.name)}</div><div class="ls">${esc(templateLabel(t.kind))}</div></div>
            <button class="btn ghost sm" data-tpl-rename="${esc(t.id)}" aria-label="Rename template" style="width:34px;padding:0;height:30px;flex:none" ${TPL_BUSY?"disabled":""}>${icon("edit",15)}</button>
            <button class="btn ghost danger micro" data-tpl-del="${esc(t.id)}" style="width:auto;margin-left:6px" ${TPL_BUSY?"disabled":""}>Delete</button>
          </div>`).join("")||`<div class="ls" style="padding:6px 2px">No templates saved yet.</div>`}
        </div>
        <button class="btn ghost sm" data-knob="tplmanage:1" style="width:auto;padding:0 14px;margin-top:10px">Done managing</button>
        `:`
        <div class="std-chips">
          ${(TPL&&TPL.rows?TPL.rows:[]).map(t=>`<span class="std-chip" data-knob="tpl:${esc(t.id)}" title="${esc(templateLabel(t.kind))}">${esc(t.name)}</span>`).join("")}
          <span class="std-chip dashed" data-knob="tplsave:1">${icon("plus",14)} Save current</span>
        </div>
        ${SHOW_TPL_SAVE?`
        <div style="display:flex;gap:8px;margin-top:12px">
          <input class="std-name" id="tpl-name" aria-label="Template name" maxlength="40" placeholder="Template name" style="flex:1" />
          <button class="btn primary sm" id="tpl-save-btn" style="width:auto;padding:0 16px">Save</button>
        </div>`:""}
        ${TPL&&TPL.rows&&TPL.rows.length?`<button class="btn ghost sm" data-knob="tplmanage:1" style="width:auto;padding:0 14px;margin-top:10px">Manage templates</button>`:""}
        `}
      </section>`:""}

      ${(()=>{const preview=previewFromKnobs(KNOB);if(!preview)return"";const{std,items}=preview;const KIND_IC={lift:"bolt",weigh:"scale",recovery:"moon",checkin:"clipboard"};const scheduleLabel=freq=>{if(!freq)return"";if(freq.type==="daily")return"Every day";if(freq.type==="weekly")return freq.label||"Weekly";if(freq.type==="days")return freq.label||(Array.isArray(freq.days)?weighLabel(freq.days):"");return""};const mealItems=items.filter(it=>it.kind==="meal");const mealRows=std.slots.map((slot,i)=>{const it=mealItems[i]||{};const title=std.titles[slot]||cap(String(slot).replace("-"," "));const due=std.deadlines[slot];const g=std.grace&&std.grace[slot];const bits=[due!=null?`Due by ${fmtMin(due)}`:"No deadline set"];if(g)bits.push(`${g} min grace`);bits.push(it.proof==="check"?"Tap to check":"Photo");if(it.dayType==="training")bits.push("Training days");else if(it.dayType==="rest")bits.push("Rest days");if((std.optional||[]).includes(slot))bits.push("Optional");return`
          <div class="std-prev-row">
            <div class="std-prev-ic">${icon(PREV_IC[slot]||"utensils",15)}</div>
            <div style="flex:1;min-width:0"><div class="std-prev-t">${esc(title)}</div>
            <div class="std-prev-s">${esc(bits.join(" \xB7 "))}</div></div>
          </div>`}).join("");const otherRows=items.filter(it=>it.kind!=="meal").map(it=>{const scored=it.kind==="recovery"||it.kind==="checkin";const sub2=[scheduleLabel(it.freq),scored?"Scored pillar":"Tracked, not scored"].filter(Boolean).join(" \xB7 ");return`
          <div class="std-prev-row">
            <div class="std-prev-ic">${icon(KIND_IC[it.kind]||"clipboard",15)}</div>
            <div style="flex:1;min-width:0"><div class="std-prev-t">${esc(it.title)}</div>
            <div class="std-prev-s">${esc(sub2)}</div></div>
          </div>`}).join("");return`
        <section class="std-preview">
          <div class="std-prev-h">${icon("eye",13)} What the athlete sees</div>
          ${mealRows}${otherRows}
          <div class="std-prev-foot"><b>${std.mealsRequired}</b> meal${std.mealsRequired===1?"":"s"} make the day\u2019s nutrition score.</div>
        </section>`})()}

      <section class="std-mod">
        ${modHead("arrowRight","std-ic-b","Effective from","Applies going forward. Today never changes")}
        <div class="std-seg" id="set-effective">
          <button class="${existing?"":"on"}" data-eff="today">Today</button>
          <button class="${existing?"on":""}" data-eff="tomorrow">Tomorrow</button>
          <button data-eff="date">Pick a date</button>
        </div>
        <input type="date" id="set-eff-date" class="std-time" style="display:none;margin-top:8px;width:auto" min="${(()=>{const d=new Date;return`${d.getFullYear()}-${String(d.getMonth()+1).padStart(2,"0")}-${String(d.getDate()).padStart(2,"0")}`})()}" aria-label="Effective date" />
        <div class="std-help">Today applies it now. Tomorrow keeps today unchanged. Or pick a future date. Past, already-scored days are never rewritten.</div>
      </section>

      <div class="std-save">
        <button class="btn primary" id="set-save">${icon("check",19)} Save the ${kind==="team"?CD.kind==="practice"?"client standard":"team standard":`${esc(value)} room standard`}</button>
        ${kind!=="team"&&existing?`<div style="height:9px"></div><button class="btn ghost" id="set-clear">Use the team standard instead</button>`:""}
        <div class="std-status" id="set-status"></div>
      </div>
    </div>
    `},mount(root,{sub}){loadBook(false,bookKindFor(RT.authRole)).then(()=>{loadSets();loadTemplates()});const[kind,...restVal]=(sub||"team").split("/");const rawVal=restVal.length?restVal.join("/"):void 0;const value=rawVal?decodeURIComponent(rawVal).toUpperCase():null;const say=(msg,isErr)=>{const el=root.querySelector("#set-status");if(el)sayStatus(el,msg,{error:!!isErr})};const fromHM=s=>{const[h,mm]=String(s||"").split(":").map(Number);return Number.isFinite(h)&&Number.isFinite(mm)?h*60+mm:null};const materializeMeals=()=>{const need=arr=>!Array.isArray(arr)||arr.length!==KNOB.meals;if(need(KNOB.mealNames)||need(KNOB.mealWins)||need(KNOB.mealProofs)||need(KNOB.mealDayTypes)){const{names,wins,proofs,dayTypes}=resolveMeals(KNOB);KNOB.mealNames=[...names];KNOB.mealWins=wins.map(w=>({...w}));KNOB.mealProofs=[...proofs];KNOB.mealDayTypes=[...dayTypes]}};root.querySelectorAll(".mname").forEach(el=>el.addEventListener("change",()=>{materializeMeals();KNOB.mealNames[+el.getAttribute("data-meal")]=el.value}));root.querySelectorAll(".lift-title").forEach(el=>el.addEventListener("change",()=>{KNOB.liftTitle=el.value}));root.querySelectorAll(".lift-desc").forEach(el=>el.addEventListener("change",()=>{KNOB.liftDesc=el.value}));root.querySelectorAll(".mwin").forEach(el=>el.addEventListener("change",()=>{materializeMeals();const i=+el.getAttribute("data-meal");const edge=el.getAttribute("data-edge");const mins=fromHM(el.value);if(edge==="open"){if(mins==null)delete KNOB.mealWins[i].open;else KNOB.mealWins[i].open=mins}else{KNOB.mealWins[i].due=mins}}));root.querySelectorAll("[data-mealproof]").forEach(el=>el.addEventListener("click",()=>{materializeMeals();const i=+el.getAttribute("data-mealproof");KNOB.mealProofs[i]=KNOB.mealProofs[i]==="check"?"photo":"check";KNOB.photoProof=KNOB.mealProofs.every(p=>p==="photo");window.__render()}));root.querySelectorAll("[data-mealday]").forEach(el=>el.addEventListener("click",()=>{materializeMeals();const[i,dt]=el.getAttribute("data-mealday").split(":");KNOB.mealDayTypes[+i]=dt==="training"||dt==="rest"?dt:"any";window.__render()}));root.querySelectorAll("[data-weighday]").forEach(el=>el.addEventListener("click",()=>{const d=+el.getAttribute("data-weighday");const set=new Set(Array.isArray(KNOB.weighDays)?KNOB.weighDays:[]);if(set.has(d))set.delete(d);else set.add(d);KNOB.weighDays=[...set].sort((a,b)=>a-b);window.__render()}));root.querySelectorAll("[data-knob]").forEach(el=>el.addEventListener("click",()=>{const[k,arg]=el.getAttribute("data-knob").split(":");if(k==="meals"){KNOB.meals=+arg;delete KNOB.mealNames;delete KNOB.mealWins;delete KNOB.mealProofs;delete KNOB.mealDayTypes}if(k==="lifts")KNOB.lifts=+arg;if(k==="weigh"){KNOB.weigh=arg;if(arg==="custom"&&!(Array.isArray(KNOB.weighDays)&&KNOB.weighDays.length))KNOB.weighDays=[1,3,5]}const tog=v=>arg==="toggle"?!v:arg==="1";if(k==="photo"){materializeMeals();const allPhoto=KNOB.mealProofs.every(p=>p==="photo");const nextP=allPhoto?"check":"photo";KNOB.mealProofs=KNOB.mealProofs.map(()=>nextP);KNOB.photoProof=nextP==="photo"}if(k==="review")KNOB.coachReview=tog(KNOB.coachReview);if(k==="snack")KNOB.snackOptional=tog(KNOB.snackOptional);if(k==="grace")KNOB.grace=+arg;if(k==="late")KNOB.latePolicy=arg;if(k==="tpl"){const tpl=TPL&&TPL.rows&&TPL.rows.find(t=>String(t.id)===arg);if(tpl)KNOB={key:KNOB.key,...knobsFromItems(tpl.items)}}if(k==="tplsave")SHOW_TPL_SAVE=!SHOW_TPL_SAVE;if(k==="tplmanage"){SHOW_TPL_MANAGE=!SHOW_TPL_MANAGE;TPL_RENAMING=null}window.__restate()}));root.querySelectorAll("[data-tpl-rename]").forEach(el=>el.addEventListener("click",()=>{TPL_RENAMING=el.getAttribute("data-tpl-rename");window.__restate()}));root.querySelectorAll("[data-tpl-rename-cancel]").forEach(el=>el.addEventListener("click",()=>{TPL_RENAMING=null;window.__restate()}));const submitTplRename=async id=>{const input=root.querySelector(`[data-tpl-rename-input="${id}"]`);const clean=(input&&input.value||"").trim().slice(0,40);if(!clean||TPL_BUSY){TPL_RENAMING=null;window.__render();return}TPL_BUSY=true;window.__render();const r=await roles.renameRequirementTemplate(id,clean);TPL_BUSY=false;TPL_RENAMING=null;if(r.ok)await loadTemplates(true);else{say(r.error||"Could not rename it.",true);window.__render()}};root.querySelectorAll("[data-tpl-rename-save]").forEach(el=>el.addEventListener("click",()=>submitTplRename(el.getAttribute("data-tpl-rename-save"))));root.querySelectorAll("[data-tpl-rename-input]").forEach(el=>el.addEventListener("keydown",e=>{if(e.key==="Enter"&&!e.isComposing)submitTplRename(el.getAttribute("data-tpl-rename-input"));else if(e.key==="Escape"&&!e.isComposing){TPL_RENAMING=null;window.__restate()}}));root.querySelectorAll("[data-tpl-del]").forEach(el=>el.addEventListener("click",async()=>{if(TPL_BUSY)return;const id=el.getAttribute("data-tpl-del");TPL_BUSY=true;window.__render();const r=await roles.deleteRequirementTemplate(id);TPL_BUSY=false;if(r.ok)await loadTemplates(true);else{say("Could not delete it.",true);window.__render()}}));const tplSaveBtn=root.querySelector("#tpl-save-btn");if(tplSaveBtn)tplSaveBtn.addEventListener("click",async()=>{const teamId=CD.roster&&CD.roster.teams[0]&&CD.roster.teams[0].id;const name=((root.querySelector("#tpl-name")||{}).value||"").trim();if(!name){say("Name the template first.",true);return}if(!teamId){say("Your team hasn\u2019t loaded yet. Give it a second.",true);return}tplSaveBtn.disabled=true;say("Saving template\u2026");const r=await roles.saveRequirementTemplate(teamId,name,"custom",itemsFromKnobs(KNOB));tplSaveBtn.disabled=false;if(!r.ok){say(r.error||"Could not save the template.",true);return}SHOW_TPL_SAVE=false;say("Template saved.");await loadTemplates(true)});root.querySelectorAll("#set-effective button").forEach(b=>b.addEventListener("click",()=>{root.querySelectorAll("#set-effective button").forEach(x=>x.classList.remove("on"));b.classList.add("on");const dateInput=root.querySelector("#set-eff-date");if(dateInput)dateInput.style.display=b.getAttribute("data-eff")==="date"?"":"none"}));const save=root.querySelector("#set-save");if(save)save.addEventListener("click",async()=>{const teamId=CD.roster&&CD.roster.teams[0]&&CD.roster.teams[0].id;if(!teamId){say("Your team hasn\u2019t loaded yet. Give it a second.",true);return}const{wins}=resolveMeals(KNOB);for(let i=0;i<wins.length;i++){const w=wins[i];if(w.due==null){say(`Meal ${i+1}'s window closes before it opens. Fix the times.`,true);return}if(w.open!=null&&!(w.open<w.due)){say(`Meal ${i+1}'s window closes before it opens. Fix the times.`,true);return}}const isoOffset=n=>{const d=new Date;d.setDate(d.getDate()+n);return`${d.getFullYear()}-${String(d.getMonth()+1).padStart(2,"0")}-${String(d.getDate()).padStart(2,"0")}`};const effBtn=root.querySelector("#set-effective .on");const effKind=effBtn?effBtn.getAttribute("data-eff"):"tomorrow";let effDate;if(effKind==="today")effDate=isoOffset(0);else if(effKind==="date"){const dv=((root.querySelector("#set-eff-date")||{}).value||"").trim();if(!dv||dv<isoOffset(0)){say("Pick a date from today onward.",true);return}effDate=dv}else effDate=isoOffset(1);save.disabled=true;say("Saving\u2026");const r=await roles.setTeamRequirements(teamId,kind,value,itemsFromKnobs(KNOB),effDate,CD.kind);save.disabled=false;if(!r.ok){say(r.error||"Could not save. Try again.",true);return}const wasSetupOpen=!(RT.coachSetup||{}).standard;act.markCoachSetup("standard");say(effDate===isoOffset(0)?"Saved. This is the standard now.":effDate===isoOffset(1)?"Saved. It takes effect tomorrow. Today is unchanged.":`Saved. It takes effect ${effDate}. Earlier days are unchanged.`);await loadSets(true);if(wasSetupOpen)setTimeout(()=>{location.hash=CD.kind==="practice"?"#trainer":"#coach-home"},700)});const clear=root.querySelector("#set-clear");if(clear)clear.addEventListener("click",async()=>{const teamId=CD.roster&&CD.roster.teams[0]&&CD.roster.teams[0].id;if(!teamId)return;clear.disabled=true;say("Resetting\u2026");const r=await roles.clearTeamRequirements(teamId,kind,value,CD.kind);clear.disabled=false;if(!r.ok){say(r.error||"Could not reset. Try again.",true);return}KNOB=null;await loadSets(true);location.hash="#coach-plan"})}};let ANN_CACHE=null;let annLoadingId=null;async function loadAnnouncements(teamId){if(!teamId)return;if(ANN_CACHE&&ANN_CACHE.teamId===teamId)return;if(annLoadingId===teamId)return;annLoadingId=teamId;try{const rows=await roles.fetchAnnouncements(teamId,3);if(rows!==null)ANN_CACHE={teamId,rows}}finally{annLoadingId=null}if(location.hash==="#coach-inbox")window.__render()}let INBOX_DATA=null;let inboxLoadingId=null;async function loadInboxData(teamId,athleteIds,force){if(!teamId)return;if(INBOX_DATA&&INBOX_DATA.teamId===teamId&&!INBOX_DATA.failed&&!force)return;if(inboxLoadingId===teamId)return;inboxLoadingId=teamId;const sinceISO=new Date(Date.now()-7*864e5).toISOString();try{const[comments,interventions,staff,staffInvites]=await Promise.all([roles.fetchTeamMealComments(athleteIds,sinceISO),CD.caps.interventions?roles.fetchRecentInterventions(teamId,sinceISO,CD.kind):[],CD.caps.staffRoles?roles.fetchTeamStaff(teamId):[],CD.caps.staffRoles?roles.fetchOpenStaffInvites(teamId):[]]);const prev=INBOX_DATA&&INBOX_DATA.teamId===teamId?INBOX_DATA:null;const keep=(rows,field)=>rows===null?prev&&prev[field]||[]:rows;INBOX_DATA={teamId,comments:keep(comments,"comments"),interventions:keep(interventions,"interventions"),staff:keep(staff,"staff"),staffInvites:keep(staffInvites,"staffInvites"),failed:[comments,interventions,staff,staffInvites].some(r=>r===null)}}catch{INBOX_DATA={teamId,comments:[],interventions:[],staff:[],staffInvites:[],failed:true}}finally{inboxLoadingId=null}if(location.hash==="#coach-inbox")window.__render()}const INBOX_CAT_KEY="onstd-inbox-cat-v1";const ALL_INBOX_CATEGORIES=[["needsResponse","Needs response"],["flagged","Flagged"],["athletes","Meal threads"],["mealReviews","Meal reviews"],["staff","Staff"],["announcements","Announcements"],["resolved","Resolved"]];const inboxCategories=()=>{const cats=ALL_INBOX_CATEGORIES.filter(([key])=>(key!=="staff"||CD.caps.staffRoles)&&(key!=="announcements"||CD.caps.announcements));if(!isNutritionBook())return cats.map(([k,l])=>k==="mealReviews"?[k,"Not opened"]:[k,l]);return[...cats.filter(([k])=>k==="mealReviews"),...cats.filter(([k])=>k!=="mealReviews")]};let INBOX_CAT="needsResponse";let INBOX_CAT_CHOSEN=false;const INBOX_PAGE=20;let INBOX_SHOWN={};try{const savedCat=localStorage.getItem(INBOX_CAT_KEY);if(savedCat&&ALL_INBOX_CATEGORIES.some(([key])=>key===savedCat)){INBOX_CAT=savedCat;INBOX_CAT_CHOSEN=true}}catch{}function staffRowsFor(rawStaff){return(rawStaff||[]).map(s=>({id:s.staff_id,name:s.name,role:s.role}))}function inboxOut(){const roster=CD.roster;const teamId=roster&&roster.teams&&roster.teams[0]&&roster.teams[0].id;const data=INBOX_DATA&&INBOX_DATA.teamId===teamId?INBOX_DATA:null;const annRows=ANN_CACHE&&ANN_CACHE.teamId===teamId?ANN_CACHE.rows:[];const nowMs=Date.now();const out=categorizeInbox({meals:CD.act&&CD.act.rows?CD.act.rows:[],comments:data?data.comments:[],interventions:data?data.interventions:[],roster:roster?roster.rows:[],pending:roster?roster.pending||[]:[],staff:staffRowsFor(data?data.staff:[]),staffInvites:data?data.staffInvites:[],announcements:annRows,seenIds:seenMealSet(RT.coachSeenMealIds||[]),nowMs});const entries=entriesFor({kind:"team",value:null});const alerts=inboxAlerts(entries,nowMs);const needsResponse=[...out.needsResponse,...alerts].sort((a,b)=>(b.ts||0)-(a.ts||0));return{...out,needsResponse,counts:{...out.counts,needsResponse:needsResponse.length}}}function inboxRow(r){const when=r.whenLabel||(r.ts?fmtWhen(new Date(r.ts).toISOString(),Date.now()):"");const stamp=when?`<span class="ib-when">${esc(when)}</span>`:"";if(r.kind==="meal"){return`
    <div class="lrow" data-go="coach-meal/${esc(r.id)}">
      <div class="lic">${icon("utensils",17)}</div>
      <div class="lm"><div class="lt">${esc(r.title)}</div><div class="ls">${esc(r.sub||"")}</div></div>
      ${stamp}
      ${icon("chevron",17)}
    </div>`}if(r.kind==="announcement"){return`
    <div class="lrow" data-go="coach-announce">
      <div class="lic">${icon("share",17)}</div>
      <div class="lm"><div class="lt">${esc(r.title)}</div><div class="ls">${esc(r.sub||"")}</div></div>
      ${stamp}
    </div>`}if(r.kind==="staff"){const clickable=!!r.go;return`
    <div class="lrow"${clickable?` data-go="${esc(r.go)}" style="cursor:pointer"`:' style="cursor:default"'}>
      <div class="lic" style="background:var(--blue-surface);color:var(--blue-bright)">${icon("user",17)}</div>
      <div class="lm"><div class="lt">${esc(r.title)}</div><div class="ls">${esc(r.sub||"")}</div></div>
      ${stamp}
      ${clickable?icon("chevron",17,'style="color:var(--text-3)"'):""}
    </div>`}if(r.kind==="alert"){return`
    <button type="button" class="lrow ib-alert" data-roster-status="overdue">
      <div class="lic">${icon("bell",17)}</div>
      <div class="lm"><div class="lt">${esc(r.title)}</div><div class="ls">${esc(r.sub||"")}</div></div>
      ${stamp}
      ${icon("chevron",17)}
    </button>`}return`
    <div class="lrow" style="cursor:default">
      <div class="lic">${icon("checkCircle",17)}</div>
      <div class="lm"><div class="lt">${esc(r.title)}</div><div class="ls">${esc(r.sub||"")}</div></div>
      ${stamp}
    </div>`}let JR_DECLINE=null;function joinRow(q){const key=`${q.teamId}:${q.athlete_id}`;const armed=JR_DECLINE===key;return`
    <div class="jr">
      <div class="jr-top">
        ${""}
        <span class="ros-av jr-av"${q.athlete_id?` data-avatar-uid="${esc(q.athlete_id)}"`:""} aria-hidden="true"><span data-avatar-fallback>${esc(initialsOf(q.athlete_name||"A","A"))}</span></span>
        <div class="jr-who">
          <div class="t">${armed?`Decline ${esc(q.athlete_name||"this athlete")}?`:`${esc(q.athlete_name||"Athlete")}${q.position?` <small style="color:var(--text-3);font-weight:700">\xB7 ${esc(q.position)}</small>`:""}`}</div>
          <div class="s">${armed?"They can request again with your code.":"Wants to join"}</div>
        </div>
      </div>
      <div class="jr-acts">
        ${armed?`
        <button class="btn ghost sm" data-jr-keep="${esc(key)}">Keep</button>
        <button class="btn danger sm" data-jr="decline" data-team="${esc(q.teamId)}" data-ath="${esc(q.athlete_id)}">Decline</button>`:`
        <button class="btn ghost sm" data-jr-arm="${esc(key)}">Decline</button>
        <button class="btn primary sm" data-jr="approve" data-team="${esc(q.teamId)}" data-ath="${esc(q.athlete_id)}">Approve</button>`}
      </div>
      <div class="jr-err"></div>
    </div>`}function replyTitle(meal){const first=String((RT.profile&&RT.profile.name||"").trim().split(" ")[0]||S.operatorIdentity&&S.operatorIdentity.handle||"Your coach").trim()||"Your coach";const slot=meal&&meal.type?String(meal.type).toLowerCase():"meal";return`${first} replied on your ${slot}`}const INBOX_EMPTY_TITLE={needsResponse:"All caught up",flagged:"Nothing flagged",mealReviews:"Every plate seen",resolved:"Nothing resolved yet"};const INBOX_EMPTY={needsResponse:"No threads need you right now.",flagged:"Nothing flagged. Flame a meal from its thread and it waits for you here.",athletes:"No athlete meal threads yet. Logs land here as they come in.",mealReviews:"Nothing unopened. You've seen every log so far.",staff:"No other staff on your team yet.",announcements:"No announcements yet. Send your first from here.",resolved:"Nothing marked resolved yet."};const INBOX_EMPTY_ACTION={athletes:{label:"Share athlete code",go:"coach-profile/code"},staff:{label:"Invite staff",go:"coach-profile/staff"},announcements:{label:"New announcement",go:"coach-announce"}};const codeRoute=()=>CD.kind==="practice"?"trainer-profile":"coach-profile/code";export const coachInbox={nav:"operator",tab:"inbox",pane:"master",badge(){if(!CD.roster||CD.roster.offline)return 0;return inboxOut().counts.needsResponse},render(){const rows=CD.roster?CD.roster.rows:null;const pending=CD.roster?CD.roster.pending||[]:[];let briefing="";if(rows===null)briefing="Reading your roster\u2026";else if(CD.roster&&CD.roster.offline)briefing="Reopen to retry. Nothing is invented while it's down.";else if(!rows.length)briefing=CD.kind==="practice"?"No clients yet. Share your client code from your Practice HQ and this becomes your morning read.":"No athletes yet. Share your team code and this becomes your morning read.";else{const entries=entriesFor({kind:"team",value:null});if(!entries)briefing='<div class="l"><span>Reading your roster\u2026</span></div>';else{const c=teamCounts(entries);const names=key=>{const list=entries.filter(e=>e.status.key===key).map(e=>e.row.name.split(" ")[0]);return`${esc(list.slice(0,3).join(", "))}${list.length>3?"\u2026":""}`};const top=entries.map(e=>({name:e.row.name,score:shownScore(e)})).filter(r=>r.score!=null&&r.score>=ON_STANDARD).sort((a,b)=>b.score-a.score)[0];const lines=[];const bline=(color,html)=>`<div class="l"><span class="dot" style="background:${color}"></span><span>${html}</span></div>`;if(c.overdue)lines.push(bline(statusColor({key:"overdue"}),`<b>${c.overdue} overdue</b>. ${names("overdue")}.`));if(c.noActivity)lines.push(bline(statusColor({key:"no_activity"}),`<b>${c.noActivity} no activity</b> yet today. ${names("no_activity")}.`));if(c.inProgress)lines.push(bline(statusColor({key:"in_progress"}),`<b>${c.inProgress} in progress</b>: under the bar with windows still open.`));if(c.attention)lines.push(bline(statusColor({key:"below_standard"}),`<b>${c.attention} ${c.attention===1?"needs":"need"} attention</b>: below standard, due soon or waiting on review.`));if(top)lines.push(bline(scoreColor(top.score),`<b>${esc(top.name)}</b> leads the day at ${top.score}.`));briefing=lines.join("")||`<div class="l"><span>Quiet so far. Logs land here as they come in.</span></div>`}}if(CD.roster&&CD.roster.offline){return`
      ${avatarHead("Inbox","Can't reach your roster",S.operatorIdentity.initials)}
      <h2 class="eyebrow">Daily briefing</h2>
      <section class="card ib-brief">${briefing}</section>
      <div class="co-gap"></div>`}if(!INBOX_CAT_CHOSEN&&isNutritionBook())INBOX_CAT="mealReviews";if(!inboxCategories().some(([key])=>key===INBOX_CAT))INBOX_CAT="needsResponse";const out=inboxOut();const needsMe=out.counts.needsResponse;const teamIdNow=CD.roster&&CD.roster.teams&&CD.roster.teams[0]&&CD.roster.teams[0].id;const inboxFailed=!!(INBOX_DATA&&INBOX_DATA.teamId===teamIdNow&&INBOX_DATA.failed);const isNeedsResponse=INBOX_CAT==="needsResponse";const showAddAnnouncement=INBOX_CAT==="announcements";const catRows=out[INBOX_CAT]||[];const genericRows=isNeedsResponse?catRows.filter(r=>r.kind!=="join"):catRows;const page=pageRows(genericRows,INBOX_SHOWN[INBOX_CAT]||0,INBOX_PAGE);const capped=!!(CD.act&&CD.act.capped);return`
    ${avatarHead("Inbox",needsMe?`${countLabel(needsMe,capped,"needsResponse")} need${needsMe===1&&!capped?"s":""} you`:inboxFailed?"Couldn't check":"All caught up",S.operatorIdentity.initials)}
    ${inboxFailed?`<div class="co-note warn">Some of your inbox didn't load, so this may not be everything. Nothing was missed on the server; it retries when you reopen.</div>`:""}

    ${isNeedsResponse?`
    <h2 class="eyebrow">Daily briefing</h2>
    <section class="card ib-brief${rows&&!rows.length?" tap":""}"${rows&&!rows.length?` data-go="${codeRoute()}"`:""}>
      ${briefing}
      ${rows&&!rows.length&&RT.team&&RT.team.code?`<div class="acts"><button class="btn ghost sm" id="inbox-copy-code" style="width:auto;padding:0 14px;letter-spacing:0.18em;font-weight:800">${esc(RT.team.code)}</button><button class="btn primary sm" id="inbox-share-code" style="width:auto;padding:0 14px">Share code</button></div>`:""}
    </section>`:""}

    <div class="co-seg co-scroll edge-fade" id="inbox-cat-row" role="radiogroup" aria-label="Inbox category">
      ${inboxCategories().map(([key,label])=>`<button type="button" class="co-chip ${INBOX_CAT===key?"on":""}" role="radio" aria-checked="${INBOX_CAT===key?"true":"false"}" data-icat="${key}">${esc(label)} <span class="cnt">${esc(countLabel(out.counts[key],capped,key))}</span></button>`).join("")}
    </div>

    ${isNeedsResponse&&pending.length?`
    <h2 class="eyebrow">Join requests \xB7 ${pending.length}</h2>
    <section class="card co-list">
      ${pending.map(joinRow).join("")}
    </section>`:""}

    ${genericRows.length||showAddAnnouncement?`
    <section class="card ib-list">
      ${page.rows.map(inboxRow).join("")}
      ${page.more?`
      <button type="button" class="lrow ib-more" data-ib-more="${esc(INBOX_CAT)}">
        <div class="lic">${icon("chevron",17)}</div>
        <div class="lm"><div class="lt">Show ${Math.min(INBOX_PAGE,page.remaining)} more</div><div class="ls">${page.remaining} more in this list</div></div>
      </button>`:""}
      ${showAddAnnouncement?`
      <div class="lrow" data-go="coach-announce">
        <div class="lic">${icon("plus",17)}</div>
        <div class="lm"><div class="lt">New announcement</div></div>
      </div>`:""}
    </section>
    ${""}
    ${isNeedsResponse&&!page.more&&!inboxFailed?`<div class="ib-end">${emptyState({icon:"check",title:"That's everything",body:"Nothing else needs you right now.",compact:true})}</div>`:""}`:isNeedsResponse&&pending.length?"":`
    ${(()=>{if(inboxFailed)return`<div class="co-note">This list couldn't be loaded, so it isn't empty as far as we know.</div>`;const practice=CD.kind==="practice";const emptyCopy=INBOX_CAT==="athletes"&&practice?"No client meal threads yet. Logs land here as they come in.":INBOX_EMPTY[INBOX_CAT];const a=INBOX_EMPTY_ACTION[INBOX_CAT];const action=a&&INBOX_CAT==="athletes"&&practice?{label:"Share client code",go:codeRoute()}:a;return emptyState({icon:INBOX_CAT==="needsResponse"?"check":"message",title:INBOX_EMPTY_TITLE[INBOX_CAT]||"Nothing here yet",body:emptyCopy,action,compact:true})})()}`}

    <div style="height:10px"></div>
    `},mount(root){root.querySelectorAll(".ib-alert[data-roster-status]").forEach(b=>b.addEventListener("click",()=>{openRosterFiltered([b.getAttribute("data-roster-status")],"Overdue")}));loadBook(false,bookKindFor(RT.authRole)).then(()=>{loadActivity();const bookId=CD.roster&&CD.roster.book[0]&&CD.roster.book[0].id;if(bookId){if(CD.caps.announcements)loadAnnouncements(bookId);const athleteIds=(CD.roster.rows||[]).map(r=>r.athleteId).filter(Boolean);loadInboxData(bookId,athleteIds)}});root.querySelectorAll("[data-jr-arm]").forEach(b=>b.addEventListener("click",()=>{JR_DECLINE=b.getAttribute("data-jr-arm");window.__restate?window.__restate():window.__render()}));root.querySelectorAll("[data-jr-keep]").forEach(b=>b.addEventListener("click",()=>{JR_DECLINE=null;window.__restate?window.__restate():window.__render()}));root.querySelectorAll("[data-jr]").forEach(b=>b.addEventListener("click",async()=>{const bookId=b.getAttribute("data-team"),ath=b.getAttribute("data-ath");const approve=b.getAttribute("data-jr")==="approve";const practice=CD.kind==="practice";const label=b.textContent;b.disabled=true;b.textContent="\u2026";const ok=approve?await(practice?roles.approveClient(bookId,ath):roles.approveMember(bookId,ath)):await(practice?roles.declineClient(bookId,ath):roles.declineMember(bookId,ath));if(!ok){b.disabled=false;b.textContent=label;const wrap=b.closest(".jr");const err=wrap&&wrap.querySelector(".jr-err");if(err)err.textContent="Couldn't save that. Try again.";return}JR_DECLINE=null;await loadBook(true,bookKindFor(RT.authRole))}));root.querySelectorAll("[data-icat]").forEach(el=>el.addEventListener("click",()=>{INBOX_CAT=el.getAttribute("data-icat");INBOX_CAT_CHOSEN=true;INBOX_SHOWN={};try{localStorage.setItem(INBOX_CAT_KEY,INBOX_CAT)}catch{}window.__render()}));root.querySelectorAll("[data-ib-more]").forEach(el=>el.addEventListener("click",()=>{const cat=el.getAttribute("data-ib-more");INBOX_SHOWN={...INBOX_SHOWN,[cat]:pageRows([],INBOX_SHOWN[cat]||0,INBOX_PAGE).next};window.__restate?window.__restate():window.__render()}));const copyChip=root.querySelector("#inbox-copy-code");if(copyChip)copyChip.addEventListener("click",async e=>{e.stopPropagation();const code=RT.team&&RT.team.code||"";copyChip.textContent=await copyText(code)?"Copied":"Couldn\u2019t copy";setTimeout(()=>{copyChip.textContent=code},1600)});const shareCode=root.querySelector("#inbox-share-code");if(shareCode)shareCode.addEventListener("click",e=>{e.stopPropagation();location.hash=`#${codeRoute()}`})}};function rosterName(athleteId){const r=CD.roster&&CD.roster.rows.find(x=>x.athleteId===athleteId);return r?{name:r.name,unit:r.unit}:{name:"Athlete",unit:""}}const MEAL_SLOTS=["breakfast","lunch","snack","dinner"];let PSECTION="overview";let PSEC_FOR=null;let NOTE_DEL=null;let NUDGE_ARM=null;let VIEWED_FOR=null;const ALL_PROFILE_SECTIONS=[["overview","Overview",null],["activity","Activity",null],["requirements","Requirements","standards"],["foodmem","Food Memory",null],["notes","Notes","notes"]];const profileSections=()=>ALL_PROFILE_SECTIONS.filter(([,,cap2])=>!cap2||CD.caps[cap2]);const CAT_ROW_STATE={done:{cls:"g",ic:"check"},late:{cls:"a",ic:"clock"},open:{cls:"b",ic:"chevron"},overdue:{cls:"r",ic:"clock"},flagged:{cls:"a",ic:"alert"},info:{cls:"muted",ic:"info"}};function coachCatCard(b){const st=s=>CAT_ROW_STATE[s]||CAT_ROW_STATE.info;return`
  <details class="bd-cat" data-cat="${b.id}">
    <summary class="bd-row">
      <div class="bd-top">
        <span class="bd-name">${esc(b.key)}</span>
        <span class="bd-val">${b.earned}<small>/${b.possible}</small></span>
      </div>
      <div class="bd-bar"><div class="bd-fill ${b.accent}" style="transform:scaleX(${b.possible?(b.earned/b.possible).toFixed(3):0})"></div></div>
      <span class="bd-chev">${icon("chevron",14)}</span>
    </summary>
    <div class="bd-detail">
      ${""}
      <div class="bd-note" style="margin-bottom:6px">${b.weightPct}% of the score${b.note?` \xB7 ${esc(b.note)}`:""}</div>
      ${b.rows.map(r=>`
        <div class="bd-req">
          <span class="bd-req-dot ${st(r.state).cls}"></span>
          <div class="bd-req-main"><div class="t">${esc(r.label)}</div>${r.sub?`<div class="s">${esc(r.sub)}</div>`:""}</div>
          ${r.value?`<div class="bd-req-val">${esc(r.value)}</div>`:""}
        </div>`).join("")}
      <div class="bd-remaining-note">${esc(b.remainingNote)}</div>
    </div>
  </details>`}function breakdownBlock(P,athleteId){const row=P.day;if(!row)return"";const set=resolveRequirementSet(CD.extras&&CD.extras.sets,athleteId,P.row?resolvePos(P.row):null);const std=set?stdFromItems(set.items):null;const b=P.basics||{};const cfg=nutritionConfigForGoal(b.base_goal,b.base_weight,b.targets);const mapped={date:row.date,meals:row.meals||{},checkin:row.checkin||{},quickAdded:row.quick_added||[],hydrationL:row.hydration_l||0,weight:row.current_weight};const day=dayFromHistoryRow(mapped,cfg);if(!day)return`
  <div class="sidebox" style="margin-top:4px"><div class="req-icon b s38">${icon("info",17)}</div>
  <div><div class="tt">Breakdown unavailable</div><div class="ts">This day was logged before detailed scoring data was captured, so it can't be broken down. Their score still stands.</div></div></div>`;const slots=std?std.slots:MEAL_KEYS;const lc=localClock(P.row&&P.row.timezone,Date.now());const nowMin=lc?lc.nowMin:minutesNow();const cats=explainCategories(day,{slots,denom:std?std.mealsRequired:4,titles:std?std.titles:{},optional:std?std.optional||[]:["snack"],nowMin,fmtClock,std});const first=(P.row&&P.row.name||"This athlete").split(" ")[0];const stored=row.score;const earned=cats.reduce((n,c)=>n+(Number(c.earned)||0),0);if(stored!=null&&Math.abs(earned-stored)>2)return`
  <h2 class="eyebrow">Why ${esc(first)}'s day scores this</h2>
  <div class="sidebox"><div class="req-icon b s38">${icon("clock",17)}</div>
  <div><div class="tt">Breakdown catching up</div><div class="ts">Today's latest logs are still syncing into the per-category view. Their score of ${esc(String(stored))} stands.</div></div></div>`;return`
  <h2 class="eyebrow">Why ${esc(first)}'s day scores this</h2>
  <section class="card bd-comp" style="padding:2px 16px">
    ${cats.map(coachCatCard).join("")}
  </section>
  <div style="height:10px"></div>`}function lastActivityLabel(iso){if(!iso)return null;const h=Math.floor((Date.now()-new Date(iso).getTime())/36e5);if(h<1)return"Active just now";if(h<24)return`Active ${h}h ago`;return`Active ${Math.floor(h/24)}d ago`}function coTrend(hist){const pts=(hist||[]).filter(h2=>h2&&h2.score!=null);if(pts.length<2){return`<div class="co-trend"><div class="co-trend-top"><span class="lbl">Last logged days</span><span class="rng">\u2014</span></div>
      <div style="font-size:12px;font-weight:600;color:var(--text-3);padding:4px 0 2px">Two or more logged days unlock the trend.</div></div>`}const w=360,h=60,scores=pts.map(p=>p.score);const min=Math.min(...scores),max=Math.max(...scores),span=Math.max(1,max-min);const xy=pts.map((p,i)=>[i/(pts.length-1)*w,h-7-(p.score-min)/span*(h-14)]);const line=xy.map((c,i)=>`${i?"L":"M"}${c[0].toFixed(1)},${c[1].toFixed(1)}`).join(" ");const area=`M0,${h} L${xy.map(c=>`${c[0].toFixed(1)},${c[1].toFixed(1)}`).join(" L")} L${w},${h} Z`;const stroke=scoreColor(pts[pts.length-1].score);const lp=xy[xy.length-1];return`<div class="co-trend">
    <div class="co-trend-top"><span class="lbl">Last ${pts.length} logged days</span><span class="rng">${min}\u2013${max}</span></div>
    <svg viewBox="0 0 ${w} ${h}" preserveAspectRatio="none" aria-hidden="true">
      <defs><linearGradient id="cotrend" x1="0" y1="0" x2="0" y2="1"><stop offset="0" stop-color="${stroke}" stop-opacity="0.26"/><stop offset="1" stop-color="${stroke}" stop-opacity="0"/></linearGradient></defs>
      <path d="${area}" fill="url(#cotrend)"/>
      <path d="${line}" fill="none" stroke="${stroke}" stroke-width="2.5" stroke-linejoin="round" stroke-linecap="round" vector-effect="non-scaling-stroke"/>
      <circle cx="${lp[0].toFixed(1)}" cy="${lp[1].toFixed(1)}" r="3.5" fill="${stroke}"/>
    </svg>
    <div class="co-trend-x"><span>then</span><span>now</span></div>
  </div>`}function manageSheet(P,athleteId,position){const sport=TGT&&TGT.athleteId===athleteId&&TGT.basics&&TGT.basics.sport||P.basics&&P.basics.sport||"";const codes=SPORT_POSITIONS[sport]||[];const rooms=CD.extras&&CD.extras.rooms||[];const curRoom=P.row&&P.row.roomId;const dis=MANAGE.busy?" disabled":"";const isTeam=CD.kind!=="practice";return`
  <section class="card ca-manage" id="ca-manage-sheet">
    <div class="ca-mrow">
      <div class="ca-mk">Position</div>
      ${codes.length?`<div class="fx-chips ca-chips">${codes.map(c=>`<button type="button" class="fx-chip${String(position||"").toUpperCase()===c.toUpperCase()?" on":""}" data-ca-pos="${esc(c)}"${dis}>${esc(c)}</button>`).join("")}</div>`:`<div class="ca-mrowin"><input class="ob-input" id="ca-pos-input" maxlength="24" placeholder="Position" value="${esc(position||"")}" aria-label="Position"${dis} /><button type="button" class="btn sm" id="ca-pos-save"${dis}>Save</button></div>`}
    </div>
    ${isTeam&&rooms.length?`
    <div class="ca-mrow">
      <div class="ca-mk">Room</div>
      <div class="fx-chips ca-chips">
        <button type="button" class="fx-chip${!curRoom?" on":""}" data-ca-room=""${dis}>None</button>
        ${rooms.map(r=>`<button type="button" class="fx-chip${curRoom===r.id?" on":""}" data-ca-room="${esc(r.id)}"${dis}>${esc(r.label)}</button>`).join("")}
      </div>
    </div>`:""}
    <div class="ca-mrow ca-mrow-danger">
      <div class="ca-mk">${isTeam?"Team":"Practice"}</div>
      ${MANAGE.arm?`<div class="ca-mrowin"><span class="ca-mnote">They keep their logs and scores; they lose your view.</span><button type="button" class="btn ghost sm" id="ca-remove-cancel"${dis}>Keep</button><button type="button" class="btn danger sm" id="ca-remove-go"${dis}>Remove</button></div>`:`<button type="button" class="btn ghost sm ca-remove" id="ca-remove"${dis}>Remove from ${isTeam?"team":"practice"}</button>`}
    </div>
    <div class="ca-mstatus" id="ca-mstatus" role="status" aria-live="polite">${esc(MANAGE.note||"")}</div>
  </section>`}function closeMoreSheet(focusBack){document.querySelectorAll(".ca-more-scrim, .sheet.ca-more").forEach(n=>n.remove());document.removeEventListener("keydown",moreKey);window.removeEventListener("hashchange",closeMoreSheetQuiet);if(focusBack&&typeof focusBack.focus==="function"){try{focusBack.focus()}catch{}}}function closeMoreSheetQuiet(){closeMoreSheet(null)}function moreKey(e){if(e.key==="Escape")closeMoreSheet(document.getElementById("ca-more"))}function openMoreSheet(root,athleteId,opener){const tpl=root.querySelector("#ca-more-tpl");const host=root.querySelector(".screen")||root;if(!tpl||overlayOpen())return;host.appendChild(tpl.content.cloneNode(true));const sheet=host.querySelector(".sheet.ca-more");if(!sheet)return;document.addEventListener("keydown",moreKey);window.addEventListener("hashchange",closeMoreSheetQuiet);host.querySelectorAll("[data-more-close]").forEach(el=>el.addEventListener("click",()=>closeMoreSheet(opener)));sheet.querySelectorAll("[data-go]").forEach(el=>el.addEventListener("click",()=>closeMoreSheet(null)));const manage=sheet.querySelector("#ca-manage");if(manage)manage.addEventListener("click",()=>{closeMoreSheet(null);MANAGE.open=!MANAGE.open;MANAGE.arm=false;MANAGE.note="";window.__render()});const end=sheet.querySelector("#tp-btn");if(end)end.addEventListener("click",async()=>{closeMoreSheet(opener);const status=document.querySelector("#tp-status");if(status)status.textContent="Ending\u2026";const ok=await roles.endPass(athleteId);const st2=document.querySelector("#tp-status");if(st2)st2.textContent=ok?"Trust Pass ended.":"Could not end it.";setTimeout(()=>{if(location.hash.startsWith("#coach-athlete"))loadAthleteProfile(athleteId,true)},500)});const first=sheet.querySelector(".sheet-row");if(first){try{first.focus()}catch{}}}let ASUM={id:null,row:null,loading:false,error:null,busy:false,note:""};const SUMMARY_REFRESH_MS=2*24*3600*1e3;async function loadAthleteSummary(athleteId){if(!athleteId||ASUM.id===athleteId&&(ASUM.loading||ASUM.row||ASUM.error))return;ASUM={id:athleteId,row:null,loading:true,error:null,busy:false,note:""};const r=await roles.fetchAthleteSummary(athleteId);if(ASUM.id!==athleteId)return;ASUM={id:athleteId,row:r.row||null,loading:false,error:r.ok?null:r.error||"unavailable",busy:false,note:""};if(location.hash.startsWith("#coach-athlete"))window.__render()}function summaryRefreshAt(row){const t=row&&row.last_manual_at?Date.parse(row.last_manual_at):NaN;if(!isFinite(t))return null;const at=t+SUMMARY_REFRESH_MS;return at>Date.now()?at:null}function fmtRefreshAt(ms){const d=new Date(ms),now=new Date;const sameDay=d.toDateString()===now.toDateString();const tomorrow=new Date(now.getFullYear(),now.getMonth(),now.getDate()+1).toDateString()===d.toDateString();const clock=fmtClock(d.getHours()*60+d.getMinutes());return sameDay?`today at ${clock}`:tomorrow?`tomorrow at ${clock}`:`${weekdayLong(d)} at ${clock}`}function aiSummaryCard(P,athleteId){const first=(P.row&&P.row.name||"this athlete").split(" ")[0];const row=ASUM.id===athleteId?ASUM.row:null;const cadence=row&&row.cadence_days===3?3:6;const gen=row&&row.generated_at?fmtWhen(row.generated_at,Date.now()):"";const nextAt=summaryRefreshAt(row);const busy=ASUM.busy;let body;if(ASUM.id!==athleteId||ASUM.loading){body=`<div class="mr-skel asum-skel" aria-label="Loading the read"><div class="mr-skel-line"></div><div class="mr-skel-line"></div><div class="mr-skel-line"></div><div class="mr-skel-line"></div></div>`}else if(!row||!row.generated_at){body=`<div class="asum-empty">${ASUM.error==="ai_consent_required"?`${esc(first)} has not turned on Nia, so she does not write a read of them.`:ASUM.error?"Can't reach Nia right now.":`Nia has not written a read of ${esc(first)} yet.`}</div>`}else{body=`
      ${row.headline?`<div class="asum-headline">${esc(row.headline)}</div>`:""}
      <p class="asum-text">${esc(row.summary||"")}</p>
      ${row.watch?`<div class="asum-watch"><span class="asum-watch-k">Watch</span><span>${esc(row.watch)}</span></div>`:""}`}const canRefresh=!busy&&ASUM.id===athleteId&&!ASUM.loading&&!nextAt;return`
  <section class="card asum" aria-label="Nia\u2019s read">
    <div class="asum-head">
      <div class="asum-who"><span class="asum-ic nia-av">${NIA_MARK}</span><span>Nia\u2019s read \xB7 AI</span></div>
      <div class="asum-when">${gen?`Updated ${esc(gen==="now"?"just now":gen)}`:""}</div>
    </div>
    ${body}
    <div class="asum-foot">
      <div class="co-seg asum-cad" role="radiogroup" aria-label="How often the read updates">
        <span class="asum-cad-k">Every</span>
        <button type="button" class="co-chip ${cadence===3?"on":""}" role="radio" aria-checked="${cadence===3}" data-asum-cad="3">3 days</button>
        <button type="button" class="co-chip ${cadence===6?"on":""}" role="radio" aria-checked="${cadence===6}" data-asum-cad="6">6 days</button>
      </div>
      <button type="button" class="btn ghost sm asum-refresh" id="asum-refresh" ${canRefresh?"":"disabled"}>${busy?"Writing\u2026":"Refresh"}</button>
    </div>
    <div class="asum-note ${ASUM.note?"":"asum-note-quiet"}" id="asum-note">${esc(ASUM.note||(nextAt?`Refresh again ${fmtRefreshAt(nextAt)}.`:row&&row.generated_at?"One refresh every two days.":""))}</div>
  </section>`}function overviewSection(P,athleteId){const st=P.status;const crit=st&&(st.key==="overdue"||st.key==="no_activity");const last=lastActivityLabel(P.row&&P.row.lastMealAt);const subtitle=st&&st.key!=="on_standard"&&st.detail||last||"";const alerts=(P.exceptions||[]).map(e=>e.reason?`Excused \xB7 ${e.reason}`:"Excused");const e0=(entriesFor({kind:"athlete",value:athleteId})||[])[0];const score=P.day&&P.day.score!=null?e0?shownScore({...e0,row:{...e0.row,score:P.day.score}}):P.day.score:null;const stLabel=st?statusLabel(st,score):"";const lastLine=last&&subtitle!==last?last:"";return`
  <section class="card co-hero">
    ${score!=null?`<div class="co-hero-ring">${scoreRing({score,size:96,stroke:9,showCenter:false,centerNum:true,uid:"coathlete"})}</div>`:""}
    <div style="min-width:0;flex:1">
      <div class="co-status co-hero-st ${crit?"crit":""}"><span class="dot" style="background:${st?statusColor(st,score):"var(--text-3)"}"></span><span class="lbl">${stLabel?esc(stLabel):"\u2014"}</span></div>
      ${subtitle?`<div class="co-hero-sub">${esc(subtitle)}</div>`:""}
      ${lastLine?`<div class="co-hero-last">${esc(lastLine)}</div>`:""}
    </div>
  </section>

  ${aiSummaryCard(P,athleteId)}
  ${todayBlock(P,athleteId)}
  ${breakdownBlock(P,athleteId)}

  <h2 class="eyebrow">7-day trend</h2>
  ${coTrend(P.row&&P.row.scoreHistory||[])}

  ${alerts.length?`<h2 class="eyebrow">Active alerts</h2>
  <section class="card" role="list" style="padding:var(--s1) var(--s4)">
    ${alerts.map(a=>`<div class="lrow" role="listitem" style="cursor:default"><div class="lic" style="color:var(--amber-bright)">${icon("bell",17)}</div><div class="lm"><div class="lt">${esc(a)}</div></div></div>`).join("")}
  </section>`:""}
  `}function todayBlock(P,athleteId){const day=P.day;const today=roles.todayISO();const todayMeals=(P.meals||[]).filter(m=>m.day_date===today);const mealsJson=day&&day.meals||{};const ci=day&&day.checkin||{};const set=resolveRequirementSet(CD.extras&&CD.extras.sets,athleteId,P.row?resolvePos(P.row):null);const std=set?stdFromItems(set.items):null;const slots=std?std.slots:MEAL_KEYS;const optional=new Set(std?std.optional||[]:["snack"]);const slotTitle=k=>std&&std.titles&&std.titles[k]||cap(k);const denom=std?std.mealsRequired:slots.filter(k=>!optional.has(k)).length;const rowSlots=new Set(todayMeals.map(m=>String(m.type||"").toLowerCase()));const isLogged=k=>!!mealsJson[k]||rowSlots.has(k);const logged=slots.filter(isLogged).length;const openSlots=slots.filter(k=>!isLogged(k)&&!optional.has(k));const requiredIn=Math.max(0,denom-openSlots.length);return`
    ${!day?`<div class="sidebox" style="margin-top:14px"><div class="req-icon a s38">${icon("clock",17)}</div>
    <div><div class="tt">No logs today yet</div><div class="ts">Nothing to review. They haven't logged. Their day appears here as they log it.</div></div></div>`:`
    <h2 class="eyebrow">Today's proof${todayMeals.length?"":" \xB7 none yet"}</h2>
    ${""}
    ${todayMeals.length?`<div class="hscroll">
      ${todayMeals.map(m=>{const label=cap(m.type||"Meal");const scored=m.quality!=null;const acc=scored&&qualityAccent(m.quality)==="g"?"g":"b";return`
        <div class="co-proof" data-go="coach-meal/${esc(m.id)}" role="button" aria-label="${esc(label)}, ${scored?`meal score ${m.quality}`:"not scored yet"}. Review and comment">
          <div class="pm${P.photos[m.id]?"":" icon"}">
            ${P.photos[m.id]?`<img src="${esc(P.photos[m.id])}" alt="Photo of this meal" loading="lazy" decoding="async"/>`:icon("utensils",26)}
            ${scored?`<span class="sc ${acc}">${m.quality}</span>`:""}
          </div>
          <div class="ft"><div class="nm">${esc(label)}</div>${scored?"":'<div class="st">Not scored yet</div>'}</div>
        </div>`}).join("")}
    </div>`:`<div class="co-proof-none">No meal photos logged today.</div>`}

    ${""}
    ${(()=>{const anyOpen=openSlots.length>0||!ci.submitted;return`
      <h2 class="eyebrow">${anyOpen?"What's open":"Day complete"} \xB7 ${requiredIn} of ${denom} meals in</h2>
      ${anyOpen?`<section class="card co-open" role="list">
        ${openSlots.map(k=>`
          <div class="lrow" role="listitem"><div class="lic">${icon("bowl",17)}</div>
          <div class="lm"><div class="lt">${esc(slotTitle(k))}</div><div class="ls">Not logged yet</div></div><span class="status-pill muted">Open</span></div>`).join("")}
        ${!ci.submitted?`<div class="lrow" role="listitem"><div class="lic">${icon("moon",17)}</div>
          <div class="lm"><div class="lt">Recovery check-in</div><div class="ls">Before bed</div></div><span class="status-pill muted">Open</span></div>`:""}
      </section>`:`<div class="co-done"><div class="ic">${icon("check",16)}</div>
        <div><div class="t">Everything is in</div><div class="s">Finished day</div></div></div>`}`})()}`}
    <div style="height:10px"></div>
  `}function relTime(iso){if(!iso)return"";const t=new Date(iso).getTime();if(!isFinite(t))return"";const ms=Date.now()-t;const future=ms<0;const m=Math.floor(Math.abs(ms)/6e4);const fmt=(v,u)=>future?`in ${v}${u}`:`${v}${u} ago`;if(m<1)return future?"soon":"just now";if(m<60)return fmt(m,"m");const h=Math.floor(m/60);if(h<24)return fmt(h,"h");const d=Math.floor(h/24);if(d<7)return fmt(d,"d");return fmt(Math.floor(d/7),"w")}let TLOGS={id:null,rows:[]};function activitySection(P){const items=[];for(const l of TLOGS.rows||[]){if(!l||!l.log_date)continue;let when=l.log_date,ts=0;try{const d=new Date(l.log_date+"T12:00:00");ts=d.getTime();when=d.toLocaleDateString(void 0,{month:"short",day:"numeric"})}catch{}const feelW=l.feel?["","rough","tough","ok","good","great"][l.feel]:"";const detail=l.note?`\xB7 \u201C${esc(l.note.slice(0,80))}${l.note.length>80?"\u2026":""}\u201D`:feelW?`\xB7 felt ${feelW}`:"";items.push({ts:isFinite(ts)?ts:0,cls:"i-coach",when,what:`Training: ${esc(l.title||"Workout")}${detail?` <span class="sub">${detail}</span>`:""}`})}for(const m of P.meals||[]){if(!m||!m.id||!m.logged_at)continue;items.push({ts:new Date(m.logged_at).getTime(),cls:"i-meal",go:`coach-meal/${m.id}`,when:relTime(m.logged_at),what:`${esc(cap(m.type||"Meal"))} logged${m.quality!=null?` <span class="sub">\xB7 quality ${m.quality}</span>`:""}`})}const day=P.day;if(day&&day.updated_at){const t=new Date(day.updated_at).getTime();if(isFinite(t)){if(day.current_weight!=null)items.push({ts:t,cls:"i-weight",when:relTime(day.updated_at),what:`Weighed in <span class="sub">\xB7 ${esc(String(day.current_weight))} lb</span>`});if(day.checkin&&day.checkin.submitted)items.push({ts:t,cls:"i-weight",when:relTime(day.updated_at),what:"Recovery check-in submitted"})}}for(const iv of P.interventions||[]){if(!iv||!iv.created_at||iv.kind!=="nudge"&&iv.kind!=="handled")continue;items.push({ts:new Date(iv.created_at).getTime(),cls:"i-coach",when:relTime(iv.created_at),what:iv.kind==="nudge"?"You nudged them":"You marked this handled"})}for(const a of P.assignments||[]){if(!a||!a.created_at)continue;items.push({ts:new Date(a.created_at).getTime(),cls:"i-coach",when:relTime(a.created_at),what:`Assigned <span class="sub">\xB7 ${esc(a.title||"Requirement")}</span>`})}items.sort((x,y)=>y.ts-x.ts);if(!items.length)return`
  ${TLOGS.error?`<div class="co-note warn">Training logs couldn't load just now. Reopen the page to retry.</div>`:""}
  ${emptyState({icon:"clock",title:"No activity in the last 30 days",body:"Meal logs, weigh-ins, check-ins, and your own actions land here as they happen."})}`;return`
  <h2 class="eyebrow">Last 30 days</h2>
  ${TLOGS.error?`<div class="co-note warn">Training logs couldn't load just now, so they're missing from this list. Reopen the page to retry.</div>`:""}
  <div class="co-tl">
    ${items.map(i=>`<div class="co-tl-item ${i.cls}${i.go?" go":""}"${i.go?` data-go="${esc(i.go)}"`:""}><div class="co-tl-when">${esc(i.when)}</div><div class="co-tl-what">${i.what}</div></div>`).join("")}
  </div>`}function requirementSourceLabel(set){if(!set)return"Team standard (built-in)";if(set.scope_kind==="athlete")return"Individual";if(set.scope_kind==="position")return`${String(set.scope_value||"").trim().toUpperCase()||"Position"} room`;return"Team standard"}function requirementsSection(P,athleteId){const set=resolveRequirementSet(CD.extras&&CD.extras.sets,athleteId,P.row&&P.row.position);const reqs=set?catalogFromItems(set.items):CATALOG;const source=requirementSourceLabel(set);const exceptions=P.exceptions||[];const assignments=P.assignments||[];const assignFailed=!!(P.failedSections&&P.failedSections.assignments);const win=r=>{const w=r.window||{};if(Number.isFinite(w.open)&&Number.isFinite(w.due))return`${fmtMin(w.open)} \u2013 ${fmtMin(w.due)}`;if(Number.isFinite(w.due))return w.label?`${w.label} \xB7 by ${fmtMin(w.due)}`:`By ${fmtMin(w.due)}`;return w.label||""};const editStd=set&&set.scope_kind==="position"&&set.scope_value?`coach-plan-set/position/${encodeURIComponent(String(set.scope_value))}`:"coach-plan-set/team";const tg=TGT&&TGT.athleteId===athleteId?TGT:null;const t=tg?tg.targets||{}:null;const seeWeight=CD.kind==="practice"||canViewWeight(CD.extras&&CD.extras.myRole);const rc=(VC.board||[]).find(b=>b&&b.type==="morning_roll_call")||null;return`
  <h2 class="eyebrow">Their standard <span class="ca-src">\xB7 ${esc(source)}</span></h2>
  <section class="card co-list ro" role="list">
    ${reqs.length?reqs.map(r=>`
    <div class="lrow" role="listitem"><div class="lic" style="color:${accentVar(r.accent)}">${icon(r.icon||"clipboard",17)}</div>
    <div class="lm"><div class="lt">${esc(r.title)}</div><div class="ls">${esc(win(r))}${win(r)?" \xB7 ":""}${esc(PROOF[r.proof]&&PROOF[r.proof].label||"Proof")} \xB7 ${esc(freqLabel(r.freq))}${r.grace?` \xB7 ${r.grace} min grace`:""}</div></div></div>`).join(""):`<div class="lrow" role="listitem"><div class="lm"><div class="ls">No requirements set.</div></div></div>`}
    <div class="lrow" data-go="${esc(editStd)}">
      <div class="lic ca-lic-blue">${icon("edit",17)}</div>
      <div class="lm"><div class="lt">Change meal times and proof</div><div class="ls">${set&&set.scope_kind==="position"?`Edits the ${esc(String(set.scope_value||"").toUpperCase())} room's standard`:"Edits the team standard"}</div></div>
      ${icon("chevron",17)}
    </div>
  </section>

  <h2 class="eyebrow">Targets</h2>
  <section class="card co-list ro" role="list">
    ${!tg?`<div class="lrow" role="listitem"><div class="lm"><div class="ls">Loading their targets\u2026</div></div></div>`:`
    <div class="lrow" role="listitem"><div class="lic ca-lic-blue">${icon("target",17)}</div><div class="lm"><div class="lt">Protein</div></div><span class="lv">${t.protein!=null?`${esc(String(t.protein))}g`:"\u2014"}</span></div>
    <div class="lrow" role="listitem"><div class="lic">${icon("bolt",17)}</div><div class="lm"><div class="lt">Calories</div></div><span class="lv">${t.calories!=null?esc(String(t.calories)):"\u2014"}</span></div>
    ${seeWeight?`<div class="lrow" role="listitem"><div class="lic">${icon("bars",17)}</div><div class="lm"><div class="lt">Goal weight</div><div class="ls">${tg.basics&&tg.basics.base_weight?`Now ${esc(String(tg.basics.base_weight))} lb`:""}</div></div><span class="lv">${t.weight!=null?`${esc(String(t.weight))} lb`:"\u2014"}</span></div>`:""}`}
    <div class="lrow" data-go="coach-plan/${esc(athleteId)}">
      <div class="lic ca-lic-blue">${icon("edit",17)}</div>
      <div class="lm"><div class="lt">Change targets</div><div class="ls">Protein, calories${seeWeight?", goal weight":""}, plan style</div></div>
      ${icon("chevron",17)}
    </div>
  </section>

  ${ROLLCALL_OFF?"":`<h2 class="eyebrow">Roll call</h2>
  <section class="card co-list ro" role="list">
    ${rc?`
    <div class="lrow" role="listitem"><div class="lic">${icon("sun",17)}</div>
      <div class="lm"><div class="lt">${esc(rc.title||"Roll call")}</div><div class="ls">${rc.starts_min!=null?`${esc(fmtMin(Number(rc.starts_min)))} \xB7 `:""}${esc(rc.audience_label||"Everyone")}</div></div></div>
    ${""}
    <div class="lrow" data-go="rollcall/${esc(rc.commitment_id)}">
      <div class="lic ca-lic-blue">${icon("sun",17)}</div>
      <div class="lm"><div class="lt">Open the roll call</div><div class="ls">Who will ring, the live board and results</div></div>
      ${icon("chevron",17)}
    </div>`:`
    <div class="lrow" data-go="rollcall-new">
      <div class="lic ca-lic-blue">${icon("plus",17)}</div>
      <div class="lm"><div class="lt">Set a roll call</div><div class="ls">None scheduled for this ${CD.kind==="practice"?"practice":"team"}</div></div>
      ${icon("chevron",17)}
    </div>`}
  </section>`}

  ${exceptions.length?`
  <h2 class="eyebrow co-minor">Excused</h2>
  <section class="card co-list ro" role="list">
    ${exceptions.map(e=>`
    <div class="lrow" role="listitem"><div class="lic" style="color:var(--amber-bright)">${icon("bell",17)}</div>
    <div class="lm"><div class="lt">${esc(e.reason||"Excused")}</div><div class="ls">${esc(e.starts_on||"")}${e.ends_on?` \u2013 ${esc(e.ends_on)}`:""}</div></div></div>`).join("")}
  </section>`:""}

  ${assignFailed&&!assignments.length?`<div class="co-note warn">Couldn't load their assignment history. Nothing was changed; reopen to retry.</div>`:""}
  ${assignments.length?`
  <h2 class="eyebrow co-minor">Assignments</h2>
  <section class="card co-list ro" role="list">
    ${assignments.map(a=>`
    <div class="lrow" role="listitem"><div class="lic">${icon("clipboard",17)}</div>
    <div class="lm"><div class="lt">${esc(a.title||"Requirement")}</div>
    <div class="ls">${esc(PROOF[a.proof]&&PROOF[a.proof].label||a.proof||"Proof")} \xB7 ${esc(cap(a.status||"open"))} \xB7 ${esc(relTime(a.due_at||a.created_at))}${a.note?` \xB7 ${esc(a.note)}`:""}</div></div></div>`).join("")}
  </section>`:""}
  <div class="co-gap"></div>`}let FMEM={id:null,items:null,places:[]};function foodMemSection(P,athleteId){if(FMEM.id!==athleteId||FMEM.items===null&&!FMEM.error){return`<div class="sidebox"><div class="req-icon b s38">${icon("utensils",17)}</div>
    <div><div class="tt">Loading their saved meals\u2026</div><div class="ts">What they eat repeatedly, learned from their logging.</div></div></div>`}if(FMEM.error){return errorState({title:"Couldn't load their saved meals",body:"Nothing is missing on their side; this screen just could not reach the server.",retryId:"fm-retry"})}const items=(FMEM.items||[]).filter(i=>i.status!=="archived");if(!items.length){return`<div class="state-demo"><div class="sd-ic">${icon("utensils",24)}</div>
    <div class="sd-t">Nothing saved yet</div>
    <div class="sd-s">As they log, OnStandard learns their usual meals and orders. Saved meals show up here for you to review and verify.</div></div>`}const placeName=pid=>{const p=FMEM.places.find(x=>x.id===pid);return p?p.name:null};return`
  <h2 class="eyebrow">Their usual meals <span class="n">${items.length}</span></h2>
  <div style="font-size:12.5px;font-weight:600;color:var(--text-2);line-height:1.5;margin:2px 2px 10px">Verify a meal you know is right. It gets a trusted badge on their Plan and Nia leans on it in future reads.</div>
  <section class="card" style="padding:4px 16px">
    ${items.map(it=>{const pl=it.place_id?placeName(it.place_id):null;return`<div class="bd-row" style="display:flex;align-items:center;gap:12px">
      <div class="req-icon b s38" style="flex:none">${icon(it.kind==="supplement"?"bolt":"utensils",17)}</div>
      <div style="flex:1;min-width:0">
        <div style="font-size:14px;font-weight:800;overflow:hidden;text-overflow:ellipsis;white-space:nowrap">${esc(it.name)}</div>
        <div style="font-size:12px;font-weight:600;color:var(--text-2);margin-top:2px">${it.protein||0}g protein \xB7 ${it.kcal||0} kcal${pl?` \xB7 ${esc(pl)}`:""}${it.times_logged>1?` \xB7 logged ${it.times_logged}\xD7`:""}</div>
      </div>
      ${it.verified_at?`<span class="bd-weight" style="color:var(--green-bright);flex:none;display:inline-flex;align-items:center;gap:4px">${icon("check",12)} Verified</span>`:`<button class="btn ghost sm" data-fm-verify="${esc(it.id)}" style="width:auto;padding:0 14px;height:36px;flex:none">Verify</button>`}
    </div>`}).join("")}
  </section>`}function notesSection(P){const notes=P.notes||[];const notesFailed=!!(P.failedSections&&P.failedSections.notes);return`
  <div class="co-notebanner"><span class="ic">${icon("lock",16)}</span><span>Private to your staff. <b>the athlete never sees these.</b></span></div>

  <h2 class="eyebrow">Notes${notes.length?` <span class="n">${notes.length}</span>`:" \xB7 none yet"}</h2>
  ${notes.length?`
  <section class="card" style="padding:0 var(--s4)">
    ${notes.map(n=>`
    <div class="co-note-row" data-vt-row="note-${esc(n.id)}">
      <div style="flex:1;min-width:0">
        <div><span class="who">${n.author_id===RT.userId?"You":"Staff"}</span> <span class="when">\xB7 ${esc(relTime(n.created_at))}</span></div>
        <div class="body">${esc(n.body)}</div>
      </div>
      ${NOTE_DEL===n.id?`
      <div style="display:flex;gap:6px;flex:none;align-items:center">
        <button class="btn ghost micro" data-del-note-cancel="1" style="width:auto">Keep</button>
        <button class="btn danger micro" data-del-note-confirm="${esc(n.id)}" style="width:auto">Delete</button>
      </div>`:`
      <button class="btn sm" data-del-note="${esc(n.id)}" style="flex:none;width:36px;height:36px;padding:0" aria-label="Delete note">${icon("x",15)}</button>`}
    </div>`).join("")}
  </section>`:notesFailed?`<div class="co-note warn">Couldn't load their notes. Any notes already written are safe; reopen to retry.</div>`:`<div class="co-note">No notes on this athlete yet. Jot the first below.</div>`}

  <h2 class="eyebrow">Add a note</h2>
  <section class="card" style="padding:var(--s3) var(--s4)">
    <textarea id="cn-input" aria-label="New note" aria-describedby="cn-err" rows="3" maxlength="1000" placeholder="Something worth remembering about this athlete\u2026"
      style="display:block;width:100%;box-sizing:border-box;border-radius:var(--r-chip);background:var(--surface-2);border:1.5px solid var(--hairline);color:var(--text);font-family:var(--font);font-size:14px;font-weight:600;line-height:1.5;padding:11px 13px;outline:none;resize:none"></textarea>
    <div id="cn-err" style="font-size:12px;font-weight:700;color:var(--amber-bright);min-height:0;margin:6px 0"></div>
    <button class="btn primary sm" id="cn-save">Save note</button>
  </section>`}export const coachAthlete={nav:"operator",tab:"roster",pane:"detail",render({sub}){const athleteId=sub;if(athleteId!==PSEC_FOR){PSECTION="overview";PSEC_FOR=athleteId;NUDGE_ARM=null;NOTE_DEL=null}if(!profileSections().some(([k])=>k===PSECTION))PSECTION="overview";const who=rosterName(athleteId);const opView=isNutritionBook()?"dietitian view":"";const opBack=CD.kind==="practice"?"trainer-roster":"coach-roster";if(!athleteId)return`${backHead(CD.kind==="practice"?"Client":"Athlete",opView,opBack)}<div class="state-demo"><div class="sd-t">No ${CD.kind==="practice"?"client":"athlete"} selected</div></div>`;const P=CD.profile;if(!P||P.athleteId!==athleteId){return`${backHead(who.name,[who.unit?esc(who.unit):"",opView].filter(Boolean).join(" \xB7 "),opBack)}
      <div class="sidebox"><div class="req-icon b s38">${icon("user",17)}</div>
      <div><div class="tt">Loading their profile\u2026</div><div class="ts">Pulling today's real score and logged meals.</div></div></div>`}const name=P.row&&P.row.name||who.name;const position=P.row&&P.row.position||who.unit;const head=`<div class="back-head ca-head">
      <div class="bk" data-back="${esc(opBack)}" role="button" aria-label="Back">${icon("back",20)}</div>
      <div class="ca-av" data-avatar-uid="${esc(athleteId)}"><span data-avatar-fallback>${esc(initialsOf(name,"A"))}</span></div>
      <div class="bh-t"><h1 class="ht">${esc(name)}</h1><div class="hs">${esc([position,opView].filter(Boolean).join(" \xB7 "))}</div></div>
    </div>`;const e1=(entriesFor({kind:"athlete",value:athleteId})||[])[0];const shown1=e1?shownScore(e1):null;const onStd=shown1!=null&&shown1>=ON_STANDARD;const nudgedTodayHere=(RT.coachNudged||{})[athleteId]===roles.todayISO()||nudgedTodayFromInterventions(P.interventions,roles.todayISO());if(P.offline){return`${head}
      ${errorState({title:"Can't reach their profile",body:"Nothing is invented while it's down. Their record is safe on the server.",retryId:"coach-ath-retry"})}`}const rosterLoaded=!!(CD.roster&&CD.roster.rows);const onRoster=rosterLoaded&&CD.roster.rows.some(r=>r.athleteId===athleteId);if(rosterLoaded&&!onRoster&&!P.day&&!(P.meals||[]).length){return`${head}
      <div class="state-demo"><div class="sd-ic">${icon("user",24)}</div>
      <div class="sd-t">${CD.kind==="practice"?"Client":"Athlete"} not found</div>
      <div class="sd-s">This ${CD.noun} isn't on your roster. The link may be old, or they left. Head back and pick someone from your roster.</div>
      <div class="sd-cta"><button class="btn ghost sm" data-go="coach-roster">Back to roster</button></div></div>
      <div style="height:10px"></div>`}const body=PSECTION==="overview"?overviewSection(P,athleteId):PSECTION==="activity"?activitySection(P):PSECTION==="requirements"?requirementsSection(P,athleteId):PSECTION==="foodmem"?foodMemSection(P,athleteId):notesSection(P);return`
    ${head}

    ${""}
    <div class="co-actionbar">
      ${onStd?`<button class="co-act" disabled aria-label="They're on standard today. Nothing to nudge." title="They're on standard today. Nothing to nudge.">${icon("bell",18)}<span class="lbl">Nothing to nudge</span></button>`:nudgedTodayHere?`<button class="co-act" disabled aria-label="Already nudged today. One a day keeps it meaningful." title="Already nudged today. One a day keeps it meaningful.">${icon("check",18)}<span class="lbl">Nudged today</span></button>`:`<button class="co-act${P.pass?"":" hero"}" data-anudge="${esc(athleteId)}">${icon("bell",18)}<span class="lbl">Nudge</span></button>`}
      <button class="co-act co-act-more${MANAGE.open&&MANAGE.id===athleteId?" on":""}" id="ca-more" aria-haspopup="dialog">${icon("more",18)}<span class="lbl">More</span></button>
    </div>
    <template id="ca-more-tpl">
      <div class="sheet-scrim ca-more-scrim" data-more-close></div>
      <div class="sheet ca-more" role="dialog" aria-modal="true" aria-labelledby="ca-more-t">
        <div class="grab"></div>
        <div class="sh-title" id="ca-more-t">${esc(name)}</div>
        <button type="button" class="sheet-row" data-go="coach-plan/${esc(athleteId)}"><span class="si">${icon("edit",20)}</span><span class="st"><span class="t">Targets</span><span class="s">Their meal and macro targets</span></span>${icon("chevron",16)}</button>
        <button type="button" class="sheet-row" id="ca-manage"><span class="si">${icon("gear",20)}</span><span class="st"><span class="t">Manage</span><span class="s">Position, room, or remove from the ${CD.kind==="practice"?"practice":"team"}</span></span>${icon("chevron",16)}</button>
        ${CD.caps.trustPass?P.pass?`<button type="button" class="sheet-row" id="tp-btn"><span class="si">${icon("shield",20)}</span><span class="st"><span class="t">End pass</span><span class="s">Their Trust Pass is active</span></span></button>`:`<button type="button" class="sheet-row" data-go="pass-grant/${esc(athleteId)}"><span class="si">${icon("shield",20)}</span><span class="st"><span class="t">Reward</span><span class="s">Give a Trust Pass</span></span>${icon("chevron",16)}</button>`:""}
        <button type="button" class="cancel" data-more-close>Close</button>
      </div>
    </template>
    ${NUDGE_ARM?`
    <div class="nx-edit">
      <input id="anudge-body" class="ob-input nx-input" maxlength="120" value="${esc(NUDGE_ARM.body)}" aria-label="Nudge message" />
      <div class="nx-acts">
        <button class="btn ghost sm" data-anudge-cancel="1">Cancel</button>
        <button class="btn sm primary" data-anudge-send="${esc(athleteId)}">Send</button>
      </div>
      <div class="nx-note">They'll get a push titled "${esc(S.operatorIdentity.handle)} is waiting" with this message.</div>
    </div>`:""}
    <div id="tp-status" style="text-align:center;font-size:var(--t-sm);font-weight:600;color:var(--text-3);min-height:0"></div>
    ${MANAGE.open&&MANAGE.id===athleteId?manageSheet(P,athleteId,position):""}

    ${""}
    <div class="co-seg co-tabs co-tabs-fit co-scroll edge-fade" id="psec-row" role="radiogroup" aria-label="Profile section">
      ${profileSections().map(([key,label])=>`<button type="button" class="co-chip ${PSECTION===key?"on":""}" role="radio" aria-checked="${PSECTION===key?"true":"false"}" data-psec="${key}">${esc(label)}</button>`).join("")}
    </div>

    ${body}
    <div class="co-bottom"></div>
    `},mount(root,{sub}){const athleteIdM=sub;if(MANAGE.id!==athleteIdM)MANAGE={id:athleteIdM,open:false,busy:false,note:"",arm:false};loadTargets(athleteIdM);if(!VC.board&&currentBookId())loadBoard(currentBookId(),CD.kind).then(()=>{if(location.hash.startsWith("#coach-athlete"))window.__render()}).catch(()=>{});loadAthleteSummary(athleteIdM);const snote=(t,ok)=>{ASUM.note=t||"";const el=root.querySelector("#asum-note");if(el){el.textContent=ASUM.note;el.classList.toggle("asum-note-quiet",!ASUM.note);el.classList.toggle("ok",!!ok)}};const sref=root.querySelector("#asum-refresh");if(sref)sref.addEventListener("click",async()=>{if(ASUM.busy||ASUM.id!==athleteIdM)return;ASUM.busy=true;sref.disabled=true;sref.textContent="Writing\u2026";snote("Nia is writing a fresh read\u2026");const r=await roles.refreshAthleteSummary(athleteIdM);if(ASUM.id!==athleteIdM)return;ASUM.busy=false;if(r.row)ASUM.row=r.row;if(r.ok){ASUM.note="";window.__render();return}if(r.error==="throttled"){ASUM.note="";window.__render();return}ASUM.note=r.error==="offline"?"Can't reach Nia right now.":"Couldn't write a fresh read. Try again in a minute.";window.__render()});root.querySelectorAll("[data-asum-cad]").forEach(b=>b.addEventListener("click",async()=>{const days=+b.getAttribute("data-asum-cad")===3?3:6;if(ASUM.busy||!ASUM.row&&ASUM.loading)return;const cur=ASUM.row&&ASUM.row.cadence_days===3?3:6;if(days===cur&&ASUM.row)return;const book=currentBookId();const kind=CD.kind==="practice"?"practice":"team";const r=await roles.setAiSummaryCadence(athleteIdM,kind,book,days);if(ASUM.id!==athleteIdM)return;if(!r.ok){snote("Couldn't change the cadence.");return}ASUM.row={...ASUM.row||{},cadence_days:days};ASUM.note=`Updates every ${days} days.`;window.__render()}));const moreBtn=root.querySelector("#ca-more");if(moreBtn)moreBtn.addEventListener("click",()=>openMoreSheet(root,athleteIdM,moreBtn));const mnote=(t,ok)=>{MANAGE.note=t||"";const el=root.querySelector("#ca-mstatus");if(el){el.textContent=MANAGE.note;el.classList.toggle("ok",!!ok)}};const setPos=async v=>{if(MANAGE.busy)return;MANAGE.busy=true;mnote("Saving\u2026");const r=await roles.coachSetAthletePosition(athleteIdM,v);MANAGE.busy=false;if(!r.ok){mnote(r.error||"Couldn't save the position.");return}mnote(`Position set to ${v||"none"}.`,true);loadCoachRoster(true).then(()=>{TGT=null;loadTargets(athleteIdM);window.__render()})};root.querySelectorAll("[data-ca-pos]").forEach(b=>b.addEventListener("click",()=>setPos(b.getAttribute("data-ca-pos"))));const posSave=root.querySelector("#ca-pos-save");if(posSave)posSave.addEventListener("click",()=>setPos(((root.querySelector("#ca-pos-input")||{}).value||"").trim()));root.querySelectorAll("[data-ca-room]").forEach(b=>b.addEventListener("click",async()=>{if(MANAGE.busy)return;MANAGE.busy=true;mnote("Saving\u2026");const r=await roles.assignAthleteRoom(athleteIdM,b.getAttribute("data-ca-room")||null);MANAGE.busy=false;if(!r.ok){mnote(r.error||"Couldn't move them.");return}mnote("Room updated.",true);loadCoachRoster(true).then(()=>window.__render())}));const rm=root.querySelector("#ca-remove");if(rm)rm.addEventListener("click",()=>{MANAGE.arm=true;window.__render()});const rmc=root.querySelector("#ca-remove-cancel");if(rmc)rmc.addEventListener("click",()=>{MANAGE.arm=false;window.__render()});const rmg=root.querySelector("#ca-remove-go");if(rmg)rmg.addEventListener("click",async()=>{if(MANAGE.busy)return;MANAGE.busy=true;mnote("Removing\u2026");const book=currentBookId();const ok=CD.kind==="practice"?await roles.removePracticeClient(book,athleteIdM):await roles.declineMember(book,athleteIdM);MANAGE.busy=false;if(!ok){mnote("Couldn't remove them. Check your connection and try again.");return}MANAGE={id:null,open:false,busy:false,note:"",arm:false};await loadCoachRoster(true);if(window.__go)window.__go("coach-roster")});const athleteId=sub;loadBook(false,bookKindFor(RT.authRole));loadAthleteProfile(athleteId);const athRetry=root.querySelector("#coach-ath-retry");if(athRetry)athRetry.addEventListener("click",()=>{athRetry.disabled=true;loadAthleteProfile(athleteId,true)});if(TLOGS.id!==athleteId){TLOGS={id:athleteId,rows:[]};roles.listTrainingLogs(athleteId).then(rows=>{if(TLOGS.id===athleteId){TLOGS={id:athleteId,rows:rows||[],error:rows===null};if(window.__render)window.__render()}}).catch(()=>{if(TLOGS.id===athleteId){TLOGS={id:athleteId,rows:[],error:true};if(window.__render)window.__render()}})}if(FMEM.id!==athleteId){FMEM={id:athleteId,items:null,places:[]};roles.fetchFoodMemory(athleteId).then(r=>{if(FMEM.id!==athleteId)return;FMEM=r&&r.error?{id:athleteId,items:null,places:[],error:true}:{id:athleteId,items:r&&r.items||[],places:r&&r.places||[]};if(window.__render)window.__render()}).catch(()=>{if(FMEM.id===athleteId){FMEM={id:athleteId,items:null,places:[],error:true};if(window.__render)window.__render()}})}const fmRetry=root.querySelector("#fm-retry");if(fmRetry)fmRetry.addEventListener("click",()=>{FMEM={id:null,items:null,places:[]};window.__render()});root.querySelectorAll("[data-fm-verify]").forEach(el=>el.addEventListener("click",async()=>{if(el.disabled)return;el.disabled=true;el.textContent="Verifying\u2026";const ok=await roles.coachVerifyMemoryItem(el.getAttribute("data-fm-verify"));if(ok&&FMEM.items){const it=FMEM.items.find(x=>x.id===el.getAttribute("data-fm-verify"));if(it)it.verified_at=new Date().toISOString();window.__render()}else{el.disabled=false;el.textContent="Verify"}}));if(VIEWED_FOR!==athleteId){VIEWED_FOR=athleteId;const vr=CD.roster&&(CD.roster.rows||[]).find(r=>r.athleteId===athleteId);try{roles.markDayViewed(athleteId,vr&&vr.dayISO||roles.todayISO(),RT.userId,S.operatorIdentity.handle)}catch{}}const P0=CD.profile;if(P0&&P0.athleteId===athleteId&&P0.day&&P0.day.score!=null){reveal(root,{key:`coathlete:${athleteId}:${P0.day.score}`,haptic:null})}root.querySelectorAll("[data-psec]").forEach(el=>el.addEventListener("click",()=>{PSECTION=el.getAttribute("data-psec");window.__restate()}));root.querySelectorAll("[data-anudge]").forEach(el=>el.addEventListener("click",()=>{if(el.disabled)return;const st0=CD.profile&&CD.profile.status;NUDGE_ARM={body:presetForStatus(st0&&st0.key)};window.__restate()}));root.querySelectorAll("[data-anudge-cancel]").forEach(el=>el.addEventListener("click",()=>{NUDGE_ARM=null;window.__restate()}));root.querySelectorAll("[data-anudge-send]").forEach(el=>el.addEventListener("click",async()=>{if(el.disabled)return;const id=el.getAttribute("data-anudge-send");const input=root.querySelector("#anudge-body");const body=(input&&input.value||"").trim()||"Time to get your log in.";const status=root.querySelector("#tp-status");el.disabled=true;el.textContent="\u2026";if(status){status.style.color="var(--text-3)";status.textContent="Sending nudge\u2026"}const r=await roles.nudgePush(id,`${S.operatorIdentity.handle} is waiting`,body);const copy=nudgeResultCopy(r);if(copy.ok){try{act.markNudged(id)}catch{}try{const st1=CD.profile&&CD.profile.status;const rk=st1?reasonKey(st1):void 0;const tier=st1?tierForStatus(st1.key)||void 0:void 0;const okLog=await logBookIntervention({athleteId:id,kind:"nudge",reasonKey:rk,tier});if(okLog&&CD.caps.interventions&&CD.extras&&Array.isArray(CD.extras.interventions)&&rk){CD.extras.interventions.push({athlete_id:id,kind:"nudge",reason_key:rk,tier})}}catch{}NUDGE_ARM=null}else{el.disabled=false;el.textContent="Send";NUDGE_ARM={body}}window.__render();const st=document.querySelector("#tp-status");if(st){st.style.color=copy.tone==="ok"?"var(--green-bright)":copy.tone==="warn"?"var(--amber-bright)":"var(--red)";st.textContent=copy.msg}}));const cnInput=root.querySelector("#cn-input");const cnErr=root.querySelector("#cn-err");const cnSave=root.querySelector("#cn-save");if(cnSave&&cnInput)cnSave.addEventListener("click",async()=>{const body=(cnInput.value||"").trim();if(cnErr)cnErr.textContent="";cnInput.removeAttribute("aria-invalid");const cnFail=m=>{if(cnErr)cnErr.textContent=m;cnInput.setAttribute("aria-invalid","true")};if(!body){cnFail("Write something first.");return}const teamId=CD.roster&&CD.roster.teams[0]&&CD.roster.teams[0].id;if(!teamId){cnFail("Couldn't save. No team found.");return}cnSave.disabled=true;const r=await roles.postCoachNote(teamId,athleteId,body,CD.kind);cnSave.disabled=false;if(!r.ok){cnFail(r.error||"Couldn't save. Try again.");return}cnInput.value="";loadAthleteProfile(athleteId,true)});root.querySelectorAll("[data-del-note]").forEach(el=>el.addEventListener("click",()=>{NOTE_DEL=el.getAttribute("data-del-note");window.__restate()}));root.querySelectorAll("[data-del-note-cancel]").forEach(el=>el.addEventListener("click",()=>{NOTE_DEL=null;window.__restate()}));root.querySelectorAll("[data-del-note-confirm]").forEach(el=>el.addEventListener("click",async()=>{el.disabled=true;await roles.deleteCoachNote(el.getAttribute("data-del-note-confirm"));NOTE_DEL=null;loadAthleteProfile(athleteId,true)}))}};let MC=null;let RESOLVED_MEALS=new Set;let FLAGGED_MEALS=new Set;let FIX_FOR=null;let FIX_NOTE="";let FIX_BUSY=false;const msgClock=iso=>{if(!iso)return"";const d=new Date(iso);if(isNaN(d.getTime()))return"";let h=d.getHours();const mm=String(d.getMinutes()).padStart(2,"0");const ap=h>=12?"PM":"AM";h=h%12||12;return`${h}:${mm} ${ap}`};const msgDay=ms=>{const d=new Date(ms);return`${d.getFullYear()}-${d.getMonth()}-${d.getDate()}`};let mcLoadingId=null;async function loadMealComments(mealId,force){if(!mealId||mcLoadingId===mealId&&!force)return;if(!force&&MC&&MC.mealId===mealId)return;mcLoadingId=mealId;const comments=await roles.fetchMealComments(mealId);const athleteId=Array.isArray(comments)&&comments.length?comments[0].athlete_id:null;const participants=athleteId?await roles.fetchThreadParticipants(athleteId).catch(()=>[]):[];MC={mealId,comments,participants};mcLoadingId=null;if(location.hash.startsWith("#coach-meal"))window.__render()}let MEAL=null;let mealLoadingId=null;async function loadMeal(mealId){if(!mealId)return;if(MEAL&&MEAL.id===mealId)return;if(mealLoadingId===mealId)return;mealLoadingId=mealId;const row=await roles.fetchMeal(mealId);if(row&&row.photo_path)row._url=await roles.signedMealPhotoUrl(row.photo_path);if(mealLoadingId===mealId)mealLoadingId=null;if(row)MEAL={id:mealId,row};else if(MEAL&&MEAL.id===mealId)MEAL=null;if(location.hash.startsWith("#coach-meal"))window.__render()}function mealById(mealId){return MEAL&&MEAL.id===mealId?MEAL.row:null}let DRAFTS={mealId:null,items:[],loading:false,error:null};let CM_ADDED=0;const CM_WIRED=new WeakSet;const STANCE_LABEL={supportive:"Supportive",direct:"Direct",context:"Ask for context",followup:"Set a follow-up"};let MENU_FOR=null;let MENU_MOUNTED_FOR=null;function athleteContextForMeal(meal){const id=meal&&meal.athlete_id;if(!id)return{};const row=(CD.roster&&CD.roster.rows||[]).find(r=>r.athleteId===id);const pos=row?resolvePos(row):"";return pos?{athlete:{position:String(pos).slice(0,40)}}:{}}function coachAskContext(meal){const ctx={meal:{}};if(meal){ctx.meal={type:meal.type||null,name:typeof meal.name==="string"&&meal.name.trim()?meal.name.trim():void 0,protein:meal.protein,carbs:meal.carbs,fat:meal.fat,kcal:meal.kcal,fiber:meal.fiber!=null?meal.fiber:void 0,quality:meal.quality!=null?meal.quality:void 0,minutesLate:typeof meal.minutes_late==="number"?meal.minutes_late:void 0,foods:(Array.isArray(meal.detected)?meal.detected:[]).slice(0,8).map(f=>typeof f==="string"?f:f&&f.name).filter(Boolean)};if(meal.analysis)ctx.aiRead=String(meal.analysis).slice(0,400);if(TGT&&TGT.athleteId===meal.athlete_id&&TGT.targets&&(TGT.targets.protein!=null||TGT.targets.calories!=null)){ctx.targets={protein:TGT.targets.protein,calories:TGT.targets.calories}}}const msgs=Array.isArray(MC&&MC.comments)?threadMessages(MC.comments).slice(-6):[];ctx.thread=msgs.map(c=>({role:c.role,text:String(c.text||"").slice(0,200)}));return ctx}export const coachMeal={nav:"operator",tab:"roster",pane:"detail",hideTabs:true,render({sub}){const mealId=sub;const meal=mealById(mealId);const slotName=meal?cap(meal.type||"Meal"):"Meal";const dishName=meal&&typeof meal.name==="string"&&meal.name.trim()&&meal.name.trim().toLowerCase()!==slotName.toLowerCase()?meal.name.trim():null;const title=dishName||slotName;const backTo=meal&&meal.athlete_id?`coach-athlete/${meal.athlete_id}`:RT.authRole==="trainer"?"trainer":"coach-home";if(!MC||MC.mealId!==mealId){return`${backHead(title,`Your comment lands on the ${CD.noun}\u2019s log`,backTo)}<div class="sidebox"><div class="req-icon b s38">${icon("message",17)}</div>
      <div><div class="tt">Loading the thread\u2026</div><div class="ts">Reading the athlete\u2019s comments on this meal.</div></div></div>`}const head=backHead(title,`Your comment lands on the ${CD.noun}\u2019s log`,backTo,{id:"cm-more",label:"Meal actions",icon:"more"});const M=meal?pastMealDetail(meal):null;if(M&&meal){if(meal.source)M.source=meal.source;M.dish=dishName||"";M.img=meal._url||null}const athleteTargets=TGT&&meal&&TGT.athleteId===meal.athlete_id&&TGT.targets?TGT.targets:null;const read=M?mealReadHtml(M,{exec:null,past:true,viewer:"coach",targets:athleteTargets,planStyle:{showMacros:true,showCalories:true,key:"structured"},athleteName:(CD.roster&&CD.roster.rows.find(x=>x.athleteId===meal.athlete_id)||{}).name||""}):{photoBlock:"",breakdown:""};const mlateTop=meal&&typeof meal.minutes_late==="number"?meal.minutes_late:null;const execTop=meal?`
    <section class="mt-confirm">
      <div class="row1">
        <div class="ck">${icon("check",20)}</div>
        <div><div class="t">${esc(slotName)} logged</div>
        <div class="s">${meal.day_date?`${esc(weekdayLong(String(meal.day_date)))} \xB7 ${esc(shortDate(String(meal.day_date)))}`:""}${(()=>{const c=msgClock(meal.logged_at);return c?` \xB7 Logged ${c}`:""})()}${mlateTop==null?"":mlateTop>0?` \xB7 ${mlateTop} min late`:" \xB7 on time"}${meal.source==="gallery"?" \xB7 from gallery":""}</div></div>
      </div>
    </section>`:"";const fixPanel=meal?(()=>{const partial=[meal.protein,meal.carbs,meal.fat].filter(v=>v==null).length>=2&&(meal.source!=="manual"&&meal.source!=="label");return`
      ${""}
      <div class="est-note" style="margin-top:6px">${partial&&FIX_FOR!==mealId?"The read only returned part of this plate. ":""}<span class="link" id="cm-correct" role="button" tabindex="0">${FIX_FOR===mealId?"Close the correction panel":"Correct the read"}</span></div>
      ${FIX_FOR===mealId?(()=>{const rich=normalizeDetected(meal.detected);const dis=FIX_BUSY?" disabled":"";return`
      <section class="card pad" id="cm-fix" style="margin-top:8px;padding-top:12px"${FIX_BUSY?' aria-busy="true"':""}>
        <h2 class="eyebrow" style="margin:0 0 8px">Detected foods</h2>
        ${rich.length?rich.map(d=>`
        <div class="food-row">
          <span class="conf-dot ${esc(d.confidence||"high")}"></span>
          <span class="fr-name">${esc(d.name)}</span>
          <span class="fr-qty">${d.quantity?esc(d.quantity):""}</span>
          <button type="button" class="cm-rm" data-cm-rm="${esc(d.name)}" aria-label="Remove ${esc(d.name)} from this read"${dis}>${icon("x",13)}</button>
        </div>`).join(""):`<div class="est-note">No itemized foods on this read, so there is nothing to remove. The portion check below still works.</div>`}
        <h2 class="eyebrow" style="margin:12px 0 8px">Portion check \xB7 the whole plate</h2>
        <div class="fx-chips">
          <button class="fx-chip" data-cm-portion="right"${dis}>Looks right</button>
          <button class="fx-chip" data-cm-portion="larger"${dis}>Bigger than that</button>
          <button class="fx-chip" data-cm-portion="three-quarters"${dis}>Smaller than that</button>
        </div>
        <div id="cm-fix-note" class="est-note" role="status" aria-live="polite" style="margin-top:10px;min-height:16px">${esc(FIX_BUSY?"Saving the correction\u2026":FIX_NOTE||`Your correction becomes part of the record, logged under your name. The ${CD.noun}'s day score updates when they next open this meal.`)}</div>
        <div class="rub-fine">Removing a line subtracts that item's own numbers; a portion mark re-estimates the whole plate. Nia\u2019s original read stays on record either way.</div>
      </section>`})():""}`})():"";return`<div class="meal-screen">
    ${head}
    ${execTop}
    ${read.photoBlock}
    ${read.breakdown}
    ${fixPanel}
    <section class="disc" id="meal-disc" aria-labelledby="disc-title">
    <h2 class="sr-only" id="disc-title">${threadTitle(participantList(MC.participants||[],RT.userId),{hasCoach:true,noun:RT.authRole==="trainer"?"trainer":"coach"})}</h2>
    <div class="disc-head">
      ${(()=>{const people2=participantList(MC.participants||[],RT.userId);const faces=facesHtml(people2,esc);const line=participantSummary(people2);const title2=threadTitle(people2,{hasCoach:true,noun:RT.authRole==="trainer"?"trainer":"coach"});return`<button type="button" class="facepile disc-fp" id="cm-members-slot" aria-label="Who can see this conversation"><span class="fp">${faces}</span><span class="names"><b>${title2}</b>${line?`<small>${esc(line)}</small>`:""}</span></button>`})()}
    </div>
    ${MC.comments&&MC.comments.error?`
    <div style="text-align:center;padding:14px 12px;border-radius:var(--r-tile);background:var(--surface-1);border:1px solid var(--hairline)">
      <div style="font-size:12.5px;font-weight:600;color:var(--text-2);line-height:1.4">Couldn't load the discussion. Nothing was lost.</div>
      <button class="btn ghost sm" id="coach-thread-retry" style="margin-top:10px">${icon("wifiOff",15)} Try again</button>
    </div>`:(()=>{const rx=reactionGroups(MC.comments);const msgs=threadMessages(MC.comments);const mlate=meal&&typeof meal.minutes_late==="number"?meal.minutes_late:null;const opening=meal?openingMessage({name:title,quality:meal.quality,note:meal.note,analysis:meal.analysis||"",goal:null,coachTargets:null,late:mlate==null?null:mlate>0,minutesLate:mlate}):"";const visible=visibleThread(msgs,RT.mutedUsers);const lastMsg=visible.length?visible[visible.length-1]:null;const{fresh,added}=noteArrivals(mealId,visible,RT.userId);const rxAt=reactionAnchor(visible);CM_ADDED+=added;return`
      ${""}
      <div class="thread" id="cm-thread" role="log" aria-label="Meal review conversation">
        ${opening&&!msgs.some(isAnalysisOpener)?meal&&meal.analysis?`
        <div class="msg ai last">
          <div class="av">${NIA_MARK}</div>
          <div class="stack">${whoHtml(AI_NAME,true,esc,`What the ${esc(CD.noun)} was told`)}
          <div class="bubble">${esc(opening)}</div>${aiDisclaimer()}</div>
        </div>`:`
        <div class="msg coach last quick-read">
          <div class="av">${icon("flash",14)}</div>
          <div class="stack"><div class="who">Quick read \xB7 what the ${esc(CD.noun)} was told</div>
          <div class="bubble">${esc(opening)}</div>${aiDisclaimer()}</div>
        </div>`:""}
        ${layoutThread(msgs,{muted:RT.mutedUsers,fmtTime:msgClock,fmtDay:msgDay,fmtDayLabel:dayLabelOf}).map((item,_i,all)=>{if(item.type==="time")return timeSepHtml(item,esc);const c=item.comment;if(isCorrectionReceipt(c))return receiptCardHtml(c,esc,{fresh:fresh.has(String(c.id)),first:item.firstOfRun});const mine=c.author_id===RT.userId&&c.role!=="ai";const who=mine?"You":authorName(c,MC.participants||[],RT.userId);const update=isAnalysisUpdate(c);const escalated=isEscalated(c);const quoted=update?quotedFor(c,visible):null;const rq=quoted?"":replyQuoteHtml(replyQuote(c,visible,RT.mutedUsers,x=>x.author_id===RT.userId&&x.role!=="ai"?"You":authorName(x,MC.participants||[],RT.userId)),esc);const photo=attachedPhoto(c);const photoOnly=isPhotoOnly(c);const bubbleRx=c===rxAt?rx:[];return`
          <div class="${msgRowClass({mine,role:c.role,firstOfRun:item.firstOfRun,lastOfRun:item.lastOfRun,hasRx:bubbleRx.length>0,photoOnly})}${fresh.has(String(c.id))?" in":""}" data-cid="${esc(String(c.id||""))}">
            ${""}
            ${!mine&&item.lastOfRun?`<div class="av"${c.role!=="ai"&&c.author_id?` data-avatar-uid="${esc(c.author_id)}"`:""}>${c.role==="ai"?NIA_MARK:`<span data-avatar-fallback>${esc(initialsFor(who))}</span>`}</div>`:'<div class="av-sp"></div>'}
            <div class="stack">
              ${item.firstOfRun&&!mine?whoHtml(who,c.role==="ai",esc):""}
              ${quoted?`<div class="quote"><span class="stem"></span><span class="qtext">${esc(quoted.text)}</span></div>`:rq}
              ${""}
              <div class="bubble">${escalated?`<span class="esc">${AI_NAME} flagged this for you</span>`:""}${bubblePhotoHtml(photo,esc)}${photoOnly?"":c.role==="ai"?richText(c.text,esc):personText(c.text,esc)}${bubbleRx.length?`<span class="rxo">${bubbleRx.map(r=>`${esc(r.emoji)} ${r.count}`).join(" ")}</span>`:""}</div>
              ${""}
              ${c.role==="ai"&&!(opening&&!msgs.some(isAnalysisOpener))&&all.find(it=>it.type!=="time"&&it.comment&&it.comment.role==="ai"&&!isCorrectionReceipt(it.comment))===item?aiDisclaimer():""}
              ${deliveredHtml({mine,isLast:c===lastMsg})}
            </div>
            ${msgTimeHtml(c,msgClock,esc)}
          </div>`}).join("")}
        ${!visible.length?`
        ${""}
        ${(()=>{const rxs=reactionGroups(visibleThread(MC.comments,RT.mutedUsers));return rxs.length?`<div class="rx-strip">${rxs.map(r=>`<span class="rx">${esc(r.emoji)}<span class="n">${r.count}</span></span>`).join("")}</div>`:""})()}
        ${msgs.length?`<div class="msg-status">${MUTED_HIDDEN_NOTE}</div>`:`<div style="font-size:12.5px;font-weight:600;color:var(--text-3);margin:2px 2px 8px">No comments yet. Say something, or press and hold a message to react. The ${CD.noun} sees it on the log.</div>`}`:""}
      </div>`})()}
    ${(()=>{const drafting=DRAFTS.loading&&DRAFTS.mealId===sub;const drafts=DRAFTS.mealId===sub&&DRAFTS.items.length?DRAFTS.items:[];return`
    <div class="tmenu" id="cm-menu"${MENU_FOR===sub?"":" hidden"}>
      <div class="tm-row">
        <button class="qa" id="cm-ask-photo">Request another photo</button>
        <button class="qa" id="cm-note-toggle">Private note</button>
      </div>
      <div class="tm-row">
        ${drafting?`<span class="tm-note" style="padding:6px 2px">Drafting\u2026</span>`:drafts.length?drafts.map((d,i)=>`<button class="qa" data-draft="${i}">${esc(STANCE_LABEL[d.stance]||cap(d.stance||"Reply"))}</button>`).join(""):`<button class="qa" id="cm-draft">${icon("sparkle",13)} Draft a reply with ${AI_NAME}</button>`}
      </div>
      ${DRAFTS.mealId===sub&&DRAFTS.error&&!drafts.length&&!drafting?`<div class="tm-note">${DRAFTS.error==="ai_consent_required"?esc(aiOffForCoach(DRAFTS.who)).replace(" Your question was posted.",""):"Couldn\u2019t draft right now. Write your own or try again."}</div>`:""}
      <div class="tm-row" style="align-items:center">
        <button class="btn ghost sm" id="cm-resolve">${RESOLVED_MEALS.has(mealId)?`Resolved ${icon("check",12)}`:"Mark resolved"}</button>
        <span id="cm-resolve-note" class="tm-note"></span>
      </div>
      ${""}
      <div class="tm-row" style="align-items:center">
        <button class="btn ghost sm" id="cm-flag"${FLAGGED_MEALS.has(mealId)?' style="color:var(--amber-bright);border-color:var(--amber-border)"':""}>${icon("flame",12)} ${FLAGGED_MEALS.has(mealId)?"Flagged \xB7 tap to clear":"Flag for follow-up"}</button>
        <span id="cm-flag-note" class="tm-note"></span>
      </div>
      <div class="tm-note" id="rx-note">Press and hold any message to react to it.</div>
    </div>`})()}
    <div class="chat-dock disc-dock dock-end">
    ${composer({inputId:"cm-input",sendId:"cm-send",placeholder:"Comment on this meal\u2026",sendLabel:"Send comment",attachId:"cm-attach",aiId:"cm-ai",atEnd:true})}
    <div class="composer-attach-pending" id="cm-attach-pending" hidden></div>
    <div id="cm-note" class="cmp-note cmp-err"></div>
    </div>
    </section>
    ${""}
    <div class="cm-after">
    ${(()=>{const notes=Array.isArray(MC.comments)?privateNotes(MC.comments):[];return`
      <div id="cm-notes-wrap"${notes.length?"":" hidden"}>
        <h2 class="eyebrow" style="margin-top:14px">Private notes <span style="color:var(--text-3);font-weight:600;text-transform:none;letter-spacing:0">\xB7 only you and staff see these</span></h2>
        <section class="card" role="list" style="padding:6px 16px" id="cm-notes">
          ${notes.map(n2=>`<div class="lrow" role="listitem" style="cursor:default"><div class="lic" style="background:var(--purple-surface);color:var(--purple-bright)">${icon("lock",15)}</div><div class="lm"><div class="ls" style="white-space:normal;line-height:1.45;color:var(--text-2)">${esc(n2.text)}</div></div></div>`).join("")}
        </section>
      </div>
      <div id="cm-note-box" hidden style="margin-top:8px">
        ${composer({inputId:"cm-note-input",sendId:"cm-note-send",placeholder:"Private note. The athlete never sees this\u2026",sendLabel:"Save note",sendIcon:"lock",sendStyle:"background:linear-gradient(150deg, var(--purple), var(--purple-deep))"})}
      </div>`})()}
    </div>
    </div>`},mount(root,{sub}){if(MENU_MOUNTED_FOR!==sub){MENU_MOUNTED_FOR=sub;MENU_FOR=null}if(!CD.roster)loadBook(false,bookKindFor(RT.authRole));loadMeal(sub);loadMealComments(sub);act.markMealSeen(sub);if(sub&&!RESOLVED_MEALS.has(sub)){roles.fetchMealResolved(sub).then(done=>{if(done){RESOLVED_MEALS.add(sub);if(location.hash===`#coach-meal/${sub}`)window.__render()}}).catch(()=>{})}if(sub&&!FLAGGED_MEALS.has(sub)){roles.fetchMealFlagged(sub).then(on=>{if(on){FLAGGED_MEALS.add(sub);if(location.hash===`#coach-meal/${sub}`)window.__render()}}).catch(()=>{})}const threadRetry=root.querySelector("#coach-thread-retry");if(threadRetry)threadRetry.addEventListener("click",()=>loadMealComments(sub,true));const moreBtn=root.querySelector("#cm-more");const menu=root.querySelector("#cm-menu");const setMenu=open=>{MENU_FOR=open?sub:null;if(menu)menu.hidden=!open;if(moreBtn)moreBtn.setAttribute("aria-expanded",String(open))};if(moreBtn&&menu){moreBtn.setAttribute("aria-expanded",String(!menu.hidden));moreBtn.addEventListener("click",()=>{const open=menu.hidden;setMenu(open);if(open)menu.scrollIntoView({block:"nearest",behavior:"smooth"})})}const hero=root.querySelector("#meal-hero");const heroImg=root.querySelector("#meal-photo");const rowNow=mealById(sub);if(hero&&heroImg&&rowNow&&rowNow._url){heroImg.src=rowNow._url;heroImg.style.display="block";const back=root.querySelector("#meal-backdrop-img");if(back)back.src=rowNow._url;hero.style.cursor="zoom-in";hero.setAttribute("tabindex","0");hero.setAttribute("role","button");hero.setAttribute("aria-label","View photo full screen");hero.addEventListener("click",()=>openImageViewer(rowNow._url,"Meal photo",heroImg))}else if(hero&&heroImg){heroImg.style.display="none";hero.classList.add("ph-nophoto")}const askPhoto=root.querySelector("#cm-ask-photo");if(askPhoto)askPhoto.addEventListener("click",()=>{const input0=root.querySelector("#cm-input");if(input0){input0.value="Can you send another photo of this one? I want to see the whole plate.";input0.focus()}setMenu(false)});const noteToggle=root.querySelector("#cm-note-toggle");const noteBox=root.querySelector("#cm-note-box");if(noteToggle&&noteBox)noteToggle.addEventListener("click",()=>{noteBox.hidden=!noteBox.hidden;if(!noteBox.hidden){setMenu(false);const ni=root.querySelector("#cm-note-input");if(ni)ni.focus()}});const noteSend=root.querySelector("#cm-note-send");const noteInput=root.querySelector("#cm-note-input");let noteBusy=false;const saveNote=async()=>{const text=(noteInput&&noteInput.value||"").trim();if(!text||noteBusy)return;noteBusy=true;const meal0=mealById(sub);const athleteId0=meal0?meal0.athlete_id:MC&&MC.comments[0]&&MC.comments[0].athlete_id;if(!athleteId0){noteBusy=false;return}const ok=await roles.postMealComment(sub,athleteId0,RT.userId,"coach",text,"note");if(ok){if(noteInput)noteInput.value="";await loadMealComments(sub,true)}noteBusy=false};if(noteSend)noteSend.addEventListener("click",saveNote);if(noteInput)noteInput.addEventListener("keydown",e=>{if(e.key==="Enter"&&!e.isComposing)saveNote()});const input=root.querySelector("#cm-input");const membersBtn=root.querySelector("#cm-members-slot");if(membersBtn)membersBtn.addEventListener("click",()=>openMembersSheet(participantList(MC&&MC.participants||[],RT.userId),{mealId:MC&&MC.mealId}));const send=root.querySelector("#cm-send");const cmNote=root.querySelector("#cm-note");void hydrateThreadPhotos(root,roles);hydrateAvatars(root);if(!CM_WIRED.has(root)){CM_WIRED.add(root);root.addEventListener("click",ev=>{const im=ev.target&&ev.target.closest?ev.target.closest("#cm-thread img.bimg"):null;if(!im||!im.src)return;openImageViewer(im.src,"Photo attached to this message",im)})}const cmAttach=wireComposerAttach({root,attachId:"cm-attach",pendingId:"cm-attach-pending",safeImg,onNote:m=>{if(cmNote)cmNote.textContent=m}});const cmDock=()=>root.querySelector("#meal-disc .chat-dock");const cmThread=()=>root.querySelector("#cm-thread");const placeLive=(arrived=true)=>{const el=cmThread();if(!el)return;const hold=holdThread(el,sub);const sending=syncLive(el,sub,{esc,imgSrc:safeImg});followThread(hold,{force:sending,smooth:arrived})};const resolveAthlete=()=>{const meal=mealById(sub);return meal?meal.athlete_id:MC&&MC.comments[0]&&MC.comments[0].athlete_id};const deliver=async(item,{ask=false}={})=>{const athleteId=resolveAthlete();const meal=mealById(sub);if(!athleteId){endSend(sub,item.lid,{ok:false});return null}const res=await postChatMessage(roles,{mealId:sub,athleteId,authorId:RT.userId,role:"coach",text:item.text,photo:item.photo,replyTo:item.replyTo||null});endSend(sub,item.lid,{ok:res.ok});const noteEl=root.querySelector("#cm-note");if(!res.ok){if(res.error==="filtered"){takeFailed(sub,item.lid);const box=root.querySelector("#cm-input");if(box&&!box.value)box.value=item.text;if(noteEl){noteEl.style.color="var(--red-bright)";noteEl.textContent=FILTERED_NOTE}}else if(noteEl&&res.error==="upload"){noteEl.style.color="var(--red-bright)";noteEl.textContent="Couldn't upload that photo. Tap the message to try again."}return null}const text=item.text;roles.nudgePush(athleteId,replyTitle(meal),text||"Sent a photo",{kind:"coach_comment",ref:sub});logBookIntervention({athleteId,kind:"message",reasonKey:"meal:"+sub}).catch(()=>{});if(!ask)await loadMealComments(sub,true);return res};const takeComposer=()=>{const box=root.querySelector("#cm-input");const text=(box&&box.value||"").trim();return{box,text,photo:cmAttach.get()}};const clearComposer=box=>{if(box)box.value="";cmAttach.clear();clearReply(sub);paintReplyChip(cmDock(),sub,esc);const noteEl=root.querySelector("#cm-note");if(noteEl)noteEl.textContent=""};const submit=async()=>{const{box,text,photo}=takeComposer();if(!text&&!photo)return;if(!resolveAthlete())return;const claim=beginSend(sub,{text,photo,replyTo:replyOf(sub)});if(!claim.ok){if(claim.reason==="duplicate"&&cmNote){cmNote.style.color="var(--text-3)";cmNote.textContent="You just sent that."}return}clearComposer(box);await deliver(claim.item)};const retryItem=async item=>{const claim=beginSend(sub,{text:item.text,photo:item.photo,replyTo:item.replyTo});if(claim.ok)await deliver(claim.item)};bindLive(sub,{sync:placeLive,onRetry:retryItem});placeLive(CM_ADDED>0);paintReplyChip(cmDock(),sub,esc);syncJump(cmThread(),sub,{dock:cmDock(),added:CM_ADDED});CM_ADDED=0;wireThreadTaps({root,scope:"#cm-thread",key:()=>sub});if(send)send.addEventListener("click",submit);if(input)input.addEventListener("keydown",e=>{if(e.key==="Enter"&&!e.isComposing)submit()});const aiBtn=root.querySelector("#cm-ai");if(aiBtn)aiBtn.addEventListener("click",async()=>{const{box,text,photo:pendingPhoto}=takeComposer();const note=(msg,neutral)=>{const el=root.querySelector("#cm-note");if(el){el.style.color=neutral?"var(--text-3)":"var(--red-bright)";el.textContent=msg}};if(!text){note("Type your question first, then tap the sparkle.",true);return}const meal0=mealById(sub);if(!resolveAthlete())return;if(isSending(sub))return;let photoPath=null;if(!(justSent(sub,text)&&!pendingPhoto)){const claim=beginSend(sub,{text,photo:pendingPhoto,replyTo:replyOf(sub)});if(!claim.ok)return;clearComposer(box);const res2=await deliver(claim.item,{ask:true});if(!res2)return;photoPath=res2.photoPath||null}else{clearComposer(box);noteSent(sub,text)}if(!await ensureAiConsent(RT.userId,{role:RT.authRole||"coach"})){note(aiOffForCoach("you"));return}aiBtn.disabled=true;const res={photoPath};setAiWorking(sub,true,{label:res.photoPath?"Reading the photo":workingLabel(threadMessages(MC&&MC.comments))});let failMsg="";try{const{data,error}=await window.sb.functions.invoke("meal-chat",{body:{mealId:sub,coachAsk:true,question:text,context:coachAskContext(meal0),...athleteContextForMeal(meal0),...res.photoPath?{photoPath:res.photoPath}:{},canDirectAdd:true,askerNoun:RT.authRole==="trainer"?"trainer":"coach"}});if(isConsentSkip(data)){if(data.who==="you")noteAiConsentRequired(RT.userId);failMsg=aiOffForCoach(data.who)}else{if(error||!data||!data.reply)throw new Error("no-reply");if(data.addition&&data.addition.id)await applyAdditionHere(data.addition)}}catch{failMsg="Nia couldn't answer right now. Your question was still posted to the thread."}setAiWorking(sub,false);const btnNow=root.querySelector("#cm-ai");if(btnNow)btnNow.disabled=false;await loadMealComments(sub,true);if(failMsg)note(failMsg)});const startReply=row=>{const id=row&&row.getAttribute("data-cid");const c=threadMessages(MC&&MC.comments).find(x=>x&&String(x.id)===id);if(!c)return;const mineRow=c.author_id===RT.userId&&c.role!=="ai";const who=mineRow?"You":authorName(c,MC.participants||[],RT.userId);setReply(sub,replyTargetMeta(c,who));paintReplyChip(cmDock(),sub,esc);focusComposer(root.querySelector("#cm-input"))};wireChatTimes({root,scope:"#cm-thread",onReply:startReply});const resolveBtn=root.querySelector("#cm-resolve");const resolveNote=root.querySelector("#cm-resolve-note");if(resolveBtn)resolveBtn.addEventListener("click",async()=>{const meal0=mealById(sub);const athleteId0=meal0?meal0.athlete_id:MC&&MC.comments[0]&&MC.comments[0].athlete_id;const teamId=CD.roster&&CD.roster.teams[0]&&CD.roster.teams[0].id;if(!athleteId0||!teamId){if(resolveNote)resolveNote.textContent="Couldn't resolve. Try again.";return}const ok=await logBookIntervention({athleteId:athleteId0,kind:"handled",reasonKey:"meal:"+sub});if(!ok){if(resolveNote)resolveNote.textContent="Couldn't resolve. Try again.";return}RESOLVED_MEALS.add(sub);resolveBtn.innerHTML=`Resolved ${icon("check",12)}`;if(resolveNote)resolveNote.textContent="Resolved.";setTimeout(()=>{location.hash="#coach-inbox"},800)});const flagBtn=root.querySelector("#cm-flag");const flagNote=root.querySelector("#cm-flag-note");if(flagBtn)flagBtn.addEventListener("click",async()=>{const meal0=mealById(sub);const athleteId0=meal0?meal0.athlete_id:MC&&MC.comments[0]&&MC.comments[0].athlete_id;if(!athleteId0){if(flagNote)flagNote.textContent="Couldn't flag. Try again.";return}const wasOn=FLAGGED_MEALS.has(sub);flagBtn.disabled=true;const ok=await logBookIntervention({athleteId:athleteId0,kind:wasOn?"handled":"flag",reasonKey:"flag:meal:"+sub});flagBtn.disabled=false;if(!ok){if(flagNote)flagNote.textContent="Couldn't save the flag. Try again.";return}if(wasOn)FLAGGED_MEALS.delete(sub);else FLAGGED_MEALS.add(sub);window.__render()});const metaFromRow=row=>{const rich=normalizeDetected(row.detected);return{mealId:row.id,protein:row.protein||0,carbs:row.carbs==null?null:row.carbs||0,fat:row.fat==null?null:row.fat||0,kcal:row.kcal||0,fiber:row.fiber==null?null:row.fiber||0,quality:row.quality!=null?row.quality:null,detectedRich:rich,detected:rich.map(d=>d.name),corrections:[],minutesLate:row.minutes_late||0}};const persistPro=async(r,payload,confirmOnly)=>{const row=MEAL.id===sub&&MEAL.row?MEAL.row:null;if(!row){FIX_NOTE="Still loading this meal. Try again in a second.";window.__render();return}FIX_BUSY=true;window.__render();const keep=(src,val)=>src==null?null:val;const fields=confirmOnly?{}:{protein:keep(row.protein,r.meta.protein),carbs:keep(row.carbs,r.meta.carbs),fat:keep(row.fat,r.meta.fat),kcal:keep(row.kcal,r.meta.kcal),fiber:keep(row.fiber,r.meta.fiber||0),quality:r.meta.quality!=null?r.meta.quality:null,detected:r.meta.detectedRich};const res=await roles.proCorrectMeal(sub,fields,r.summary);if(!res.ok){FIX_BUSY=false;FIX_NOTE=res.error;window.__render();return}const spoken=[...row.protein!=null?[`~${r.meta.protein}g protein`]:[],...row.kcal!=null?[`~${r.meta.kcal} kcal`]:[]];const text=confirmOnly?`Reviewed the read: ${r.summary}.`:`Corrected the read: ${r.summary}.${spoken.length?` Now ${spoken.join(" \xB7 ")}.`:""}`;const posted=await roles.postMealComment(sub,row.athlete_id,RT.userId,"coach",text,"message",{t:"pro_correction",c:payload});if(posted)roles.nudgePush(row.athlete_id,replyTitle(row),text,{kind:"coach_comment",ref:sub});if(!confirmOnly){MEAL.row={...row,protein:keep(row.protein,r.meta.protein),carbs:keep(row.carbs,r.meta.carbs),fat:keep(row.fat,r.meta.fat),kcal:keep(row.kcal,r.meta.kcal),fiber:keep(row.fiber,r.meta.fiber||0),quality:r.meta.quality!=null?r.meta.quality:row.quality,detected:r.meta.detectedRich}}FIX_BUSY=false;FIX_NOTE=confirmOnly?"Sign-off logged in the thread.":`${r.summary} \xB7 saved and posted in the thread.`;loadMealComments(sub,true);window.__render()};const applyAdditionHere=async add=>{try{const row=MEAL.id===sub&&MEAL.row?MEAL.row:null;if(!row||!add||!Array.isArray(add.foods)||!add.foods.length)return;const foods=add.foods.map(f=>({...f,addId:String(add.id)}));const r=applyMealCorrection(metaFromRow(row),{kind:"add-foods",foods,said:add.said||void 0,minutesLate:row.minutes_late||0});if(!r||r.nothingPriced||!r.moved)return;const keep=(src,val)=>src==null?null:val;const addTo=k=>row[k]==null?Number(r.meta[k])>0?r.meta[k]:null:r.meta[k];const fields={protein:addTo("protein"),carbs:addTo("carbs"),fat:addTo("fat"),kcal:addTo("kcal"),fiber:keep(row.fiber,r.meta.fiber||0),quality:r.meta.quality!=null?r.meta.quality:null,detected:r.meta.detectedRich};const res=await roles.proCorrectMeal(sub,fields,r.summary);if(!res.ok)return;const before={protein:row.protein,carbs:row.carbs,fat:row.fat,kcal:row.kcal,quality:row.quality};MEAL.row={...row,...fields,quality:fields.quality!=null?fields.quality:row.quality};const band=q=>q==null?"":(qualityBand(Math.round(+q))||{}).cls||"";const rows=[["Protein",before.protein,fields.protein,"g"],["Carbs",before.carbs,fields.carbs,"g"],["Fat",before.fat,fields.fat,"g"],["Calories",before.kcal,fields.kcal,""],["Meal score",before.quality,fields.quality,""]].filter(([,a,b])=>a!=null&&b!=null&&Math.round(+a)!==Math.round(+b)).map(([label,a,b,unit])=>({label,unit,from:Math.round(+a),to:Math.round(+b),score:label==="Meal score",band:label==="Meal score"?band(b):""}));if(rows.length)await window.sb.functions.invoke("meal-chat",{body:{mealId:sub,additionReceipt:{additionId:String(add.id),rows}}});window.__render()}catch{}};const correctLink=root.querySelector("#cm-correct");if(correctLink)correctLink.addEventListener("click",()=>{if(FIX_BUSY)return;FIX_FOR=FIX_FOR===sub?null:sub;FIX_NOTE="";window.__render()});root.querySelectorAll("[data-cm-rm]").forEach(b=>b.addEventListener("click",async()=>{if(FIX_BUSY)return;const nm=b.getAttribute("data-cm-rm");const row=MEAL.id===sub&&MEAL.row?MEAL.row:null;if(!row)return;const r=applyFoodRemoval(metaFromRow(row),nm,{by:"pro",minutesLate:row.minutes_late||0});if(!r){FIX_NOTE="That line isn't on the read any more.";window.__render();return}await persistPro(r,{edit:{kind:"remove",name:nm}},false)}));root.querySelectorAll("[data-cm-portion]").forEach(b=>b.addEventListener("click",async()=>{if(FIX_BUSY)return;const v=b.getAttribute("data-cm-portion");const row=MEAL.id===sub&&MEAL.row?MEAL.row:null;if(!row)return;if(v==="right"){await persistPro({meta:metaFromRow(row),summary:"Portion confirmed"},{kind:"other",detail:"Portion confirmed on review"},true);return}const r=applyMealCorrection(metaFromRow(row),{kind:"portion",value:v});if(!r){FIX_NOTE="Nothing to adjust on this read.";window.__render();return}await persistPro(r,{kind:"portion",value:v},false)}));const rxNote=root.querySelector("#rx-note");let rxBusy=false;wireTapback({root,scope:"#cm-thread",onReply:startReply,emoji:REACTION_EMOJI,mine:()=>new Set((Array.isArray(MC&&MC.comments)?MC.comments:[]).filter(c=>c&&c.kind==="reaction"&&c.author_id===RT.userId).map(c=>String(c.text))),onReact:async emoji=>{if(rxBusy)return;rxBusy=true;const meal=mealById(sub);const athleteId=meal?meal.athlete_id:MC&&MC.comments[0]&&MC.comments[0].athlete_id;if(!athleteId){rxBusy=false;return}const existing=(Array.isArray(MC&&MC.comments)?MC.comments:[]).find(c=>c&&c.kind==="reaction"&&c.author_id===RT.userId&&String(c.text)===emoji);const ok=existing?await roles.deleteMealComment(existing.id).catch(()=>false):await roles.postMealComment(sub,athleteId,RT.userId,"coach",emoji,"reaction").catch(()=>false);if(!ok){if(rxNote)rxNote.textContent="Couldn't send. Try again.";rxBusy=false;return}if(!existing)roles.nudgePush(athleteId,`Coach reacted to your ${meal?cap(meal.type):"meal"}`,emoji,{kind:"coach_react",ref:sub});await loadMealComments(sub,true);rxBusy=false}});const draftBtn=root.querySelector("#cm-draft");if(draftBtn)draftBtn.addEventListener("click",async()=>{if(!await ensureAiConsent(RT.userId,{role:RT.authRole||"coach"})){DRAFTS={mealId:sub,items:[],loading:false,error:"ai_consent_required",who:"you"};window.__render();return}DRAFTS={mealId:sub,items:[],loading:true,error:null};window.__render();const meal0=mealById(sub);const context={meal:meal0?{type:meal0.type,protein:meal0.protein,kcal:meal0.kcal,quality:meal0.quality}:{},thread:threadMessages(MC&&MC.comments).slice(-6).map(c=>({role:c.role,senderId:c.author_id||null,text:String(c.text).slice(0,300)}))};const r=await roles.draftMealReplies(sub,context,athleteContextForMeal(meal0).athlete);if(DRAFTS.mealId!==sub)return;DRAFTS.loading=false;DRAFTS.items=r.ok?r.drafts:[];DRAFTS.error=r.ok?null:r.error||"unavailable";DRAFTS.who=r.who||null;if(r.error==="ai_consent_required"&&r.who==="you")noteAiConsentRequired(RT.userId);window.__render()});root.querySelectorAll("[data-draft]").forEach(b=>b.addEventListener("click",()=>{const i=+b.getAttribute("data-draft");const d=DRAFTS.items[i];if(!d||!input)return;input.value=d.text;input.focus();const end=input.value.length;if(input.setSelectionRange)input.setSelectionRange(end,end);DRAFTS.items=[];setMenu(false)}))}};export const parent={hideTabs:true,render(){return`
    ${titleHead("Your athletes","Daily scores")}
    ${emailVerifyBanner()}

    <div id="par-list" data-tour="children">${skeletonRows(1,"Loading your athletes")}</div>

    <section class="card par-link-card" id="par-link">
      <div class="lrow" data-go="parent-link" data-tour="link"><div class="lic">${icon("plus",17)}</div><div class="lm"><div class="lt">Link an athlete</div><div class="ls">Enter the invite code they gave you</div></div>${icon("chevron",17)}</div>
    </section>

    ${""}
    <h2 class="eyebrow">Privacy &amp; app</h2>
    <section class="card" style="padding:6px 16px">
      <div class="lrow" style="cursor:default">
        <div class="lic">${icon("mail",17)}</div>
        <div class="lm"><div class="lt">Signed in as</div><div class="ls">${esc(RT.email||"Email unavailable, sign in again to refresh")}</div></div>
      </div>
      <div class="lrow" data-go="settings"><div class="lic">${icon("gear",18)}</div><div class="lm"><div class="lt">App settings</div></div>${icon("chevron",17)}</div>
      <div class="lrow" data-go="privacy"><div class="lic">${icon("lock",17)}</div><div class="lm"><div class="lt">Privacy &amp; your data</div><div class="ls">Who sees what \xB7 download your data</div></div>${icon("chevron",17)}</div>
      <div class="lrow" data-go="terms"><div class="lic">${icon("clipboard",17)}</div><div class="lm"><div class="lt">Terms &amp; privacy policy</div></div>${icon("chevron",17)}</div>
    </section>

    <h2 class="eyebrow">Account</h2>
    <section class="card" style="padding:6px 16px">
      <div class="lrow" data-go="welcome"><div class="lic">${icon("back",17)}</div><div class="lm"><div class="lt">Sign out</div></div></div>
      <div class="lrow" data-go="delete-account"><div class="lic" style="color:var(--red)">${icon("trash",17)}</div><div class="lm"><div class="lt" style="color:var(--red)">Delete account</div></div>${icon("chevron",17)}</div>
    </section>
    <div style="height:10px"></div>
    `},async mount(root){maybeStartTour();wireEmailVerifyBanner(root);const list=root.querySelector("#par-list");if(!list)return;let kids=null;try{kids=await act.guardianChildren()}catch{kids=null}if(kids===null){list.innerHTML=errorState({title:"Couldn't load your athletes",body:"Their record is safe. Reconnect and it loads right here.",retryId:"par-retry"});const retry=list.querySelector("#par-retry");if(retry)retry.addEventListener("click",()=>{window.__render&&window.__render()});return}if(!kids.length){list.innerHTML=`<div data-tour="visibility">${emptyState({icon:"users",title:"No athletes linked yet",body:"Ask your athlete for their invite code. You will see their daily score and their week, never their meal photos, weight, or check-in answers.",action:{label:"Link an athlete",go:"parent-link"}})}</div>`;const linkCard=root.querySelector("#par-link");if(linkCard)linkCard.remove();return}const today=dateKey();const weeks=await Promise.all(kids.map(k=>{const uid=k.athlete_id||k.id;return uid?act.guardianChildDays(uid,7).catch(()=>[]):Promise.resolve([])}));list.innerHTML=kids.map((k,i)=>{const hasScore=k.latest_score!=null;const age=k.latest_day?daysBetween(k.latest_day,today):null;const stale=age!=null&&age>1;const on=k.latest_day?shortDate(k.latest_day)||String(k.latest_day):"";const when=age==null?"No days logged yet":age<=0?"Today, still in progress":age===1?"Yesterday":`Last logged ${on} \xB7 ${age} days ago`;const rows=weeks[i]||[];const trusted=rows.length>0||age==null||age>6;const week=calendarWeek(rows,today);const logged=week.filter(d=>d.score!=null);const onStd=logged.filter(d=>d.score>=ON_STANDARD).length;const meta=logged.length?`${logged.length} of 7 days logged \xB7 ${onStd} on standard`:"Nothing logged in the last 7 days";const kidUid=k.athlete_id||k.id||"";return`
      <section class="card par-card">
        <div class="par-head">
          <span class="ros-av"${kidUid?` data-avatar-uid="${esc(kidUid)}"`:""} aria-hidden="true"><span data-avatar-fallback>${esc(initialsOf(k.name||"A","A"))}</span></span>
          <div class="par-who"><div class="par-name">${esc(k.name||"Athlete")}</div>
          <div class="par-when">${esc(when)}</div></div>
          ${hasScore?`<div class="par-score${stale?" stale":""}">
            <div class="par-n"${stale?"":` style="color:${scoreColor(k.latest_score)}"`}>${esc(String(k.latest_score))}</div>
            <div class="par-tier">${esc(tierFor(k.latest_score).name)}</div>
          </div>`:""}
        </div>
        ${trusted?`${weekBars({scores:week.map(d=>d.score),labels:week.map(d=>d.label),gaps:true})}
        <div class="par-meta">${esc(meta)}</div>`:""}
      </section>`}).join("");hydrateAvatars(list)}};export const inviteParent={hideTabs:true,render(){return`
    ${backHead("Invite a parent","They see your score and your week")}
    <div class="sidebox">
      <div class="req-icon b s38">${icon("lock",17)}</div>
      <div><div class="tt">What they'll see</div>
      <div class="ts">Your daily score and your last seven days. Never your meal photos, weight, or check-in answers.</div></div>
    </div>
    <div style="height:16px"></div>
    <div id="inv-out"></div>
    <button id="inv-go" class="btn primary">Generate an invite code</button>
    <div style="height:10px"></div>`},mount(root){const btn=root.querySelector("#inv-go");const out=root.querySelector("#inv-out");btn.addEventListener("click",async()=>{if(btn.disabled)return;btn.disabled=true;btn.textContent="Generating\u2026";const r=await act.createGuardianInvite("parent");if(r.ok){out.innerHTML=`
        <section class="card" style="padding:18px;text-align:center;margin-bottom:12px">
          <div class="ls" style="margin-bottom:6px">Give this code to your parent</div>
          <div style="font-size:30px;font-weight:800;letter-spacing:0.12em;color:var(--blue-bright)">${esc(r.token||"")}</div>
          <div class="ls" style="margin-top:8px">They tap \u201CLink an athlete\u201D and enter it. Single use \xB7 expires in 14 days.</div>
          <div class="btn-row mt">
            <button class="btn ghost sm" id="inv-copy">${icon("clipboard",16)} Copy</button>
            <button class="btn sm primary" id="inv-share">${icon("share",16)} Share</button>
          </div>
        </section>`;const token=r.token||"";const copyBtn=out.querySelector("#inv-copy");if(copyBtn)copyBtn.addEventListener("click",async()=>{const ok=await copyText(token);copyBtn.innerHTML=ok?`${icon("check",16)} Copied`:"Couldn\u2019t copy";setTimeout(()=>{copyBtn.innerHTML=`${icon("clipboard",16)} Copy`},1600)});const shareBtn=out.querySelector("#inv-share");if(shareBtn)shareBtn.addEventListener("click",async()=>{const text=`OnStandard parent invite code: ${token}. Get the app, choose Parent, then tap "Link an athlete" and enter it. Single use, expires in 14 days.`;try{if(window.OnStandardNative&&window.OnStandardNative.share)window.OnStandardNative.share({title:"OnStandard parent invite",message:text});else if(navigator.share)await navigator.share({text});else if(await copyText(text)){shareBtn.innerHTML=`${icon("check",16)} Copied invite`;setTimeout(()=>{shareBtn.innerHTML=`${icon("share",16)} Share`},1600)}}catch{}});btn.textContent="Generate another"}else{out.innerHTML=`<div class="si-err" style="text-align:center">${esc(r.error||"Could not create an invite.")}</div>`;btn.textContent="Try again"}btn.disabled=false})}};export const parentLink={hideTabs:true,render(){return`
    ${backHead("Link an athlete","Enter their invite code")}
    ${""}
    <div class="sidebox pw-pre">
      <div class="req-icon b s38">${icon("users",17)}</div>
      <div><div class="tt">Ask your athlete for the code</div>
      <div class="ts">In their app: <b>Profile &rsaquo; Invite a parent</b>. They can text it to you straight from there. Each code works once and expires after 14 days.</div></div>
    </div>
    <input id="pl-code" class="ob-input" type="text" autocapitalize="characters" autocorrect="off" spellcheck="false" placeholder="Invite code" aria-label="Invite code" aria-describedby="pl-hint pl-err" style="text-transform:uppercase;letter-spacing:0.12em">
    <div id="pl-hint" class="ts pl-hint">Letters and numbers, no spaces.</div>
    <div id="pl-err" class="si-err pl-hint"></div>
    <button id="pl-go" class="btn primary">Link athlete</button>
    <div style="height:10px"></div>`},mount(root){const code=root.querySelector("#pl-code");const err=root.querySelector("#pl-err");const btn=root.querySelector("#pl-go");const submit=async()=>{if(btn.disabled)return;err.textContent="";code.removeAttribute("aria-invalid");const token=(code.value||"").trim().toUpperCase();if(!token){err.textContent="Enter the invite code.";code.setAttribute("aria-invalid","true");return}btn.disabled=true;btn.textContent="Linking\u2026";const r=await act.acceptGuardianInvite(token,"parent");if(r.ok){window.__go("parent")}else{err.textContent=r.error||"Could not link. Check the code.";code.setAttribute("aria-invalid","true");btn.disabled=false;btn.textContent="Link athlete"}};btn.addEventListener("click",submit);code.addEventListener("keydown",e=>{if(e.key==="Enter"&&!e.isComposing)submit()})}};
