import{backHead,esc,alertMsg}from"../components.js";import{icon}from"../icons.js";import*as roles from"../roles.js";import{track,EVENTS}from"../analytics.js";import{longDate}from"../fmt-date.js";let UI={code:"",busy:false,result:null,kind:null};if(typeof window!=="undefined"){window.addEventListener("hashchange",()=>{if((location.hash||"").slice(1).split("/")[0]!=="redeem-code")UI={code:"",busy:false,result:null,kind:null}})}function reasonMessage(r){if(r&&r.error)return r.error;const reason=r&&r.reason;if(reason==="invalid_code")return"That code isn't valid.";if(reason==="full")return"This sponsorship's seats are all claimed. Ask whoever gave you the code for another, or start a membership from the plans page.";if(reason==="already_redeemed")return"You already redeemed this.";if(reason==="already_used")return"That code has already been used on another account.";if(reason==="expired")return"That code has expired. Contact your trainer.";if(reason==="sign_in")return"Please sign in.";return"That code isn't valid."}const formatDate=d=>longDate(d)||(d?String(d):"");async function redeemEither(code){const c=code.trim().toUpperCase();if(c.startsWith("TR-"))return{kind:"trainer",r:await roles.redeemOfferCode(code)};if(c.startsWith("SP-"))return{kind:"sponsor",r:await roles.redeemSponsorCode(code)};const t=await roles.redeemOfferCode(code);if(t&&t.ok)return{kind:"trainer",r:t};const s=await roles.redeemSponsorCode(code);if(s&&s.ok)return{kind:"sponsor",r:s};const specific=r=>r&&r.reason&&r.reason!=="invalid_code";if(specific(t)&&!specific(s))return{kind:"trainer",r:t};return{kind:"sponsor",r:s}}export default{render(){const r=UI.result;const success=r&&r.ok===true;const viaTrainer=UI.kind==="trainer";const who=viaTrainer?r&&r.trainer_name:r&&r.label;return`${backHead("Redeem a code","Unlock premium with a code you were given","profile")}

    ${""}
    ${""}
    ${success?"":`
    <section class="card pad">
      <label for="rc-code" style="display:block;font-size:12.5px;font-weight:700;color:var(--text-2);margin-bottom:4px">Your code</label>
      <input class="ob-input" id="rc-code" value="${esc(UI.code)}" placeholder="TR-XXXXX-XXXXX" aria-describedby="rc-hint rc-err" aria-invalid="${r&&!success?"true":"false"}" autocapitalize="characters" autocomplete="off" />
      <div id="rc-hint" style="font-size:12px;color:var(--text-3);margin-top:6px">From your trainer after you paid, or from a sponsor.</div>
      <div style="height:14px"></div>
      ${alertMsg({id:"rc-err",text:r?reasonMessage(r):"",style:"color:var(--red);font-size:13px;font-weight:600;min-height:18px"})}
      <button class="btn primary" id="rc-redeem" ${UI.busy?'disabled aria-busy="true" style="opacity:.6"':""}>${icon("key",18)} ${UI.busy?"Redeeming\u2026":"Redeem"}</button>
    </section>`}

    ${success?`
    <div class="sidebox" role="status" style="margin-top:10px"><div class="req-icon g s38">${icon("check",18)}</div>
      <div><div class="tt">${viaTrainer?"You are connected":"Premium unlocked"}</div>
      <div class="ts">${[viaTrainer?who?`Working with ${esc(who)} \xB7 membership included`:"Membership included with your coaching":who?`Sponsored by ${esc(who)}`:"",r.expires_at?`${viaTrainer?"Covered through":"Until"} ${esc(formatDate(r.expires_at))}`:""].filter(Boolean).join(" \xB7 ")}</div></div>
    </div>
    <button class="btn primary" data-go="home" style="margin-top:12px">Start your day</button>`:""}
    <div style="height:10px"></div>
    `},mount(root){const codeEl=root.querySelector("#rc-code");if(codeEl)codeEl.addEventListener("input",()=>{UI.code=codeEl.value});const btn=root.querySelector("#rc-redeem");if(btn)btn.addEventListener("click",async()=>{const err=root.querySelector("#rc-err");const code=UI.code.trim();if(!code){if(err)err.textContent="Enter a code.";codeEl&&codeEl.setAttribute("aria-invalid","true");return}if(err)err.textContent="";if(codeEl)codeEl.setAttribute("aria-invalid","false");UI.busy=true;UI.result=null;UI.kind=null;if(window.__render)window.__render();const{kind,r}=await redeemEither(code);UI.busy=false;UI.kind=kind;UI.result=r;if(r&&r.ok)track(EVENTS.TF_CODE_REDEEMED,{kind});else track(EVENTS.TF_CODE_FAILED,{reason:r&&r.reason||"error"});if(window.__render)window.__render()})}};
