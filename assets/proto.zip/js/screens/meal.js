import{S,RT,tier,act,MEAL,mealDetail,fmtClock,liveWeightPct,athleteContextForAnalysis}from"../state.js";import{DAY,slotDeadline}from"../day.js";import{icon}from"../icons.js";import{backHead,esc,safeImg,nonLiveBadge,composer,segBar,skeletonRows}from"../components.js";import{reveal,buzz}from"../motion.js";import{playPerfectMoment}from"../perfect-moment.js";import{scoreMoveBar,playScoreMove}from"../score-move.js";import{openingMessage,openingSummary,qualityBand,scoreReasons,coachFocus,reactionGroups,threadMessages,contextForChat,applyFoodEdit,hasUserEdits,restrictionConflicts,estimateConfidence,estRange,mealPatterns,scoreRubric,coachThreadStatus,REACTION_EMOJI}from"../meal-intel.js";import{attachedPhoto,isPhotoOnly,wireComposerAttach,postChatMessage,bubblePhotoHtml,hydrateThreadPhotos}from"../chat-attach.js";import{openImageViewer}from"../image-viewer.js";import{openMembersSheet}from"../members-sheet.js";import{openMealQuestions,autoShownFor,markAutoShown}from"../meal-questions-sheet.js";import{hydrateAvatars}from"../avatar.js";import{wireTapback}from"../tapback.js";import{scrollThreadToEnd,focusComposer}from"../keyboard.js";import{recentRows,warmRecent as warmRecentShared}from"../recent-meals.js";import{foodMemory,warmFoodMemory}from"../food-memory-data.js";import{remainingToday}from"../food-memory.js";import{wireReadMore}from"../thread-readmore.js";import{layoutThread,authorName,initialsFor,participantList,participantSummary,participantMeta,isAnalysisOpener,isAnalysisUpdate,isEscalated,quotedFor,memoryOfferOf,memoryOfferChips,mealSuggestOf,fillMealSuggestion,mealSuggestHtml,dayLabelOf}from"../chat-view.js";export function miniDial(score){const c=31,r=26,A0=120,SWEEP=300;const pt=deg=>{const a=deg*Math.PI/180;return`${(c+Math.cos(a)*r).toFixed(2)} ${(c+Math.sin(a)*r).toFixed(2)}`};const d=`M ${pt(A0)} A ${r} ${r} 0 1 1 ${pt(60)}`;const off=(100-score).toFixed(1);const light=typeof document!=="undefined"&&document.documentElement.getAttribute("data-theme")==="light";const tipA=(A0+score/100*SWEEP)*Math.PI/180;const tx=c+Math.cos(tipA)*r,ty=c+Math.sin(tipA)*r;const jewel=score>=6?light?`<circle cx="${tx.toFixed(1)}" cy="${ty.toFixed(1)}" r="3.1" fill="#FFFFFF" stroke="#DBEAFE" stroke-width="1"/>
       <circle cx="${tx.toFixed(1)}" cy="${ty.toFixed(1)}" r="1.75" fill="#2563EB"/>`:`<circle cx="${tx.toFixed(1)}" cy="${ty.toFixed(1)}" r="3.1" fill="#0F172A"/>
       <circle cx="${tx.toFixed(1)}" cy="${ty.toFixed(1)}" r="1.75" fill="#FFFFFF"/>`:"";return`<svg class="sc-ring" width="62" height="62" viewBox="0 0 62 62" aria-hidden="true">
    <defs>
      <linearGradient id="scg" gradientUnits="userSpaceOnUse" x1="12.5" y1="53.9" x2="37.2" y2="5">
        <stop offset="0%" stop-color="var(--ring-a)"/>
        <stop offset="50%" stop-color="var(--ring-b)"/>
        <stop offset="100%" stop-color="var(--ring-c)"/>
      </linearGradient>
    </defs>
    <path d="${d}" fill="none" stroke="var(--ring-track)" stroke-width="3.5" stroke-linecap="round"/>
    <path class="ring-arc sc-arc" d="${d}" fill="none" stroke="url(#scg)" stroke-width="3.5" stroke-linecap="round"
      pathLength="100" stroke-dasharray="100" stroke-dashoffset="${off}" data-off="${off}"/>
    ${jewel}
  </svg>`}async function warmRecent(rolesMod,uid){const before=recentRows(uid);const rows=await warmRecentShared(rolesMod,uid);if(rows&&rows!==before&&location.hash.startsWith("#meal-"))window.__render&&window.__render()}const expandedBubbles=new Set;const THREAD_CACHE={mealId:null,comments:[],lastKnownAt:null,fp:null};let _liveThreadRefresh=null;let _liveThreadRtStatus=null;let _threadRtLive=false;let PENDING_FACTS={uid:null,rows:[],at:0};const OFFERED_IN_THREAD=new Set;const ANSWERED_FACTS=new Set;async function warmPendingFacts(uid,{force=false}={}){if(!uid)return;if(!force&&PENDING_FACTS.uid===uid&&Date.now()-PENDING_FACTS.at<6e4)return;const rows=await act.pendingMemoryFacts().catch(()=>[]);PENDING_FACTS={uid,rows:rows||[],at:Date.now()};if(location.hash.startsWith("#meal-"))window.__render&&window.__render()}let RECEIPT={uid:null,date:null,reviewed:false,at:0};async function warmReceipt(rolesMod,uid,dateISO){if(!uid)return;if(RECEIPT.uid===uid&&RECEIPT.date===dateISO&&Date.now()-RECEIPT.at<6e4)return;const rows=await rolesMod.fetchMyDayReceipts(uid,dateISO).catch(()=>[]);RECEIPT={uid,date:dateISO,reviewed:!!(rows&&rows.length),rows:rows||[],at:Date.now()}}let PARTICIPANTS={uid:null,rows:[],at:0};async function warmParticipants(rolesMod,uid){if(!uid)return false;if(PARTICIPANTS.uid===uid&&Date.now()-PARTICIPANTS.at<3e5)return false;const rows=await rolesMod.fetchThreadParticipants(uid).catch(()=>[]);PARTICIPANTS={uid,rows:rows||[],at:Date.now()};return PARTICIPANTS.rows.length>0}function macroRow(m){const cells=[];if(S.planStyle.showMacros)cells.push(`<div class="macro"><div class="mv">${m.protein}g</div><div class="mk">Protein</div></div>`,`<div class="macro"><div class="mv">${m.carbs}g</div><div class="mk">Carbs</div></div>`,`<div class="macro"><div class="mv">${m.fat}g</div><div class="mk">Fat</div></div>`);if(S.planStyle.showCalories)cells.push(`<div class="macro"><div class="mv">${m.cals}</div><div class="mk">Calories</div></div>`);return cells.length?`<div class="macro-row${cells.length>=4?" four":""}">${cells.join("\n    ")}</div>`:""}export const analyzing={tab:"camera",hideTabs:true,transient:true,render(){const img=safeImg(MEAL&&MEAL.photoDataUrl||S.logging.img);const nonLive=MEAL&&MEAL.live===false;return`
    <div class="analyzing">
      <!-- Same data-vt="plate" as the photo on the confirm screen and the hero on the thread:
           one key, one photograph, carried the whole length of the flow instead of being thrown away
           and redrawn at each step. -->
      <div class="scanbox" data-vt="plate">
        <div class="img" style="background-image:url('${img}')"></div>
        <div class="scanline"></div>
      </div>
      ${nonLive?`<div style="display:flex;justify-content:center;padding-top:10px">${nonLiveBadge()}</div>`:""}
      <div class="phase" id="an-phase" role="status">Analyzing meal<span class="dots"></span></div>
      <div class="phase-sub" id="an-sub">Detecting foods and portions</div>
    </div>`},async mount(root,{sub:slotArg}={}){analysis._editing=false;const phase=root.querySelector("#an-phase");const sub=root.querySelector("#an-sub");const onScreen=()=>location.hash.startsWith("#analyzing");const slotKey=slotArg||MEAL&&MEAL.key||null;const landed=()=>{if(!slotKey||!DAY.meals[slotKey])return false;return!(DAY.slotMacros[slotKey]||{}).pending};const SLOW_MS=4200;const slowTimer=setTimeout(()=>{if(!phase||!onScreen()||landed())return;phase.innerHTML=`Still reading<span class="dots"></span>`;if(sub)sub.textContent="A careful read takes a few seconds"},SLOW_MS);const clearPhases=()=>clearTimeout(slowTimer);const slot=slotKey;if(slot&&DAY.meals[slot]){const MIN_MS=1e3,MAX_MS=9e3;const BEAT_MS=420;const t0=Date.now();const reduced=(()=>{try{return typeof matchMedia==="function"&&matchMedia("(prefers-reduced-motion: reduce)").matches}catch{return false}})();const finishScan=()=>{const line=root.querySelector(".scanline");if(line){try{const m=/matrix\(([^)]+)\)/.exec(getComputedStyle(line).transform||"");const y=m?parseFloat(m[1].split(",")[5])||0:0;line.style.animation="none";line.style.transform=`translateY(${y}px)`;void line.offsetWidth;line.style.transition="transform var(--dur-2) var(--ease-out-quart), opacity var(--dur-1) linear var(--dur-1)";line.style.transform="translateY(188.6px)";line.style.opacity="0"}catch{line.style.display="none"}}const box=root.querySelector(".scanbox");if(box)box.classList.add("read");if(phase)phase.textContent="Read complete";if(sub)sub.textContent="Your breakdown is ready"};const leave=dir=>{clearPhases();if(onScreen())window.__go("meal-thread/"+slot,{dir,vt:"plate"})};let beatAt=0;const tick=()=>{if(!root.isConnected||!onScreen()){clearPhases();return}const waited=Date.now()-t0;if(waited>=MAX_MS&&!beatAt){leave("push");return}if(beatAt){if(Date.now()>=beatAt)leave("resolve");else setTimeout(tick,60);return}if(landed()){clearPhases();if(!reduced)finishScan();beatAt=Math.max(Date.now()+(reduced?0:BEAT_MS),t0+MIN_MS);if(Date.now()>=beatAt){leave("resolve");return}setTimeout(tick,60);return}setTimeout(tick,110)};setTimeout(tick,110);return}if(MEAL&&MEAL.photoBase64&&!MEAL.result){const r=await act.runAnalysis();if(!location.hash.startsWith("#analyzing"))return;if(r.ok){location.hash=r.kind==="questions"?"#meal-questions":"#meal-analysis";return}clearPhases();const sl=root.querySelector(".scanline");if(sl)sl.style.display="none";if(phase)phase.textContent="Couldn't read this plate.";if(sub){const errTxt=typeof r.error==="string"?r.error.trim():"";const human=errTxt&&errTxt.length<=90&&!/[{}<>\n]/.test(errTxt)&&!/\b[45]\d{2}\b/.test(errTxt)&&!/(error code|exception|stack|traceback|undefined)/i.test(errTxt);sub.textContent=`Nothing was logged. Your photo is still here.${human?` ${errTxt}`:""}`}root.querySelector(".analyzing").insertAdjacentHTML("beforeend",`<div style="height:18px"></div>
         <button class="btn primary sm" id="an-retry" style="width:100%">${icon("camera",18)} Retake photo</button>
         <div style="height:10px"></div>
         <button class="btn ghost sm" id="an-report" style="width:100%">${icon("message",17)} Tell us what happened</button>`);root.querySelector("#an-retry").addEventListener("click",()=>{location.hash="#camera"});root.querySelector("#an-report").addEventListener("click",async()=>{const{openFeedback}=await import("./feedback.js");openFeedback("analysis-failed","bug");window.__go?window.__go("feedback"):location.hash="#feedback"});return}if(location.hash.startsWith("#analyzing"))location.hash="#camera"}};function askPendingQuestions(M){if(!M||!Array.isArray(M.pendingQuestions)||!M.pendingQuestions.length)return false;return openMealQuestions({questions:M.pendingQuestions,photo:M.img||M.photoDataUrl||null,slot:String(M.name||M.slot||"meal").toLowerCase(),onAnswer:answers=>act.answerPendingQuestions(M.slot,answers),onSkip:()=>act.skipPendingQuestions(M.slot)})}export const mealQuestions={tab:"camera",hideTabs:true,transient:true,render(){const qs=MEAL&&Array.isArray(MEAL.questions)?MEAL.questions:[];if(!qs.length){if(location.hash==="#meal-questions")location.hash="#camera";return""}const img=safeImg(MEAL&&MEAL.photoDataUrl||S.logging.img);return`
    ${""}
    ${backHead(qs.length===1?"One quick thing":qs.length===2?"Two quick things":`${qs.length} quick things`,"So your numbers are exact","camera")}
    ${img?`<div class="mq-photo" style="background-image:url('${img}')"><div class="mq-grad"></div>
      <div class="mq-badge">${icon("sparkle",13)} The camera can't see everything</div></div>`:""}
    <div class="mq-lead">A photo can't show what's hidden under or off the plate. Answer these and your read is dead on.</div>
    <div class="mq-list">
      ${qs.map((q,i)=>`
        <label class="mq-item">
          <div class="mq-q"><span class="mq-n">${i+1}</span><span>${esc(q)}</span></div>
          <input class="mq-input" data-qi="${i}" type="text" autocomplete="off" enterkeyhint="${i===qs.length-1?"done":"next"}"
            placeholder="Your answer" aria-label="${esc(q)}" />
        </label>`).join("")}
    </div>
    <div class="mq-actions">
      <button class="btn primary" id="mq-go">${icon("check",18)} Get my result</button>
      <button class="mq-skip" id="mq-skip">Skip, just estimate</button>
    </div>
    <div class="mq-note">${icon("lock",12)} Your answers only sharpen this meal's numbers. Nothing else changes.</div>`},mount(root){const goBtn=root.querySelector("#mq-go");const skipBtn=root.querySelector("#mq-skip");if(!goBtn||!skipBtn)return;const inputs=()=>Array.from(root.querySelectorAll(".mq-input"));const answers=()=>{const a=[];inputs().forEach(el=>{a[+el.dataset.qi]=el.value});return a};let busy=false;const finish=async ans=>{if(busy)return;busy=true;const go=root.querySelector("#mq-go");const skip=root.querySelector("#mq-skip");if(go){go.disabled=true;go.innerHTML=`${icon("sparkle",18)} Reading your meal...`}if(skip)skip.style.pointerEvents="none";const r=await act.finalizeAnalysis(ans);if(location.hash!=="#meal-questions")return;if(r.ok){location.hash="#meal-analysis";return}busy=false;if(go){go.disabled=false;go.innerHTML=`${icon("check",18)} Get my result`}if(skip)skip.style.pointerEvents="";let err=root.querySelector("#mq-err");if(!err){root.querySelector(".mq-actions").insertAdjacentHTML("afterend",`<div id="mq-err" class="mq-err">${icon("x",14)} <span></span></div>`);err=root.querySelector("#mq-err")}err.querySelector("span").textContent=r.error||"Couldn't get your result. Check your connection and try again."};goBtn.addEventListener("click",()=>finish(answers()));skipBtn.addEventListener("click",()=>finish([]));inputs().forEach((el,i,arr)=>el.addEventListener("keydown",e=>{if(e.key!=="Enter")return;e.preventDefault();if(i<arr.length-1)arr[i+1].focus();else finish(answers())}))}};function openingInputs(M){const goal=RT.profile&&RT.profile.baseGoal;const dayP=S.mealDayProgress;const recent=recentRows(RT.userId)||[];const patterns=mealPatterns(recent,{slot:M.slot,mealProteinBar:dayP.proteinTarget>0?Math.round(dayP.proteinTarget/4):0});const sum=openingSummary({quality:M.score,macros:M.macros,fiber:M.fiber,highlights:M.highlights,late:M.late,goal,detected:M.detectedRich,source:M.source,deadlineClock:M.deadlineLabel,day:dayP,numbers:S.planStyle.showMacros,tone:S.planStyle.tone});const styleSafeProse=S.planStyle.showMacros&&S.planStyle.showCalories||M.styleApplied===S.planStyle.key;const fullText=openingMessage({name:M.name,quality:M.score,note:M.note,analysis:styleSafeProse?M.analysis:null,highlights:M.highlights,goal,coachTargets:S.planTargets,late:M.late,minutesLate:M.minutesLate,detected:M.detectedRich,source:M.source,day:dayP,patterns,impact:S.mealScoreImpact(M.slot)});return{sum,fullText,fq:null}}export function openingBlockHtml(M,{sum,fullText,fq,hasPersistedRead=false,part="all"}={}){const wrap=(lead,tail)=>part==="lead"?lead:part==="tail"?tail:lead+tail;const aiRow=(inner,id)=>`
      <div class="msg ai"${id?` id="${id}"`:""}>
        <div class="av">${icon("sparkle",15)}</div>
        <div><div class="who">AI Nutritionist</div>
        <div class="bubble">${inner}</div></div>
      </div>`;if(M&&M.analysisFailed){const capacity=M.analysisFailed==="capacity";const lost=M.analysisFailed==="photo_lost";return wrap(aiRow(`
          <div style="font-weight:700">${capacity?"I couldn't get to this one today.":lost?"I couldn't read this one.":"I couldn't read this plate."}</div>
          <div style="margin-top:4px;color:var(--text-2)">${lost?"The photo couldn't be kept on this device, so there's nothing left to read. The log still counts for timing.":`It's logged and counts for timing either way. Your photo is the proof.${capacity?"":" Worth another try?"}`}</div>
          ${M.rereadError?`<div class="mt-warnline">Couldn't fetch the photo just now. Try again in a moment.</div>`:""}
          ${capacity||lost?"":`<div class="fq-chips"><button class="fx-chip" id="mt-retry-analysis">${icon("sparkle",13)} Read it again</button></div>`}`,"analysis-failed"),"")}if(M&&Array.isArray(M.pendingQuestions)&&M.pendingQuestions.length){const qs=M.pendingQuestions.slice(0,3);const qHead=qs.length===1?"One quick thing":qs.length===2?"Two quick things":`${qs.length} quick things`;return wrap(aiRow(`
          <div style="font-weight:700">${qHead} and your numbers are exact.</div>
          <div style="margin-top:3px;color:var(--text-2)">${qs.length===1?"A photo can\u2019t show what\u2019s under or off the plate.":"A photo can\u2019t show what\u2019s under or off the plate. It takes a moment."}</div>
          <div class="fq-chips">
            <button class="fx-chip" id="mq-thread-go">${icon("sparkle",13)} ${qs.length===1?"Answer it":"Answer them"}</button>
            <button class="fx-chip" id="mq-thread-skip">Skip, just estimate</button>
          </div>`,"mq-bubble"),"")}if(M&&M.pending){return wrap(aiRow(`
          <div style="font-weight:700">Reading your plate<span class="dots"></span></div>
          <div style="margin-top:4px;color:var(--text-2)">Logged and counting. The breakdown lands here in a few seconds. You don't have to wait on this screen.</div>`,"analysis-pending"),"")}const plate=new Set((M&&Array.isArray(M.detectedRich)?M.detectedRich:[]).map(d=>String(d&&d.name||"").toLowerCase()).filter(Boolean));const unoffered=(PENDING_FACTS.rows||[]).filter(f=>f&&!OFFERED_IN_THREAD.has(String(f.id)));const askFact=unoffered.find(f=>f.kind==="dislike"&&plate.has(String(f.value).toLowerCase()))||unoffered[0]||null;const confirmRow=askFact?`
      <div class="msg ai" id="fact-confirm">
        <div class="av">${icon("sparkle",15)}</div>
        <div><div class="who">AI Nutritionist</div>
        <div class="bubble">
          ${esc(askFact.kind==="dislike"?`Noted. You took ${askFact.value} off a plate. Skip it in future reads?`:`Should I remember: ${askFact.kind.replace(/_/g," ")} (${askFact.value})?`)}
          <div class="fq-chips">
            <button class="fx-chip" data-fact="${esc(askFact.id)}" data-keep="1">Yes, remember</button>
            <button class="fx-chip" data-fact="${esc(askFact.id)}" data-keep="0">No, one-off</button>
          </div>
        </div></div>
      </div>`:"";const fqRow=f=>`
      <div class="msg ai" id="fq-bubble">
        <div class="av">${icon("sparkle",15)}</div>
        <div><div class="who">AI Nutritionist</div>
        <div class="bubble">
          ${esc(f.q)}
          <div class="fq-chips">${f.chips.map(c=>`<button class="fx-chip" data-fq="${esc(f.kind)}" data-val="${esc(c.value)}">${esc(c.label)}</button>`).join("")}</div>
        </div></div>
      </div>`;if(hasPersistedRead)return wrap("",(fq?fqRow(fq):"")+confirmRow);const body=fullText?esc(fullText):[sum&&sum.wentWell,sum&&sum.opportunity,sum&&sum.next].filter(Boolean).map(esc).join(" ");if(!body)return wrap("",(fq?fqRow(fq):"")+confirmRow);return wrap(`
      <div class="msg ai">
        <div class="av">${icon("sparkle",15)}</div>
        <div><div class="who">AI Nutritionist</div>
        <div class="bubble">${body}</div></div>
      </div>`,(fq?fqRow(fq):"")+confirmRow)}function captureTimingLine(capturedAtMin,slot){if(capturedAtMin==null)return null;const dl=slotDeadline(slot);const when=fmtClock(capturedAtMin);if(capturedAtMin>dl)return`Captured ${when} \xB7 ${capturedAtMin-dl} min past the ${fmtClock(dl)} deadline`;return`Captured ${when} \xB7 ${dl-capturedAtMin} min before the ${fmtClock(dl)} deadline`}export const analysis={tab:"camera",hideTabs:true,transient:true,render(){const L=S.logging;const slot=MEAL.key||"dinner";const already=!!DAY.meals[slot];const nonLive=MEAL.live===false;const timingLine=captureTimingLine(L.capturedAtMin,slot);const rich=MEAL.result&&Array.isArray(MEAL.result.detectedRich)&&MEAL.result.detectedRich.length?MEAL.result.detectedRich:L.foods.map(f=>({name:f,confidence:"high"}));const edited=hasUserEdits(MEAL.result);const src=MEAL.source;const srcLabel=edited?"edited by you":src==="label"?"exact, from the nutrition label":src==="manual"?"entered by you":"estimated from photo";const showNums=S.planStyle.showMacros||S.planStyle.showCalories;const styleSafeProse=S.planStyle.showMacros&&S.planStyle.showCalories||L.styleApplied===S.planStyle.key;return`
    ${backHead(`${L.name} Analysis`,already?"Already logged":"Check it before it counts","camera")}

    <div class="photo-hero" style="${safeImg(L.img)?`background-image:url('${safeImg(L.img)}')`:"background:linear-gradient(150deg, rgba(var(--green-rgb),0.14), rgba(var(--blue-deep-rgb),0.06))"}">
      <div class="ph-grad"></div>
      <div class="ph-meta">
        <div><div class="ph-t">${esc(L.name)}</div><div class="ph-s">${esc(timingLine||(nonLive?"From your gallery":"Captured just now"))}</div>${nonLive?`<div style="margin-top:6px">${nonLiveBadge()}</div>`:""}</div>
        ${L.score!=null?`<div class="scorechip ${(qualityBand(L.score)||{}).cls||""}"><span class="v">${L.score}</span><span class="k">Meal</span></div>`:""}
      </div>
    </div>

    <h2 class="eyebrow" style="flex-wrap:wrap;row-gap:2px;column-gap:8px"><span style="white-space:nowrap">Breakdown</span><span style="color:var(--text-3);font-weight:600;text-transform:none;letter-spacing:0;white-space:nowrap">\xB7 ${srcLabel}</span> <span class="link" id="edit-foods" style="margin-left:auto">${"Edit"}</span></h2>
    <section class="card" style="padding:4px 16px" id="foods">
      ${rich.map(d=>`
        <div class="food-row" data-name="${esc(d.name)}">
          <span class="conf-dot ${esc(d.confidence)}"></span>
          <span class="fr-name">${esc(d.name)}${d.confidence==="low"?'<span class="q" title="AI is unsure. Confirm or remove">?</span>':""}</span>
          <span class="fr-qty">${d.quantity?esc(d.quantity):""}</span>
        </div>`).join("")}
      <div class="food-row fr-add" id="food-add" style="display:none">
        <span class="conf-dot high"></span>
        <input class="fr-in name" id="add-name" maxlength="60" placeholder="Add item (e.g. 2 eggs off-frame)" aria-label="Food name" />
        <input class="fr-in qty" id="add-qty" maxlength="12" placeholder="Qty" aria-label="Quantity" />
        <button class="fr-ok" id="add-ok" aria-label="Add">${icon("check",15)}</button>
      </div>
      ${edited?`<div style="font-size:var(--t-xs);font-weight:600;color:var(--text-3);padding:4px 0 8px">${MEAL.result&&MEAL.result.recomputed?"Edited by you. Macros and score recalculated from the foods listed.":"Edited by you. Macros stay the AI\u2019s estimate."}</div>`:""}
    </section>

    ${showNums?`<h2 class="eyebrow">${src==="label"?"From the label":src==="manual"?"As entered":"Estimated"}</h2>
    ${macroRow(L.macros)}`:""}

    <div style="height:14px"></div>
    ${(()=>{if(!RT.allergies.length&&!RT.restrictions)return"";const cf=restrictionConflicts(rich,RT.restrictions||{allergies:RT.allergies.map(n=>({name:String(n).split("\xB7")[0].trim(),severity:/severe/i.test(String(n))?"severe":"moderate"}))});const vAll=MEAL.result&&Array.isArray(MEAL.result.verifyAllergens)?MEAL.result.verifyAllergens:[];const severeHits=[...new Set([...cf.severe,...vAll])];if(severeHits.length)return`
      <div style="display:flex;gap:10px;padding:13px 14px;border-radius:var(--r-tile);background:var(--red-surface);border:1.5px solid var(--red-border)">
        ${icon("bell",17,'style="color:var(--red);flex:none;margin-top:1px"')}
        <div><div style="font-size:var(--t-sm);font-weight:800;color:var(--red-bright)">Possible severe allergen: ${esc(severeHits.join(", "))}</div>
        <div style="font-size:var(--t-sm);font-weight:600;color:var(--text-2);margin-top:3px;line-height:1.45">A detected food may contain it. The read can't see every ingredient or cross-contact. Check the label or ask staff before you eat or log this.</div></div>
      </div>`;if(cf.moderate.length||cf.noted.length)return`
      <div style="display:flex;align-items:center;gap:9px;padding:10px 14px;border-radius:var(--r-tile);background:var(--amber-surface);border:1px solid var(--amber-border)">
        ${icon("bell",15)} <span style="font-size:var(--t-sm);font-weight:700;color:var(--amber-bright)">Heads up: this may contain ${esc([...cf.moderate,...cf.noted].join(", "))} from your restrictions.</span>
      </div>`;return`
      <div style="display:flex;align-items:center;gap:9px;padding:10px 14px;border-radius:var(--r-tile);background:var(--surface-2);border:1px solid var(--hairline)">
        ${icon("shield",15)} <span style="font-size:var(--t-sm);font-weight:600;color:var(--text-2)">Compared with your saved restrictions. No matches detected. Detection can miss ingredients or cross-contact; always verify severe allergens yourself.</span>
      </div>`})()}

    <div style="height:12px"></div>
    <div class="ai-note">
      <div class="av">${icon("sparkle",18)}</div>
      <div><div class="who">AI Analysis</div><p>${esc((styleSafeProse?L.analysis:"")||L.ai)}</p></div>
    </div>

    ${already?"":`<div class="score-change">${icon("arrowUp",16)} Logging this counts toward Nutrition (${liveWeightPct("nutrition")}%) and closes 1 of ${S.remainingCount} remaining tonight.</div>`}

    <div style="height:20px"></div>
    <div class="btn-row">
      ${src==="manual"?`<button class="btn ghost sm" style="flex:1" data-go="food-search">${icon("search",17)} Edit plate</button>`:src==="label"?`<button class="btn ghost sm" style="flex:1" data-go="label-scan">${icon("barcode",17)} Edit label</button>`:`<button class="btn ghost sm" style="flex:1" data-go="camera/${slot}">${icon("camera",17)} Retake</button>`}
      ${already?`<button class="btn ghost sm" style="flex:1.6" data-back="home">Back to Home</button>`:`<button class="btn green sm" style="flex:1.6" data-act="logMeal:${slot}" data-then="meal-thread/${slot}">${icon("check",18)} Log ${esc(L.name)}</button>`}
    </div>
    <div style="height:10px"></div>
    `},mount(root){const hero=root.querySelector(".photo-hero");if(hero&&MEAL.photoDataUrl){hero.style.cursor="zoom-in";hero.setAttribute("tabindex","0");hero.setAttribute("role","button");hero.setAttribute("aria-label","View photo full screen");hero.addEventListener("click",()=>openImageViewer(MEAL.photoDataUrl,"Meal photo",hero))}const btn=root.querySelector("#edit-foods");const box=root.querySelector("#foods");if(!btn||!box)return;const editing=analysis._editing;if(editing){btn.textContent="Done";box.classList.add("editing");const addRow=root.querySelector("#food-add");if(addRow)addRow.style.display="flex";box.querySelectorAll(".food-row:not(.fr-add)").forEach(row=>{const name=row.getAttribute("data-name");const nameEl=row.querySelector(".fr-name");const qtyEl=row.querySelector(".fr-qty");const item=MEAL.result&&(MEAL.result.detectedRich||[]).find(d=>d&&d.name===name);row.insertAdjacentHTML("beforeend",`<button type="button" class="cm-rm" aria-label="Remove ${esc(name)}">${icon("x",14)}</button>`);row.querySelector(".cm-rm").addEventListener("click",e=>{e.stopPropagation();const op={kind:"remove",name};if(applyFoodEdit(MEAL.result,op)){act.recomputeStagedMeal(op);analysis._editing=true;window.__render()}});if(nameEl){nameEl.innerHTML=`<input class="fr-in name" maxlength="60" value="${esc(name)}" aria-label="Food name" />`;nameEl.querySelector("input").addEventListener("change",e=>{const op={kind:"rename",name,newName:e.target.value};if(applyFoodEdit(MEAL.result,op))act.recomputeStagedMeal(op);analysis._editing=true;window.__render()})}if(qtyEl){qtyEl.innerHTML=`<input class="fr-in qty" maxlength="12" value="${esc(item&&item.quantity||"")}" placeholder="Qty" aria-label="Quantity" />`;qtyEl.querySelector("input").addEventListener("change",e=>{const op={kind:"quantity",name,quantity:e.target.value};if(applyFoodEdit(MEAL.result,op))act.recomputeStagedMeal(op);analysis._editing=true;window.__render()})}});const addOk=root.querySelector("#add-ok");if(addOk)addOk.addEventListener("click",()=>{const n=root.querySelector("#add-name"),q=root.querySelector("#add-qty");const op={kind:"add",name:n&&n.value,quantity:q&&q.value};if(applyFoodEdit(MEAL.result,op)){act.recomputeStagedMeal(op);analysis._editing=true;window.__render()}})}btn.addEventListener("click",()=>{analysis._editing=!analysis._editing;window.__restate()})}};analysis._editing=false;export const thread={tab:"home",hideTabs:true,render({sub}){const slot=sub||MEAL.key||"dinner";const M=mealDetail(slot);const e=S.exec;if(!M.logged){return`
      ${backHead(M.name,"Not logged yet","home")}
      <div class="state-demo">
        <div class="sd-ic">${icon("camera",24)}</div>
        <div class="sd-t">${esc(M.name)} isn't logged yet</div>
        <div class="sd-s">Log it with a photo and its full breakdown (foods, macros, your team's take) lives here.</div>
      </div>
      <button class="btn green" data-go="camera/${M.slot}">${icon("camera",18)} Log ${esc(M.name)}</button>
      <div style="height:10px"></div>`}const move=RT.lastMove&&(RT.lastMove.what||"").toLowerCase()===M.slot?RT.lastMove:null;const justLogged=!!move&&!move._played;const dupFlagged=M.flagged==="dup";const timing=M.loggedAt?`Logged ${M.loggedAt} \xB7 ${M.minutesLate>0?`${M.minutesLate} min late`:"on time"}`:M.late?"Logged late \xB7 still counts":"Logged on time";const toTier=justLogged?tier(move.to):null;const firstEver=justLogged&&!(DAY.scoreHistory||[]).some(h=>h&&h.date&&h.date<String(DAY.date));const cStatus=coachThreadStatus({mealId:M.mealId,hasCoach:S.coach.hasCoach,comments:[],noun:S.coach.noun,dayReviewed:RECEIPT.uid===RT.userId&&RECEIPT.date===String(DAY.date)&&RECEIPT.reviewed});const execTop=`
    <section class="mt-confirm">
      <div class="row1">
        <div class="ck${justLogged?" pop":""}">${icon("check",20)}</div>
        <div><div class="t">${esc(M.name)} logged</div>
        <div class="s">${timing}${cStatus.label?` \xB7 <span id="coach-status">${esc(cStatus.label)}</span>`:""}</div></div>
      </div>
      ${dupFlagged?`<div class="dup-note">Duplicate photo \xB7 recorded, but it doesn't count. Coach can see the flag.</div>`:""}
      ${""}
      ${justLogged&&!dupFlagged?scoreMoveBar({from:move.from,to:move.to,uid:"mt",head:`<div class="score-line">
        <span class="k">Daily Score</span>
        <span class="from">${move.from}</span>
        <span class="arr">${icon("arrowRight",14)}</span>
        <span class="to ${toTier.cls}" data-sm-count="${move.to}">${move.to}</span>
        <span class="gain ${toTier.cls}">+${move.gain}</span>
        ${toTier.name!==tier(move.from).name?`<span class="tier-chip ${toTier.cls}" data-sm-tier="\u25B2 " data-sm-base="tier-chip">\u25B2 ${esc(toTier.name)}</span>`:""}
      </div>`})+(firstEver?'<div class="sm-first">First one in. From here the number is live: every meal, every check-in, every day.</div>':""):""}
      ${""}
      ${(()=>{if(justLogged||dupFlagged)return"";const gain=S.mealScoreImpact(M.slot)||0;return gain>0?`
      <div class="score-line">
        <span class="k">Daily Score</span>
        <span class="gain n">+${gain} from this meal</span>
      </div>`:""})()}
      <div class="prog-line">
        ${segBar(e.met,e.total,`${e.met} of ${e.total} completed today`)}
        <span class="pk">${e.met} of ${e.total} in today${S.streakDays>0?` \xB7 ${S.streakDays} day streak`:""}</span>
      </div>
    </section>`;const band=qualityBand(M.score);const reasons=scoreReasons({macros:M.macros,fiber:M.fiber,detected:M.detectedRich,minutesLate:M.minutesLate});const dayProgCF=S.mealDayProgress||{};const nextMealCF=e.now&&e.now.proof==="photo"?e.now.title:null;const focus=coachFocus({macros:M.macros,fiber:M.fiber,detected:M.detectedRich,minutesLate:M.minutesLate,nextMealName:nextMealCF,dayGap:(Number(dayProgCF.proteinTarget)||0)-(Number(dayProgCF.proteinSoFar)||0),mealsRemaining:Number(dayProgCF.mealsRemaining)||0,numbers:S.planStyle.showMacros});const rub=scoreRubric({quality:M.score,minutesLate:M.minutesLate,macros:M.macros,fiber:M.fiber,detected:M.detectedRich,source:M.source,userNote:M.userNote,photoQ:M.photoQ});const RUB_DOT={met:"g",partial:"a",miss:"r"};const settled=!M.pending&&!M.analysisFailed&&!(Array.isArray(M.pendingQuestions)&&M.pendingQuestions.length);const T=S.planTargets||{};const fromPhoto=M.source!=="label"&&M.source!=="manual";const conf=estimateConfidence(M.source,M.detectedRich);const srcLabel=M.source==="label"?"exact, from the nutrition label":M.source==="manual"?"entered by you":`estimated from photo \xB7 ${conf} confidence`;const tilde=fromPhoto?"~":"";const dayProg=S.mealDayProgress||{};const mealsLeft=Math.max(0,Number(dayProg.mealsRemaining)||0);const project=(target,soFar)=>{if(!target||!mealsLeft)return null;const gap=Math.max(0,target-(Number(soFar)||0));return gap?Math.round(gap/Math.max(1,mealsLeft))*mealsLeft:0};const targetBars=[...S.planStyle.showMacros?[["Protein",M.macros.protein,T.protein,"g",project(T.protein,dayProg.proteinSoFar)]]:[],...S.planStyle.showCalories?[["Calories",M.macros.cals,T.calories,"",null]]:[]].filter(([,,target])=>target);const projectedTotal=S.planStyle.showMacros&&T.protein?(Number(dayProg.proteinSoFar)||0)+(project(T.protein,dayProg.proteinSoFar)||0):null;const paceNote=projectedTotal&&mealsLeft?`On pace for about ${projectedTotal}g if your ${mealsLeft===1?"last meal lands":`last ${mealsLeft} meals land`} on plan`:"";const emptyRead=settled&&fromPhoto&&!M.macros.protein&&!M.macros.carbs&&!M.macros.fat&&!M.macros.cals;const rereadNote=`<div class="est-note" style="margin-top:8px">These numbers didn't land. The read came back empty, so nothing was measured.${M.mealId?` <span class="link" id="mt-reread" role="button" tabindex="0">Re-read this meal</span>`:""}${M.rereadError?` <b style="color:var(--text-2)">Couldn't fetch the photo just now. Try again in a moment.</b>`:""}</div>`;const showNums=S.planStyle.showMacros||S.planStyle.showCalories;const nutInCard=settled&&showNums?`
    <div class="nut-src">Nutrition \xB7 ${esc(srcLabel)}</div>
    ${emptyRead?`<div style="padding:0 16px 13px">${rereadNote}</div>`:`
    <div class="nut-values${S.planStyle.showMacros&&S.planStyle.showCalories?" wrap2":""}">
      ${S.planStyle.showMacros?`
      <div class="nv lead"><div class="mv">${tilde}${M.macros.protein}<i>g</i></div><div class="mk">Protein</div></div>
      <div class="nv"><div class="mv">${tilde}${M.macros.carbs}<i>g</i></div><div class="mk">Carbs</div></div>
      <div class="nv"><div class="mv">${tilde}${M.macros.fat}<i>g</i></div><div class="mk">Fat</div></div>`:""}
      ${S.planStyle.showCalories?`<div class="nv${S.planStyle.showMacros?"":" lead"}"><div class="mv">${tilde}${M.macros.cals}</div><div class="mk">Calories</div></div>`:""}
    </div>
    ${targetBars.length?`<div class="day-bars">
        ${targetBars.map(([k,v,target,u,projected])=>{const now=Math.min(100,Math.round(v/target*100));const ahead=projected!=null?Math.max(0,Math.min(100-now,Math.round(projected/target*100))):0;return`
          <div class="cons-row">
            <span class="k" style="width:64px">${k}</span>
            ${""}
            <div class="track"><div class="fillb" style="width:${now}%;background:linear-gradient(90deg,var(--blue-deep),var(--blue))"></div>${ahead?`<div class="ghostb" style="left:${now}%;width:${ahead}%"></div>`:""}</div>
            <span class="v" style="width:110px;white-space:nowrap">${tilde}${v}${u} <small style="color:var(--text-3)">of ${esc(String(target))}${u}</small></span>
          </div>`}).join("")}
        ${paceNote?`<div class="pace">${esc(paceNote)}</div>`:""}
    </div>`:""}
    ${""}`}`:"";const photoBlock=`
    <!-- The plate, blurred, as the screen's own backdrop. The meal thread is the one screen with a
         real photograph on it, and it sat on the same flat canvas as everything else; letting the
         food tint the room is what makes the screen feel like it is ABOUT that meal. Same <img>
         src as the hero below (assigned once in mount), so this costs no second fetch. Decorative
         and behind everything: aria-hidden, no pointer events. -->
    <div class="meal-backdrop" aria-hidden="true"><img id="meal-backdrop-img" alt="" decoding="async"/></div>
    <div class="photo-hero" id="meal-hero" data-vt="plate" style="margin-top:14px;background:linear-gradient(150deg, rgba(var(--green-rgb),0.14), rgba(var(--blue-deep-rgb),0.06))">
      <img id="meal-photo" alt="Photo of this meal" decoding="async" style="width:100%;height:100%;object-fit:cover;position:absolute;inset:0;display:none"/>
      <div class="ph-grad"></div>
      <div class="ph-meta"><div>${M.live===false?`<div>${nonLiveBadge()}</div>`:"<div></div>"}</div>
      ${M.score!=null?`<div class="scorechip ${band?band.cls:""}" id="meal-scorechip">
        ${miniDial(M.score)}
        <span class="v" data-count="${M.score}">${M.score}</span><span class="k">Meal</span>
      </div>`:""}</div>
    </div>
    ${""}
    ${""}
    ${band?`<section class="meal-read">
    <div class="score-read">
      <div class="sr-head">
        <span class="sr-band ${band.cls}">${band.label}</span>
      </div>
      ${reasons.length?`<div class="sr-rows">
        ${[...reasons].sort((a,b)=>(a.state==="met"?-1:1)-(b.state==="met"?-1:1)).map(r=>`
        <div class="sr-row ${r.state}"><span class="sr-ic">${icon(r.state==="met"?"check":"x",12)}</span>${esc(r.label)}</div>`).join("")}
      </div>`:""}
    </div>
    ${""}
    ${""}
    ${nutInCard}
    <details class="rub">
      <summary>${esc(rub.headline)} ${icon("chevron",13)}</summary>
      <div class="rub-body">
        ${rub.rows.map(r=>`
        <div class="rub-row">
          <span class="bd-req-dot ${RUB_DOT[r.state]||"muted"}"></span>
          <span class="rk">${esc(r.k)}</span>
          <span class="rn">${esc(r.note)}</span>
          <span class="rx-tag">${r.exact?"exact":"estimated"}</span>
        </div>`).join("")}
        <div class="rub-fine">Exact items are facts (timing, what you submitted). Estimated items come from the photo read and move when you correct it in the chat.</div>
      </div>
    </details>
    </section>`:nutInCard?`<section class="meal-read">${nutInCard}</section>`:""}`;const foodRows=M.detectedRich.map(d=>`
      <div class="food-row">
        <span class="conf-dot ${esc(d.confidence||"high")}"></span>
        <span class="fr-name">${esc(d.name)}</span>
        <span class="fr-qty">${d.quantity?`${fromPhoto?"~ ":""}${esc(d.quantity)}`:""}</span>
        ${d.basis==="label"?'<span class="rx-tag">label read</span>':d.basis==="database"?'<span class="rx-tag">known product</span>':""}
      </div>`).join("");const corrLog=(M.corrections||[]).length;const needsAnswer=Array.isArray(M.pendingQuestions)&&M.pendingQuestions.length>0;const breakdown=!settled?`
    <h2 class="eyebrow" style="margin-top:16px">Meal Breakdown</h2>
    <section class="card pad" style="margin-top:8px">
      <div class="macro-row five">
        ${["Protein","Carbs","Fat","Calories","Fiber"].map(k=>`
        <div class="macro"><div class="mv${M.pending&&!needsAnswer?" mv-wait":""}" style="color:var(--text-3)">\u2014</div><div class="mk">${k}</div></div>`).join("")}
      </div>
      ${needsAnswer?`<div class="mq-blocked">
        <div class="mqb-t">${M.pendingQuestions.length===1?"One answer from you and these are exact.":`${M.pendingQuestions.length} answers and these are exact.`}</div>
        <button class="btn primary sm" id="mq-open-breakdown" type="button">${icon("sparkle",15)} Answer</button>
      </div>`:""}
      ${M.analysisFailed?`<div class="est-note" style="margin-top:10px">No numbers for this one. The photo is still your proof that the meal happened.</div>`:""}
    </section>`:!showNums?`
    <h2 class="eyebrow" style="margin-top:16px;flex-wrap:wrap;row-gap:2px;column-gap:8px"><span style="white-space:nowrap">What was on the plate</span><span style="color:var(--text-3);font-weight:600;text-transform:none;letter-spacing:0;white-space:nowrap">\xB7 ${srcLabel}</span></h2>
    ${foodRows?`<section class="card" style="margin-top:8px;padding:4px 16px">${foodRows}</section>`:""}
    ${M.userNote?`<div class="est-note" style="margin-top:8px"><b style="color:var(--text-2)">Your note:</b> ${esc(M.userNote)}</div>`:""}
    <div class="est-note" style="margin-top:8px">Your plan tracks how food leaves you feeling rather than calorie and macro counts. Your ${esc(S.coach.noun)} can still see the full numbers.</div>
    ${emptyRead?rereadNote:""}`:`
    ${""}
    <details class="bd-wrap"${thread._bdOpen?" open":""}>
      <summary>View detected foods ${icon("chevron",13)}</summary>
      <div class="bd-body">
      ${foodRows?`<section class="card" style="margin-top:8px;padding:4px 16px">${foodRows}</section>`:""}
      ${""}
      ${targetBars.length||T.protein||T.calories?"":`<div class="est-note">No coach targets set yet, so there's nothing to measure against. These are this meal's totals.</div>`}
      ${S.planStyle.showMacros?`<div class="est-note" style="margin-top:8px">~${M.fiber}g fiber estimated. The full component read lives under "Why this meal reads ${M.score!=null?M.score:"what it reads"}".</div>`:""}
      ${M.userNote?`<div class="est-note" style="margin-top:8px"><b style="color:var(--text-2)">Your note:</b> ${esc(M.userNote)}</div>`:""}
      ${corrLog?`<div class="est-note" style="margin-top:8px;color:var(--blue-bright)"><b style="color:var(--blue-bright)">Corrected by you</b>: ${corrLog} correction${corrLog===1?"":"s"} applied. The AI's original estimate is kept for reference${(()=>{if(!M.orig)return"";const bits=[];if(S.planStyle.showMacros)bits.push(`~${M.orig.protein}g protein`);if(S.planStyle.showCalories)bits.push(`~${M.orig.kcal} kcal`);return bits.length?` (was ${bits.join(" \xB7 ")})`:""})()}.</div>`:""}
      ${""}
      ${""}
      ${emptyRead?"":M.mealId?`<div class="est-note">${fromPhoto?"Estimated from the photo. ":""}Something off or left out? <span class="link" id="tell-ai" role="button" tabindex="0">Tell the AI Nutritionist below</span> and the name, numbers and score update together.</div>`:""}
      </div>
    </details>`;const{sum,fullText,fq}=openingInputs(M);const people=participantList(PARTICIPANTS.uid===RT.userId?PARTICIPANTS.rows:[],RT.userId);const facepile=!M.mealId?"":`
    <button class="facepile" id="meal-members" aria-label="Who can see this conversation">
      <span class="fp">${people.slice(0,4).map(p=>`<span class="fpav ${esc(p.kind==="ai"?"ai":p.self?"self":"other")}"${p.kind!=="ai"&&p.id?` data-avatar-uid="${esc(p.id)}"`:""}>${p.kind==="ai"?icon("sparkle",13):`<span data-avatar-fallback>${esc(initialsFor(p.name))}</span>`}</span>`).join("")}</span>
      <span class="names">${esc(participantSummary(people))}<small>${people.length} in this conversation</small></span>
      <span class="chev">${icon("chevron",15)}</span>
    </button>`;const discussion=`
    <h2 class="eyebrow" style="margin-top:18px;display:flex;align-items:baseline;gap:8px">
      <span>Team Discussion</span>
      ${M.mealId?`<span class="link" id="open-full-chat" role="button" tabindex="0" style="margin-left:auto;text-transform:none;letter-spacing:0;font-size:12px">View full chat &rarr;</span>`:""}
    </h2>
    ${facepile}
    ${""}
    ${""}
    <div class="thread" id="meal-thread" role="log" aria-label="Meal conversation">
      ${openingBlockHtml(M,{sum,fullText,fq})}
      ${""}
      ${M.mealId?`<div id="thread-status">${THREAD_CACHE.mealId===M.mealId?"":skeletonRows(2,"Loading the thread")}</div>`:`<div class="msg-status" id="thread-status">${S.coach.hasCoach?`Syncs when connected \xB7 your ${esc(S.coach.noun)} sees this log either way.`:"Syncs when connected \xB7 this log is saved either way."}</div>`}
    </div>
    ${M.mealId?`
    ${""}
    ${composer({inputId:"meal-msg",sendId:"meal-send",placeholder:"Ask about this meal\u2026",sendLabel:"Send",attachId:"meal-attach",atEnd:true})}
    <div class="composer-attach-pending" id="meal-attach-pending" hidden></div>
    <div id="chat-note" style="min-height:18px"></div>`:""}`;const dayTier=e.celebration?tier(e.score):null;const next=e.celebration?`
    <section class="day-sealed" data-go="score-breakdown" role="button" tabindex="0"
      aria-label="Day complete. Daily Score ${e.score}, ${esc(dayTier.name)}. Open the score breakdown">
      <div class="ds-dial">${miniDial(e.score)}<span class="ds-n">${e.score}</span></div>
      <div class="ds-body">
        <div class="ds-t">Everything's in.</div>
        <div class="ds-s">${S.streakDays>0?`Day ${S.streakDays} locks at midnight`:"Locks at midnight \xB7 that starts your streak"}</div>
      </div>
      <span class="tier-chip ${dayTier.cls}" style="margin-top:0">${esc(dayTier.name)}</span>
    </section>`:"";const backHome=`<div class="meal-foot">
      <button class="btn ghost meal-back" data-go="home" aria-label="Back to home">${icon("back",16)} Back to Home</button>
    </div>`;return`<div class="meal-screen">${backHead(M.dish||M.name,dupFlagged?"Duplicate photo":"","home")}${execTop}${next}${photoBlock}${breakdown}${discussion}${backHome}</div>`},async mount(root,{sub}){const slot=sub||MEAL.key||"dinner";const M=mealDetail(slot);const mv=RT.lastMove&&(RT.lastMove.what||"").toLowerCase()===slot?RT.lastMove:null;if(mv&&!mv._played){playScoreMove(root,{key:`move:${slot}:${DAY.date}:${mv.from}-${mv.to}`,from:mv.from,to:mv.to,onDone:()=>{mv._played=true}})}if(!M.logged)return;if(Array.isArray(M.pendingQuestions)&&M.pendingQuestions.length){const key=`${slot}:${DAY.date}`;if(!autoShownFor(key)){markAutoShown(key);setTimeout(()=>{const now=mealDetail(slot);if(!root.isConnected||!now||!Array.isArray(now.pendingQuestions)||!now.pendingQuestions.length)return;askPendingQuestions(now)},420)}}reveal(root.querySelector("#meal-scorechip"),{key:`meal:${M.slot}:${M.mealId||""}`,whenSeen:true,onPlay:()=>{if(Number(M.score)>=100)playPerfectMoment({slotLabel:M.name,dish:M.dish,score:M.score})}});const roles=await import("../roles.js");const viewEl=root.querySelector("#view")||root;void warmRecent(roles,RT.userId);void warmPendingFacts(RT.userId);void warmParticipants(roles,RT.userId).then(fetched=>{if(fetched)window.__render&&window.__render()});void warmReceipt(roles,RT.userId,String(DAY.date)).then(()=>{const el=root.querySelector("#coach-status");if(el&&RECEIPT.reviewed&&/^Sent to /.test(el.textContent)){el.textContent=`${S.coach.noun.charAt(0).toUpperCase()}${S.coach.noun.slice(1)} opened your day`}});const bdWrap=root.querySelector(".bd-wrap");if(bdWrap)bdWrap.addEventListener("toggle",()=>{thread._bdOpen=bdWrap.open});const focusMealComposer=()=>focusComposer(root.querySelector("#meal-msg"));const tellAi=root.querySelector("#tell-ai");if(tellAi)tellAi.addEventListener("click",focusMealComposer);const photo=root.querySelector("#meal-photo");if(photo){if(M.img){photo.src=M.img;photo.style.display="block"}const store=await import("../photo-store.js");let url=M.img;if(!url&&RT.userId&&M.hasPhoto){url=await store.resolveMealPhoto(store.todayMealPhotoPath(RT.userId,String(DAY.date),M.slot))}const hero=root.querySelector("#meal-hero");const noPhoto=label=>{if(!hero||!root.isConnected)return;photo.style.display="none";hero.classList.add("ph-nophoto");if(!hero.querySelector(".ph-wait"))hero.insertAdjacentHTML("beforeend",`<div class="ph-wait">${icon("image",15)} <span></span></div>`);hero.querySelector(".ph-wait span").textContent=label};if(url){photo.onerror=()=>noPhoto("This photo didn't sync from the device.");photo.src=url;photo.style.display="block";const back=root.querySelector("#meal-backdrop-img");if(back)back.src=url;if(hero){hero.style.cursor="zoom-in";hero.setAttribute("tabindex","0");hero.setAttribute("role","button");hero.setAttribute("aria-label","View photo full screen");hero.addEventListener("click",()=>openImageViewer(url,`${M.name} photo`,hero))}}else if(M.hasPhoto){const{getJob,jobKey}=await import("../meal-outbox.js");const job=RT.userId?getJob(jobKey(RT.userId,DAY.date,M.slot)):null;noPhoto(job&&job.needUpload&&!job.dead?"Photo syncing from your device\u2026":"This photo didn't sync from the device.")}}if(!M.mealId)return;const threadEl=root.querySelector("#meal-thread");const statusEl=root.querySelector("#thread-status");let threadBusy=false;const showThreadError=()=>{if(!statusEl)return;statusEl.style.cssText="align-self:stretch;text-align:center;padding:14px 12px;border-radius:var(--r-tile);background:var(--surface-1);border:1px solid var(--hairline);margin-top:2px";statusEl.innerHTML=`<div style="font-size:var(--t-sm);font-weight:600;color:var(--text-2);line-height:1.4">Couldn't load the discussion. Your log is safe, coach can still see it.</div>
        <button class="btn ghost sm" id="thread-retry" style="margin-top:10px">${icon("wifiOff",15)} Try again</button>`;const retryBtn=statusEl.querySelector("#thread-retry");if(retryBtn)retryBtn.addEventListener("click",()=>{if(threadBusy)return;threadBusy=true;refresh().finally(()=>{threadBusy=false})})};let gen=0;const cacheHit=THREAD_CACHE.mealId===M.mealId;let comments=cacheHit?THREAD_CACHE.comments:[];let lastKnownAt=cacheHit?THREAD_CACHE.lastKnownAt:null;let rxBusy=false;const fmtMsgTime=iso=>{if(!iso)return"";const d=new Date(iso);if(isNaN(d.getTime()))return"";let h=d.getHours();const mm=String(d.getMinutes()).padStart(2,"0");const ap=h>=12?"PM":"AM";h=h%12||12;return`${h}:${mm} ${ap}`};const participants=PARTICIPANTS.uid===RT.userId?PARTICIPANTS.rows:[];const dayKey=ms=>{const d=new Date(ms);return`${d.getFullYear()}-${d.getMonth()}-${d.getDate()}`};let aiTyping=false;const typingRow=()=>`
        <div class="msg ai typing" id="ai-typing">
          <div class="av">${icon("sparkle",15)}</div>
          <div><div class="who">AI Nutritionist is typing<span class="sr-only">, a reply is on its way</span></div>
          <div class="bubble tdots"><span></span><span></span><span></span></div></div>
        </div>`;let corrFx=null;const corrReceipt=()=>{if(!corrFx||!corrFx.rows.length)return"";return`
        <div class="msg ai" id="corr-fx">
          <div class="av">${icon("sparkle",15)}</div>
          <div class="corr-card" role="status">
            <div class="corr-head">${corrFx.done?icon("check",14):'<span class="corr-spin" aria-hidden="true"></span>'}<span>${corrFx.done?"Updated":"Recomputing"}</span></div>
            ${corrFx.rows.map(r=>`
              <div class="corr-row">
                <span class="ck">${esc(r.label)}</span>
                ${""}
                <span class="cv"><i class="was">${esc(r.fromText)}</i>${icon("arrowRight",12)}${corrFx.done?`<b data-fx-from="${r.from}" data-fx-to="${r.to}" data-fx-unit="${esc(r.unit||"")}">${esc(r.fromText)}</b>`:'<b class="pend" aria-hidden="true"></b>'}</span>
              </div>`).join("")}
          </div>
        </div>`};const playCorrReceipt=root2=>{const card=root2.querySelector("#corr-fx");if(!card||!corrFx||corrFx.played)return;const reduce=window.matchMedia&&window.matchMedia("(prefers-reduced-motion: reduce)").matches;const nums=[...card.querySelectorAll("[data-fx-to]")];const settle=n=>{n.textContent=n.dataset.fxTo+(n.dataset.fxUnit||"")};if(reduce){corrFx.played=true;corrFx.done=true;nums.forEach(settle);buzz("reveal");return}card.classList.add("in");if(!corrFx.done){corrFx.played=true;setTimeout(()=>{if(!corrFx)return;corrFx.done=true;corrFx.played=false;paint()},420);return}corrFx.played=true;const dur=900,t0=performance.now();const step=t=>{const p=Math.min(1,(t-t0)/dur);const e=1-Math.pow(1-p,3);for(const n of nums){const a=+n.dataset.fxFrom,b=+n.dataset.fxTo;n.textContent=String(Math.round(a+(b-a)*e))+(n.dataset.fxUnit||"")}if(p<1)requestAnimationFrame(step);else{nums.forEach(settle);card.classList.add("landed");buzz("reveal")}};requestAnimationFrame(step)};const setCorrFx=(before,after)=>{const P=S.planStyle;const cand=[];if(P.showMacros){cand.push(["Protein",before.protein,after.protein,"g"]);cand.push(["Carbs",before.carbs,after.carbs,"g"]);cand.push(["Fat",before.fat,after.fat,"g"])}if(P.showCalories)cand.push(["Calories",before.kcal,after.kcal,""]);cand.push(["Meal score",before.quality,after.quality,""]);const rows=cand.filter(([,a,b])=>a!=null&&b!=null&&Math.round(+a)!==Math.round(+b)).map(([label,a,b,unit])=>({label,unit,from:Math.round(+a),to:Math.round(+b),fromText:Math.round(+a)+(unit||"")}));corrFx=rows.length?{rows}:null};const offerChips=c=>{const offer=memoryOfferOf(c);if(!offer)return"";if(ANSWERED_FACTS.has(offer.id))return"";const known=PENDING_FACTS.uid===RT.userId;if(known&&!(PENDING_FACTS.rows||[]).some(f=>f&&String(f.id)===offer.id))return"";return memoryOfferChips(offer,esc)};const suggestRemaining=()=>{const PS=S.planStyle||{},T=S.planTargets||{},c=S.dayConsumed||{};return remainingToday({proteinSoFar:c.protein,kcalSoFar:c.kcal,proteinTarget:PS.showMacros?T.protein:null,kcalTarget:PS.showCalories?T.calories:null})};const suggestItems=()=>{const fm=foodMemory(RT.userId);return fm?fm.items:[]};const bubbleText=c=>{const sug=mealSuggestOf(c);if(!sug)return esc(c.text);return mealSuggestHtml(sug,fillMealSuggestion(sug,suggestItems(),suggestRemaining()),esc)};const paint=()=>{if(!threadEl)return;const msgs=threadMessages(comments);OFFERED_IN_THREAD.clear();for(const c of msgs){const o=memoryOfferOf(c);if(o)OFFERED_IN_THREAD.add(o.id)}const coachSeen=(Array.isArray(comments)?comments:[]).some(c=>c&&c.role==="coach");const dayReviewed=RECEIPT.uid===RT.userId&&RECEIPT.date===String(DAY.date)&&RECEIPT.reviewed;const daySeen=(RECEIPT.rows||[]).length>0;const csEl=root.querySelector("#coach-status");const Noun=S.coach.noun.charAt(0).toUpperCase()+S.coach.noun.slice(1);if(csEl&&coachSeen)csEl.textContent=`${Noun} replied`;const tail=[];if(!msgs.length&&!aiTyping)tail.push("No replies yet. Ask below and the AI Nutritionist answers from your plan.");if(S.coach.hasCoach&&!coachSeen&&!dayReviewed&&!daySeen)tail.push(`Your ${S.coach.noun} hasn't opened this yet.`);const hasPersistedRead=msgs.some(isAnalysisOpener);const live=mealDetail(M.slot)||M;const openingInp={...openingInputs(live),hasPersistedRead};const openingLead=openingBlockHtml(live,{...openingInp,part:"lead"});const openingTail=openingBlockHtml(live,{...openingInp,part:"tail"});const PREVIEW_MSGS=4;const shown=msgs.slice(-PREVIEW_MSGS);const hiddenCount=msgs.length-shown.length;const lastMsg=msgs.length?msgs[msgs.length-1]:null;const rows=layoutThread(shown,{muted:RT.mutedUsers,fmtTime:fmtMsgTime,fmtDay:dayKey,fmtDayLabel:dayLabelOf}).map(item=>{if(item.type==="time")return`<div class="tsep">${esc(item.label)}</div>`;const c=item.comment;const mine=c.role==="athlete"&&(!c.author_id||c.author_id===RT.userId);const who=authorName(c,participants,RT.userId,S.coach.noun);const update=isAnalysisUpdate(c);const escalated=isEscalated(c);const quoted=update?quotedFor(c,msgs):null;const rx=c===lastMsg?reactionGroups(comments):[];const photo2=attachedPhoto(c);const photoOnly=isPhotoOnly(c);return`
        <div class="msg ${mine?"athlete":c.role==="ai"?"ai":"coach"}${item.firstOfRun?"":" cont"}${rx.length?" has-rx":""}">
          ${!mine&&item.firstOfRun?`<div class="av"${c.role!=="ai"&&c.author_id?` data-avatar-uid="${esc(c.author_id)}"`:""}>${c.role==="ai"?icon("sparkle",15):`<span data-avatar-fallback>${esc(initialsFor(who))}</span>`}</div>`:'<div class="av-sp"></div>'}
          <div class="stack">
            ${item.firstOfRun&&!mine?`<div class="who">${esc(who)}</div>`:""}
            ${quoted?`<div class="quote"><span class="stem"></span><span class="qtext">${esc(quoted.text)}</span></div>`:""}
            ${""}
            <div class="bubble">${escalated?'<span class="esc">Sent to your coach</span>':""}${bubblePhotoHtml(photo2,esc)}${photoOnly?"":bubbleText(c)}${offerChips(c)}</div>
            ${rx.length?`<span class="rxo">${rx.map(r=>`${esc(r.emoji)} ${r.count}`).join(" ")}</span>`:""}
          </div>
        </div>`}).join("");const lastMsgAt=msgs.length?Math.max(...msgs.map(c=>{const t=Date.parse(c&&c.created_at);return isNaN(t)?0:t})):0;const freshReceipt=(RECEIPT.rows||[]).map(r=>({...r,_at:Date.parse(r&&r.seen_at)})).filter(r=>!isNaN(r._at)&&r._at>=lastMsgAt).sort((a,b)=>b._at-a._at)[0]||null;const seen=freshReceipt?(()=>{const nm=String(freshReceipt.viewer_name||"").trim();const who=/^[A-Za-z][A-Za-z.'\- ]+$/.test(nm)?nm:`Your ${S.coach.noun}`;return`${esc(who)} opened your day \xB7 ${esc(fmtMsgTime(freshReceipt.seen_at))}`})():"";const lastCoach=[...msgs].reverse().find(c=>c&&c.role==="coach"&&!isPhotoOnly(c)&&String(c.text||"").trim());const coachPin=lastCoach&&!shown.includes(lastCoach)?(()=>{const who=authorName(lastCoach,participants,RT.userId,S.coach.noun);return`<div class="coach-pin">
          <div class="cp-head"><span class="cp-av"${lastCoach.author_id?` data-avatar-uid="${esc(lastCoach.author_id)}"`:""}><span data-avatar-fallback>${esc(initialsFor(who))}</span></span><span class="cp-who">${esc(who)}</span><span class="cp-tag">${icon("pin",11)} Pinned</span></div>
          <div class="cp-text">${esc(String(lastCoach.text||""))}</div>
        </div>`})():"";const earlierBtn=hiddenCount>0?`<button class="cont-earlier" id="thread-more">View ${hiddenCount} earlier message${hiddenCount===1?"":"s"} &rarr;</button>`:"";threadEl.innerHTML=coachPin+openingLead+earlierBtn+rows+openingTail+(aiTyping?typingRow():"")+corrReceipt()+(seen?`<div class="seen">${seen}</div>`:"")+(tail.length?`<div class="msg-status">${tail.join(" ")}</div>`:"");hydrateAvatars(threadEl);wireReadMore(threadEl,expandedBubbles);scrollThreadToEnd(threadEl);void hydrateThreadPhotos(threadEl,roles);playCorrReceipt(threadEl)};const setTyping=on=>{aiTyping=!!on;paint()};let lastFetchFp=cacheHit?THREAD_CACHE.fp:null;const refresh=async(opts={})=>{const myGen=++gen;const probeSince=opts.probe&&lastKnownAt?lastKnownAt:null;const fetched=await roles.fetchMealComments(M.mealId,probeSince);if(myGen!==gen)return;if(fetched&&fetched.unchanged)return;if(fetched&&fetched.error){lastFetchFp=null;THREAD_CACHE.fp=null;showThreadError();return}const fp=JSON.stringify(fetched);const changed=fp!==lastFetchFp;lastFetchFp=fp;comments=fetched;if(statusEl)statusEl.remove();for(const row of Array.isArray(comments)?comments:[]){if(row&&row.created_at&&(!lastKnownAt||row.created_at>lastKnownAt))lastKnownAt=row.created_at}THREAD_CACHE.mealId=M.mealId;THREAD_CACHE.comments=comments;THREAD_CACHE.lastKnownAt=lastKnownAt;THREAD_CACHE.fp=fp;let proApplied=false;for(const c of Array.isArray(comments)?comments:[]){if(c&&c.meta&&c.meta.t==="pro_correction"){if(act.applyProCorrection(M.slot,c))proApplied=true}}if(proApplied&&window.__render){window.__render();return}if(changed)paint()};if(cacheHit){if(statusEl)statusEl.remove();paint();void refresh({probe:true}).catch(()=>{})}else{await refresh()}const membersBtn=root.querySelector("#meal-members");if(membersBtn)membersBtn.addEventListener("click",()=>{openMembersSheet(participantList(PARTICIPANTS.uid===RT.userId?PARTICIPANTS.rows:[],RT.userId))});try{clearInterval(window.__threadTick)}catch{}const channelReused=!!(window.__threadChannel&&window.__threadChannelMealId===M.mealId);try{if(window.__threadChannel&&!channelReused){void window.__threadChannel.unsubscribe();window.__threadChannel=null;window.__threadChannelMealId=null}}catch{}let rtLive=channelReused?_threadRtLive:false;let burstUntil=0;const BASE_MS=15e3,SLOW_MS=45e3,BURST_MS=2500,FOCUS_MS=6e3;const tickDelay=()=>{if(Date.now()<burstUntil)return BURST_MS;const composerEl=root.querySelector("#meal-msg");if(composerEl&&typeof document!=="undefined"&&document.activeElement===composerEl)return FOCUS_MS;return rtLive?SLOW_MS:BASE_MS};const scheduleTick=()=>{try{clearTimeout(window.__threadTick)}catch{}window.__threadTick=setTimeout(async()=>{if(typeof document==="undefined"||!document.hidden){if(!threadBusy){const probing=Date.now()>=burstUntil;await refresh({probe:probing}).catch(()=>{})}}if(root.isConnected)scheduleTick()},tickDelay())};scheduleTick();const startBurst=(ms=2e4)=>{burstUntil=Date.now()+ms;scheduleTick()};_liveThreadRefresh=opts=>{if(!root.isConnected){try{if(window.__threadChannel){void window.__threadChannel.unsubscribe();window.__threadChannel=null;window.__threadChannelMealId=null}}catch{}return}if(!threadBusy)void refresh(opts).catch(()=>{})};_liveThreadRtStatus=live=>{if(!root.isConnected)return;rtLive=live;scheduleTick()};void(async()=>{if(!M.mealId||channelReused)return;try{const c=typeof window!=="undefined"?window.sb:null;if(!c||typeof c.channel!=="function")return;const ch=c.channel(`meal_thread:${M.mealId}`).on("postgres_changes",{event:"*",schema:"public",table:"meal_comments",filter:`meal_id=eq.${M.mealId}`},()=>{if(_liveThreadRefresh)_liveThreadRefresh()}).subscribe(status=>{_threadRtLive=status==="SUBSCRIBED";if(_liveThreadRtStatus)_liveThreadRtStatus(_threadRtLive)});window.__threadChannel=ch;window.__threadChannelMealId=M.mealId}catch{}})();const input=root.querySelector("#meal-msg");const send=root.querySelector("#meal-send");const note=root.querySelector("#chat-note");const prefill=text=>{if(!input)return;if(text)input.value=text;focusComposer(input)};root.querySelectorAll(".qa").forEach(b=>b.addEventListener("click",()=>prefill(b.getAttribute("data-qa")||"")));root.addEventListener("click",ev=>{const fm=ev.target&&ev.target.closest?ev.target.closest("[data-fm-log]"):null;if(fm){if(act.stageSavedMeal(fm.getAttribute("data-fm-log")))location.hash="#meal-analysis";return}const fx=ev.target&&ev.target.closest?ev.target.closest("[data-fact]"):null;if(fx){const id=fx.getAttribute("data-fact");ANSWERED_FACTS.add(String(id));PENDING_FACTS={uid:PENDING_FACTS.uid,rows:(PENDING_FACTS.rows||[]).filter(f=>f.id!==id),at:Date.now()};void act.confirmMemoryFact(id,fx.getAttribute("data-keep")==="1");return}const t=ev.target&&ev.target.closest?ev.target.closest("#mq-thread-go, #mq-thread-skip, #mq-open-breakdown, #mt-retry-analysis, #mt-reread, #open-full-chat, #thread-more"):null;if(!t)return;if(t.id==="mt-retry-analysis"){t.disabled=true;t.textContent="Reading the plate\u2026";void act.retryAnalysis(M.slot);return}if(t.id==="open-full-chat"||t.id==="thread-more"){if(window.__navigate)window.__navigate("nutrition-chat");else location.hash="#nutrition-chat";return}if(t.id==="mt-reread"){t.textContent="Reading the plate\u2026";void act.rereadMeal(M.slot);return}if(t.id==="mq-thread-skip"){act.skipPendingQuestions(M.slot);return}askPendingQuestions(M)});const setNote=(t,retry)=>{if(note)note.innerHTML=t?`<div class="mt-retry" ${retry?'id="chat-retry"':""}>${esc(t)}</div>`:""};let busy=false;const askAI=async(text,photoPath=null)=>{try{const recent=await roles.fetchRecentMeals(RT.userId,roles.daysAgoISO(7)).catch(()=>[]);await warmFoodMemory(roles,RT.userId).catch(()=>null);const ex=S.exec;const recentAscending=(recent||[]).slice().reverse();const context=contextForChat({meal:{name:M.name,slot:M.slot,macros:M.macros,fiber:M.fiber,quality:M.score,late:M.late,note:M.note,foods:(M.detectedRich||[]).map(d=>d&&{name:d.name,per:d.per,basis:d.basis,product:d.product,brand:d.brand,quantity:d.quantity}).filter(Boolean)},plan:{goal:RT.profile&&RT.profile.baseGoal,targets:S.planTargets,allergies:RT.allergies},exec:{met:ex.met,total:ex.total,score:ex.score,possible:ex.possible,next:ex.now&&ex.now.title},day:(()=>{const dp=S.mealDayProgress||{};return{proteinSoFar:dp.proteinSoFar,proteinTarget:dp.proteinTarget,mealsRemaining:dp.mealsRemaining}})(),recentMeals:recentAscending.map(m=>({type:m.type,protein:m.protein,kcal:m.kcal,quality:m.quality,date:m.day_date})),thread:threadMessages(comments).slice(-20).map(c=>({role:c.role,text:String(c.text).slice(0,300)})),usualMeals:suggestItems()});setTyping(true);const{data,error}=await window.sb.functions.invoke("meal-chat",{body:{mealId:M.mealId,question:text||"I sent a photo. What do you make of it?",context,...athleteContextForAnalysis(),canApplyCorrection:true,canRemember:true,canSuggestMeal:true,...photoPath?{photoPath}:{}}});setTyping(false);if(data&&data.memory&&data.memory.id)void warmPendingFacts(RT.userId,{force:true});if(error||!data||data.error){let parsed=data&&data.error?data:null;if(!parsed&&error&&error.context&&typeof error.context.json==="function"){parsed=await error.context.json().catch(()=>null)}if(parsed&&parsed.error==="limit")setNote("You've hit today's AI coaching limit. Back tomorrow. Your coach still sees this.");else setNote("Couldn't reach your AI coach. Tap to try again.",true)}else{if(data.correction&&(data.correction.item||Array.isArray(data.correction.missed)&&data.correction.missed.length)){const c=data.correction;const parts=[c,...Array.isArray(c.more)?c.more:[]].filter(p=>p&&p.item).map(p=>({kind:"item",item:p.item,newName:p.newName||void 0,quantity:p.quantity||void 0,per:p.per||{},perBasis:p.perBasis||void 0,add:p.add||void 0,minutesLate:M.minutesLate}));if(Array.isArray(c.missed)&&c.missed.length)parts.push({kind:"add-foods",foods:c.missed,minutesLate:M.minutesLate});const applied=await act.correctMeal(M.slot,parts,{skipAiUpdate:true});if(!applied){setNote("That didn't line up with anything in this meal's read, so your numbers haven't changed. Tell me which food you mean, or what was on the plate, and I'll put it in.");focusMealComposer();if(window.__render)window.__render();return}if(applied.unpriced&&applied.unpriced.length){setNote(`Added what I could price. There are no numbers on file for ${applied.unpriced.join(" or ")}, so it isn't counted yet. Tell me its protein and calories, or what it's closest to, and I'll count it.`)}else setNote("");if(applied.before&&applied.meta)setCorrFx(applied.before,applied.meta);if(window.__render)window.__render();return}await refresh()}}catch{setTyping(false);setNote("Couldn't reach your AI coach. Tap to try again.",true)}const retry=root.querySelector("#chat-retry");if(retry)retry.addEventListener("click",async()=>{if(busy)return;busy=true;setNote("");await askAI(text);busy=false})};const attach=wireComposerAttach({root,attachId:"meal-attach",pendingId:"meal-attach-pending",safeImg,onNote:m=>setNote(m)});const submit=async()=>{const typed=(input.value||"").trim();const pendingPhoto=attach.get();if(!typed&&!pendingPhoto||busy)return;busy=true;setNote("");input.value="";if(pendingPhoto)setNote("Uploading photo\u2026");const res=await postChatMessage(roles,{mealId:M.mealId,athleteId:RT.userId,authorId:RT.userId,role:"athlete",text:typed,photo:pendingPhoto});const photoPath=res.photoPath;if(res.ok){attach.clear();setNote("");startBurst()}else{input.value=typed;setNote(res.error==="upload"?"Couldn't upload that photo. Try again, or remove it and send.":"Couldn't send. Try again.");busy=false;return}if(S.coach.hasCoach){void roles.notifyMyCoach({kind:M.mealId?`meal_action:${M.mealId}`:"meal_action",urgent:true,title:`${S.athlete.first||"Your athlete"} ${photoPath&&!typed?"sent a photo about":"asked about"} ${M.name}`,body:`${(typed||"Sent a photo").slice(0,140)} \xB7 Tap to open the conversation.`,route:`coach-meal/${M.mealId}`})}await refresh();scrollThreadToEnd(root,{force:true});await askAI(typed,photoPath);busy=false};if(send)send.addEventListener("click",submit);if(input)input.addEventListener("keydown",e2=>{if(e2.key==="Enter"&&!e2.isComposing)submit()});if(M.mealId)wireTapback({root,scope:"#meal-thread",emoji:REACTION_EMOJI,mine:()=>new Set((Array.isArray(comments)?comments:[]).filter(c=>c&&c.kind==="reaction"&&c.author_id===RT.userId).map(c=>String(c.text))),onReact:async emoji=>{if(!emoji||rxBusy)return;rxBusy=true;const existing=(Array.isArray(comments)?comments:[]).find(c=>c&&c.kind==="reaction"&&c.author_id===RT.userId&&String(c.text)===emoji);let ok=false;if(existing){ok=await roles.deleteMealComment(existing.id)}else{ok=await roles.postMealComment(M.mealId,RT.userId,RT.userId,"athlete",emoji,"reaction")}if(ok)await refresh();else setNote("Couldn't save that reaction. Try again.");rxBusy=false}});const threadRoot=root.querySelector("#meal-thread");if(threadRoot)threadRoot.addEventListener("click",ev=>{const im=ev.target&&ev.target.closest?ev.target.closest("img.bimg"):null;if(!im||!im.src)return;openImageViewer(im.src,"Photo attached to this message",im)})}};export const confirm=thread;export const detail=thread;
