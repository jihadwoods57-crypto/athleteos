import{S,RT}from"../state.js";import{icon}from"../icons.js";import{backHead,esc,errorState,emptyState}from"../components.js";import{morningReadiness,commitmentStreak,wakeupHistory,wakeupSummary,VERDICT}from"../commitments.js";import{loadMineRange,todayISO,shiftISO}from"../commitment-data.js";import{WAKEUP_SHIFT}from"../plan-style.js";let RANGE=30;let ROWS=null;let LOADED_FOR=null;let FAILED=null;function bar(label,done,total){const pct=total?Math.round(done/total*100):null;return`
  <div class="vc-mr">
    <div class="vc-mr-top"><span class="vc-mr-l">${esc(label)}</span>
      <span class="vc-mr-n">${total?`${done}/${total}`:"\u2014"}</span></div>
    <div class="vc-mr-track"><div class="vc-mr-fill" style="width:${pct==null?0:pct}%"></div></div>
  </div>`}const VERDICT_PILL={on_standard:["g","On standard"],late:["a","Late"],missed:["r","Missed"],pending:["muted","Pending"],excused:["muted","Excused"]};function dayLabel(iso,today){if(iso===today)return"Today";if(iso===shiftISO(today,-1))return"Yesterday";const d=new Date(String(iso)+"T12:00:00");return isNaN(d)?String(iso):d.toLocaleDateString([],{weekday:"long",month:"short",day:"numeric"})}function wakeupSection(rows,loading){if(loading)return"";const h=wakeupHistory(rows,new Date().toISOString());if(!h.length)return"";const s=wakeupSummary(h);const today=todayISO();const line=s.total?`${s.onStandard} On standard \xB7 ${s.late} Late \xB7 ${s.missed} Missed`:"Your first one is today";return`
    <h2 class="eyebrow">Roll call <span class="opt">${esc(line)}</span></h2>
    <section class="card rows">
      ${h.slice(0,30).map(x=>{const[cls,label]=VERDICT_PILL[x.verdict]||["muted",x.verdict];const sub=x.verdict===VERDICT.PENDING?`Answer by ${x.due}`:x.at?`${x.at}${x.verdict===VERDICT.LATE&&x.lateMin?` \xB7 ${x.lateMin} min late`:""}`:x.verdict===VERDICT.MISSED?`No answer by ${x.due}`:"";return`
        <div class="lrow wk-hist" data-go="roll-call/${esc(x.instance_id)}">
          <div class="lm"><div class="lt">${esc(dayLabel(x.occurs_on,today))}</div><div class="ls">${esc(sub)}</div></div>
          <span class="status-pill ${cls}">${esc(label)}</span>
        </div>`}).join("")}
    </section>`}export default{tab:"progress",render(){if(FAILED===`${RANGE}:${todayISO()}`){return`
      ${backHead("Roll call record","Verified commitments","progress")}
      ${errorState({title:"Couldn't load your record",body:"Nothing was lost. Reconnect and it loads right here.",retryId:"mr-retry"})}`}const rows=ROWS||[];const m=morningReadiness(rows);const streak=commitmentStreak(rows,todayISO());const loading=ROWS===null;if(!loading&&!rows.length){return`
      ${backHead("Roll call record","Verified commitments","progress")}
      ${emptyState({icon:"clock",title:"Nothing to show yet",body:`${S.coach.hasCoach?`When your ${S.coach.noun} schedules a roll call, a lift, or a study hall`:"When a roll call, a lift, or a study hall is scheduled for you"}, your responses and finished sessions build this record.`,action:S.coach.hasCoach?null:{label:"Connect a coach",go:"connect"},compact:true})}`}return`
    ${backHead("Roll call record",`Last ${RANGE} days`,"progress")}

    ${""}
    <section class="rfig">
      <div class="rfig-n">${loading?"\u2014":m.pct==null?"\u2014":`${m.pct}%`}</div>
      <div class="rfig-k">of every commitment ${S.coach.hasCoach?`your ${esc(S.coach.noun)} scheduled`:"scheduled for you"}</div>
      ${streak?`<div class="rfig-row"><span class="status-pill g">${streak} day${streak===1?"":"s"} clean</span></div>`:""}
    </section>

    <div style="height:12px"></div>
    <div style="display:flex;gap:6px" role="radiogroup" aria-label="Range">
      <button class="chip ${RANGE===7?"on":""}" role="radio" aria-checked="${RANGE===7?"true":"false"}" data-range="7" style="flex:1">Last 7 days</button>
      <button class="chip ${RANGE===30?"on":""}" role="radio" aria-checked="${RANGE===30?"true":"false"}" data-range="30" style="flex:1">Last 30 days</button>
    </div>

    ${wakeupSection(rows,loading)}

    ${""}
    <h2 class="eyebrow">The two signals</h2>
    <section class="card pad">
      ${bar("Wake responses",m.wake.done,m.wake.total)}
      ${bar("Completed sessions",m.completion.done,m.completion.total)}
    </section>

    ${""}
    <div class="sidebox" style="margin-top:14px">
      <div class="req-icon b s38">${icon("target",19)}</div>
      <div>
        <div class="tt">How this record works</div>
        <div class="ts">Finishing the session counts most; answering counts a little. Anything that couldn't be verified is left out rather than counted against you. This % is its own record. An answered roll call also moves your daily score, by up to ${Math.round(WAKEUP_SHIFT*100)} points.</div>
      </div>
    </div>
    <div style="height:20px"></div>`},mount(root){const want=`${RANGE}:${todayISO()}`;if(LOADED_FOR!==want&&FAILED!==want){loadMineRange(shiftISO(todayISO(),-(RANGE-1)),todayISO()).then(rows=>{if(rows===null){FAILED=want}else{ROWS=rows;LOADED_FOR=want;FAILED=null}if(root.isConnected)window.__render&&window.__render()})}const retry=root.querySelector("#mr-retry");if(retry)retry.addEventListener("click",()=>{FAILED=null;window.__render&&window.__render()});root.querySelectorAll("[data-range]").forEach(b=>b.addEventListener("click",()=>{RANGE=+b.getAttribute("data-range");ROWS=null;LOADED_FOR=null;FAILED=null;RT.vcRange=RANGE;window.__render&&window.__render()}))}};
