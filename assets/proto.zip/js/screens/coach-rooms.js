import{RT,act}from"../state.js";import{icon}from"../icons.js";import{backHead,esc,emptyState,errorState,skeletonRows}from"../components.js";import{initialsOf}from"../initials.js";import*as roles from"../roles.js";import{CD,loadCoachRoster}from"../coach-data.js";import{suggestedRooms,slugifyRoomKey,groupRosterByRoom}from"../rooms.js";const teamId=()=>CD.roster&&CD.roster.teams&&CD.roster.teams[0]&&CD.roster.teams[0].id;const rosterRows=()=>CD.roster&&CD.roster.rows||[];const rosterPositions=()=>rosterRows().map(r=>(r.position||"").toUpperCase());let BUSY=false;let STAFF=null;let OPEN_OWNER=null;let RENAMING=null;let DELETING=null;let ERR="";let ADD_VAL="";let RENAME_VAL=null;const LAPSED="Your plan has lapsed. Rooms are still here to look at. Funding the team turns editing back on.";async function run(work){if(BUSY)return;if(!CD.caps.rooms){ERR=LAPSED;window.__render();return}BUSY=true;ERR="";window.__render();try{await work()}finally{BUSY=false;window.__render()}}const FAIL="Couldn't save that. Check your connection.";const staffName=id=>{const s=(STAFF||[]).find(x=>x.staff_id===id);return s?s.name:null};const setOwner=(roomId,staffId)=>run(async()=>{OPEN_OWNER=null;const r=await roles.setRoomOwner(roomId,staffId);if(r.ok)await loadCoachRoster(true);else ERR=FAIL});const createRoom=label=>run(async()=>{const id=teamId();const key=slugifyRoomKey(label);if(!id||!key)return;const r=await roles.saveTeamRoom(id,{key,label:label.trim().slice(0,40)});if(r.ok){ADD_VAL="";try{act.markCoachSetup("group")}catch{}await loadCoachRoster(true)}else{ADD_VAL=label;ERR=FAIL}});const deleteRoom=roomId=>run(async()=>{DELETING=null;if(await roles.deleteTeamRoom(roomId))await loadCoachRoster(true);else ERR=FAIL});const renameRoom=(room,label)=>run(async()=>{const clean=String(label||"").trim().slice(0,40);if(!clean||clean===room.label){RENAMING=null;RENAME_VAL=null;return}const r=await roles.saveTeamRoom(teamId(),{id:room.id,key:room.key,label:clean});if(r.ok){RENAMING=null;RENAME_VAL=null;await loadCoachRoster(true)}else{RENAME_VAL=clean;ERR=FAIL}});const assign=(athleteId,roomId)=>run(async()=>{const r=await roles.assignAthleteRoom(athleteId,roomId);if(r.ok)await loadCoachRoster(true);else ERR=FAIL});export const coachRooms={nav:"coach",tab:"profile",render(){const head=backHead("Rooms","Position units for your team.","coach-profile");if(!CD.extras){if(CD.roster&&CD.roster.offline)return`${head}${errorState({title:"Couldn't load your team",body:"Your rooms are safe. Reconnect and they load right here.",retryId:"rooms-retry"})}`;return`${head}${skeletonRows(3,"Loading your team")}`}const rooms=CD.extras&&CD.extras.rooms||[];const{byRoom,needs}=groupRosterByRoom(rosterRows(),rooms);const suggestions=suggestedRooms(rosterPositions(),rooms);const roomCard=rm=>{const members=byRoom.get(rm.id)||[];return`
      <section class="card" style="padding:6px 16px;margin-bottom:10px">
        ${DELETING===rm.id?`
        <div class="lrow" style="cursor:default;gap:8px">
          <div class="lm"><div class="lt">Delete ${esc(rm.label)}?</div>
            <div class="ls">${members.length?`Its ${members.length} athlete${members.length===1?"":"s"} stay on the roster, unassigned. `:""}A standard scoped to this position keeps running until you clear it in the standards editor.</div></div>
          <button class="btn ghost sm" data-room-del-cancel="1" style="width:auto;padding:0 12px;height:34px;flex:none">Keep</button>
          <button class="btn danger xs" data-room-del-confirm="${esc(rm.id)}" style="width:auto;flex:none">Delete room</button>
        </div>`:RENAMING===rm.id?`
        <div class="lrow" style="cursor:default;gap:8px">
          <input class="ob-input room-rename-input" data-room-rename-input="${esc(rm.id)}" maxlength="40" value="${esc(RENAMING===rm.id&&RENAME_VAL!=null?RENAME_VAL:rm.label)}" style="flex:1" aria-label="Rename ${esc(rm.label)}" />
          <button class="btn sm" data-room-rename-save="${esc(rm.id)}" style="width:auto;padding:0 12px;height:34px">Save</button>
          <button class="btn ghost sm" data-room-rename-cancel="1" style="width:auto;padding:0 12px;height:34px">Cancel</button>
        </div>`:`
        <div class="lrow" style="cursor:default">
          <div class="lic" style="background:rgba(var(--blue-rgb),0.14);color:var(--blue-bright)">${icon("users",17)}</div>
          <div class="lm"><div class="lt">${esc(rm.label)}</div><div class="ls">${members.length?`${members.length} athlete${members.length===1?"":"s"}`:"No one assigned yet"}</div></div>
          <button class="btn ghost sm" data-room-rename="${esc(rm.id)}" aria-label="Rename room" style="width:34px;padding:0;height:30px;flex:none">${icon("edit",15)}</button>
          <button class="btn ghost micro" data-go="coach-plan-set/position/${esc(String(rm.label).trim().toUpperCase())}" style="width:auto">Standard</button>
          <button class="btn ghost danger micro" data-room-del="${esc(rm.id)}" style="width:auto;margin-left:6px">Delete</button>
        </div>`}
        <div class="lrow" data-owner-toggle="${esc(rm.id)}" style="cursor:pointer;padding-left:6px">
          <div class="xico sm gray" style="width:26px;height:26px">${icon("user",15)}</div>
          <div class="lm"><div class="lt" style="font-size:13.5px">Room owner</div><div class="ls">${rm.staff_owner_id?staffName(rm.staff_owner_id)?esc(staffName(rm.staff_owner_id)):"Assigned":"Unassigned \xB7 tap to set"}</div></div>
          ${icon("chevron",16,'style="color:var(--text-3)"')}
        </div>
        ${OPEN_OWNER===rm.id?`<div class="chip-row" role="radiogroup" aria-label="Room owner" style="margin:2px 0 8px 6px">
          ${(STAFF||[]).map(s=>`<span class="chip ${s.staff_id===rm.staff_owner_id?"on":""}" role="radio" aria-checked="${s.staff_id===rm.staff_owner_id?"true":"false"}" tabindex="0" data-set-owner="${esc(rm.id)}|${esc(s.staff_id)}">${esc(s.name)}</span>`).join("")||'<span class="ls">No staff yet. Invite staff first.</span>'}
          ${rm.staff_owner_id?`<span class="chip" role="button" tabindex="0" data-set-owner="${esc(rm.id)}|">Clear</span>`:""}
        </div>`:""}
        ${members.map(m=>`
        <div class="lrow" style="cursor:default;padding-left:6px">
          <div class="xico sm gray" style="width:26px;height:26px;border-radius:50%"${m.athleteId?` data-avatar-uid="${esc(m.athleteId)}"`:""}><span data-avatar-fallback>${esc(initialsOf(m.name,"A",1))}</span></div>
          <div class="lm"><div class="lt" style="font-size:14px">${esc(m.name)}</div><div class="ls">${m.position?`${esc(m.position)} \xB7 `:""}They stay on the roster, just not in this room.</div></div>
          <button class="btn ghost sm" data-room-unassign="${esc(m.athleteId)}" style="width:auto;padding:0 10px;height:28px;font-size:var(--t-xs)">Unassign</button>
        </div>`).join("")}
      </section>`};const needsCard=needs.length&&rooms.length?`
      <h2 class="eyebrow" style="color:var(--amber-bright)">Needs assignment \xB7 ${needs.length}</h2>
      <section class="card" style="padding:6px 16px;background:var(--amber-surface);border-color:var(--amber-border)">
        ${needs.map(m=>`
        <div class="lrow" style="cursor:default;display:block;padding:10px 4px">
          <div style="display:flex;align-items:center;gap:10px;margin-bottom:6px">
            <div class="xico sm gray" style="width:26px;height:26px;border-radius:50%"${m.athleteId?` data-avatar-uid="${esc(m.athleteId)}"`:""}><span data-avatar-fallback>${esc(initialsOf(m.name,"A",1))}</span></div>
            <div class="lm"><div class="lt" style="font-size:14px">${esc(m.name)}</div>${m.position?`<div class="ls">${esc(m.position)}</div>`:""}</div>
          </div>
          <div class="chip-row" style="margin:0">${rooms.map(rm=>`<span class="chip" role="button" tabindex="0" aria-label="Assign ${esc(m.name)} to ${esc(rm.label)}" data-assign="${esc(m.athleteId)}|${esc(rm.id)}">${esc(rm.label)}</span>`).join("")}</div>
        </div>`).join("")}
      </section>`:"";const roomsFailed=!!(CD.extras&&CD.extras.failed)&&!rooms.length;const roomList=rooms.length?rooms.map(roomCard).join(""):roomsFailed?errorState({title:"Couldn't load your rooms",body:"Any rooms you already built are safe. Reconnect and they list right here.",retryId:"rooms-retry"}):emptyState({icon:"users",title:"No rooms yet",body:"Add one per position group below. Athletes drop into their room as they join.",compact:true});const suggestChips=suggestions.length?`
      <h2 class="eyebrow">Suggested from your roster \xB7 tap to add</h2>
      <div class="chip-row" id="room-suggest">
        ${suggestions.map(s=>`<span class="chip" role="button" tabindex="0" aria-label="Add a ${esc(s.label)} room" data-room-add="${esc(s.label)}">${icon("plus",12)} ${esc(s.label)}</span>`).join("")}
      </div>`:"";return`
    ${backHead("Rooms","Position units. Build them before athletes join; assign anyone below.","coach-profile")}
    ${roomList}
    ${needsCard}
    ${suggestChips}

    <h2 class="eyebrow" id="rooms-add-l">Add a room</h2>
    <div style="display:flex;gap:8px;align-items:center">
      <input id="room-name" class="ob-input" aria-labelledby="rooms-add-l" maxlength="40" placeholder="e.g. Defensive Backs" value="${esc(ADD_VAL)}" style="flex:1" ${BUSY?"disabled":""} />
      <button class="btn sm" id="room-add" style="width:auto;padding:0 16px" ${BUSY?"disabled":""}>${BUSY?"Adding\u2026":"Add"}</button>
    </div>
    <div id="rooms-status" style="font-size:var(--t-xs);font-weight:700;color:var(--red);min-height:16px;margin-top:6px">${esc(ERR)}</div>

    ${""}
    <div class="co-note">A room is a permanent position unit that can carry its own standard. A roster group is a quick filter.</div>
    <div style="height:10px"></div>
    `},mount(root){if(CD.roster===null)loadCoachRoster();if(STAFF===null&&teamId()){STAFF=[];roles.fetchTeamStaff(teamId()).then(s=>{STAFF=s||[];window.__render()})}const roomsRetry=root.querySelector("#rooms-retry");if(roomsRetry)roomsRetry.addEventListener("click",()=>{roomsRetry.disabled=true;loadCoachRoster(true).then(()=>window.__render())});root.querySelectorAll("[data-owner-toggle]").forEach(el=>el.addEventListener("click",()=>{const id=el.getAttribute("data-owner-toggle");OPEN_OWNER=OPEN_OWNER===id?null:id;window.__render()}));root.querySelectorAll("[data-set-owner]").forEach(el=>el.addEventListener("click",()=>{const[roomId,staffId]=el.getAttribute("data-set-owner").split("|");setOwner(roomId,staffId||null)}));const input=root.querySelector("#room-name");const add=root.querySelector("#room-add");const submit=()=>{const v=(input&&input.value||"").trim();if(v)createRoom(v)};if(add)add.addEventListener("click",submit);if(input)input.addEventListener("keydown",e=>{if(e.key==="Enter"&&!e.isComposing)submit()});root.querySelectorAll("[data-room-add]").forEach(el=>el.addEventListener("click",()=>createRoom(el.getAttribute("data-room-add"))));root.querySelectorAll("[data-room-del]").forEach(el=>el.addEventListener("click",()=>{DELETING=el.getAttribute("data-room-del");RENAMING=null;OPEN_OWNER=null;window.__render()}));root.querySelectorAll("[data-room-del-cancel]").forEach(el=>el.addEventListener("click",()=>{DELETING=null;window.__render()}));root.querySelectorAll("[data-room-del-confirm]").forEach(el=>el.addEventListener("click",()=>deleteRoom(el.getAttribute("data-room-del-confirm"))));root.querySelectorAll("[data-room-rename]").forEach(el=>el.addEventListener("click",()=>{RENAMING=el.getAttribute("data-room-rename");RENAME_VAL=null;OPEN_OWNER=null;window.__render()}));root.querySelectorAll("[data-room-rename-cancel]").forEach(el=>el.addEventListener("click",()=>{RENAMING=null;window.__render()}));const submitRename=roomId=>{const room=(CD.extras&&CD.extras.rooms||[]).find(r=>r.id===roomId);const input2=root.querySelector(`[data-room-rename-input="${roomId}"]`);if(room&&input2)renameRoom(room,input2.value)};root.querySelectorAll("[data-room-rename-save]").forEach(el=>el.addEventListener("click",()=>submitRename(el.getAttribute("data-room-rename-save"))));root.querySelectorAll("[data-room-rename-input]").forEach(el=>el.addEventListener("keydown",e=>{if(e.key==="Enter"&&!e.isComposing)submitRename(el.getAttribute("data-room-rename-input"));else if(e.key==="Escape"&&!e.isComposing){RENAMING=null;window.__render()}}));root.querySelectorAll("[data-room-unassign]").forEach(el=>el.addEventListener("click",()=>assign(el.getAttribute("data-room-unassign"),null)));root.querySelectorAll("[data-assign]").forEach(el=>el.addEventListener("click",()=>{const[athleteId,roomId]=el.getAttribute("data-assign").split("|");assign(athleteId,roomId)}))}};
