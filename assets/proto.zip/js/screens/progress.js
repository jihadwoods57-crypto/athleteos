import{S,RT}from"../state.js";import{icon}from"../icons.js";import{esc,segBar}from"../components.js";import{weekBars}from"../week-bars.js";import{tierFor}from"../score-band.js";import{maybeShowTip}from"../tour.js";import{cutoverIndex}from"../score-cutover.js";import{ROLLCALL_OFF}from"../commitments.js";import{DAY}from"../day.js";const tierInk=v=>`tier-ink ${tierFor(v).cls}`;function baseline(P){const dots=segBar(P.unlockHave,P.unlockNeed,`${P.unlockHave} of ${P.unlockNeed} days logged toward your first trend`,"flex:1");const scoredToday=!RT.day0&&!S.notYetScored;return`
  <section class="card pad">
    <h2 class="eyebrow pg-base-h">Progress starts today</h2>
    <div class="bigstat score"><span class="n ${scoredToday?tierInk(S.score):"tier-ink none"}">${scoredToday?S.score:"\u2013"}</span><span class="d">${scoredToday?"Today's score":"Not scored yet"}</span></div>
    <div class="unlock-row">
      ${dots}
      <span class="unlock-k">${P.unlockHave} of ${P.unlockNeed} days</span>
    </div>
    <div class="base-stats">
      <div class="stat"><div class="v">${S.streak.days} day${S.streak.days===1?"":"s"}</div><div class="k">Current streak</div></div>
      <div class="stat"><div class="v${P.daysLogged?` ${tierInk(P.bestScore)}`:""}">${P.daysLogged?P.bestScore:"\u2013"}</div><div class="k">Best score</div></div>
      <div class="stat"><div class="v">${P.daysLogged}</div><div class="k">Days logged</div></div>
    </div>
    ${RT.day0?`
    <div class="pg-base-act">
      <div class="pg-sub">Today counts the moment you log. Your first meal photo starts the record.</div>
      <button class="btn primary sm pg-wbtn" data-go="camera">${icon("camera",16)} Log a meal</button>
    </div>`:`
    <div class="pg-sub">Early baseline. These sharpen as days accumulate.</div>`}
  </section>`}function weightCard(){const W=S.weight;return`
  <section class="card pad">
    ${W.current!=null?`
    <div class="pg-wrow">
      <!-- weight direction is goal-dependent (a gain can be good or bad depending on the athlete's
           target): the honest signal is the S.weight.pace pill, never color this by sign -->
      ${""}
      <div class="bigstat md"><span class="n">${W.current}</span><span class="u">lb</span>${W.deltaMonth?`<span class="d">${W.deltaMonth}</span>`:""}</div>
      ${W.pace?`<span class="status-pill ${W.pace==="On pace"?"g":"a"}">${W.pace}</span>`:""}
    </div>
    <div class="pg-sub">${W.start!=null?`Started ${W.start} lb \xB7 `:""}${W.target!=null?`goal ${W.target} lb \xB7 `:""}never affects your daily score</div>
    <button class="btn ghost sm pg-wbtn" data-go="weight">${icon("scale",16)} Log weight</button>`:`
    <div class="pg-wempty">Start your weight trend</div>
    <div class="pg-sub">Weight tracks long-term progress and does not affect your daily score.</div>
    <button class="btn primary sm pg-wbtn" data-go="weight">${icon("scale",16)} Log weight</button>`}
  </section>`}function bodySection(){return`
  <h2 class="eyebrow">Body</h2>
  ${weightCard()}`}function recordsSection(){const row=(go,ic,title,sub,extra)=>`
    <div class="lrow" data-go="${go}">
      <div class="lic">${icon(ic,17)}</div>
      <div class="lm"><div class="lt">${title}${extra||""}</div><div class="ls">${sub}</div></div>
      ${""}
      ${icon("chevron",17)}
    </div>`;return`
  <h2 class="eyebrow">Records</h2>
  <section class="card pg-rows">
    ${""}
    ${ROLLCALL_OFF?"":row("accountability","sun","Roll call record","Roll calls and sessions")}
    ${S.coach.hasCoach&&S.coach.kind==="coach"?row("squad","users","Squad","Score opt-in only. Your team sees roll call answers"):""}
    ${""}
    ${""}
    ${row("history","clock","Activity history","The proof trail, day by day")}
    ${row("monthly-report","clipboard","Monthly report","Your month in review",` <span class="status-pill b">Premium</span>`)}
  </section>`}function styleBandRow(){const bands=S.styleBands;if(!bands||bands.length<2)return"";return`
  <div class="ps-band" aria-label="Plan style history">
    ${bands.map(b=>`<span class="seg s-${esc(b.style)}"><i></i>${esc(b.name)} \xB7 ${b.days}d \xB7 avg ${b.avg}</span>`).join("")}
  </div>
  ${""}
  <div class="pg-note">Each style measures your day differently. Compare within a band, not across.</div>`}function trendsEmptyLine(){const scored=(DAY.scoreHistory||[]).filter(r=>r&&r.score!=null).length;if(scored>=3)return"Your daily scores are in, but the Nutrition and Recovery split is not available for those days, so the trend by category is not shown.";const left=3-scored;return`Category trends appear after your fourth scored day. ${left===1?"One more day to go.":`${left} more days to go.`}`}export default{tab:"progress",render(){const P=S.progress;if(P.daysLogged<P.unlockNeed){return`
      <h1 class="screen-title">Progress</h1>
      <div style="height:10px"></div>
      ${baseline(P)}
      ${bodySection()}
      ${recordsSection()}
      <div style="height:10px"></div>`}const st=S.streak;let streakRow="";if(st.days>=2&&!st.todayCounted){const strong=st.graceUsedRecently;streakRow=`<div class="streak-ribbon ${strong?"strong":"mild"}" data-go="streak" style="margin-top:14px">
        <div class="sr-ic">${icon(strong?"flame":"shield",18)}</div>
        <div class="sr-body"><div class="sr-t">${st.days}-day streak${strong?" \xB7 at risk":""}</div>
        <div class="sr-s">${strong?"This week\u2019s grace is used. Reach 80 before the day closes to continue your streak.":"Today is still live. Reach 80 before the day closes to continue your streak."}</div></div>
        ${icon("chevron",16,'style="color:var(--text-3);flex:none"')}
      </div>`}const wd=parseFloat(P.weekDelta);const ddir=wd>0?" up":wd<0?" down":"";const trends=S.categoryTrends;const insight=S.progressInsight;const cutIdx=cutoverIndex(P.weekDates);const CUTOVER_LABEL="Scoring changed. Days before this were scored a different way";const scoreTrendSection=`
    <section class="card pad" data-tour="trend">
      <div class="bigstat score"><span class="n ${tierInk(P.weekAvg)}">${P.weekAvg}</span>${P.weekDelta?`<span class="d${ddir}">${P.weekDelta} vs prior week</span>`:""}</div>
      ${""}
      <div class="pg-sub">${P.onDays} days on standard (\u226580)</div>
      ${""}
      ${weekBars({scores:P.weekScores,labels:P.weekDayLabels,cutIdx,cutLabel:CUTOVER_LABEL})}
      ${cutIdx!==-1?`<div class="pg-note">${esc(CUTOVER_LABEL)}</div>`:""}
      ${styleBandRow()}
      <div class="sd-cta pg-share-row">
        <button class="btn ghost sm" id="pg-share" aria-label="Share today's score as an image">${icon("share",16)} Share today</button>
      </div>
    </section>
    ${streakRow}

    ${""}
    <div class="pg-stats">
      <div class="stat center tap" data-go="streak" role="button" tabindex="0" aria-label="Current streak, ${st.days} days. Open streak details"><div class="v">${st.days}d</div><div class="k">Streak</div></div>
      <div class="stat center"><div class="v">${P.bestStreak}d</div><div class="k">Best streak</div></div>
      <div class="stat center${P.monthConsistency==null?" dim":""}"><div class="v">${P.monthConsistency!=null?`${P.monthConsistency}%`:"\u2013"}</div><div class="k">Consistency</div></div>
    </div>

    ${""}
    ${trends||insight?`
    <h2 class="eyebrow">What's moving</h2>
    <section class="card pad">
      ${trends?`
      <div class="cat-trends">
        ${trends.map(t=>`
        <div class="cat-trend">
          <span class="ct-k">${esc(t.key)}</span>
          <div class="track"><div class="fillb ${t.accent}" style="width:${t.now}%"></div></div>
          <span class="ct-v">${t.now}%</span>
          <span class="ct-d ${t.delta>0?"up":t.delta<0?"down":""}">${t.delta>0?`\u2191${t.delta}`:t.delta<0?`\u2193${Math.abs(t.delta)}`:"\u2013"}</span>
        </div>`).join("")}
      </div>`:""}
      ${insight?`
      <div class="insight">
        <div class="req-icon g s38">${icon("target",18)}</div>
        <p>${esc(insight)}</p>
      </div>`:""}
    </section>`:`
    <h2 class="eyebrow">What's moving</h2>
    <div class="pl-standard pg-flush">${esc(trendsEmptyLine())}</div>`}`;const isClient=S.audience==="client";return`
    <h1 class="screen-title">Progress</h1>
    ${isClient?bodySection()+scoreTrendSection:scoreTrendSection+bodySection()}
    ${recordsSection()}
    <div class="pg-tail"></div>
    `},mount(root){maybeShowTip("tip:progress",{anchor:"trend",title:"Your last seven days",body:"One bar per day against the 80 standard. The pattern matters more than any single day."});const btn=root.querySelector("#pg-share");if(!btn)return;btn.addEventListener("click",async()=>{btn.disabled=true;try{const{shareDay}=await import("../share-card.js");const st=S.streak;await shareDay({score:S.score,streak:st&&st.days?st.days:0,met:S.metCount,total:S.reqTotal})}catch{}finally{btn.disabled=false}})}};
