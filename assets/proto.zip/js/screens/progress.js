import{S,RT}from"../state.js";import{icon}from"../icons.js";import{esc,segBar,emptyState}from"../components.js";import{scoreBand}from"../score-band.js";import{maybeShowTip}from"../tour.js";import{cutoverIndex}from"../score-cutover.js";import{ROLLCALL_OFF}from"../commitments.js";function baseline(P){const dots=segBar(P.unlockHave,P.unlockNeed,`${P.unlockHave} of ${P.unlockNeed} days logged toward your first trend`,"flex:1");return`
  <section class="card pad">
    <h2 class="eyebrow" style="margin:0 0 10px">Progress starts today</h2>
    <div class="bigstat"><span class="n">${S.score}</span><span class="d">Today's score</span></div>
    <div class="unlock-row">
      ${dots}
      <span class="unlock-k">${P.unlockHave} of ${P.unlockNeed} days</span>
    </div>
    <div class="base-stats">
      <div class="stat"><div class="v">${S.streak.days} day${S.streak.days===1?"":"s"}</div><div class="k">Current streak</div></div>
      <div class="stat"><div class="v">${P.bestScore}</div><div class="k">Best score</div></div>
      <div class="stat"><div class="v">${P.daysLogged}</div><div class="k">Days logged</div></div>
    </div>
    <div style="font-size:var(--t-xs);font-weight:600;color:var(--text-3);margin-top:8px">Early baseline. These sharpen as days accumulate.</div>
  </section>`}function weightCard(){const W=S.weight;return`
  <section class="card pad">
    ${W.current!=null?`
    <div style="display:flex;justify-content:space-between;align-items:baseline">
      <!-- weight direction is goal-dependent (a gain can be good or bad depending on the athlete's
           target): the honest signal is the S.weight.pace pill, never color this by sign -->
      <div class="bigstat"><span class="n" style="font-size:var(--t-3xl)">${W.current}</span>${W.deltaMonth?`<span class="d">${W.deltaMonth}</span>`:""}</div>
      ${W.pace?`<span class="status-pill ${W.pace==="On pace"?"g":"a"}">${W.pace}</span>`:""}
    </div>
    <div style="font-size:var(--t-sm);font-weight:600;color:var(--text-2);margin-top:2px">${W.start!=null?`Started ${W.start} lb \xB7 `:""}${W.target!=null?`goal ${W.target} lb \xB7 `:""}never affects your daily score</div>
    <button class="btn ghost sm" data-go="weight" style="margin-top:12px;width:auto;padding:0 18px">${icon("scale",16)} Log weight</button>`:`
    <div style="font-size:var(--t-md);font-weight:800">Start your weight trend</div>
    <div style="font-size:var(--t-sm);font-weight:600;color:var(--text-2);margin-top:4px;line-height:1.45">Weight tracks long-term progress and does not affect your daily score.</div>
    <button class="btn primary sm" data-go="weight" style="margin-top:12px;width:auto;padding:0 20px">${icon("scale",16)} Log weight</button>`}
  </section>`}function bodySection(){return`
  <h2 class="eyebrow">Body</h2>
  ${weightCard()}`}function trainingCard(){return`
  <h2 class="eyebrow">Training</h2>
  <section class="card" style="padding:6px 16px">
    <div class="lrow" data-go="training-history">
      <div class="lic">${icon("bolt",17)}</div>
      <div class="lm"><div class="lt">Training log</div><div class="ls">Your sessions &amp; notes \xB7 tracked, not scored</div></div>
      ${icon("chevron",17,'style="color:var(--text-3)"')}
    </div>
    ${""}
    ${ROLLCALL_OFF?"":`
    <div class="lrow" data-go="accountability">
      <div class="lic">${icon("sun",17)}</div>
      <div class="lm"><div class="lt">Roll call record</div><div class="ls">Roll calls &amp; sessions \xB7 a separate record from your score</div></div>
      ${icon("chevron",17,'style="color:var(--text-3)"')}
    </div>`}
  </section>`}function styleBandRow(){const bands=S.styleBands;if(!bands||bands.length<2)return"";return`
  <div class="ps-band" aria-label="Plan style history">
    ${bands.map(b=>`<span class="seg s-${esc(b.style)}"><i></i>${esc(b.name)} \xB7 ${b.days}d \xB7 avg ${b.avg}</span>`).join("")}
  </div>
  <div style="font-size:var(--t-xs);font-weight:600;color:var(--text-3);margin-top:6px;line-height:1.45">Your plan style changed during this stretch. Each style measures your day differently, so compare within a band, not across.</div>`}export default{tab:"progress",render(){const P=S.progress;if(P.daysLogged<P.unlockNeed){return`
      <h1 class="screen-title">Progress</h1>
      <div style="height:10px"></div>
      ${baseline(P)}
      ${RT.day0?`
      ${emptyState({icon:"camera",title:"Today counts the moment you log",body:"Your first meal photo starts the record.",action:{go:"camera",label:"Log a meal"},compact:true})}`:""}
      ${bodySection()}
      ${trainingCard()}
      <div style="height:10px"></div>`}const st=S.streak;let streakRow="";if(st.days>=2&&!st.todayCounted){const strong=st.graceUsedRecently;streakRow=`<div class="streak-ribbon ${strong?"strong":"mild"}" data-go="streak" style="margin-top:14px">
        <div class="sr-ic">${icon(strong?"flame":"shield",18)}</div>
        <div class="sr-body"><div class="sr-t">${st.days}-day streak${strong?" \xB7 at risk":""}</div>
        <div class="sr-s">${strong?"This week\u2019s grace is used. Reach 80 before the day closes to continue your streak.":"Today is still live. Reach 80 before the day closes to continue your streak."}</div></div>
        ${icon("chevron",16,'style="color:var(--text-3);flex:none"')}
      </div>`}const wd=parseFloat(P.weekDelta);const ddir=wd>0?" up":wd<0?" down":"";const trends=S.categoryTrends;const insight=S.progressInsight;const cutIdx=cutoverIndex(P.weekDates);const CUTOVER_LABEL="Scoring changed. Days before this were scored a different way";const scoreTrendSection=`
    <h2 class="eyebrow" data-tour="trend">Score Trend</h2>
    <section class="card pad">
      <div class="bigstat"><span class="n">${P.weekAvg}</span>${P.weekDelta?`<span class="d${ddir}">${P.weekDelta} vs prior week</span>`:""}</div>
      <div style="font-size:var(--t-sm);font-weight:600;color:var(--text-2);margin-top:2px">${P.onDays} days on standard (\u226580) \xB7 best streak ${P.bestStreak}d</div>
      <div class="weekbars" role="img" aria-label="Last ${P.weekScores.length} days: ${P.weekScores.map((v,i)=>`${P.weekDayLabels[i]||""} ${v}`).join(", ")}. The standard is 80.${cutIdx!==-1?` ${esc(CUTOVER_LABEL)}.`:""}">
        ${P.weekScores.map((v,i)=>`
          ${i===cutIdx?`<div class="wb-cutover" aria-hidden="true" title="${esc(CUTOVER_LABEL)}" style="align-self:stretch;width:2px;border-radius:1px;background:var(--text-3);opacity:.4"></div>`:""}
          <div class="wb b-${scoreBand(v)||"off"}">
            <div class="track"><div class="bar" style="height:${Math.max(0,Math.min(100,v))}%"></div></div>
            <span class="d">${P.weekDayLabels[i]||""}</span>
          </div>`).join("")}
      </div>
      ${cutIdx!==-1?`<div style="font-size:var(--t-xs);font-weight:600;color:var(--text-3);margin-top:6px;line-height:1.4">${esc(CUTOVER_LABEL)}</div>`:""}
      ${styleBandRow()}
      <div class="sd-cta" style="margin-top:12px">
        <button class="btn ghost sm" id="pg-share" style="width:auto;padding:0 18px" aria-label="Share today's score as an image">${icon("share",16)} Share today</button>
      </div>
    </section>
    ${streakRow}

    ${""}
    <div class="pg-stats">
      <div class="stat center tap" data-go="streak" role="button" tabindex="0" aria-label="Current streak, ${st.days} days. Open streak details"><div class="v">${st.days}d</div><div class="k">Streak</div></div>
      <div class="stat center"><div class="v">${P.bestStreak}d</div><div class="k">Best streak</div></div>
      <div class="stat center${P.monthConsistency==null?" dim":""}"><div class="v">${P.monthConsistency!=null?`${P.monthConsistency}%`:"\u2013"}</div><div class="k">Consistency</div></div>
    </div>

    <h2 class="eyebrow">Category trends</h2>
    ${trends?`
    <section class="card pad" style="padding-top:8px;padding-bottom:8px">
      ${trends.map(t=>`
        <div class="cat-trend">
          <span class="ct-k">${esc(t.key)}</span>
          <div class="track"><div class="fillb ${t.accent}" style="width:${t.now}%"></div></div>
          <span class="ct-v">${t.now}%</span>
          <span class="ct-d ${t.delta>0?"up":t.delta<0?"down":""}">${t.delta>0?`\u2191 ${t.delta}`:t.delta<0?`\u2193 ${Math.abs(t.delta)}`:"\u2013"}</span>
        </div>`).join("")}
    </section>`:`
    <div class="pl-standard" style="margin-top:0">Category trends appear after your fourth scored day.</div>`}`;const insightSection=insight?`
    <h2 class="eyebrow">Your biggest opportunity</h2>
    <div class="insight">
      <div class="req-icon g s38">${icon("target",18)}</div>
      <p>${esc(insight)}</p>
    </div>`:"";const isClient=S.audience==="client";return`
    <h1 class="screen-title">Progress</h1>
    ${isClient?bodySection()+scoreTrendSection+insightSection:scoreTrendSection+insightSection+bodySection()}
    ${trainingCard()}

    <!-- Squad and Monthly report used to follow trainingCard() with no eyebrow of their own, so
         both sat visually inside the "TRAINING" group. Neither is training. Own heading. -->
    <h2 class="eyebrow">More</h2>
    ${S.coach.hasCoach&&S.coach.kind==="coach"?`
    <div class="sidebox" data-go="squad" style="cursor:pointer">
      <div class="req-icon b s38">${icon("users",17)}</div>
      <div><div class="tt">Squad</div><div class="ts">Your team's board \xB7 opt-in, score number only</div></div>
      ${icon("chevron",17,'style="color:var(--text-3)"')}
    </div>`:""}
    <div class="sidebox" data-go="history" style="cursor:pointer">
      <div class="req-icon b s38">${icon("clipboard",17)}</div>
      <div><div class="tt">Score history</div><div class="ts">The proof trail, day by day</div></div>
      ${icon("chevron",17,'style="color:var(--text-3)"')}
    </div>
    <div class="sidebox" data-go="monthly-report" style="cursor:pointer">
      <div class="req-icon b s38">${icon("clipboard",17)}</div>
      <div><div class="tt" style="display:flex;align-items:center;gap:7px">Monthly report <span class="status-pill b">Premium</span></div><div class="ts">Your month in review</div></div>
    </div>
    <div style="height:10px"></div>
    `},mount(root){maybeShowTip("tip:progress",{anchor:"trend",title:"Your last seven days",body:"One bar per day against the 80 standard. The pattern matters more than any single day."});const btn=root.querySelector("#pg-share");if(!btn)return;btn.addEventListener("click",async()=>{btn.disabled=true;try{const{shareDay}=await import("../share-card.js");const st=S.streak;await shareDay({score:S.score,streak:st&&st.days?st.days:0,met:S.metCount,total:S.reqTotal})}catch{}finally{btn.disabled=false}})}};
