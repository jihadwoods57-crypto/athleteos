import{S,RT,act}from"../state.js";import{icon}from"../icons.js";import{avatarControlHtml,wireAvatarUpload}from"../avatar-upload.js";import{backHead,titleHead,logoMark,esc,copyText,sayStatus,emptyState}from"../components.js";import{initialsOf}from"../initials.js";import{accountBody,wireAccount}from"./ob-account.js";import{standardForGoal,reqHeadTint,showConfirmPending}from"../ob-helpers.js";import{commitButton,wireCommit}from"../ob-commit.js";import{track,EVENTS}from"../analytics.js";import{encodeQR,addQuietZone,qrSvg}from"../qr.js";import{setMyTeamCode,regenerateMyTeamCode,setMyPracticeCode,regenerateMyPracticeCode,renamePractice,fetchTeamStaff,createStaffInvite,revokeStaff,setStaffScope}from"../roles.js";import{roleLabel,scopeText,normalizeRole,RESPONSIBILITIES}from"../staff-access.js";import{seedTemplates,templateLabel}from"../templates.js";import{weightsFor,styleForStructureAnswer,DEFAULT_STYLE}from"../plan-style.js";let STAFF=null;let staffLoadingFor=null;async function loadStaff(teamId,force){if(!teamId||staffLoadingFor===teamId)return;if(STAFF&&STAFF.teamId===teamId&&!force)return;staffLoadingFor=teamId;try{const rows=await fetchTeamStaff(teamId);STAFF=rows===null?{teamId,rows:[],failed:true}:{teamId,rows,failed:false}}catch{STAFF={teamId,rows:[],failed:true}}finally{staffLoadingFor=null}if(location.hash.startsWith("#coach-profile"))window.__render()}function inviteLink(code){const c=(code||"").trim().toUpperCase();return c?`https://onstandard.app/join?code=${c}`:""}function inviteShareText(code,practiceName){const c=(code||"").trim().toUpperCase();if(!c)return"";const name=practiceName&&practiceName.trim()||"my practice";return`Join ${name} on OnStandard. Use code ${c} or open ${inviteLink(c)}`}function progressOf(n,total){return`<div class="ob-prog" role="progressbar" aria-label="Step ${n} of ${total}" aria-valuenow="${n}" aria-valuemax="${total}">${Array.from({length:total},(_,i)=>`<i class="${i+1<=n?"on":""}"></i>`).join("")}</div>`}function frame(n,total,title,sub,body,cta,next,opts={}){return`
  <div class="ob">
    <div class="ob-nav"><div class="ob-back" data-go="${opts.back||"role"}" aria-label="Back">${icon("chevron",18)}</div>${progressOf(n,total)}</div>
    ${""}
    <h1 class="ob-title">${esc(title)}</h1>
    <div class="ob-sub">${esc(sub)}</div>
    <div class="ob-body">${body}</div>
    <div class="ob-foot">
      <button class="btn ${opts.green?"green":"primary"}" ${opts.id?`id="${opts.id}"`:""} ${opts.disabled?"disabled":""} data-go="${next}">${cta}</button>
      ${opts.skip?`<div class="ob-textlink" style="padding-top:14px" data-go="${opts.skip}">Skip for now</div>`:""}
    </div>
  </div>`}function pillOf(el){return el.classList.contains("std-switch")?el:el.querySelector(".std-switch")||el}function switchOn(el){return!!el&&pillOf(el).classList.contains("on")}function paintSwitch(el,on){if(!el)return;pillOf(el).classList.toggle("on",!!on);el.setAttribute("aria-checked",on?"true":"false")}function flipSwitch(el){const on=!switchOn(el);paintSwitch(el,on);return on}async function toggles(root){const{wireToggles}=await import("./settings.js");root.querySelectorAll(".chip-row:not([data-multi]), .choice-grid, .seg").forEach(g=>g.setAttribute("data-toggle-group",""));wireToggles(root);root.querySelectorAll("[data-multi] .chip").forEach(ch=>ch.addEventListener("click",()=>ch.classList.toggle("on")))}export const role={hideTabs:true,render(){const card=(go,ic,tint,accent,t,s)=>`
      <div class="role-card" data-go="${go}" role="button" tabindex="0" aria-label="${esc(t)}: ${esc(s)}">
        <div class="role-ic" style="background:${tint};color:${accent}">${icon(ic,21)}</div>
        <div class="role-tt"><div class="role-t">${esc(t)}</div><div class="role-s">${esc(s)}</div></div>
        <div class="role-chev">${icon("chevron",18)}</div>
      </div>`;return`
    <div class="ob">
      <div style="width:56px;height:56px;margin:6px auto 18px">${logoMark(56,"role")}</div>
      <div class="ob-title" style="text-align:center">Choose your role</div>
      <div class="ob-sub" style="text-align:center">We'll personalize your account, permissions, and experience.</div>
      <div class="ob-body">
        <div class="role-list">
          ${card("onboarding/1","bolt","var(--green-surface)","var(--green-bright)","Athlete","Compete for a team and execute your coach\u2019s standard.")}
          ${card("client-ob/1","user","var(--blue-surface)","var(--blue-bright)","Client","Build consistency with a personal trainer or coach.")}
          ${card("coach-ob/1","users","var(--amber-surface)","var(--amber-bright)","Coach","Set the standard and see who consistently executes.")}
          ${card("trainer-ob/1","bars","var(--purple-surface)","var(--purple-bright)","Trainer","Manage clients, track consistency, and prove results.")}
        </div>
        <div style="height:14px"></div>
        <div class="sidebox">
          <div class="req-icon b s38">${icon("lock",17)}</div>
          <div><div class="tt">Joining as a parent or guardian?</div>
          <div class="ts">Open the invite your athlete or coach sent you. Parents connect from there, and only ever see scores and streaks, never photos or weight.</div></div>
        </div>
      </div>
      <div class="ob-foot">
        <div class="ob-textlink" role="button" tabindex="0" aria-label="Back" data-go="welcome">Back</div>
      </div>
    </div>`},mount(root){const ROLE_BY_GO={"onboarding/1":"athlete","client-ob/1":"client","coach-ob/1":"coach","trainer-ob/1":"trainer"};root.querySelectorAll(".role-card[data-go]").forEach(c=>c.addEventListener("click",()=>{const r=ROLE_BY_GO[c.getAttribute("data-go")];if(r)track(EVENTS.ONBOARDING_ROLE,{role:r})}))}};const coachSteps={1:()=>frame(1,7,"You, coach.","Your athletes see this name on every standard you set.",`
    <input id="co-first" class="ob-input" maxlength="40" placeholder="First name" aria-label="First name" autocomplete="given-name" autocapitalize="words" />
    <div style="height:12px"></div>
    <input id="co-last" class="ob-input" maxlength="40" placeholder="Last name" aria-label="Last name" autocomplete="family-name" autocapitalize="words" />
    <h2 class="eyebrow" style="margin:16px 2px 10px">What the room calls you</h2>
    <div class="chip-row" id="co-handle"></div>
    <input id="co-handle-custom" class="ob-input" maxlength="24" placeholder="Or type it, e.g. Coach B" aria-label="What the room calls you" style="margin-top:10px" />
    <div style="font-size:var(--t-sm);font-weight:600;color:var(--text-3);margin:8px 2px 0;line-height:1.4">This is the name athletes see everywhere: greetings, meal threads, your standard.</div>`,"Next","coach-ob/2",{back:"role"}),2:()=>{const c=(RT.ob||{}).coach||{};return frame(2,7,"Your school.","Athletes find you by school. Same-name schools split by city.",c.schoolName?`
      <section class="card team-preview">
        <div class="tp-av">${esc(c.schoolName[0])}</div>
        <div style="flex:1"><div style="font-size:var(--t-md);font-weight:800">${esc(c.schoolName)}</div>
        <div style="font-size:var(--t-sm);font-weight:600;color:var(--text-2);margin-top:2px">${esc([c.city,c.state].filter(Boolean).join(", ")||"\u2014")}</div></div>
        <span class="status-pill g">Set</span>
      </section>
      <div style="height:12px"></div>
      <div style="text-align:center;font-size:var(--t-sm);font-weight:700;color:var(--text-3);cursor:pointer" id="co-school-clear">Change school</div>`:`
      <input id="co-q" class="ob-input" placeholder="Search your school" aria-label="Search your school" autocorrect="off" spellcheck="false" />
      <div id="co-out" style="margin-top:14px"></div>
      <div style="height:10px"></div>
      <div id="co-add" style="text-align:center;font-size:var(--t-base);font-weight:700;color:var(--amber-bright);cursor:pointer">My school isn't listed, add it</div>`,"Next","coach-ob/3",{back:"coach-ob/1"})},3:()=>{const c=(RT.ob||{}).coach||{};const mode=c.joinMode==="join"?"join":"create";const seg=`<div class="seg" style="width:100%;margin-bottom:18px" id="co-joinmode" aria-label="Create a team or join a staff">
      <button class="${mode==="create"?"on":""}" data-mode="create">Create a team</button>
      <button class="${mode==="join"?"on":""}" data-mode="join">Join a staff</button>
    </div>`;const createBody=`
    <input id="co-team" class="ob-input" maxlength="60" placeholder="Team name (e.g. Varsity Football)" aria-label="Team name" />
    <div style="height:16px"></div>
    <h2 class="eyebrow" style="margin:8px 2px 10px">Sport</h2>
    <div class="chip-row" id="co-sport">
      <span class="chip on">Football</span><span class="chip">Basketball</span><span class="chip">Baseball</span><span class="chip">Track</span><span class="chip">Other</span>
    </div>
    <div style="height:16px"></div>
    <h2 class="eyebrow" style="margin:8px 2px 10px">Level</h2>
    <div class="chip-row" id="co-level">
      <span class="chip">Youth</span><span class="chip on">High School</span><span class="chip">College</span><span class="chip">Pro</span>
    </div>
    <div style="height:16px"></div>
    ${""}
    <div class="lrow" id="co-disc" role="switch" tabindex="0" aria-checked="true" aria-label="Listed in school search" aria-describedby="co-disc-sub" style="padding:0 2px">
      <div class="lm"><div class="lt">Listed in school search</div><div class="ls" id="co-disc-sub">Athletes at your school can find this team. The code is still required to join.</div></div>
      <div class="std-switch on" aria-hidden="true"></div>
    </div>`;const joinBody=`
    <h2 class="eyebrow" style="margin:8px 2px 10px">Staff code</h2>
    ${""}
    <input id="co-staff-code" class="ob-input" maxlength="12" placeholder="Code from your head coach" aria-label="Staff code" autocapitalize="characters" autocorrect="off" spellcheck="false" style="text-align:center;letter-spacing:0.12em;text-transform:uppercase" />
    <div style="font-size:var(--t-sm);font-weight:600;color:var(--text-3);margin:8px 2px 0;line-height:1.45">Your head coach hands out staff codes. It lands you on their team's staff with the role and permissions they set. You won't create a new team.</div>`;return frame(3,7,mode==="join"?"Join a staff.":"Build the team.",mode==="join"?"Enter the code from your head coach.":"Athletes join it with one code. You can run more than one group.",`${seg}${mode==="join"?joinBody:createBody}`,"Next","coach-ob/4",{back:"coach-ob/2"})},4:()=>{const c=(RT.ob||{}).coach||{};const choice=c.responsibility||"team";const needRooms=choice==="side"||choice==="room";const RESP_ICON={org:"shield",team:"users",side:"bars",room:"target",individuals:"user"};return frame(4,7,"What\u2019s yours to run?","This sets how far your view reaches: your roster, priorities, and alerts follow it.",`
    <div class="choice-grid" id="co-resp">
      ${RESPONSIBILITIES.map(r=>`
      <div class="choice ${choice===r.key?"on":""}" data-val="${r.key}" style="cursor:pointer">
        <div class="cic" style="background:rgba(var(--amber-rgb),0.18);color:var(--amber-bright)">${icon(RESP_ICON[r.key]||"users",19)}</div>
        <div class="ct">${esc(r.title)}</div><div class="cs">${esc(r.sub)}</div>
      </div>`).join("")}
    </div>
    ${needRooms?`
    <h2 class="eyebrow" style="margin:16px 2px 8px">${choice==="room"?"Which room?":"Which rooms?"}</h2>
    <input id="co-rooms" class="ob-input" aria-label="Rooms you coach" placeholder="${choice==="room"?"e.g. LB":"e.g. OL, TE, QB"}" autocapitalize="characters" autocorrect="off" spellcheck="false" />
    <div style="font-size:var(--t-sm);font-weight:600;color:var(--text-3);margin:8px 2px 0;line-height:1.4">Use the position names your athletes pick: that\u2019s how the app knows who\u2019s in your room. Leave it blank and you keep the whole team.</div>`:choice==="individuals"?`
    <div style="height:14px"></div>
    <div class="sidebox">
      <div class="req-icon b s38">${icon("users",17)}</div>
      <div><div class="tt">You\u2019ll pick them after</div><div class="ts">A private \u201CMy athletes\u201D group is created for you. Add athletes to it from the Roster and your view follows it.</div></div>
    </div>`:""}`,"Next","coach-ob/5",{back:"coach-ob/3"})},5:()=>{const c=(RT.ob||{}).coach||{};if(c.joinMode==="join"){return frame(5,7,"The standard is set.","Your head coach owns the team standard. You\u2019ll see it (and everything your athletes log against it) the moment you\u2019re on staff.",`
      <div class="sidebox">
        <div class="req-icon g s38">${icon("check",17)}</div>
        <div><div class="tt">Nothing to configure here</div><div class="ts">Meals, windows, recovery, and check-ins are already defined for this team. If your role includes standards, you can fine-tune them later in Standards.</div></div>
      </div>`,"Next","coach-ob/6",{back:"coach-ob/4"})}const sel=c.standardTemplate||"default";const seeds=seedTemplates();const chosen=sel==="default"?null:seeds.find(s=>s.kind===sel);const KIND_ICON={meal:"utensils",lift:"bolt",recovery:"moon",weigh:"scale",checkin:"clipboard",custom:"clipboard"};const PROOF_LABEL={photo:"photo proof",form:"quick form",scale:"scale",counter:"count it",check:"check it off"};const dw=weightsFor(DEFAULT_STYLE,"athlete");const dpct=k=>Math.round(dw[k]*100);const rows=chosen?chosen.items.map(it=>[KIND_ICON[it.kind]||"clipboard",it.title,[it.freq&&it.freq.label||(it.freq&&it.freq.type==="daily"?"Daily":""),PROOF_LABEL[it.proof]||""].filter(Boolean).join(" \xB7 ")]):[["utensils","Three meals \xB7 photo proof",`Nutrition \xB7 ${dpct("nutrition")}% of score`],["moon","Recovery check-in \xB7 nightly",`Recovery \xB7 ${dpct("checkin")+dpct("recovery")}%`],["scale","Weight \xB7 Mon / Wed / Fri","Season trend \xB7 not scored"]];return frame(5,7,"Set the team standard.","Start from a proven template. Fine-tune meals, windows, and rooms anytime in Standards.",`
    <div class="chip-row" id="co-tpl">
      <span class="chip ${sel==="default"?"on":""}" data-tpl="default">Standard day</span>
      ${seeds.map(s=>`<span class="chip ${sel===s.kind?"on":""}" data-tpl="${s.kind}">${esc(templateLabel(s.kind))}</span>`).join("")}
    </div>
    <div style="height:12px"></div>
    <section class="card" style="padding:6px 16px" role="list">
      ${rows.map(([ic,t,s])=>{const[bg,fg]=reqHeadTint(ic);return`
        <div class="lrow" role="listitem" style="cursor:default">
          <div class="lic" style="background:${bg};color:${fg}">${icon(ic,17)}</div>
          <div class="lm"><div class="lt">${esc(t)}</div><div class="ls">${esc(s)}</div></div>
        </div>`}).join("")}
    </section>
    <div style="font-size:var(--t-sm);font-weight:600;color:var(--text-3);margin-top:10px">Start from a template, then make the standard yours: meals, windows, and rooms are all editable in Standards.</div>`,"Next","coach-ob/6",{back:"coach-ob/4"})},6:()=>{const c=(RT.ob||{}).coach||{};const n=c.notif||{};const switchRow=(id,title,sub,on)=>`
      <div class="lrow" id="${id}" role="switch" tabindex="0" aria-checked="${on?"true":"false"}" aria-label="${title}" aria-describedby="${id}-sub">
        <div class="lm"><div class="lt">${title}</div><div class="ls" id="${id}-sub">${sub}</div></div>
        <div class="std-switch ${on?"on":""}" aria-hidden="true"></div>
      </div>`;return frame(6,7,"How you hear from us.","Planned on your phone from your latest roster view, never noise for its own sake.",`
    <section class="card" style="padding:6px 16px">
      ${switchRow("co-nf-brief","Morning briefing","7:30 AM \xB7 who needs you today",n.briefing!==false)}
      ${switchRow("co-nf-recap","Evening recap","8:30 PM \xB7 how the day closed",n.recap!==false)}
      ${switchRow("co-nf-crit","Critical alerts immediately","Overdue athletes, gone-quiet streaks",n.immediateCritical!==false)}
      ${switchRow("co-nf-hourly","Hourly summaries","Off by default: the briefing catches it",n.hourly===true)}
    </section>
    <div style="height:10px"></div>
    <div class="sidebox">
      <div class="req-icon b s38">${icon("bell",17)}</div>
      <div><div class="tt">Quiet hours are on</div><div class="ts">Nothing between 10 PM and 7 AM unless it\u2019s critical and you\u2019ve allowed that. Times and quiet hours are tunable in Profile \u2192 Notifications.</div></div>
    </div>`,"Next","coach-ob/7",{back:"coach-ob/5"})},7:()=>`
  <div class="ob">
    <div class="ob-nav"><div class="ob-back" data-go="coach-ob/6">${icon("chevron",18)}</div>${progressOf(7,7)}</div>
    <div class="ob-title">Create your account.</div>
    <div class="ob-sub">Your team, code, and roster live on it.</div>
    <div style="height:8px"></div>
    ${accountBody({terms:"cob"})}
    <div class="ob-foot" style="margin-top:auto"><button id="su-go" class="btn primary" disabled>Create account &amp; Get my code</button></div>
  </div>`,8:()=>{const joined=(RT.ob||{}).joinedStaff;if(joined){return`
  <div class="ob">
    <div class="standard-set">
      <div class="halo"><div class="core" style="background:linear-gradient(155deg,var(--amber),var(--amber-deep))">${icon("users",34)}</div></div>
      <div class="ob-title" style="margin-top:22px">You're on staff.</div>
      <div class="ob-sub" style="padding:0 8px">${esc(joined.teamName||"The team")} \xB7 ${esc(roleLabel(normalizeRole(joined.role)))}. The roster, standards, and activity feed are yours to work.</div>
    </div>
    <div class="ob-foot" style="margin-top:auto">
      <button class="btn primary" data-go="coach-home">Open your dashboard</button>
    </div>
  </div>`}const code=(RT.ob||{}).teamCode||"";return`
  <div class="ob">
    <div class="standard-set">
      <div class="halo"><div class="core" style="background:linear-gradient(155deg,var(--amber),var(--amber-deep))">${icon("users",34)}</div></div>
      <div class="ob-title" style="margin-top:22px">Your team code.</div>
      <div class="ob-sub" style="padding:0 8px">Send it to the group chat. Athletes enter it once and their work starts counting toward your board.</div>
      <div style="height:22px"></div>
      ${code?`<div class="code-boxes fit">${code.split("").map(c=>`<div class="cb filled" style="border-color:var(--amber-border);background:rgba(var(--amber-rgb),0.08)">${c}</div>`).join("")}</div>
      <div style="height:12px"></div>
      <div style="display:flex;justify-content:center;gap:8px">
        <button class="btn ghost sm" id="copy-code" style="width:auto;padding:0 22px">${icon("clipboard",16)} Copy code</button>
        <button class="btn ghost sm" id="ob-code-edit" style="width:auto;padding:0 22px">Customize</button>
      </div>
      <div id="ob-code-editor" style="display:none;margin-top:14px">
        <input id="ob-code-input" class="ob-input" placeholder="YOUR CODE \xB7 6\u201312 letters/numbers" aria-label="Custom join code" maxlength="12"
          autocapitalize="characters" autocorrect="off" spellcheck="false" style="text-align:center;letter-spacing:0.12em;text-transform:uppercase" />
        <div style="display:flex;justify-content:center;gap:8px;margin-top:10px">
          <button class="btn primary sm" id="ob-code-save" style="width:auto;padding:0 22px">Save code</button>
        </div>
        <div id="ob-code-status" style="font-size:var(--t-sm);font-weight:600;color:var(--text-3);min-height:16px;margin-top:8px;text-align:center">Make it yours, e.g. GATORS. The random code stops working once you save.</div>
      </div>`:`<div class="sidebox"><div class="req-icon b s38">${icon("clipboard",17)}</div>
        <div><div class="tt">We couldn't create your team</div><div class="ts">Your account is set up. The team isn't yet. Open your dashboard below and use the <b>Create team</b> button waiting there. It takes one tap.</div></div></div>`}
    </div>
    <div class="ob-foot" style="margin-top:auto">
      <button class="btn primary" data-go="coach-home">Open your dashboard</button>
    </div>
  </div>`}};export const coachOb={hideTabs:true,render({sub}){const n=Math.min(8,Math.max(1,+(sub||1)));return coachSteps[n]()},async mount(root){await toggles(root);const cap=patch=>act.captureOb({coach:{...(RT.ob||{}).coach||{},...patch}});const $=s=>root.querySelector(s);const restore=(sel,saved)=>{const g=$(sel);if(!g||saved==null)return;const items=[...g.querySelectorAll(".chip, button")];const match=items.find(el=>el.textContent.trim()===String(saved));if(match){items.forEach(el=>el.classList.remove("on"));match.classList.add("on")}};const f=$("#co-first");if(f){const l=$("#co-last");const nextBtn=root.querySelector(".ob-foot .btn");const c=(RT.ob||{}).coach||{};if(c.name){const[cf,...cl]=c.name.split(" ");f.value=cf;l.value=cl.join(" ")}const handleRow=$("#co-handle"),handleCustom=$("#co-handle-custom");let autoHandle=!(((RT.ob||{}).coach||{}).coachName||"").trim();const paintHandles=()=>{if(!handleRow)return;const first=f.value.trim(),last=l.value.trim();const opts=[...new Set([last&&`Coach ${last}`,first&&`Coach ${first}`,first&&last&&`Coach ${first[0].toUpperCase()}${last[0].toUpperCase()}`].filter(Boolean))];const customTyped=!!(handleCustom&&handleCustom.value.trim());if(autoHandle&&!customTyped&&last&&opts.length&&opts[0]!==(((RT.ob||{}).coach||{}).coachName||"").trim()){cap({coachName:opts[0]})}const saved=(((RT.ob||{}).coach||{}).coachName||"").trim();handleRow.innerHTML=opts.map(o=>`<span class="chip ${saved===o?"on":""}">${esc(o)}</span>`).join("")||`<span style="font-size:var(--t-sm);font-weight:600;color:var(--text-3)">Type your name above and options appear.</span>`;handleRow.querySelectorAll(".chip").forEach(el=>el.addEventListener("click",()=>{autoHandle=false;handleRow.querySelectorAll(".on").forEach(x=>x.classList.remove("on"));el.classList.add("on");if(handleCustom)handleCustom.value="";cap({coachName:el.textContent.trim()})}))};const sync=()=>{const name=`${f.value.trim()} ${l.value.trim()}`.trim();cap({name});act.captureOb({name});nextBtn.disabled=!(f.value.trim()&&l.value.trim());paintHandles()};[f,l].forEach(el=>el.addEventListener("input",sync));sync();if(handleCustom){const saved=(((RT.ob||{}).coach||{}).coachName||"").trim();if(saved&&!handleRow.querySelector(".on"))handleCustom.value=saved;handleCustom.addEventListener("input",()=>{autoHandle=false;handleRow.querySelectorAll(".on").forEach(x=>x.classList.remove("on"));cap({coachName:handleCustom.value.trim()})})}}const q=$("#co-q");if(q){const{dir,debounce}=await import("../ob-directory.js");const out=$("#co-out");let gen=0;q.addEventListener("input",debounce(async()=>{gen++;const myGen=gen;const v=q.value.trim();if(v.length<2){out.innerHTML="";return}try{const{orgs}=await dir.search(v);if(myGen!==gen||q.value.trim()!==v)return;out.innerHTML=orgs.length?`<section class="card" style="padding:6px 16px">${orgs.map((o,i)=>`
            <div class="lrow" data-org="${i}"><div class="lic"${o.verified?' style="color:var(--green-bright)"':""}>${icon("shield",17)}</div>
            <div class="lm"><div class="lt">${esc(o.name)}${o.verified?` <span style="font-size:var(--t-eyebrow);font-weight:800;color:var(--green-bright);letter-spacing:0.02em">${icon("check",12)} Verified</span>`:""}</div><div class="ls">${esc([o.city,o.state].filter(Boolean).join(", ")||"\u2014")}</div></div></div>`).join("")}</section>`:`<div class="micro" style="color:var(--text-3);font-weight:700;padding:6px 2px">Nothing yet. Add your school below.</div>`;out.querySelectorAll("[data-org]").forEach(el=>el.addEventListener("click",()=>{const o=orgs[+el.getAttribute("data-org")];cap({orgId:o.id,schoolName:o.name,city:o.city,state:o.state});window.__render()}))}catch{if(myGen!==gen)return;out.innerHTML=`<div class="micro" style="color:var(--text-3);font-weight:700;padding:6px 2px">Couldn't reach the directory. You can add your school below.</div>`}},300));$("#co-add").addEventListener("click",()=>{gen++;out.innerHTML=`
          <input id="co-add-name" class="ob-input" maxlength="80" placeholder="School / organization name" aria-label="School or organization name" />
          <div style="height:10px"></div>
          <div class="dob-row">
            <input id="co-add-city" class="ob-input" maxlength="60" placeholder="City" aria-label="City" style="flex:2" />
            <input id="co-add-state" class="ob-input" placeholder="ST" aria-label="State, two letters" maxlength="2" autocapitalize="characters" />
          </div>
          <div style="height:10px"></div>
          <button class="btn ghost sm" id="co-add-go" style="width:auto;padding:0 22px;margin:0 auto;display:block">Use this school</button>`;out.querySelector("#co-add-go").addEventListener("click",()=>{const name=out.querySelector("#co-add-name").value.trim();if(!name)return;cap({orgId:null,schoolName:name,city:out.querySelector("#co-add-city").value.trim(),state:out.querySelector("#co-add-state").value.trim().toUpperCase()});window.__render()})})}const clear=$("#co-school-clear");if(clear)clear.addEventListener("click",()=>{cap({orgId:null,schoolName:"",city:"",state:""});window.__render()});const joinModeSeg=$("#co-joinmode");if(joinModeSeg){joinModeSeg.querySelectorAll("button[data-mode]").forEach(b=>b.addEventListener("click",()=>{const mode=b.getAttribute("data-mode");cap(mode==="create"?{joinMode:"create",staffCode:""}:{joinMode:"join"});window.__render()}))}const team=$("#co-team");if(team){const c=(RT.ob||{}).coach||{};if(c.teamName)team.value=c.teamName;restore("#co-sport",c.sport);restore("#co-level",c.level);if(c.discoverable!=null)paintSwitch($("#co-disc"),c.discoverable!==false);const sync=()=>{const sp=$("#co-sport .on"),lv=$("#co-level .on"),disc2=$("#co-disc");cap({teamName:team.value.trim(),sport:sp?sp.textContent.trim():null,level:lv?lv.textContent.trim():null,discoverable:!disc2||switchOn(disc2)})};team.addEventListener("input",sync);["#co-sport","#co-level"].forEach(sel=>{const el=$(sel);if(el)el.querySelectorAll(".chip").forEach(it=>it.addEventListener("click",sync))});const disc=$("#co-disc");if(disc)disc.addEventListener("click",()=>{flipSwitch(disc);sync()});sync()}const staffCode=$("#co-staff-code");if(staffCode){const c2=(RT.ob||{}).coach||{};if(c2.staffCode)staffCode.value=c2.staffCode;staffCode.addEventListener("input",()=>cap({staffCode:staffCode.value.trim().toUpperCase()}))}const resp=$("#co-resp");if(resp){resp.querySelectorAll(".choice[data-val]").forEach(el=>el.addEventListener("click",()=>{cap({responsibility:el.getAttribute("data-val")});window.__render()}));const rooms=$("#co-rooms");if(rooms){const c=(RT.ob||{}).coach||{};if(c.respRooms)rooms.value=c.respRooms;rooms.addEventListener("input",()=>cap({respRooms:rooms.value.trim().toUpperCase()}))}}const tpl=$("#co-tpl");if(tpl){tpl.querySelectorAll("[data-tpl]").forEach(el=>el.addEventListener("click",()=>{cap({standardTemplate:el.getAttribute("data-tpl")});window.__render()}))}const nfBrief=$("#co-nf-brief");if(nfBrief){const switches=[["#co-nf-brief","briefing"],["#co-nf-recap","recap"],["#co-nf-crit","immediateCritical"],["#co-nf-hourly","hourly"]];const syncNf=()=>{const patch={};for(const[sel,key]of switches){const g=$(sel);if(g)patch[key]=switchOn(g)}cap({notif:patch});try{act.setCoachNotifPrefs(patch)}catch{}};switches.forEach(([sel])=>{const g=$(sel);if(g)g.addEventListener("click",()=>{flipSwitch(g);syncNf()})})}if($("#su-go")){wireAccount(root,{role:"coach",onSession:async live=>{if(live){await act.persistCoachOnboarding();window.__go("coach-ob/8");return}showConfirmPending(root,{email:RT.email})}})}const copy=$("#copy-code");if(copy)copy.addEventListener("click",async()=>{const ok=await copyText((RT.ob||{}).teamCode||"");copy.innerHTML=ok?`${icon("check",16)} Copied`:"Couldn\u2019t copy"});const obCodeEdit=$("#ob-code-edit");if(obCodeEdit){const editor=$("#ob-code-editor"),input=$("#ob-code-input"),status=$("#ob-code-status");obCodeEdit.addEventListener("click",()=>{editor.style.display=editor.style.display==="none"?"":"none";if(editor.style.display===""&&input)input.focus()});$("#ob-code-save").addEventListener("click",async e=>{const raw=(input&&input.value||"").trim().toUpperCase();if(!/^[A-Z0-9]{6,12}$/.test(raw)){status.style.color="var(--red)";status.textContent="6\u201312 letters or numbers only (A\u2013Z, 0\u20139).";return}e.target.disabled=true;status.style.color="var(--text-3)";status.textContent="Saving\u2026";const r=await setMyTeamCode(raw);e.target.disabled=false;if(!r.ok){status.style.color="var(--red)";status.textContent=r.error||"Could not save that code.";return}act.captureOb({teamCode:r.code});if(RT.team)RT.team={...RT.team,code:r.code};window.__render()})}}};const trainerSteps={1:()=>{const t=(RT.ob||{}).trainer||{};const listed=t.discoverable!==false;return frame(1,4,"You, trainer.","Clients see this name on every note you send.",`
    <input id="tr-first" class="ob-input" maxlength="40" placeholder="First name" aria-label="First name" autocomplete="given-name" autocapitalize="words" />
    <div style="height:12px"></div>
    <input id="tr-last" class="ob-input" maxlength="40" placeholder="Last name" aria-label="Last name" autocomplete="family-name" autocapitalize="words" />
    <div style="height:16px"></div>
    <input id="tr-practice" class="ob-input" maxlength="60" placeholder="Practice name (e.g. Boone Performance)" aria-label="Practice name" autocapitalize="words" />
    <div style="height:18px"></div>
    <div class="lrow" id="tr-disc" role="switch" tabindex="0" aria-checked="${listed?"true":"false"}" aria-label="Listed in client search" aria-describedby="tr-disc-sub" style="padding:0 2px">
      <div class="lm"><div class="lt">Listed in client search</div><div class="ls" id="tr-disc-sub">Clients looking for a trainer can find your practice by name. Your code is still required to join.</div></div>
      <div class="std-switch ${listed?"on":""}" aria-hidden="true"></div>
    </div>`,"Next","trainer-ob/2",{back:"role"})},2:()=>{const w=weightsFor(DEFAULT_STYLE,"general");const pct=k=>Math.round(w[k]*100);return frame(2,4,"What a client starts on.","Every new client lands on this. You tune it in Practice HQ once your practice is live.",`
    <section class="card" style="padding:6px 16px" role="list">
      ${[["utensils","Meals, with photo proof",`Nutrition \xB7 ${pct("nutrition")}% of the daily score`],["moon","Recovery check-in, nightly",`Recovery \xB7 ${pct("checkin")+pct("recovery")}%`],["scale","Weight, on the days you pick","Trend only, tracked, not scored"]].map(([ic,t,s])=>{const[bg,fg]=reqHeadTint(ic);return`
        <div class="lrow" role="listitem" style="cursor:default">
          <div class="lic" style="background:${bg};color:${fg}">${icon(ic,17)}</div>
          <div class="lm"><div class="lt">${t}</div><div class="ls">${s}</div></div>
        </div>`}).join("")}
    </section>
    <div style="height:12px"></div>
    <div class="sidebox">
      <div class="req-icon p s38">${icon("clipboard",17)}</div>
      <div><div class="tt">Yours to change, per client too</div>
      <div class="ts">Meal count, windows, and weigh-in days live in Practice HQ under Default client standard. Any single client can be moved off the default without touching everyone else.</div></div>
    </div>`,"Next","trainer-ob/3",{back:"trainer-ob/1"})},3:()=>`
  <div class="ob">
    <div class="ob-nav"><div class="ob-back" data-go="trainer-ob/2">${icon("chevron",18)}</div>${progressOf(3,4)}</div>
    <div class="ob-title">Create your account.</div>
    <div class="ob-sub">Your practice and client code live on it.</div>
    <div style="height:8px"></div>
    ${accountBody({terms:"tob"})}
    <div class="ob-foot" style="margin-top:auto"><button id="su-go" class="btn primary" disabled>Create account &amp; Get my code</button></div>
  </div>`,4:()=>{const code=(RT.ob||{}).practiceCode||"";return`
  <div class="ob">
    <div class="standard-set">
      <div class="halo"><div class="core" style="background:linear-gradient(155deg,var(--purple),var(--purple-deep));color:var(--ink-on-accent)">${icon("heart",34)}</div></div>
      <div class="ob-title" style="margin-top:22px">Your client code.</div>
      <div class="ob-sub" style="padding:0 8px">Send it to your clients. They enter it once and their work starts counting toward your view.</div>
      <div style="height:22px"></div>
      ${code?`<div class="code-boxes fit">${code.split("").map(c=>`<div class="cb filled" style="border-color:var(--purple-border);background:rgba(var(--purple-rgb),0.08)">${c}</div>`).join("")}</div>
      <div style="height:12px"></div>
      <button class="btn ghost sm" id="copy-code" style="width:auto;padding:0 26px;margin:0 auto">${icon("clipboard",16)} Copy code</button>`:`<div class="sidebox"><div class="req-icon b s38">${icon("clipboard",17)}</div>
        <div><div class="tt">We couldn't create your practice</div><div class="ts">Your account is set up. The practice isn't yet. Open your Trainer View below and your dashboard will show how to finish setup. Your client code appears the moment it's done.</div></div></div>`}
    </div>
    <div class="ob-foot" style="margin-top:auto">
      <button class="btn primary" style="background:linear-gradient(150deg,var(--purple),var(--purple-deep));box-shadow:0 10px 30px rgba(var(--purple-rgb),0.35)" data-go="trainer">Open your Trainer View</button>
    </div>
  </div>`}};export const trainerOb={hideTabs:true,render({sub}){const n=Math.min(4,Math.max(1,+(sub||1)));return trainerSteps[n]()},async mount(root){await toggles(root);const cap=patch=>act.captureOb({trainer:{...(RT.ob||{}).trainer||{},...patch}});const $=s=>root.querySelector(s);const restore=(sel,saved)=>{const g=$(sel);if(!g||saved==null)return;const items=[...g.querySelectorAll(".chip, button")];const match=items.find(el=>el.textContent.trim()===String(saved));if(match){items.forEach(el=>el.classList.remove("on"));match.classList.add("on")}};const f=$("#tr-first");if(f){const l=$("#tr-last"),practice=$("#tr-practice");const nextBtn=root.querySelector(".ob-foot .btn");const t=(RT.ob||{}).trainer||{};if(RT.ob&&RT.ob.name){const[tf,...tl]=RT.ob.name.split(" ");f.value=tf;l.value=tl.join(" ")}if(t.practiceName)practice.value=t.practiceName;if(t.discoverable!=null)paintSwitch($("#tr-disc"),t.discoverable!==false);const sync=()=>{const name=`${f.value.trim()} ${l.value.trim()}`.trim();const disc=$("#tr-disc");cap({practiceName:practice.value.trim(),discoverable:!disc||switchOn(disc)});act.captureOb({name});nextBtn.disabled=!(f.value.trim()&&l.value.trim())};[f,l,practice].forEach(el=>el.addEventListener("input",sync));const discSw=$("#tr-disc");if(discSw)discSw.addEventListener("click",()=>{flipSwitch(discSw);sync()});sync()}if($("#su-go")){wireAccount(root,{role:"trainer",onSession:async live=>{if(live){await act.persistTrainerOnboarding();window.__go("trainer-ob/4");return}showConfirmPending(root,{email:RT.email})}})}const copy=$("#copy-code");if(copy)copy.addEventListener("click",async()=>{const ok=await copyText((RT.ob||{}).practiceCode||"");copy.innerHTML=ok?`${icon("check",16)} Copied`:"Couldn\u2019t copy"})}};const numInputCl="width:100%;background:transparent;border:none;outline:none;text-align:center;font-size:var(--t-3xl);font-weight:800;color:inherit;font-family:inherit;padding:0";const clientSteps={1:()=>frame(1,6,"What are we fixing?","This picks how your nutrition gets scored. Honest either way.",`
    <div class="choice-grid" id="cl-goal">
      <div class="choice on" data-val="lose"><div class="cic" style="background:rgba(var(--amber-rgb),0.18);color:var(--amber-bright)">${icon("target",19)}</div>
        <div class="ct">Lose fat</div><div class="cs">Calorie window \xB7 protein held high</div></div>
      <div class="choice" data-val="maintain"><div class="cic" style="background:var(--blue-surface);color:var(--blue-bright)">${icon("shield",19)}</div>
        <div class="ct">Maintain</div><div class="cs">Consistency over everything</div></div>
      <div class="choice" data-val="build"><div class="cic" style="background:rgba(var(--green-rgb),0.18);color:var(--green-bright)">${icon("arrowUp",19)}</div>
        <div class="ct">Build</div><div class="cs">Calorie floor \xB7 never under-fueled</div></div>
      <div class="choice" data-val="health"><div class="cic" style="background:rgba(var(--purple-rgb),0.18);color:var(--purple-bright)">${icon("heart",19)}</div>
        <div class="ct">Health</div><div class="cs">Energy, sleep, habits that hold</div></div>
    </div>
    <div style="height:14px"></div>
    <div class="sidebox">
      <div class="req-icon b s38">${icon("bars",17)}</div>
      <div><div class="tt">How client scoring works</div>
      <div class="ts">Same two pillars as athletes: Nutrition and Recovery. Inside Nutrition, your goal changes the mix: for fat loss it's calorie window 45, protein 25, meals logged 30.</div></div>
    </div>`,"Next","client-ob/2"),2:()=>frame(2,6,"Start with the basics","This is how your trainer will recognize you.",`
    <input id="cl-first" class="ob-input" maxlength="40" placeholder="First name" aria-label="First name" autocomplete="given-name" autocapitalize="words" autocorrect="off" spellcheck="false" />
    <div style="height:12px"></div>
    <input id="cl-last" class="ob-input" maxlength="40" placeholder="Last name" aria-label="Last name" autocomplete="family-name" autocapitalize="words" autocorrect="off" spellcheck="false" />
    <div style="height:16px"></div>
    <h2 class="eyebrow" style="margin:8px 2px 10px">Life, honestly</h2>
    <div class="chip-row" id="cl-life">
      <span class="chip">Desk job</span><span class="chip on">On my feet</span><span class="chip">Shift work</span><span class="chip">Travel a lot</span>
    </div>
    <div style="height:16px"></div>
    <h2 class="eyebrow" style="margin:8px 2px 10px">Training days per week</h2>
    <div class="chip-row" id="cl-days">
      <span class="chip">2</span><span class="chip on">3</span><span class="chip">4</span><span class="chip">5+</span>
    </div>`,"Next","client-ob/3",{back:"client-ob/1"}),3:()=>frame(3,6,"Where are you now?","Weight is a weekly trend here. One heavy morning proves nothing.",`
    <div class="bignum-pair">
      <div class="bignum"><input id="cl-cur" type="number" inputmode="decimal" placeholder="\u2014" style="${numInputCl}" /><label class="bk" for="cl-cur">Current lb</label></div>
      <div class="bignum" style="border-color:var(--green-border)"><input id="cl-tgt" type="number" inputmode="decimal" placeholder="\u2014" style="${numInputCl};color:var(--green-bright)" /><label class="bk" for="cl-tgt">Target lb</label></div>
    </div>
    <div style="height:16px"></div>
    <h2 class="eyebrow" style="margin:8px 2px 10px">Allergies & restrictions \xB7 checked on every scan</h2>
    <div class="chip-row" data-multi>
      <span class="chip">Peanuts</span><span class="chip">Tree nuts</span><span class="chip">Dairy</span>
      <span class="chip">Gluten</span><span class="chip">Shellfish</span><span class="chip">Vegetarian</span>
    </div>
    <div style="height:14px"></div>
    <div class="sidebox">
      <div class="req-icon b s38">${icon("shield",18)}</div>
      <div><div class="tt">No shame mechanics</div>
      <div class="ts">The daily score measures what you did today: meals, recovery, honesty. The scale is tracked weekly and never moves the daily number.</div></div>
    </div>`,"Next","client-ob/4",{back:"client-ob/2"}),4:()=>{const j=(RT.ob||{}).join;if(j&&j.kind==="practice"){const title=j.trainerName||j.practiceName||"Connected";return frame(4,6,"Trainer connected","Your logs will count toward their board from day one.",`
      <section class="card team-preview">
        <div class="tp-av" style="background:linear-gradient(150deg,var(--purple),var(--purple-deep));color:var(--ink-on-accent)">${esc(title[0])}</div>
        <div style="flex:1">
          <div style="font-size:var(--t-md);font-weight:800">${esc(title)}</div>
          <div style="font-size:var(--t-sm);font-weight:600;color:var(--text-2);margin-top:2px">${esc(j.practiceName||"Trainer connection")}</div>
        </div>
        <span class="status-pill g">Connected</span>
      </section>
      <div style="height:12px"></div>
      <div class="ob-textlink" style="font-size:var(--t-sm)" data-act="clearJoin">Remove connection</div>`,"Continue","client-ob/5",{back:"client-ob/3"})}return frame(4,6,"Connect your trainer.","Accountability needs a witness. Search for them, then enter the code they gave you.",`
      <input id="cl-q" class="ob-input" placeholder="Search your trainer" aria-label="Search your trainer" autocorrect="off" spellcheck="false" />
      <div id="cl-out" style="margin-top:14px"></div>
      <div style="height:10px"></div>
      <div id="cl-alt" style="text-align:center;font-size:var(--t-base);font-weight:700;color:var(--purple-bright);cursor:pointer">My gym isn't listed</div>`,"Continue","client-ob/5",{back:"client-ob/3",skip:"client-ob/5"})},5:()=>{const ob=RT.ob||{};const join=ob.join&&ob.join.kind==="practice"?ob.join:null;const std=standardForGoal(ob.goal,ob.standard&&ob.standard.mealsPerDay,"general",ob.structurePref?styleForStructureAnswer(ob.structurePref):DEFAULT_STYLE);const committed=!!ob.committedAt;const trainerFirst=join&&join.trainerName?join.trainerName.trim().split(/\s+/)[0]:null;const title=join?`${trainerFirst||"Your trainer"}\u2019s Standard`:"Your Standard";const sub=join?`The deal with ${join.practiceName||"your trainer"}. Your score is built on it: hold to commit.`:"Built from your goal. When you connect a trainer, their standard takes over.";const rows=std.rows.map(([ic,t,s])=>`
        <div class="lrow" role="listitem" style="cursor:default">
          <div class="lic" style="background:var(--surface-2)">${icon(ic,17)}</div>
          <div class="lm"><div class="lt">${t}</div><div class="ls">${s}</div></div>
        </div>`).join("");const knobs=join?"":`
      <h2 class="eyebrow" style="margin:14px 2px 10px">Meals per day</h2>
      <div class="chip-row" id="cl-meals">${[2,3,4].map(m=>`<span class="chip ${m===std.meals?"on":""}">${m}</span>`).join("")}</div>`;return frame(5,6,title,sub,`
      <section class="card" style="padding:6px 16px" role="list">${rows}</section>
      <div style="height:10px"></div>
      <div class="sidebox">
        <div class="req-icon b s38">${icon("bolt",17)}</div>
        <div><div class="tt">Your edge</div><div class="ts">${std.focus}</div></div>
      </div>
      ${knobs}
      <div style="height:16px"></div>
      ${commitButton(committed)}`,"Next","client-ob/6",{back:"client-ob/4",disabled:!committed})},6:()=>`
  <div class="ob">
    <div class="ob-nav"><div class="ob-back" data-go="client-ob/5" aria-label="Back">${icon("chevron",18)}</div>${progressOf(6,6)}</div>
    <div class="standard-set" style="padding-bottom:6px">
      <div class="halo"><div class="core">${icon("check",38)}</div></div>
      <div class="ob-title" style="margin-top:18px">Your Standard is set.</div>
      <div class="ob-sub" style="padding:0 10px">Create your account to save it: your score, meals, and trainer connection sync across devices.</div>
    </div>
    <div style="height:16px"></div>
    ${accountBody({terms:"clob"})}
    <div class="ob-foot" style="margin-top:auto">
      <button id="su-go" class="btn primary" disabled>Create account &amp; Start</button>
    </div>
  </div>`};export const clientOb={hideTabs:true,render({sub}){return clientSteps[Math.min(6,Math.max(1,+(sub||1)))]()},async mount(root){await toggles(root);const $=s=>root.querySelector(s);const cap=patch=>act.captureOb(patch);const captureGroup=(sel,key,read)=>{const g=$(sel);if(!g)return;const saved=(RT.ob||{})[key];if(saved!=null){const items=[...g.querySelectorAll(".chip, .choice")];const match=items.find(el=>(el.getAttribute("data-val")||el.textContent.trim())===saved);if(match){items.forEach(el=>el.classList.remove("on"));match.classList.add("on")}}const val=read||(()=>{const on=g.querySelector(".on");return on?on.textContent.trim():null});const sync=()=>{const v=val();if(v!=null)cap({[key]:v})};g.querySelectorAll(".chip, .choice").forEach(el=>el.addEventListener("click",sync));sync()};captureGroup("#cl-goal","goal",()=>{const on=$("#cl-goal .on");return on?on.getAttribute("data-val"):null});const first=$("#cl-first");if(first){const last=$("#cl-last");const nextBtn=root.querySelector(".ob-foot .btn");const ob=RT.ob||{};if(ob.firstName)first.value=ob.firstName;if(ob.lastName)last.value=ob.lastName;const syncName=()=>{const f=first.value.trim(),l=last.value.trim();cap({firstName:f,lastName:l,name:`${f} ${l}`.trim()});nextBtn.disabled=!(f&&l)};[first,last].forEach(el=>el.addEventListener("input",syncName));syncName()}captureGroup("#cl-life","life");captureGroup("#cl-days","trainingDays");const cur=$("#cl-cur");if(cur)cur.addEventListener("input",()=>cap({currentWeight:parseFloat(cur.value)||null}));const tgt=$("#cl-tgt");if(tgt)tgt.addEventListener("input",()=>cap({targetWeight:parseFloat(tgt.value)||null}));if(cur&&RT.ob&&RT.ob.currentWeight)cur.value=RT.ob.currentWeight;if(tgt&&RT.ob&&RT.ob.targetWeight)tgt.value=RT.ob.targetWeight;const alg=$("[data-multi]");if(alg){const savedA=RT.ob&&RT.ob.allergies||[];if(savedA.length)[...alg.querySelectorAll(".chip")].forEach(c=>c.classList.toggle("on",savedA.includes(c.textContent.trim())));const readA=()=>cap({allergies:[...alg.querySelectorAll(".chip.on")].map(c=>c.textContent.trim())});alg.addEventListener("click",readA);readA()}const q=$("#cl-q");if(q){const{dir,debounce,CODE_RE}=await import("../ob-directory.js");const out=$("#cl-out"),alt=$("#cl-alt");let gen=0;const codeEntry=ctx=>{gen++;out.innerHTML=`
          ${ctx?`<div class="sidebox" style="margin-bottom:12px"><div class="req-icon b s38">${icon("heart",17)}</div>
            <div><div class="tt">${esc(ctx.title)}</div><div class="ts">${esc(ctx.sub)}</div></div></div>`:""}
          <input id="cl-code" class="ob-input" placeholder="Client code" aria-label="Client code" autocapitalize="characters" autocorrect="off" spellcheck="false" maxlength="12" />
          <div id="cl-code-err" style="color:var(--amber-bright);font-size:var(--t-sm);font-weight:700;min-height:18px;margin-top:10px"></div>`;const codeEl=out.querySelector("#cl-code"),codeErr=out.querySelector("#cl-code-err");codeEl.addEventListener("input",debounce(async()=>{const code=codeEl.value.trim().toUpperCase();codeErr.textContent="";if(!CODE_RE.test(code))return;const myGen=gen;try{const{match}=await dir.previewCode(code);if(myGen!==gen||codeEl.value.trim().toUpperCase()!==code)return;if(!match||match.kind!=="practice"){codeErr.textContent="That code didn't match. Check with your trainer.";return}cap({join:{kind:"practice",code,practiceId:match.id,practiceName:match.name,trainerName:match.trainer_name}});window.__render()}catch{if(myGen!==gen)return;codeErr.textContent="Could not check that code. You can also skip and connect later."}},350));codeEl.focus()};q.addEventListener("input",debounce(async()=>{gen++;const myGen=gen;const v=q.value.trim();if(v.length<2){out.innerHTML="";return}out.innerHTML=`<div class="micro" style="color:var(--text-3);font-weight:700;padding:6px 2px">Searching\u2026</div>`;try{const{practices}=await dir.practices(v);if(myGen!==gen||q.value.trim()!==v)return;if(!practices.length){out.innerHTML=`<div class="sidebox"><div class="req-icon b s38">${icon("heart",17)}</div>
              <div><div class="tt">Not listed yet</div><div class="ts">No trainer by that name is on OnStandard yet. Enter your client code below, or skip; you can connect anytime from Profile.</div></div></div>`;return}out.innerHTML=`<section class="card" style="padding:6px 16px">${practices.map((p,i)=>`
            <div class="lrow" data-prac="${i}">
              <div class="lic">${icon("heart",17)}</div>
              <div class="lm"><div class="lt">${esc(p.name)}</div><div class="ls">${esc(p.trainer_name||"\u2014")}${p.handle?` \xB7 @${esc(p.handle)}`:""}</div></div>
              ${icon("chevron",17,'style="color:var(--text-3)"')}
            </div>`).join("")}</section>`;out.querySelectorAll("[data-prac]").forEach(el=>el.addEventListener("click",()=>{const p=practices[+el.getAttribute("data-prac")];codeEntry({title:`Ask ${p.trainer_name||"your trainer"} for your client code`,sub:`${p.name} \xB7 the code is the handshake: only your trainer hands it out.`})}))}catch{if(myGen!==gen)return;out.innerHTML=`<div class="sidebox"><div class="req-icon b s38">${icon("heart",17)}</div>
            <div><div class="tt">Can't reach the directory</div><div class="ts">Check your connection, enter a client code directly, or skip for now.</div></div></div>`}},300));alt.addEventListener("click",()=>codeEntry(null))}const mealsRow=$("#cl-meals");if(mealsRow)mealsRow.querySelectorAll(".chip").forEach(chp=>chp.addEventListener("click",()=>{cap({standard:{...(RT.ob||{}).standard||{},mealsPerDay:+chp.textContent.trim()}});window.__render()}));if($("#ob-commit"))wireCommit(root,()=>{const ob=RT.ob||{};cap({committedAt:new Date().toISOString(),standard:{...ob.standard||{},mealsPerDay:ob.standard&&ob.standard.mealsPerDay||3}});window.__render()});if($("#su-go")){wireAccount(root,{role:"athlete",onSession:async live=>{await act.persistOnboarding();if(live){act.startDay0();let bio=false;try{bio=window.OnStandardNative&&window.OnStandardNative.biometrics?await window.OnStandardNative.biometrics.available():false}catch{}window.__go(bio?"bio-optin":"home");return}showConfirmPending(root,{email:RT.email})}})}}};const CP_SECTIONS=[{sub:"personal",icon:"user",t:"Personal profile",s:"Your name, coach handle, sign out"},{sub:"invitations",icon:"share",t:"Athlete code & invites",s:"The code athletes join with"},{sub:"staff",icon:"users",t:"Staff & collaborators",s:"Invite staff, set their scope"},{sub:"program",icon:"clipboard",t:"Program",s:"Standards, templates, Coach Voice, visibility"},{sub:"analytics",icon:"bars",t:"Insights",s:"Team trends and standard adherence",go:"coach-insights"},{sub:"preferences",icon:"bell",t:"Preferences",s:"Notifications and appearance"},{sub:"account",icon:"key",t:"Account",s:"Email, password, billing, delete"}];function cpNames(){const ci=S.coachIdentity;const ob=RT.ob&&RT.ob.coach||{};const name=ci.name!=="Coach"?ci.name:ob.name||"Coach";const teamBits=ci.hasIdentity?[ci.teamName]:[ob.teamName,ob.schoolName].filter(Boolean);const metaLine=teamBits.filter(Boolean).map(esc).join(" \xB7 ")||"Your team";const code=ci.code||(RT.ob||{}).teamCode||"";return{ci,name,metaLine,code}}function cpIdCard(withHandle){const{ci,name,metaLine}=cpNames();return`
    <section class="card id-card">
      ${""}
      ${""}
      ${""}
      ${avatarControlHtml({uid:RT.userId,initials:ci.initials||initialsOf(name,"C"),size:62,editable:true})}
      <div class="id-txt">
        ${""}
        <div class="nm cp-name" id="cp-name-edit" role="button" tabindex="0" aria-label="Change your name">${esc(name)} <span class="cp-name-pen">${icon("edit",14)}</span></div>
        <div class="meta">${metaLine}</div>
        ${withHandle?`<div class="meta" style="margin-top:3px">Goes by <b style="color:var(--text)">${esc(ci.handle)}</b> \xB7 <span id="handle-edit" style="color:var(--blue-bright);cursor:pointer;font-weight:800">Change</span></div>`:""}
      </div>
    </section>
    <div id="cp-name-editor" class="cp-name-editor" hidden>
      <input id="cp-name-input" class="ob-input" maxlength="60" placeholder="Your name" aria-label="Your name" value="${esc(name==="Coach"?"":name)}" />
      <div class="cp-name-row">
        <button class="btn ghost sm" id="cp-name-cancel" type="button">Cancel</button>
        <button class="btn primary sm" id="cp-name-save" type="button">Save</button>
      </div>
      <div id="cp-name-status" class="cp-name-status">Shown on your profile, in threads and on every athlete's Coach row.</div>
    </div>`}function wireNameEditor(root){const open=root.querySelector("#cp-name-edit"),box=root.querySelector("#cp-name-editor");if(!open||!box)return;const input=root.querySelector("#cp-name-input"),status=root.querySelector("#cp-name-status");open.addEventListener("click",()=>{box.hidden=!box.hidden;if(!box.hidden&&input)input.focus()});root.querySelector("#cp-name-cancel").addEventListener("click",()=>{box.hidden=true});const save=async()=>{const v=(input.value||"").trim();if(v.length<2){status.classList.add("bad");status.textContent="Give it at least 2 characters.";return}status.classList.remove("bad");status.textContent="Saving\u2026";const ok=await act.saveOperatorName(v);if(!ok){status.classList.add("bad");status.textContent="Couldn't save that. Check your connection and try again.";return}window.__render()};root.querySelector("#cp-name-save").addEventListener("click",save);if(input)input.addEventListener("keydown",e=>{if(e.key==="Enter"&&!e.isComposing)save()})}function cpHandleEditor(){const{ci}=cpNames();return`
    <div id="handle-editor" style="display:none;margin:6px 0 12px">
      <input id="handle-input" class="ob-input" maxlength="40" placeholder="e.g. Coach JB" aria-label="What the room calls you" value="${esc(ci.handle)}" />
      <div style="display:flex;gap:8px;margin-top:8px">
        <button class="btn ghost sm" id="handle-cancel" style="width:auto;padding:0 18px">Cancel</button>
        <button class="btn primary sm" id="handle-save" style="width:auto;padding:0 22px">Save</button>
      </div>
      <div id="handle-status" style="font-size:var(--t-sm);font-weight:600;color:var(--text-3);min-height:16px;margin-top:6px">Athletes see this everywhere: greetings, meal threads, your standard.</div>
    </div>`}function cpCodeBlock(){const{ci,code}=cpNames();return`
    <h2 class="eyebrow" id="cp-code">Athlete code \xB7 share it</h2>
    ${code?`
    <section class="card pad" style="text-align:center">
      <div class="code-boxes fit" style="padding:0 0 4px">
        ${code.split("").map(ch=>`<div class="cb filled" style="border-color:var(--amber-border)">${esc(ch)}</div>`).join("")}
      </div>
      <div style="display:flex;justify-content:center;gap:8px;margin-top:8px">
        <button class="btn ghost sm" id="copy-code" style="width:auto;padding:0 18px">${icon("clipboard",16)} Copy</button>
        <button class="btn ghost sm" id="edit-code" style="width:auto;padding:0 18px">Customize</button>
        <button class="btn ghost sm" id="regen-code" style="width:auto;padding:0 18px">New code</button>
      </div>
      <div id="code-editor" style="display:none;margin-top:12px">
        <input id="code-input" class="ob-input" placeholder="YOUR CODE \xB7 6\u201312 letters/numbers" aria-label="Custom join code" maxlength="12"
          autocapitalize="characters" autocorrect="off" spellcheck="false" style="text-align:center;letter-spacing:0.12em;text-transform:uppercase" />
        <div style="display:flex;justify-content:center;gap:8px;margin-top:10px">
          <button class="btn ghost sm" id="code-cancel" style="width:auto;padding:0 18px">Cancel</button>
          <button class="btn primary sm" id="code-save" style="width:auto;padding:0 22px">Save code</button>
        </div>
      </div>
      <div id="code-status" style="font-size:var(--t-sm);font-weight:600;color:var(--text-3);min-height:16px;margin-top:8px"></div>
    </section>`:ci.state==="loading"?`
    <div class="sidebox">
      <div class="req-icon b s38">${icon("clipboard",17)}</div>
      <div><div class="tt">Loading your team\u2026</div><div class="ts">Checking your team and code.</div></div>
    </div>`:ci.state==="offline"?`
    <div class="sidebox">
      <div class="req-icon b s38">${icon("clipboard",17)}</div>
      <div><div class="tt">Can't reach the server</div><div class="ts">Your code is safe: reconnect and it shows right here.</div></div>
    </div>`:`
    ${emptyState({icon:"clipboard",title:"No code yet",body:"It appears when your team is created, automatically on your next sign-in.",compact:true})}`}`}function cpStaffBlock(){const mine=STAFF&&STAFF.teamId===(RT.team&&RT.team.id)?STAFF:null;const staff=mine?mine.rows:null;const staffFailed=!!(mine&&mine.failed);const me=staff&&staff.find(s=>s.staff_id===RT.userId);const iAmHead=!staff||!me||me.role==="head_coach";return`
    <h2 class="eyebrow" id="cp-staff">Staff &amp; collaborators</h2>
    <section class="card" style="padding:6px 16px">
      ${staffFailed?`
      <div class="lrow" style="cursor:default"><div class="lic" style="color:var(--amber-bright)">${icon("wifiOff",17)}</div>
      <div class="lm"><div class="lt">Couldn't load your staff</div><div class="ls">Anyone you already invited is still on your team. Reopen to retry.</div></div></div>`:staff===null?`
      <div class="lrow" style="cursor:default"><div class="lic">${icon("users",17)}</div>
      <div class="lm"><div class="lt">Loading your staff\u2026</div></div></div>`:`
      ${staff.map(s=>`
      <div class="lrow" style="cursor:default">
        <div class="lic" style="${s.role==="nutritionist"?"background:rgba(var(--purple-rgb),0.16);color:var(--purple-bright)":""}">${icon(s.role==="nutritionist"?"heart":s.role==="readonly"?"eye":"user",17)}</div>
        <div class="lm"><div class="lt">${esc(s.name)}</div><div class="ls">${esc(roleLabel(normalizeRole(s.role)))}${s.role==="head_coach"?"":` \xB7 ${esc(scopeText(s.scope_kind?{kind:s.scope_kind,value:s.scope_value}:null))}`}</div></div>
        ${iAmHead&&s.role!=="head_coach"&&s.staff_id!==RT.userId?`
        <button class="btn ghost sm" data-staff-scope="${esc(s.staff_id)}" style="width:auto;padding:0 10px;height:44px;font-size:var(--t-xs)">Scope</button>
        <button class="btn ghost danger sm" data-staff-rm="${esc(s.staff_id)}" style="width:auto;padding:0 10px;font-size:var(--t-xs);margin-left:6px">Remove</button>`:""}
      </div>
      ${iAmHead&&s.role!=="head_coach"?`
      <div id="staff-scope-ed-${esc(s.staff_id)}" style="display:none;padding:2px 2px 12px">
        <input class="ob-input" data-scope-input="${esc(s.staff_id)}" aria-label="Rooms this staff member covers" placeholder="Rooms, comma-separated, e.g. LB or OL, TE. Blank = whole team"
          autocapitalize="characters" autocorrect="off" spellcheck="false" value="${s.scope_kind==="position"?esc(s.scope_value||""):""}" />
        <div style="display:flex;gap:8px;margin-top:8px">
          <button class="btn primary sm" data-scope-save="${esc(s.staff_id)}" style="width:auto;padding:0 18px">Save scope</button>
        </div>
      </div>`:""}`).join("")}
      ${iAmHead?`
      <div class="lrow" style="cursor:default">
        <div class="lic">${icon("plus",17)}</div>
        <div class="lm"><div class="lt">Invite to your staff</div><div class="ls">Single-use code \xB7 they enter it at coach sign-up</div></div>
      </div>
      <div class="chip-row" style="padding:0 2px 12px">
        <span class="chip" data-staff-invite="coordinator">Coordinator</span>
        <span class="chip" data-staff-invite="position_coach">Position coach</span>
        <span class="chip" data-staff-invite="s_and_c">Strength &amp; Conditioning</span>
        <span class="chip" data-staff-invite="athletic_trainer">Athletic Trainer</span>
        <span class="chip" data-staff-invite="nutritionist">Dietitian</span>
        <span class="chip" data-staff-invite="team_admin">Team Admin</span>
        <span class="chip" data-staff-invite="readonly">View only</span>
      </div>`:`
      <div style="font-size:var(--t-xs);font-weight:600;color:var(--text-3);padding:2px 2px 10px">Staff invites and scopes are managed by the head coach.</div>`}`}
      <div id="staff-code-out" style="display:none;padding:4px 2px 10px">
        <div class="code-boxes fit" id="staff-code-boxes" style="padding:0 0 6px"></div>
        <div style="font-size:var(--t-xs);font-weight:600;color:var(--text-3);text-align:center">One use only. Text it to them. At sign-up they pick "Coach" (a dietitian picks "Team Dietitian / RD"), choose "Join a staff", and enter it.</div>
      </div>
      <div id="staff-status" style="font-size:var(--t-xs);font-weight:600;color:var(--text-3);min-height:14px;padding:0 2px 8px"></div>
    </section>`}function cpProgramBlock(){return`
    <h2 class="eyebrow">Program</h2>
    <section class="card" style="padding:6px 16px">
      <div class="lrow" data-go="coach-plan"><div class="lic">${icon("clipboard",17)}</div><div class="lm"><div class="lt">Standards</div><div class="ls">Targets, focus, publish updates</div></div>${icon("chevron",17)}</div>
      <div class="lrow" data-go="coach-assign"><div class="lic">${icon("plus",17)}</div><div class="lm"><div class="lt">Requirement templates</div><div class="ls">What you assign most</div></div>${icon("chevron",17)}</div>
      <div class="lrow" data-go="coach-voice"><div class="lic" style="background:rgba(var(--purple-rgb),0.16);color:var(--purple-bright)">${icon("sparkle",17)}</div><div class="lm"><div class="lt">AI Nutritionist</div><div class="ls">Tone, length, instructions: make it coach like you</div></div>${icon("chevron",17)}</div>
      <div class="lrow" data-go="privacy"><div class="lic">${icon("lock",17)}</div><div class="lm"><div class="lt">Visibility rules</div><div class="ls">What parents and trainers can see</div></div>${icon("chevron",17)}</div>
    </section>`}function cpAnalyticsBlock(){return`
    <h2 class="eyebrow">Analytics</h2>
    <section class="card" style="padding:6px 16px">
      <div class="lrow" data-go="coach-insights"><div class="lic" style="background:var(--blue-surface);color:var(--blue-bright)">${icon("bars",17)}</div><div class="lm"><div class="lt">Insights</div><div class="ls">Team trends, standard adherence</div></div>${icon("chevron",17)}</div>
    </section>`}function cpPrefsBlock(){return`
    <h2 class="eyebrow">Preferences</h2>
    <section class="card" style="padding:6px 16px">
      <div class="lrow" data-go="coach-notif-settings"><div class="lic">${icon("bell",17)}</div><div class="lm"><div class="lt">Notifications</div><div class="ls">Briefings, alerts, quiet hours</div></div>${icon("chevron",17)}</div>
      ${""}
      <div class="lrow" data-go="settings"><div class="lic">${icon("moon",17)}</div><div class="lm"><div class="lt">App settings</div><div class="ls">Light or dark, plan, health, security</div></div>${icon("chevron",17)}</div>
    </section>`}function cpSignOut(){return`
    <section class="card" style="padding:6px 16px">
      <div class="lrow" data-go="welcome"><div class="lic" style="color:var(--red)">${icon("x",17)}</div><div class="lm"><div class="lt" style="color:var(--red)">Sign out</div></div></div>
    </section>`}function operatorAccountSection(){return`
    <h2 class="eyebrow">Account</h2>
    <section class="card" style="padding:6px 16px">
      <div class="lrow" style="cursor:default">
        <div class="lic">${icon("mail",17)}</div>
        <div class="lm"><div class="lt">Signed in as</div><div class="ls">${esc(RT.email||"Email unavailable, sign in again to refresh")}</div></div>
        ${RT.emailVerified===true?'<span class="status-pill g">Verified</span>':""}
      </div>
      <div class="lrow" data-go="account">
        <div class="lic">${icon("lock",17)}</div>
        <div class="lm"><div class="lt">Sign-in &amp; email</div><div class="ls">Change your password or email in the app</div></div>
        ${icon("chevron",17,'style="color:var(--text-3)"')}
      </div>
      <div class="lrow" data-go="billing">
        <div class="lic">${icon("bars",17)}</div>
        <div class="lm"><div class="lt">Plan &amp; billing</div><div class="ls">Your subscription and invoices</div></div>
        ${icon("chevron",17,'style="color:var(--text-3)"')}
      </div>
      <div class="lrow" data-go="privacy">
        <div class="lic">${icon("shield",17)}</div>
        <div class="lm"><div class="lt">Privacy &amp; your data</div><div class="ls">Who sees what \xB7 download your data</div></div>
        ${icon("chevron",17,'style="color:var(--text-3)"')}
      </div>
      <div class="lrow" data-go="delete-account">
        <div class="lic" style="color:var(--red)">${icon("trash",17)}</div>
        <div class="lm"><div class="lt" style="color:var(--red)">Delete account</div><div class="ls">Permanent: everything goes</div></div>
        ${icon("chevron",17,'style="color:var(--text-3)"')}
      </div>
    </section>`}function wireOperatorAccount(root){const row=root.querySelector("#acct-pass");if(!row)return;let busy=false;const send=async()=>{if(busy)return;busy=true;const note=root.querySelector("#acct-pass-note");if(note)note.textContent="Sending\u2026";await act.requestPasswordReset(RT.email||"");if(note)note.textContent=RT.email?`Reset link sent to ${RT.email}. Check your inbox.`:"Could not find your email. Sign in again first.";busy=false};row.addEventListener("click",send)}export const coachProfile={nav:"coach",tab:"profile",render({sub}={}){const alias=sub==="code"?"invitations":sub||"";const back=(t,s)=>backHead(t,s,"coach-profile");if(alias==="personal")return`${back("Personal profile","Your identity and handle")}${cpIdCard(true)}${cpHandleEditor()}<div style="height:8px"></div>${cpSignOut()}<div style="height:10px"></div>`;if(alias==="invitations")return`${back("Athlete code","Share it: athletes join with this")}${cpCodeBlock()}<div style="height:10px"></div>`;if(alias==="staff")return`${back("Staff & collaborators","Invite staff and set their scope")}${cpStaffBlock()}<div style="height:10px"></div>`;if(alias==="program")return`${back("Program","Standards, templates, and voice")}${cpProgramBlock()}<div style="height:10px"></div>`;if(alias==="analytics")return`${back("Analytics","What the numbers say")}${cpAnalyticsBlock()}<div style="height:10px"></div>`;if(alias==="preferences")return`${back("Preferences","Notifications and appearance")}${cpPrefsBlock()}<div style="height:10px"></div>`;if(alias==="account")return`${back("Account","Email, password, billing, delete")}${operatorAccountSection()}<div style="height:10px"></div>`;return`
    ${titleHead("Coach Profile","You, your team, your code")}
    ${cpIdCard(false)}
    <h2 class="eyebrow">Manage</h2>
    <section class="card" style="padding:6px 16px">
      ${CP_SECTIONS.map(x=>`<div class="lrow" data-go="${esc(x.go||`coach-profile/${x.sub}`)}"><div class="lic">${icon(x.icon,17)}</div><div class="lm"><div class="lt">${esc(x.t)}</div><div class="ls">${esc(x.s)}</div></div>${icon("chevron",17)}</div>`).join("")}
    </section>
    <div style="height:8px"></div>
    ${cpSignOut()}
    ${""}
    <div class="co-bottom"></div>
    `},mount(root,{sub}={}){if(sub==="staff")loadStaff(RT.team&&RT.team.id);wireAvatarUpload(root);wireNameEditor(root);wireOperatorAccount(root);const sStatus=root.querySelector("#staff-status");const sSay=(msg,isErr)=>{if(sStatus){sStatus.style.color=isErr?"var(--red)":"var(--text-3)";sStatus.textContent=msg}};root.querySelectorAll("[data-staff-invite]").forEach(b=>b.addEventListener("click",async()=>{const teamId=RT.team&&RT.team.id;if(!teamId){sSay("Your team hasn\u2019t loaded yet.",true);return}b.disabled=true;sSay("Creating a code\u2026");const r=await createStaffInvite(teamId,b.getAttribute("data-staff-invite"));b.disabled=false;if(!r.ok){sSay(r.error||"Could not create the code.",true);return}act.markCoachSetup("staff");const out=root.querySelector("#staff-code-out"),boxes=root.querySelector("#staff-code-boxes");if(out&&boxes){boxes.innerHTML=r.code.split("").map(ch=>`<div class="cb filled" style="border-color:var(--blue-border)">${esc(ch)}</div>`).join("");out.style.display=""}sSay(await copyText(r.code)?"Copied to clipboard.":"Copy it from the boxes above.")}));root.querySelectorAll("[data-staff-rm]").forEach(b=>b.addEventListener("click",async()=>{if(b.getAttribute("data-armed")!=="1"){b.setAttribute("data-armed","1");b.textContent="Sure?";return}b.disabled=true;const ok=await revokeStaff(RT.team&&RT.team.id,b.getAttribute("data-staff-rm"));if(ok)await loadStaff(RT.team&&RT.team.id,true);else{b.disabled=false;b.textContent="Remove";b.removeAttribute("data-armed");sSay("Could not remove them. Try again.",true)}}));root.querySelectorAll("[data-staff-scope]").forEach(b=>b.addEventListener("click",()=>{const ed=root.querySelector(`#staff-scope-ed-${CSS.escape(b.getAttribute("data-staff-scope"))}`);if(ed)ed.style.display=ed.style.display==="none"?"":"none"}));root.querySelectorAll("[data-scope-save]").forEach(b=>b.addEventListener("click",async()=>{const staffId=b.getAttribute("data-scope-save");const input2=root.querySelector(`[data-scope-input="${CSS.escape(staffId)}"]`);const rooms=(input2&&input2.value||"").trim().toUpperCase();b.disabled=true;sSay("Saving scope\u2026");const r=rooms?await setStaffScope(RT.team&&RT.team.id,staffId,"position",rooms):await setStaffScope(RT.team&&RT.team.id,staffId,null,null);b.disabled=false;if(!r.ok){sSay(r.error||"Could not set the scope.",true);return}sSay("");await loadStaff(RT.team&&RT.team.id,true)}));const hEdit=root.querySelector("#handle-edit"),hBox=root.querySelector("#handle-editor");if(hEdit&&hBox){hEdit.addEventListener("click",()=>{hBox.style.display=hBox.style.display==="none"?"":"none"});const hStatus=root.querySelector("#handle-status");root.querySelector("#handle-cancel").addEventListener("click",()=>{hBox.style.display="none"});root.querySelector("#handle-save").addEventListener("click",async()=>{const v=(root.querySelector("#handle-input").value||"").trim();if(v.length<2){hStatus.style.color="var(--red)";hStatus.textContent="Give it at least 2 characters.";return}hStatus.style.color="var(--text-3)";hStatus.textContent="Saving\u2026";const r=await act.saveCoachHandle(v);if(!r.ok){hStatus.style.color="var(--red)";hStatus.textContent=r.error||"Could not save that.";return}window.__render()})}const copy=root.querySelector("#copy-code");if(copy)copy.addEventListener("click",async()=>{const ok=await copyText(S.coachIdentity.code||(RT.ob||{}).teamCode||"");copy.innerHTML=ok?`${icon("check",16)} Copied`:"Couldn\u2019t copy";setTimeout(()=>{copy.innerHTML=`${icon("clipboard",16)} Copy`},1600)});const editor=root.querySelector("#code-editor");const input=root.querySelector("#code-input");const status=root.querySelector("#code-status");const say=(msg,isErr)=>{if(status)sayStatus(status,msg,{error:!!isErr})};const applyCode=newCode=>{if(RT.team)RT.team={...RT.team,code:newCode};window.__render()};const edit=root.querySelector("#edit-code");if(edit&&editor)edit.addEventListener("click",()=>{editor.style.display=editor.style.display==="none"?"":"none";if(editor.style.display===""&&input)input.focus()});const cancel=root.querySelector("#code-cancel");if(cancel&&editor)cancel.addEventListener("click",()=>{editor.style.display="none";say("")});const save=root.querySelector("#code-save");if(save)save.addEventListener("click",async()=>{const raw=(input&&input.value||"").trim().toUpperCase();if(!/^[A-Z0-9]{6,12}$/.test(raw)){say("6\u201312 letters or numbers only (A\u2013Z, 0\u20139).",true);return}save.disabled=true;say("Saving\u2026");const r=await setMyTeamCode(raw);save.disabled=false;if(!r.ok){say(r.error||"Could not save that code.",true);return}applyCode(r.code)});const regen=root.querySelector("#regen-code");if(regen){let armed=false;regen.addEventListener("click",async()=>{if(!armed){armed=true;regen.textContent="Sure? Old code dies";say("A new code replaces this one immediately. Anyone holding the old code can no longer join.");return}regen.disabled=true;say("Creating a new code\u2026");const r=await regenerateMyTeamCode();regen.disabled=false;armed=false;regen.textContent="New code";if(!r.ok||!r.code){say(r.error||"Could not make a new code.",true);return}applyCode(r.code)})}}};function trainerSettingsSections(){return`
    <h2 class="eyebrow">Your clients</h2>
    <section class="card" style="padding:6px 16px">
      <div class="lrow" data-go="coach-plan-set/team" style="cursor:pointer">
        <div class="lic">${icon("clipboard",17)}</div>
        <div class="lm"><div class="lt">Default client standard</div><div class="ls">Meals, windows, and check-ins: applied to every client</div></div>
        ${icon("chevron",17,'style="color:var(--text-3)"')}
      </div>
      <div class="lrow" data-go="coach-voice"><div class="lic" style="background:rgba(var(--${S.trainerIdentity.discipline==="nutrition"?"green":"purple"}-rgb),0.16);color:var(--${S.trainerIdentity.discipline==="nutrition"?"green":"purple"}-bright)">${icon("sparkle",17)}</div><div class="lm"><div class="lt">AI Nutritionist</div><div class="ls">Tone, length, instructions: make it coach like you</div></div>${icon("chevron",17)}</div>
      <div class="lrow" data-go="trust-pass-policy"><div class="lic" style="background:var(--green-surface);color:var(--green-bright)">${icon("shield",17)}</div><div class="lm"><div class="lt">Trust Pass defaults</div><div class="ls">${(RT.passPolicy||{default_credits:3}).default_credits}-credit default \xB7 earned after ${(RT.passPolicy||{eligibility_days:7}).eligibility_days} photo-logged days</div></div>${icon("chevron",17)}</div>
    </section>

    <h2 class="eyebrow">Your app</h2>
    <section class="card" style="padding:6px 16px">
      <div class="lrow" data-go="coach-notif-settings"><div class="lic">${icon("bell",17)}</div><div class="lm"><div class="lt">Notifications</div><div class="ls">Briefings, alerts, quiet hours</div></div>${icon("chevron",17)}</div>
      <div class="lrow" data-go="settings"><div class="lic">${icon("moon",17)}</div><div class="lm"><div class="lt">App settings</div><div class="ls">Light or dark, plan, health, security</div></div>${icon("chevron",17)}</div>
      <div class="lrow" data-go="privacy"><div class="lic">${icon("lock",17)}</div><div class="lm"><div class="lt">Your visibility scope</div><div class="ls">Recovery, readiness, consistency only</div></div>${icon("chevron",17)}</div>
    </section>`}export const trainerProfile={nav:"trainer",tab:"profile",render({sub}={}){if(sub==="settings"){return`
    ${backHead("Practice settings","Your standard, voice, and app preferences","trainer-profile")}
    ${trainerSettingsSections()}
    <div style="height:10px"></div>`}if(sub==="account"){return`
    ${backHead("Account","Email, password, billing, delete","trainer-profile")}
    ${operatorAccountSection()}
    <div style="height:10px"></div>`}const ti=S.trainerIdentity;const loading=ti.state==="loading";const minting=ti.state==="minting";const offline=ti.state==="offline";const offlineNoCode=offline&&!ti.code;const subTitle=offline?ti.code?"Offline \xB7 showing your saved details":"Offline \xB7 reconnecting":"Manage your practice";const hue=ti.discipline==="nutrition"?"green":"purple";const header=loading?`
    <section class="card id-card">
      <div class="sk" style="width:62px;height:62px;border-radius:50%"></div>
      <div style="flex:1">
        <div class="sk" style="height:19px;width:65%"></div>
        <div class="sk" style="height:12px;width:45%;margin-top:9px"></div>
      </div>
    </section>`:`
    <section class="card id-card">
      ${avatarControlHtml({uid:RT.userId,initials:ti.initials||"T",size:62,editable:true})}
      <div class="id-txt">
        <div class="nm">${esc(ti.name)}</div>
        ${""}
        <div class="meta">${esc(ti.practiceName)}${ti.discipline==="nutrition"&&!/nutrition|dietitian|dietetic/i.test(ti.practiceName)?" \xB7 Nutrition practice":""}</div>
        <div style="margin-top:9px;display:flex;align-items:center;gap:10px">${offline?`<span class="status-pill a">Reconnecting</span>`:minting?`<span class="status-pill p">Setting up</span>`:`<span class="status-pill g">Live</span>`}${!offline&&!minting?`<span class="link" id="pr-rename" role="button" tabindex="0" style="font-size:var(--t-xs);font-weight:700">Rename</span>`:""}</div>
      </div>
    </section>
    ${""}
    <section class="card" id="pr-rename-card" style="display:none;padding:14px 16px;margin-top:8px">
      <h2 class="eyebrow" style="margin:0 0 8px">Practice name</h2>
      <input id="pr-name-input" class="ob-input" maxlength="60" placeholder="Your practice's name" aria-label="Practice name" value="${esc(ti.practiceName==="Your practice"?"":ti.practiceName)}"/>
      <div style="display:flex;gap:8px;margin-top:10px">
        <button class="btn ghost sm" id="pr-name-cancel" style="width:auto;padding:0 18px">Cancel</button>
        <button class="btn sm" id="pr-name-save" style="width:auto;padding:0 22px;background:linear-gradient(150deg,var(--${hue}),var(--${hue}-deep));color:var(--ink-on-accent)">Save name</button>
      </div>
      <div id="pr-name-status" style="font-size:var(--t-sm);font-weight:600;color:var(--text-3);min-height:16px;margin-top:8px"></div>
    </section>`;let invite;if(loading){invite=`
      <h2 class="eyebrow">Invite a client</h2>
      <section class="card" style="padding:18px">
        <div class="hq-invite-top">
          <div style="flex:1">
            <div class="sk" style="height:11px;width:40%"></div>
            <div class="sk" style="height:56px;width:100%;margin-top:10px;border-radius:13px"></div>
          </div>
          <div class="sk" style="width:104px;height:104px;border-radius:var(--r-card-sm)"></div>
        </div>
      </section>`}else if(minting){invite=`
      <h2 class="eyebrow">Invite a client</h2>
      <div class="sidebox">
        <div class="req-icon ${hue==="green"?"g":"p"} s38"><span class="hq-spin"></span></div>
        <div><div class="tt">Your client code is being created</div>
        <div class="ts">It mints the moment your practice is set up on the server, usually a few seconds. Nothing shows until it's real, so a client never gets a dead code.</div></div>
      </div>`}else if(offlineNoCode){invite=`
      <h2 class="eyebrow">Invite a client</h2>
      <div class="sidebox">
        <div class="req-icon a s38">${icon("wifiOff",17)}</div>
        <div><div class="tt">Can't reach the server</div>
        <div class="ts">We couldn't load your client code. Check your connection: this picks back up on its own once you're back online.</div></div>
      </div>`}else{const link=inviteLink(ti.code);const svg=qrSvg(addQuietZone(encodeQR(link,"M")),96,"#0B0D12",`QR code to join ${esc(ti.practiceName)}`);invite=`
      <h2 class="eyebrow">Invite a client</h2>
      <section class="card" style="padding:18px">
        <div class="hq-invite-top">
          <div style="flex:1;min-width:0">
            <h2 class="eyebrow" style="margin:0 0 8px">Client code</h2>
            <div class="code-boxes fit" style="justify-content:flex-start;padding:0">
              ${ti.code.split("").map(ch=>`<div class="cb filled" style="border-color:var(--${hue}-border);background:rgba(var(--${hue}-rgb),0.08)">${esc(ch)}</div>`).join("")}
            </div>
            <div style="font-size:var(--t-xs);font-weight:600;color:var(--text-3);margin-top:10px;line-height:1.4">
              ${offline?"Showing your saved code. Reconnect to share a fresh invite.":"They scan the code or enter it to request to join your practice."}
            </div>
          </div>
          <div>
            <div class="hq-qr">${svg}</div>
            <div class="hq-qcap">SCAN TO JOIN</div>
          </div>
        </div>
        <div class="btn-row mt">
          <button class="btn ghost sm" id="copy-code">${icon("clipboard",16)} Copy code</button>
          <button class="btn sm" id="share-invite" style="background:linear-gradient(150deg,var(--${hue}),var(--${hue}-deep));color:var(--ink-on-accent)"${offline?" disabled":""}>${icon("share",16)} Share invite</button>
        </div>
        ${""}
        ${offline?"":`
        ${""}
        <div style="display:flex;justify-content:center;gap:18px;margin-top:12px">
          <span class="link" id="pc-edit" role="button" tabindex="0" style="font-size:var(--t-xs);font-weight:700">Customize code</span>
          <span class="link" id="pc-regen" role="button" tabindex="0" style="font-size:var(--t-xs);font-weight:700">New code</span>
        </div>
        <div id="pc-editor" style="display:none;margin-top:12px">
          <input id="pc-input" class="ob-input" placeholder="YOUR CODE \xB7 6\u201312 letters/numbers" aria-label="Custom join code" maxlength="12"
            autocapitalize="characters" autocorrect="off" spellcheck="false" style="text-align:center;letter-spacing:0.12em;text-transform:uppercase" />
          <div style="display:flex;justify-content:center;gap:8px;margin-top:10px">
            <button class="btn ghost sm" id="pc-cancel" style="width:auto;padding:0 18px">Cancel</button>
            <button class="btn sm" id="pc-save" style="width:auto;padding:0 22px;background:linear-gradient(150deg,var(--${hue}),var(--${hue}-deep));color:var(--ink-on-accent)">Save code</button>
          </div>
        </div>
        <div id="pc-status" style="font-size:var(--t-sm);font-weight:600;color:var(--text-3);min-height:16px;margin-top:8px;text-align:center"></div>`}
      </section>`}return`
    ${titleHead("Practice HQ",subTitle)}
    ${header}
    ${invite}

    ${""}
    <h2 class="eyebrow">Your practice</h2>
    <section class="card" style="padding:6px 16px">
      <div class="lrow" data-go="coach-insights"><div class="lic" style="background:var(--blue-surface);color:var(--blue-bright)">${icon("bars",17)}</div><div class="lm"><div class="lt">Insights</div><div class="ls">Client trends and standard adherence</div></div>${icon("chevron",17)}</div>
    </section>

    ${""}
    <h2 class="eyebrow">Manage</h2>
    <section class="card" style="padding:6px 16px">
      <div class="lrow" data-go="trainer-profile/settings"><div class="lic">${icon("gear",17)}</div><div class="lm"><div class="lt">Practice settings</div><div class="ls">Standard, AI voice, notifications, appearance</div></div>${icon("chevron",17)}</div>
      <div class="lrow" data-go="trainer-profile/account"><div class="lic">${icon("key",17)}</div><div class="lm"><div class="lt">Account</div><div class="ls">Email, password, billing, delete</div></div>${icon("chevron",17)}</div>
    </section>

    ${""}
    <div style="font-size:var(--t-xs);font-weight:600;color:var(--text-3);margin:12px 4px 0;line-height:1.5">Business health, an AI assistant, branding, and integrations are being built one slice at a time. Each appears here the day it's real.</div>

    ${""}
    <section class="card" style="padding:6px 16px;margin-top:10px">
      <div class="lrow" data-go="welcome"><div class="lic" style="color:var(--red)">${icon("x",17)}</div><div class="lm"><div class="lt" style="color:var(--red)">Sign out</div></div></div>
    </section>
    <div class="co-bottom"></div>
    `},mount(root){wireAvatarUpload(root);wireNameEditor(root);const ti=S.trainerIdentity;wireOperatorAccount(root);const copy=root.querySelector("#copy-code");if(copy)copy.addEventListener("click",async()=>{const ok=await copyText(ti.code||"");copy.innerHTML=ok?`${icon("check",16)} Copied`:"Couldn\u2019t copy";setTimeout(()=>{copy.innerHTML=`${icon("clipboard",16)} Copy code`},1600)});const share=root.querySelector("#share-invite");if(share&&!share.disabled)share.addEventListener("click",async()=>{const url=inviteLink(ti.code);const text=inviteShareText(ti.code,ti.practiceName);try{if(window.OnStandardNative&&window.OnStandardNative.share){window.OnStandardNative.share({title:`Join ${ti.practiceName}`,message:text,url})}else if(navigator.share){await navigator.share({title:`Join ${ti.practiceName}`,text,url})}else if(await copyText(text)){share.innerHTML=`${icon("check",16)} Copied invite`;setTimeout(()=>{share.innerHTML=`${icon("share",16)} Share invite`},1600)}}catch{}});const pcSay=(msg,isErr)=>{const el=root.querySelector("#pc-status");if(el){el.textContent=msg;el.style.color=isErr?"var(--red)":"var(--text-3)"}};const pcApply=code=>{RT.practice={...RT.practice||{},code};if(window.__render)window.__render()};const linkWire=(el,fn)=>{if(el)el.addEventListener("click",fn)};const pcEdit=root.querySelector("#pc-edit");const pcEditor=root.querySelector("#pc-editor");if(pcEdit&&pcEditor)linkWire(pcEdit,()=>{const open=pcEditor.style.display!=="none";pcEditor.style.display=open?"none":"block";if(!open){const inp=root.querySelector("#pc-input");if(inp)inp.focus()}});const pcCancel=root.querySelector("#pc-cancel");if(pcCancel)pcCancel.addEventListener("click",()=>{if(pcEditor)pcEditor.style.display="none";pcSay("",false)});const pcSave=root.querySelector("#pc-save");if(pcSave)pcSave.addEventListener("click",async()=>{const inp=root.querySelector("#pc-input");const raw=String(inp&&inp.value||"").trim().toUpperCase();if(!/^[A-Z0-9]{6,12}$/.test(raw)){pcSay("6\u201312 letters or numbers only (A\u2013Z, 0\u20139).",true);return}pcSave.disabled=true;pcSay("Saving\u2026",false);const r=await setMyPracticeCode(raw);pcSave.disabled=false;if(!r.ok){pcSay(r.error,true);return}pcApply(r.code)});const pcRegen=root.querySelector("#pc-regen");if(pcRegen){let armed=false,regenBusy=false;linkWire(pcRegen,async()=>{if(regenBusy)return;if(!armed){armed=true;pcRegen.textContent="Sure? Old code dies";pcSay("A new code replaces this one immediately. Anyone holding the old code can no longer join.",false);return}regenBusy=true;pcSay("Minting a new code\u2026",false);const r=await regenerateMyPracticeCode();regenBusy=false;armed=false;pcRegen.textContent="New code";if(!r.ok){pcSay(r.error,true);return}pcApply(r.code)})}const prSay=(msg,isErr)=>{const el=root.querySelector("#pr-name-status");if(el){el.textContent=msg;el.style.color=isErr?"var(--red)":"var(--text-3)"}};const prLink=root.querySelector("#pr-rename");const prCard=root.querySelector("#pr-rename-card");if(prLink&&prCard){const toggle=()=>{const open=prCard.style.display!=="none";prCard.style.display=open?"none":"block";if(!open){const inp=root.querySelector("#pr-name-input");if(inp)inp.focus()}};prLink.addEventListener("click",toggle);prLink.addEventListener("keydown",ev=>{if(ev.key==="Enter"||ev.key===" "){ev.preventDefault();toggle()}})}const prCancel=root.querySelector("#pr-name-cancel");if(prCancel)prCancel.addEventListener("click",()=>{if(prCard)prCard.style.display="none";prSay("",false)});const prSave=root.querySelector("#pr-name-save");if(prSave)prSave.addEventListener("click",async()=>{const inp=root.querySelector("#pr-name-input");const name=String(inp&&inp.value||"").trim();if(!name){prSay("Give your practice a name first.",true);return}prSave.disabled=true;prSay("Saving\u2026",false);const r=await renamePractice(RT.practice&&RT.practice.id,name);prSave.disabled=false;if(!r.ok){prSay(r.error,true);return}RT.practice={...RT.practice||{},name:r.name};if(window.__render)window.__render()})}};
