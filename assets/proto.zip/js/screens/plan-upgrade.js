import{canOpenExternalCheckout,storeNotice}from"../store-policy.js";import{RT,act,roleNav}from"../state.js";import{icon}from"../icons.js";import{backHead,alertMsg,statusMsg,esc}from"../components.js";import{PLANS,planCard}from"../ob2.js";import{track,EVENTS}from"../analytics.js";const UP={busy:null,note:null,slots:null,loaded:false,loading:false};async function loadSlots(){if(UP.loading)return;UP.loading=true;try{const roles=await import("../roles.js");UP.slots=await roles.foundingSlotsLeft()}finally{UP.loading=false;UP.loaded=true;if(window.__render)window.__render()}}function listFor(){const role=RT.authRole||"";return role==="trainer"?PLANS.seat:PLANS.org}export const planUpgrade={tab:"profile",hideTabs:true,get nav(){return roleNav()},render(){if(!UP.loaded)void loadSlots();const plans=listFor();const overageRate=RT.authRole==="trainer"?10:15;const founding=canOpenExternalCheckout()&&UP.slots!=null&&UP.slots>0?`<section class="card" style="padding:14px 16px;border-color:var(--green-border);margin-top:14px">
          <div style="display:flex;gap:12px;align-items:center">
            <div class="req-icon g" style="width:40px;height:40px">${icon("flame",19)}</div>
            <div><div style="font-size:14.5px;font-weight:800">Founding 50 \xB7 ${UP.slots} spot${UP.slots===1?"":"s"} left</div>
            <div style="font-size:12px;font-weight:600;color:var(--text-2);line-height:1.5">Today's price locked for good, including the $${overageRate}/mo per active client over your limit. Claimed automatically when you subscribe.</div></div>
          </div>
        </section>`:"";const picked=RT.ob&&RT.ob.plan||null;const wall=RT.planWall?`<div class="sidebox pw-pre warn">
      <div class="req-icon a s38">${icon("lock",17)}</div>
      <div><div class="tt">That needs a plan</div><div class="ts">Your free preview has ended. Your roster is still yours to read; ${esc(RT.planWall)} needs ${canOpenExternalCheckout()?"one of the plans below":"a plan, which is set up from your account on the web"}.</div></div>
    </div>`:"";RT.planWall=null;return`<div id="pu-root">${canOpenExternalCheckout()?backHead("Choose a plan","","settings"):backHead("Your plan","Managed from your account on the web","settings")}
    ${wall}
    ${founding}
    ${""}
    ${!canOpenExternalCheckout()?storeNotice("Team and practice plans are set up from your account on the web, not inside the app.","Your roster, activity and inbox stay readable here either way."):`
    <h2 class="eyebrow" style="margin-top:16px">${picked&&plans.some(p=>p.id===picked)?"Your pick from onboarding":"Plans"}</h2>
    <div style="display:flex;flex-direction:column;gap:10px">
      ${plans.map(p=>{const card=planCard({...p,on:p.id===picked});if(UP.busy===p.id)return`<div aria-busy="true" style="opacity:.6">${card}<div style="font-size:var(--t-sm);font-weight:700;color:var(--text-2);text-align:center;padding:6px 0 0">Opening Stripe\u2026</div></div>`;return UP.busy?`<div style="opacity:.55;pointer-events:none" aria-disabled="true">${card}</div>`:card}).join("")}
    </div>
    ${""}
    <div style="font-size:var(--t-xs);font-weight:600;color:var(--text-3);margin-top:10px">The 14-day trial applies to whichever plan you start first.</div>
    <div style="font-size:11.5px;font-weight:600;color:var(--text-3);line-height:1.55;margin-top:14px">
      Billed by Stripe in your browser. The app never sees your card. Included seats count
      <b>active</b> athletes only: someone who stops logging stops counting, and $${overageRate}/mo covers each
      active athlete beyond your plan. Cancel anytime in your account settings.
    </div>`}
    ${""}
    ${UP.note?UP.note.kind==="error"?alertMsg({text:UP.note.text,style:"color:var(--red);font-size:var(--t-sm);font-weight:700;text-align:center;padding:12px 8px 0"}):statusMsg({text:UP.note.text,style:"display:block;color:var(--text-2);font-size:var(--t-sm);font-weight:700;text-align:center;padding:12px 8px 0"}):""}
    <div style="height:20px"></div></div>`},mount(root){root.querySelectorAll(".ob2-plan").forEach(el=>el.addEventListener("click",async()=>{if(UP.busy)return;const planId=el.getAttribute("data-val");const plan=listFor().find(p=>p.id===planId);if(!plan)return;if(plan.custom){try{window.OnStandardNative?.openUrl?.("https://onstandard.app/coaches#pricing")}catch{}UP.note={kind:"info",text:"Enterprise is quoted. Email support@onstandard.app and we\u2019ll set it up with you."};window.__render&&window.__render();return}UP.busy=planId;UP.note=null;window.__render&&window.__render();track(EVENTS.PLAN_SELECTED,{plan:planId});const roles=await import("../roles.js");const r=await roles.startPlanCheckout(planId,"monthly");UP.busy=null;if(r.ok){try{act.markObPlanCtaDone()}catch{}if(window.OnStandardNative?.openUrl){window.OnStandardNative.openUrl(r.url);window.__render&&window.__render()}else location.href=r.url;return}if(r.action==="portal"){UP.note={kind:"info",text:"You already have a plan. Opening your billing portal to change it."};window.__render&&window.__render();const p=await roles.openBillingPortal();if(p.ok){if(window.OnStandardNative?.openUrl)window.OnStandardNative.openUrl(p.url);else location.href=p.url}else{UP.note={kind:"error",text:p.error||"Could not open the billing portal. Try again."};window.__render&&window.__render()}return}UP.note={kind:"error",text:r.error||"Could not start checkout. Try again."};window.__render&&window.__render()}))}};
