import{S,RT,act,roleNav,roleProfileRoute}from"../state.js";import{icon}from"../icons.js";import{backHead,esc}from"../components.js";import{track,EVENTS}from"../analytics.js";import{buzz}from"../motion.js";const KINDS=[{cat:"bug",ic:"flash",t:"Something's broken",s:"A screen, a number or a photo that went wrong"},{cat:"idea",ic:"sparkle",t:"I have an idea",s:"Something that would make this better for you"},{cat:"question",ic:"message",t:"A question",s:"How something works, or what a number means"},{cat:"billing",ic:"clipboard",t:"Billing or my plan",s:"Payments, invoices, seats, cancelling"}];const SAFETY={cat:"safety",ic:"shield",t:"A safety concern",s:"Something about a person\u2019s wellbeing. Goes straight to the top of the queue."};const LABEL=Object.fromEntries([...KINDS,SAFETY].map(k=>[k.cat,k.t]));const F={cat:null,subject:"",body:"",sending:false,sent:null,error:null,from:"settings",origin:null};function reset(from,cat){F.cat=cat||null;F.subject="";F.body="";F.sending=false;F.sent=null;F.error=null;F.from=from;const r=routeNow();F.origin=r&&r!=="feedback"?r:from||null}function routeNow(){if(typeof location==="undefined")return null;return String(location.hash||"").replace(/^#/,"").split("/")[0]||null}let PRIMED=false;export function openFeedback(from="settings",cat=null){reset(from,cat);PRIMED=true;track(EVENTS.FEEDBACK_OPENED,{from})}function bugContext(){const bits=[["role",RT.authRole||"unknown"],["app",typeof window!=="undefined"&&window.__APP_VERSION||"dev"],["proto",typeof window!=="undefined"&&window.__PROTO_VERSION||"dev"],["screen",F.origin||"unknown"],["sync",S.syncIssue||"ok"],["online",typeof navigator==="undefined"?"unknown":String(navigator.onLine!==false)]];return bits.map(([k,v])=>`${k}: ${v}`).join("\n")}async function sendTicket(cat,subject,body){const roles=await import("../roles.js");try{return await roles.createSupportTicket(cat,subject,body)}catch(e){const msg=String(e&&e.message||e).toLowerCase();if(cat==="idea"&&msg.includes("invalid category")){return await roles.createSupportTicket("question",`[Idea] ${subject}`.slice(0,200),body)}throw e}}export const feedback={tab:"profile",hideTabs:true,get nav(){return roleNav()},render(){if(typeof document!=="undefined"&&!document.querySelector("#fb-root")&&!PRIMED){reset("settings",null);track(EVENTS.FEEDBACK_OPENED,{from:"settings"})}PRIMED=false;const exit=F.origin&&F.origin!=="feedback"?F.origin:roleProfileRoute();if(F.sent){return`<div id="fb-root">${backHead("Sent",LABEL[F.sent]||"Thank you",exit)}
      <section class="card" style="padding:22px 18px;text-align:center;margin-top:14px">
        <div class="req-icon g" style="width:52px;height:52px;margin:0 auto 14px">${icon("check",25)}</div>
        <div style="font-size:18px;font-weight:800;letter-spacing:var(--title-tight)">That's with us.</div>
        <div style="font-size:13.5px;font-weight:600;color:var(--text-2);line-height:1.55;margin-top:8px">
          We read every one. You'll hear back if it needs a reply.
        </div>
      </section>
      <div style="height:14px"></div>
      <button class="btn ghost sm" style="width:100%" data-go="${esc(exit)}">Done</button></div>`}if(!F.cat){const row=k=>`
        <div class="lrow" data-fb-kind="${k.cat}" role="button" tabindex="0">
          <div class="lic">${icon(k.ic,16)}</div>
          <div class="lm"><div class="lt">${esc(k.t)}</div><div class="ls" style="white-space:normal;line-height:1.45">${esc(k.s)}</div></div>
          ${icon("chevron",16,'style="color:var(--text-3)"')}
        </div>`;return`<div id="fb-root">${backHead("Send feedback","We read all of it",exit)}
      <section class="card" style="padding:6px 16px;margin-top:14px">${KINDS.map(row).join("")}</section>
      <h2 class="eyebrow" style="margin-top:18px">Urgent</h2>
      <section class="card" style="padding:6px 16px;border-color:var(--red-border)">
        <div class="lrow" data-fb-kind="safety" role="button" tabindex="0">
          <div class="lic" style="color:var(--red-bright)">${icon(SAFETY.ic,16)}</div>
          <div class="lm"><div class="lt">${esc(SAFETY.t)}</div><div class="ls" style="white-space:normal;line-height:1.45">${esc(SAFETY.s)}</div></div>
          ${icon("chevron",16,'style="color:var(--text-3)"')}
        </div>
      </section>
      <div style="height:20px"></div></div>`}const safety=F.cat==="safety";const bug=F.cat==="bug";return`<div id="fb-root"><div class="back-head">
      <div class="bk" id="fb-back" role="button" tabindex="0" aria-label="Back">${icon("back",20)}</div>
      <div class="bh-t"><h1 class="ht">${esc(LABEL[F.cat]||"Send feedback")}</h1>
      <div class="hs">${esc(safety?"Straight to the top of the queue":"As much or as little as you like")}</div></div>
    </div>
    <section class="card" style="padding:16px;margin-top:14px${safety?";border-color:var(--red-border)":""}">
      <label class="eyebrow" for="fb-subject" style="display:block">One line</label>
      <input class="ob-input" id="fb-subject" maxlength="200" style="margin-top:8px"
        placeholder="${esc(bug?"The score on Home showed 0":safety?"What is happening":"What it is")}"
        value="${esc(F.subject)}" />
      <label class="eyebrow" for="fb-body" style="display:block;margin-top:16px">More, if it helps</label>
      <textarea class="ob-input" id="fb-body" maxlength="4000" rows="6" style="margin-top:8px;resize:vertical"
        placeholder="${esc(bug?"What you were doing when it happened.":safety?"Anything you can tell us. A person reads this.":"Whatever you want us to know.")}">${esc(F.body)}</textarea>
      ${bug?`<div style="font-size:11.5px;font-weight:600;color:var(--text-3);line-height:1.5;margin-top:10px">
        Your app version and the screen you were on are attached automatically. You don't have to describe them.
      </div>`:""}
    </section>
    ${F.error?`<div style="font-size:12.5px;font-weight:700;color:var(--red-bright);text-align:center;padding:12px 16px 0">${esc(F.error)}</div>`:""}
    <div style="height:16px"></div>
    <button class="btn primary" id="fb-send" style="width:100%"${F.sending?" disabled":""}>
      ${F.sending?"Sending\u2026":`${icon("check",18)} Send`}
    </button>
    <div style="height:10px"></div>
    <button class="btn ghost sm" id="fb-other" style="width:100%">Pick a different kind</button>
    <div style="height:20px"></div></div>`},mount(root){root.querySelectorAll("[data-fb-kind]").forEach(el=>{el.addEventListener("click",()=>{F.cat=el.getAttribute("data-fb-kind");F.error=null;window.__render&&window.__render()})});const toPicker=()=>{F.cat=null;F.error=null;window.__render&&window.__render()};const back=root.querySelector("#fb-back");if(back){back.addEventListener("click",toPicker);back.addEventListener("keydown",e=>{if(e.key==="Enter"||e.key===" "){e.preventDefault();toPicker()}})}const other=root.querySelector("#fb-other");if(other)other.addEventListener("click",toPicker);const sub=root.querySelector("#fb-subject");const body=root.querySelector("#fb-body");if(sub)sub.addEventListener("input",()=>{F.subject=sub.value});if(body)body.addEventListener("input",()=>{F.body=body.value});const send=root.querySelector("#fb-send");if(send)send.addEventListener("click",async()=>{if(F.sending)return;const subject=(F.subject||"").trim();if(subject.length<3){F.error="Give it one line first, even a few words.";window.__render&&window.__render();return}F.sending=true;F.error=null;window.__render&&window.__render();let bodyText=(F.body||"").trim();if(F.cat==="bug")bodyText=`${bodyText}

---
${bugContext()}`.trim();try{await sendTicket(F.cat,subject,bodyText.slice(0,4e3));track(EVENTS.FEEDBACK_SENT,{category:F.cat});buzz("reveal");F.sent=F.cat;F.sending=false}catch(e){const msg=String(e&&e.message||e).toLowerCase();F.sending=false;F.error=msg.includes("rate limit")?"That's a few in a row. Give it an hour and send the rest.":msg.includes("not authenticated")?"Sign in first, then send this. It needs to reach your account.":"That didn't send. Nothing was lost. Try again, or email support@onstandard.app."}window.__render&&window.__render()})}};
