import{S,RT,roleNav,notifsFetchFailed}from"../state.js";import{icon}from"../icons.js";import{backHead,esc,skeletonRows,emptyState}from"../components.js";const isOperator=()=>RT.authRole==="coach"||RT.authRole==="trainer";function notif(n,read){return`<div class="notif ${n.level} ${read?"read":"unread"}" ${n.route?`data-go="${n.route}" style="cursor:pointer"`:""}>
    <div class="nic">${icon(n.icon,19)}</div>
    <div style="flex:1">
      <span class="level-tag ${n.level}">${n.tag||{high:"urgent",medium:"reminder",positive:"nice work",critical:"now",info:"announcement"}[n.level]||n.level}</span>
      <div class="nt">${esc(n.title)}</div>
      <div class="nb">${esc(n.body)}</div>
    </div>
    ${""}
    <span class="nmeta"><span class="nw">${n.when}</span>${read?"":'<span class="udot" aria-hidden="true"></span>'}${n.route?icon("chevron",15,'style="color:var(--text-3)"'):""}</span>
  </div>`}let VISIT={settled:false,fetching:false,snap:null};const keyOf=n=>n.server?`s:${n.id||n.title}`:`d:${n.title}`;export default{get nav(){return roleNav()},tab:"home",async mount(){if(VISIT.settled||VISIT.fetching)return;VISIT.fetching=true;try{await window.__act.loadNotifications()}catch{}const N=S.notifications;const rowsRead=S.unreadNotifs===0;const snap=new Set;for(const n of[...N.new,...N.earlier]){const unread=n.server?!n.read:!rowsRead;if(unread)snap.add(keyOf(n))}VISIT.snap=snap;VISIT.settled=true;VISIT.fetching=false;window.__act.readNotifs();if(window.__render)window.__render()},render(){if(typeof document!=="undefined"&&!document.querySelector("#ntf-root")){VISIT={settled:false,fetching:false,snap:null}}if(!VISIT.settled){return`<div id="ntf-root">
      ${backHead("Notifications","")}
      ${skeletonRows(3,"Checking notifications")}
      </div>`}const N=S.notifications;const snap=VISIT.snap||new Set;const isNew=n=>snap.has(keyOf(n));const row=n=>notif(n,!isNew(n));const hasRows=N.new.length||N.earlier.length;const newCount=[...N.new,...N.earlier].filter(isNew).length;return`<div id="ntf-root">
    ${backHead("Notifications","")}

    ${""}
    ${hasRows?newCount>0?N.new.some(isNew)?"":`<div class="nhead"><span class="nsummary"><span class="cnt">${newCount}</span> new</span></div>`:`<div class="nhead"><span class="nsummary allclear">${icon("checkCircle",16)} All caught up</span></div>`:""}

    ${N.new.length?`<h2 class="eyebrow">${N.new.some(isNew)?`New \xB7 ${newCount}`:"Recent"}</h2>${N.new.map(row).join("")}`:""}

    ${N.earlier.length?`<h2 class="eyebrow">Earlier</h2>${N.earlier.map(row).join("")}`:""}

    ${!hasRows&&notifsFetchFailed?`
    <div class="ne-empty">
      <div class="ne-ring" style="color:var(--amber-bright)">${icon("wifiOff",30)}</div>
      <div class="ne-t">Couldn't check notifications</div>
      <div class="ne-s">Nothing was cleared; this screen just couldn't reach the server. It retries on its own, so check back in a moment.</div>
    </div>`:""}
    ${!hasRows&&!notifsFetchFailed?`
    ${emptyState({icon:"checkCircle",title:"You're all caught up",body:`No accountability moments waiting. When something needs you, it lands here first: ${isOperator()?"meals the AI flags for your eyes, join requests and roll-call escalations, and your weekly team digest.":"meal and weigh-in nudges, requirements your coach adds, and streak reminders before midnight."}`})}`:""}

    <div style="height:6px"></div>
    <div class="sidebox" data-go="${isOperator()?"coach-notif-settings":"notif-settings"}" style="cursor:pointer">
      <div class="req-icon b s38">${icon("gear",17)}</div>
      <div style="flex:1"><div class="tt">Notification settings</div>
      <div class="ts">${isOperator()?"What reaches you, and when.":S.coach.hasCoach?`${esc(S.coach.name)} sets urgency. You set tone and quiet hours.`:"Tone and quiet hours."}</div></div>
      ${icon("chevron",17,'style="color:var(--text-3)"')}
    </div>
    <div style="height:10px"></div>
    </div>`}};
