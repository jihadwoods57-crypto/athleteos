import{isIOSApp}from"../store-policy.js";import{backHead,esc}from"../components.js";import{icon}from"../icons.js";import{RT}from"../state.js";import*as roles from"../roles.js";import{track,EVENTS}from"../analytics.js";import{CONSUMER_PLANS,planById,productId,cadencePriceParts,effectiveMonthly,annualSavings,fmtPrice,disclosure,storeName}from"../pricing.js";let UI={cadence:"annual",planId:"individual",busy:false,iapReady:null,probing:false,status:null};function planCard(p){const selected=p.id===UI.planId;const parts=cadencePriceParts(p,UI.cadence);const sub=UI.cadence==="annual"?`${fmtPrice(effectiveMonthly(p))}/mo \xB7 billed yearly \xB7 save ${fmtPrice(annualSavings(p))}`:"billed monthly";const seat=p.seatLimit?`<span class="status-pill b" style="margin-left:6px">Up to ${p.seatLimit}</span>`:"";return`
  <div class="pw-plan${selected?" on":""}" data-pw-plan="${p.id}" role="button" tabindex="0" aria-pressed="${selected}">
    <div class="pw-plan-top">
      <div class="pw-plan-name">${esc(p.name)}${seat}</div>
      <div class="pw-plan-price"><span class="n">${parts.amount}</span><span class="per">${parts.per}</span></div>
    </div>
    <div class="pw-plan-sub">${esc(sub)}</div>
    <div class="pw-plan-blurb">${esc(p.blurb)}</div>
  </div>`}function ctaState(){const p=planById(UI.planId);if(!p)return"";if(UI.status&&UI.status.kind==="ok"){return`<button class="btn primary" data-go="progress" style="width:100%">See your progress</button>`}if(UI.busy)return`<button class="btn primary" style="width:100%" disabled>Opening the store\u2026</button>`;if(UI.iapReady!==true){const notBuyable=isIOSApp()?"Update the app to join":"Join in the OnStandard app";return`<button class="btn primary" disabled>${UI.iapReady===null?"Checking the store\u2026":notBuyable}</button>`}const label=p.trialDays>0?`Start ${p.trialDays}-day free trial`:`Start ${esc(p.name)}`;return`<button class="btn primary" id="pw-buy" style="width:100%">${label}</button>
    <div class="pw-note">${esc(disclosure(p,UI.cadence))} No charge today.</div>`}function checkingSkeleton(){const card=`<div class="pw-plan sk-card">
      <div class="pw-plan-top"><div class="sk-line pw-sk-name"></div><div class="sk-line pw-sk-price"></div></div>
      <div class="sk-line pw-sk-sub"></div>
      <div class="sk-line pw-sk-blurb"></div>
    </div>`;return`<div class="pw-skel" aria-hidden="true">
    <div class="sk-line pw-sk-toggle"></div>
    <div class="pw-plans">${card.repeat(CONSUMER_PLANS.length)}</div>
  </div>`}function statusBanner(){const s=UI.status;if(!s)return"";if(s.kind==="ok"){return`<div class="sidebox" style="margin-top:10px"><div class="req-icon g s38">${icon("check",18)}</div>
      <div><div class="tt">You're a member</div><div class="ts">Premium is unlocked. Your report and Deep Dive are ready.</div></div></div>`}if(s.kind==="error"){return`<div style="color:var(--red);font-size:13px;font-weight:600;margin-top:10px;text-align:center">${esc(s.message||"Something went wrong. You weren't charged.")}</div>`}if(s.kind==="info"){return`<div style="color:var(--text-2);font-size:var(--t-sm);font-weight:600;margin-top:10px;text-align:center">${esc(s.message||"")}</div>`}return""}export default{tab:"progress",render(){const ind=planById("individual");const savePct=ind?Math.round(annualSavings(ind)/(ind.monthly*12)*100):0;return`${backHead("Membership","Unlock the written coaching","progress")}

    ${""}
    ${UI.iapReady===false?`
    ${""}
    ${isIOSApp()?`<div class="sidebox">
      <div class="req-icon b s38">${icon("download",17)}</div>
      <div><div class="tt">Update OnStandard to join</div>
      <div class="ts">This version of the app was built before memberships opened. The App Store has the current one; your stats are always yours either way.</div></div>
    </div>`:`
    ${""}
    <div class="sidebox pw-pre">
      <div class="req-icon b s38">${icon("download",17)}</div>
      <div><div class="tt">Memberships are bought in the OnStandard app</div>
      <div class="ts">The plans below are the ones the app sells. Nothing on this screen charges you.</div></div>
    </div>`}
    ${isIOSApp()?"":'<h2 class="eyebrow">The plans</h2>'}`:""}

    ${""}
    ${""}
    ${UI.iapReady===null?`
    ${isIOSApp()?"":checkingSkeleton()}
    <div class="pw-buy-wrap">${ctaState()}</div>`:isIOSApp()&&UI.iapReady===false?"":`
    <div class="pw-toggle">
      <button class="pw-seg${UI.cadence==="annual"?" on":""}" data-pw-cadence="annual" aria-pressed="${UI.cadence==="annual"}">Annual <span class="status-pill b pw-save">Save ${savePct}%</span></button>
      <button class="pw-seg${UI.cadence==="monthly"?" on":""}" data-pw-cadence="monthly" aria-pressed="${UI.cadence==="monthly"}">Monthly</button>
    </div>

    <div class="pw-plans">
      ${CONSUMER_PLANS.map(planCard).join("")}
    </div>

    ${""}
    <div class="pw-buy-wrap">
      ${ctaState()}
    </div>`}
    ${statusBanner()}

    ${""}
    <div class="pw-note pw-legal"><a class="link" href="https://onstandard.app/terms" target="_blank" rel="noopener">Terms of Use</a> \xB7 <a class="link" href="https://onstandard.app/privacy" target="_blank" rel="noopener">Privacy Policy</a></div>

    <div style="text-align:center;margin-top:14px">
      <button class="btn ghost sm" id="pw-restore" style="width:auto;padding:0 18px">Restore purchases</button>
    </div>

    <div style="height:12px"></div>
    <div style="text-align:center;font-size:11.5px;font-weight:600;color:var(--text-3);padding:0 20px;line-height:1.4">Your stats are always yours. Membership adds the written coaching, not the numbers. Cancel anytime in ${storeName()}.</div>
    <div style="height:14px"></div>
    `},async mount(root){root.querySelectorAll("[data-pw-cadence]").forEach(el=>el.addEventListener("click",()=>{UI.cadence=el.getAttribute("data-pw-cadence")==="monthly"?"monthly":"annual";if(window.__render)window.__render()}));root.querySelectorAll("[data-pw-plan]").forEach(el=>el.addEventListener("click",()=>{const id=el.getAttribute("data-pw-plan");if(planById(id)){UI.planId=id;if(window.__render)window.__render()}}));const restore=root.querySelector("#pw-restore");if(restore)restore.addEventListener("click",async()=>{restore.disabled=true;restore.textContent="Restoring\u2026";let res=null;try{res=await roles.restoreConsumerPurchases(RT.userId)}catch{res=null}if(res&&res.ok)UI.status={kind:"ok"};else if(res&&res.reason==="unavailable")UI.status={kind:"info",message:"Purchases restore once memberships are live."};else if(res&&res.ok===false&&res.reason!=="error")UI.status={kind:"info",message:"Nothing to restore on this account."};else UI.status={kind:"error",message:"Couldn't check. Nothing changed. Try again."};if(window.__render)window.__render()});if(UI.iapReady===null){if(UI.probing)return;UI.probing=true;const probe=roles.iapAvailable();UI.iapReady=await Promise.race([probe,new Promise(resolve=>setTimeout(()=>resolve(false),4e3))]);if(window.__render)window.__render();probe.then(ok=>{if(ok!==UI.iapReady){UI.iapReady=ok;if(window.__render)window.__render()}},()=>{});return}const buy=root.querySelector("#pw-buy");if(buy)buy.addEventListener("click",async()=>{const p=planById(UI.planId);if(!p)return;UI.busy=true;UI.status=null;if(window.__render)window.__render();track(EVENTS.TRIAL_STARTED,{plan:UI.planId,cadence:UI.cadence});const res=await roles.purchaseConsumerPlan(productId(UI.planId,UI.cadence),RT.userId);UI.busy=false;if(res&&res.ok)UI.status={kind:"ok"};else if(res&&res.reason==="cancelled")UI.status=null;else if(res&&res.reason==="unavailable")UI.iapReady=false;else UI.status={kind:"error",message:res&&res.message};if(window.__render)window.__render()})}};
