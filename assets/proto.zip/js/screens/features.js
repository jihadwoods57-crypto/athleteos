import { S, RT, act } from '../state.js';
import { icon } from '../icons.js';
import { backHead, esc } from '../components.js';
import * as roles from '../roles.js';
import * as CD from '../coach-data.js';

/* ============================================================
   The 11 approved ideas, made walkable. Live where possible,
   honestly framed as preview where the backend must exist first.
   ============================================================ */

/* ---------- #devices · Connect Apple Health / Health Connect (0134-adjacent, display-only) ----------
   Reads sleep / HRV / resting HR for CONTEXT on the recovery check-in — it never changes the
   score (self-report stays authoritative; the blend path is founder-gated). The screen self-gates
   on the live native probe: until the founder wires the health module (src/lib/health), the
   connect affordance stays hidden everywhere and a stale #devices deep link redirects to Profile,
   so there is no reachable "coming soon". Lights up automatically once the module is wired. */
let DEV = { checked: false, available: false, connected: false, sample: null, busy: false };
async function probeHealth() {
  DEV.available = await roles.healthAvailable();
  if (!DEV.available) { DEV.checked = true; location.hash = '#profile'; return; } // safe landing
  DEV.connected = await roles.healthConnected();
  if (DEV.connected) DEV.sample = await roles.healthRead();
  DEV.checked = true;
  if (window.__render) window.__render();
}
function fmtSleep(h) { if (h == null) return '—'; const H = Math.floor(h), M = Math.round((h - H) * 60); return `${H}h${M ? ` ${M}m` : ''}`; }
function readingRow(icn, label, val) {
  return `<div class="lrow" style="cursor:default"><div class="lic">${icon(icn, 17)}</div><div class="lm"><div class="lt">${esc(label)}</div></div><span class="lv">${esc(val)}</span></div>`;
}
export const devices = {
  tab: 'profile',
  render() {
    const head = backHead('Connect a device', 'Apple Health & Health Connect', 'profile');
    if (!DEV.checked || !DEV.available) {
      return `${head}<div class="sidebox"><div class="req-icon b" style="width:38px;height:38px">${icon('moon', 17)}</div><div><div class="tt">Checking your device…</div></div></div>`;
    }
    if (!DEV.connected) {
      return `${head}
      <section class="card pad">
        <div style="font-size:15.5px;font-weight:800">Bring your recovery data in</div>
        <div style="font-size:12.5px;font-weight:600;color:var(--text-2);margin-top:6px;line-height:1.5">Connect and your last-night <b>sleep</b>, <b>HRV</b>, and <b>resting heart rate</b> show up here as context for your recovery check-in. Read-only — it never changes your score.</div>
        <button class="btn green" id="dev-connect" style="width:100%;margin-top:14px" ${DEV.busy ? 'disabled' : ''}>${DEV.busy ? 'Connecting…' : 'Connect Apple Health / Health Connect'}</button>
      </section>`;
    }
    const s = DEV.sample || {};
    const any = s.sleepHours != null || s.hrvMs != null || s.restingHr != null;
    return `${head}
    <section class="card pad"><span class="status-pill g">Connected</span>
      <div style="height:10px"></div>
      ${any ? `<div class="eyebrow" style="margin:2px 0 4px">Last night</div>
      ${s.sleepHours != null ? readingRow('moon', 'Sleep', fmtSleep(s.sleepHours)) : ''}
      ${s.hrvMs != null ? readingRow('bolt', 'HRV', `${Math.round(s.hrvMs)} ms`) : ''}
      ${s.restingHr != null ? readingRow('bolt', 'Resting HR', `${Math.round(s.restingHr)} bpm`) : ''}`
      : `<div style="font-size:13px;font-weight:600;color:var(--text-2)">Connected — no reading yet. Your next sync will show last night's sleep, HRV, and resting heart rate here.</div>`}
    </section>
    <div style="text-align:center;font-size:11.5px;font-weight:600;color:var(--text-3);margin-top:12px;padding:0 20px;line-height:1.4">Shown for context. Your recovery score still comes from your own check-in.</div>`;
  },
  mount(root) {
    if (!DEV.checked) probeHealth();
    const c = root.querySelector('#dev-connect');
    if (c) c.addEventListener('click', async () => {
      DEV.busy = true; if (window.__render) window.__render();
      const r = await roles.healthConnect();
      DEV.busy = false;
      if (r && r.connected) { DEV.connected = true; DEV.sample = await roles.healthRead(); }
      if (window.__render) window.__render();
    });
  },
};

/* ---------- #recruiting · Discipline Record (spec §17) ---------- */
export const recruiting = {
  tab: 'profile',
  render() {
    const P = S.progress;
    const hist = S.history; // newest first, real day rows
    const range = hist.length
      ? `${hist[hist.length - 1].date} – today`
      : 'Started today';
    const avgAll = hist.length
      ? Math.round((hist.reduce((a, h) => a + (h.score || 0), 0) + S.score) / (hist.length + 1))
      : S.score;
    const onPct = hist.length
      ? Math.round(([...hist.map(h => h.score), S.score].filter(s => s >= 80).length / (hist.length + 1)) * 100)
      : null;
    const verified = S.coach.hasCoach;
    return `
    ${backHead('Discipline Record', 'Your real execution, yours to share', 'profile')}

    <section class="card pad" style="border-color:${verified ? 'var(--green-border)' : 'var(--hairline)'}">
      <div style="display:flex;align-items:center;gap:14px">
        <div class="req-icon ${verified ? 'g' : 'b'}" style="width:52px;height:52px;border-radius:16px">${icon('shield', 25)}</div>
        <div style="flex:1">
          <div style="font-size:17px;font-weight:800">${esc([S.athlete.name, S.athlete.position].filter(Boolean).join(' · '))}</div>
          <div style="font-size:12.5px;font-weight:600;color:${verified ? 'var(--green-bright)' : 'var(--text-3)'};margin-top:3px">
            ${verified ? `Verified by ${esc(S.coach.name)} · ${esc(range)}` : `Not verified yet · ${esc(range)}`}</div>
        </div>
      </div>
      ${P.daysLogged > 0 ? `
      <div class="macro-row" style="margin-top:16px">
        <div class="macro"><div class="mv">${P.daysLogged}</div><div class="mk">Days tracked</div></div>
        <div class="macro"><div class="mv" style="color:var(--green-bright)">${avgAll}</div><div class="mk">Avg score</div></div>
        ${onPct != null ? `<div class="macro"><div class="mv">${onPct}%</div><div class="mk">On standard</div></div>` : ''}
      </div>
      <div class="macro-row" style="margin-top:8px">
        <div class="macro"><div class="mv" style="color:var(--amber-bright)">${P.bestStreak}d</div><div class="mk">Best streak</div></div>
        <div class="macro"><div class="mv" style="color:var(--amber-bright)">${S.streakDays}d</div><div class="mk">Current streak</div></div>
        ${P.weekAvg != null ? `<div class="macro"><div class="mv">${P.weekAvg}</div><div class="mk">Recent avg</div></div>` : ''}
      </div>` : `
      <div style="font-size:13px;font-weight:600;color:var(--text-2);margin-top:14px">Your record builds as you log. A few days in, your real average, consistency, and streaks show up here.</div>`}
    </section>

    ${verified ? '' : `
    <div class="sidebox" style="margin-top:12px">
      <div class="req-icon b" style="width:38px;height:38px">${icon('users', 17)}</div>
      <div><div class="tt">Not verified yet</div>
      <div class="ts">Connect a coach to begin building a verified record — verification means a real coach watches the same numbers.</div>
      <div style="margin-top:8px"><button class="btn ghost sm" data-go="connect" style="width:auto;padding:0 18px">Connect a coach</button></div></div>
    </div>`}

    <div class="eyebrow">Why a recruiter cares</div>
    <div class="sidebox">
      <div class="req-icon b" style="width:38px;height:38px">${icon('bars', 17)}</div>
      <div><div class="tt">Film shows talent. This shows habits.</div>
      <div class="ts">Verified daily execution is a signal no highlight reel carries: this athlete does the work when nobody claps.</div></div>
    </div>

    <div style="height:16px"></div>
    <div class="sidebox">
      <div class="req-icon g" style="width:38px;height:38px">${icon('lock', 17)}</div>
      <div><div class="tt">Private by default</div>
      <div class="ts">Nothing here is public and nothing is shared unless you explicitly share it. You control who ever sees this record.</div></div>
    </div>
    <div style="height:10px"></div>
    `;
  },
};

/* ---------- #restrictions · Food restrictions & allergies (spec §18) ----------
   Three SEPARATE data types — allergies (with per-allergen severity), intolerances, and
   dietary preferences — never one undifferentiated chip list. Custom entries allowed in
   every section. Selected state is unmistakable (filled chip + check). Safety copy never
   claims guaranteed detection. Structured data lives in RT.restrictions; the flat
   RT.allergies summary list keeps every existing consumer (meal guardian, profile row)
   working unchanged. */
const ALLERGY_OPTS = ['Peanuts', 'Tree nuts', 'Shellfish', 'Eggs', 'Fish', 'Soy', 'Wheat', 'Sesame'];
const INTOLERANCE_OPTS = ['Dairy', 'Gluten', 'Caffeine'];
const PREFERENCE_OPTS = ['Vegetarian', 'Vegan', 'Halal', 'Kosher', 'Pescatarian'];

function currentRestrictions() {
  const r = RT.restrictions;
  if (r && typeof r === 'object') {
    return {
      allergies: Array.isArray(r.allergies) ? r.allergies : [],
      intolerances: Array.isArray(r.intolerances) ? r.intolerances : [],
      preferences: Array.isArray(r.preferences) ? r.preferences : [],
    };
  }
  // Legacy migration: old flat strings like "Peanuts · severe" / "Dairy" / "Vegetarian".
  const out = { allergies: [], intolerances: [], preferences: [] };
  for (const s of RT.allergies || []) {
    const name = String(s).split('·')[0].trim();
    const severe = /severe/i.test(String(s));
    if (PREFERENCE_OPTS.includes(name)) out.preferences.push(name);
    else if (INTOLERANCE_OPTS.includes(name)) out.intolerances.push(name);
    else out.allergies.push({ name, severity: severe ? 'severe' : 'moderate' });
  }
  return out;
}

export const restrictions = {
  tab: 'profile',
  render() {
    const R = currentRestrictions();
    const has = (arr, n) => arr.some((x) => (x.name || x) === n);
    const sevOf = (n) => { const a = R.allergies.find((x) => x.name === n); return a ? a.severity : 'severe'; };
    const chip = (n, on) => `<span class="chp rx-chip ${on ? 'on' : ''}" data-name="${esc(n)}">${on ? '✓ ' : ''}${esc(n)}</span>`;
    const customs = (arr, opts) => arr.map((x) => x.name || x).filter((n) => !opts.includes(n));
    return `
    ${backHead('Food Restrictions', 'Allergies, intolerances, and preferences — kept separate', 'profile')}

    <div class="eyebrow">Allergies · medical, taken seriously</div>
    <div class="chip-row" id="rx-allergies">
      ${[...ALLERGY_OPTS, ...customs(R.allergies, ALLERGY_OPTS)].map((n) => chip(n, has(R.allergies, n))).join('')}
    </div>
    <div id="rx-severity"></div>
    <div class="rx-add"><input class="input" id="rx-add-allergy" maxlength="30" placeholder="Add another allergen…" /><button class="btn ghost sm rx-add-btn" data-add="allergy">Add</button></div>

    <div class="eyebrow">Intolerances</div>
    <div class="chip-row" id="rx-intolerances">
      ${[...INTOLERANCE_OPTS, ...customs(R.intolerances, INTOLERANCE_OPTS)].map((n) => chip(n, R.intolerances.includes(n))).join('')}
    </div>
    <div class="rx-add"><input class="input" id="rx-add-intolerance" maxlength="30" placeholder="Add an intolerance…" /><button class="btn ghost sm rx-add-btn" data-add="intolerance">Add</button></div>

    <div class="eyebrow">Dietary preferences</div>
    <div class="chip-row" id="rx-preferences">
      ${[...PREFERENCE_OPTS, ...customs(R.preferences, PREFERENCE_OPTS)].map((n) => chip(n, R.preferences.includes(n))).join('')}
    </div>
    <div class="rx-add"><input class="input" id="rx-add-preference" maxlength="30" placeholder="Add a preference…" /><button class="btn ghost sm rx-add-btn" data-add="preference">Add</button></div>

    <div class="eyebrow">How checking works</div>
    <section class="card" style="padding:6px 16px">
      ${[
        ['camera', 'Detected foods are compared', 'The app compares detected foods and label entries with your saved restrictions. Detection may miss ingredients, preparation methods, or cross-contact.'],
        ['bell', 'Severe allergies warn loudest', 'A possible severe-allergen conflict warns you before you confirm the log — it names the allergen and tells you what it can’t be sure of.'],
        ['shield', 'Always verify severe allergens yourself', 'This never replaces reading labels, asking staff, or medical guidance. Treat every severe allergen as unverified until you check it.'],
      ].map(([ic, t, s]) => `
        <div class="lrow" style="cursor:default">
          <div class="lic">${icon(ic, 17)}</div>
          <div class="lm"><div class="lt">${t}</div><div class="ls" style="white-space:normal;line-height:1.4">${s}</div></div>
        </div>`).join('')}
    </section>

    <div style="height:16px"></div>
    <button class="btn primary" id="save-allergies">${icon('check', 18)} Save</button>
    <div style="height:10px"></div>
    `;
  },
  mount(root) {
    // Live severity panel for selected allergies (severe = loud warning; moderate = note).
    const R = currentRestrictions();
    const severity = {};
    R.allergies.forEach((a) => { severity[a.name] = a.severity || 'severe'; });
    const sevPanel = root.querySelector('#rx-severity');
    const paintSeverity = () => {
      const on = [...root.querySelectorAll('#rx-allergies .chp.on')].map((c) => c.getAttribute('data-name'));
      sevPanel.innerHTML = on.length ? `<section class="card" style="padding:4px 14px;margin-top:8px">${on.map((n) => `
        <div class="lrow" style="cursor:default">
          <div class="lm"><div class="lt" style="font-size:13px">${esc(n)}</div></div>
          <div class="seg" style="width:170px" data-sev="${esc(n)}">
            <button class="${(severity[n] || 'severe') === 'severe' ? 'on' : ''}">Severe</button>
            <button class="${(severity[n] || 'severe') === 'moderate' ? 'on' : ''}">Moderate</button>
          </div>
        </div>`).join('')}</section>` : '';
      sevPanel.querySelectorAll('[data-sev]').forEach((seg) => {
        const name = seg.getAttribute('data-sev');
        const [sv, md] = seg.querySelectorAll('button');
        sv.addEventListener('click', () => { severity[name] = 'severe'; sv.classList.add('on'); md.classList.remove('on'); });
        md.addEventListener('click', () => { severity[name] = 'moderate'; md.classList.add('on'); sv.classList.remove('on'); });
      });
    };
    const wireChip = (ch) => ch.addEventListener('click', () => {
      ch.classList.toggle('on');
      const on = ch.classList.contains('on');
      ch.textContent = `${on ? '✓ ' : ''}${ch.getAttribute('data-name')}`;
      if (ch.closest('#rx-allergies')) paintSeverity();
    });
    root.querySelectorAll('.rx-chip').forEach(wireChip);
    paintSeverity();
    // Custom entries (spec §18.5): add to the right section, pre-selected.
    root.querySelectorAll('.rx-add-btn').forEach((btn) => btn.addEventListener('click', () => {
      const kind = btn.getAttribute('data-add');
      const input = root.querySelector(`#rx-add-${kind}`);
      const name = (input.value || '').trim().slice(0, 30);
      if (!name) return;
      input.value = '';
      const wrap = root.querySelector(kind === 'allergy' ? '#rx-allergies' : kind === 'intolerance' ? '#rx-intolerances' : '#rx-preferences');
      if ([...wrap.querySelectorAll('.chp')].some((c) => c.getAttribute('data-name').toLowerCase() === name.toLowerCase())) return;
      wrap.insertAdjacentHTML('beforeend', `<span class="chp rx-chip on" data-name="${esc(name)}">✓ ${esc(name)}</span>`);
      wireChip(wrap.lastElementChild);
      if (kind === 'allergy') paintSeverity();
    }));
    root.querySelector('#save-allergies').addEventListener('click', () => {
      const names = (sel) => [...root.querySelectorAll(`${sel} .chp.on`)].map((c) => c.getAttribute('data-name'));
      const structured = {
        allergies: names('#rx-allergies').map((n) => ({ name: n, severity: severity[n] || 'severe' })),
        intolerances: names('#rx-intolerances'),
        preferences: names('#rx-preferences'),
      };
      window.__act.saveRestrictions(structured);
      // Sync to the server so the coach's Team Dietary Sheet gets the real declaration (0134).
      try { roles.saveDietaryRestrictions(RT.userId, RT.restrictions); } catch { /* best-effort */ }
      window.__back('profile');
    });

    // Cross-device hydrate: if this device has no local declaration, pull the server copy once.
    const hasLocal = RT.restrictions && ((RT.restrictions.allergies || []).length || (RT.restrictions.intolerances || []).length || (RT.restrictions.preferences || []).length);
    if (!hasLocal) {
      roles.fetchMyDietary().then((server) => {
        if (server && ((server.allergies && server.allergies.length) || (server.intolerances && server.intolerances.length) || (server.preferences && server.preferences.length))) {
          RT.restrictions = server;
          if (window.__render) window.__render();
        }
      }).catch(() => { /* offline — local stays authoritative */ });
    }
  },
};

/* ---------- #team-diet · Coach's team dietary sheet ----------
   Now REAL (0134): athletes' declarations sync to the server, so a coach sees every athlete who
   has declared, severity-flagged. This is a SAFETY surface — a coach could order team meals off
   it — so it renders ONLY real declarations (roles.fetchTeamDietary), never invented allergies,
   and honestly shows how many athletes have not declared. */
let TD = { loaded: false, entries: [], byId: {} };
async function loadTeamDiet() {
  try {
    await CD.loadCoachRoster();
    const entries = CD.entriesFor(CD.getScope()) || [];
    const ids = entries.map((e) => e.row && e.row.athleteId).filter(Boolean);
    const rows = await roles.fetchTeamDietary(ids);
    const byId = {};
    for (const r of rows) if (r && r.athlete_id) byId[r.athlete_id] = r.data || {};
    TD = { loaded: true, entries, byId };
  } catch { TD = { loaded: true, entries: [], byId: {} }; }
  if (window.__render) window.__render();
}
function dietHasAny(d) {
  return !!(d && ((Array.isArray(d.allergies) && d.allergies.length)
    || (Array.isArray(d.intolerances) && d.intolerances.length)
    || (Array.isArray(d.preferences) && d.preferences.length)));
}
function dietRow(name, d) {
  const allergyPills = (d.allergies || []).map((a) => {
    const nm = (a && a.name) || a;
    const severe = a && a.severity === 'severe';
    const style = severe ? 'background:var(--red-surface);color:var(--red)' : 'background:rgba(245,165,36,0.16);color:var(--amber-bright)';
    return `<span class="status-pill" style="${style}">${esc(nm)}${a && a.severity ? ` · ${esc(a.severity)}` : ''}</span>`;
  }).join(' ');
  const other = [...(d.intolerances || []), ...(d.preferences || [])].map((x) => `<span class="status-pill">${esc(x)}</span>`).join(' ');
  return `<section class="card pad" style="margin-bottom:8px">
    <div style="font-size:14.5px;font-weight:800">${esc(name)}</div>
    <div style="display:flex;flex-wrap:wrap;gap:6px;margin-top:8px">${allergyPills}${other}</div>
  </section>`;
}
export const teamDiet = {
  nav: 'coach', tab: 'roster',
  render() {
    const head = backHead('Team Dietary Sheet', 'Every restriction, one screen. Travel-ready.', 'coach-home');
    if (!TD.loaded) {
      return `${head}<div class="sidebox"><div class="req-icon b" style="width:38px;height:38px">${icon('bell', 17)}</div><div><div class="tt">Loading declarations…</div></div></div>`;
    }
    const declared = TD.entries.filter((e) => dietHasAny(TD.byId[e.row && e.row.athleteId]));
    const undeclared = TD.entries.length - declared.length;
    if (!declared.length) {
      return `${head}
      <div class="state-demo"><div class="sd-ic">${icon('bell', 24)}</div>
      <div class="sd-t">No declarations yet</div>
      <div class="sd-s">When your athletes declare restrictions and allergies in their profile, every one lands here — severity-flagged, one screen, travel-ready. Nothing shows until it's their real declaration; a dietary sheet is the last place for placeholder data.</div></div>
      <div style="height:10px"></div>`;
    }
    return `${head}
    <div class="eyebrow">Declared · ${declared.length} of ${TD.entries.length}</div>
    ${declared.map((e) => dietRow(e.row.name, TD.byId[e.row.athleteId])).join('')}
    ${undeclared ? `<div style="text-align:center;font-size:12px;font-weight:600;color:var(--text-3);margin:6px 0 4px">${undeclared} athlete${undeclared === 1 ? '' : 's'} ${undeclared === 1 ? 'has' : 'have'} not declared restrictions</div>` : ''}
    <div style="height:10px"></div>`;
  },
  mount() { loadTeamDiet(); },
};

/* ---------- #injury · Injury Mode (spec §19): role boundaries enforced ----------
   The ATHLETE reports pain or an injury concern (that's the real action here — it adapts
   the local Standard and flags the report). Medical restrictions and clearance belong to
   an authorized athletic trainer or medical professional; the coach sees participation
   status, never a diagnosis. Copy states each boundary explicitly. */
export const injury = {
  tab: 'home',
  render() {
    const on = RT.injured;
    return `
    ${backHead('Injury Mode', on ? 'Your Standard adapts while you heal' : 'Report it — your Standard adapts', 'home')}

    ${on ? `
    <div class="eyebrow">What changed in your Standard</div>
    <section class="card" style="padding:6px 16px">
      ${[
        ['bolt', 'Rehab replaces intensity', 'Band work 2×15 before practice, on your requirements list now.'],
        ['utensils', 'Nutrition tilts anti-inflammatory', 'Protein stays on target; add color, cut the fried stuff while you heal.'],
        ['moon', 'Recovery counts double attention', 'Sleep is when tissue heals — Recovery stays 25% of your score, with more eyes on it.'],
      ].map(([ic, t, s]) => `
        <div class="lrow" style="cursor:default">
          <div class="lic">${icon(ic, 17)}</div>
          <div class="lm"><div class="lt">${t}</div><div class="ls" style="white-space:normal;line-height:1.4">${s}</div></div>
        </div>`).join('')}
    </section>

    <div style="height:16px"></div>
    <button class="btn ghost" data-act="toggleInjury" data-then="__back:home">I'm cleared · restore the Standard</button>`
    : `
    <section class="card pad">
      <div style="font-size:15.5px;font-weight:800">Hurt, or worried you might be?</div>
      <div style="font-size:12.5px;font-weight:600;color:var(--text-2);margin-top:4px;line-height:1.5">Report it. Your Standard adapts — rehab joins your list and nutrition shifts to healing — and the right people see the right things.</div>
      <button class="btn primary sm" data-act="toggleInjury" data-then="injury" style="margin-top:12px;width:auto;padding:0 22px">${icon('bolt', 16)} Report an injury or pain</button>
    </section>`}

    <div class="eyebrow">Who does what</div>
    <section class="card" style="padding:6px 16px">
      ${[
        ['user', 'You report', 'Pain or an injury concern — that’s your part. Reporting is never punished.'],
        ['heart', 'Medical decides', 'An authorized athletic trainer or medical professional manages restrictions and clearance. Return-to-play is theirs, not an app setting.'],
        ['users', 'Coach sees participation', 'Your coach sees your participation status and adapted Standard — not a diagnosis, and they never medically clear you.'],
      ].map(([ic, t, s]) => `
        <div class="lrow" style="cursor:default">
          <div class="lic">${icon(ic, 17)}</div>
          <div class="lm"><div class="lt">${t}</div><div class="ls" style="white-space:normal;line-height:1.4">${s}</div></div>
        </div>`).join('')}
    </section>

    <div style="height:12px"></div>
    <div class="sidebox">
      <div class="req-icon p" style="width:38px;height:38px">${icon('lock', 17)}</div>
      <div><div class="tt">Who can see injury details</div>
      <div class="ts">Your report goes to your athletic trainer and coach connection only. Teammates never see it. If something feels urgent — severe pain, a head injury, numbness — tell an adult and get care first; the app comes second.</div></div>
    </div>
    <div style="height:10px"></div>
    `;
  },
};

/* ---------- #coach-voice · configure how the AI reinforces YOUR standards ---------- */
const CV_PHRASES = ['That’s the standard.', 'Don’t chase the scale, we’re building.', 'Hydration is the standard this week.', 'Keep this structure.'];
export const coachVoice = {
  nav: 'coach', tab: 'profile',
  render() {
    const cv = RT.coachVoice || {};
    const enabled = cv.enabled !== false;
    const tone = cv.tone || 'direct';
    const level = cv.level || 'balanced';
    const approved = Array.isArray(cv.approved) ? cv.approved : CV_PHRASES;
    const chip = (on, label, key, val) => `<span class="chp ${on ? 'on' : ''}" data-cv="${key}:${val}">${label}</span>`;
    return `
    ${backHead('Coach Voice', 'How the AI reinforces your standards — in your tone.', 'coach-profile')}

    <section class="card" style="padding:6px 16px">
      <div class="lrow" style="cursor:default">
        <div class="lic" style="background:rgba(168,85,247,0.16);color:var(--purple-bright)">${icon('sparkle', 17)}</div>
        <div class="lm"><div class="lt">AI in your voice</div><div class="ls">${enabled ? 'On — always labeled as AI, never signed as you' : 'Off'}</div></div>
        <div class="seg" style="width:104px" id="cv-enabled"><button class="${enabled ? 'on' : ''}">On</button><button class="${enabled ? '' : 'on'}">Off</button></div>
      </div>
    </section>

    <div class="eyebrow">Tone</div>
    <div class="chip-row" id="cv-tone">${chip(tone === 'calm', 'Calm', 'tone', 'calm')}${chip(tone === 'direct', 'Direct', 'tone', 'direct')}${chip(tone === 'fired', 'Fired up', 'tone', 'fired')}</div>

    <div class="eyebrow">Accountability</div>
    <div class="chip-row" id="cv-level">${chip(level === 'supportive', 'Supportive', 'level', 'supportive')}${chip(level === 'balanced', 'Balanced', 'level', 'balanced')}${chip(level === 'hard', 'Hard-nosed', 'level', 'hard')}</div>

    <div class="eyebrow">Phrases the AI may echo · tap to approve</div>
    <section class="card" style="padding:6px 16px" id="cv-approved">
      ${CV_PHRASES.map((p, i) => { const on = approved.includes(p); return `
        <div class="lrow" data-cvphrase="${i}" style="cursor:pointer">
          <div class="xico sm ${on ? 'green' : 'gray'}">${on ? icon('check', 15) : ''}</div>
          <div class="lm"><div class="lt" style="font-weight:700">“${esc(p)}”</div></div>
        </div>`; }).join('')}
    </section>

    <div class="eyebrow">Never say · comma-separated</div>
    <input id="cv-prohibited" class="ob-input" maxlength="200" placeholder="e.g. skinny, fat, lazy" value="${esc(cv.prohibited || '')}" />

    <div style="height:14px"></div>
    <div class="sidebox">
      <div class="req-icon b" style="width:38px;height:38px">${icon('shield', 17)}</div>
      <div><div class="tt">Hard limits</div>
      <div class="ts">Every AI message is labeled as AI and never signed as you. It reinforces rulings you already made, in your tone — it never creates requirements, changes deadlines, alters scores, or gives medical advice. New coaching always comes from you.</div></div>
    </div>
    <div style="height:10px"></div>
    `;
  },
  mount(root) {
    const seg = root.querySelector('#cv-enabled');
    if (seg) {
      const [on, off] = seg.querySelectorAll('button');
      on.addEventListener('click', () => { act.setCoachVoice({ enabled: true }); window.__render(); });
      off.addEventListener('click', () => { act.setCoachVoice({ enabled: false }); window.__render(); });
    }
    root.querySelectorAll('[data-cv]').forEach((el) => el.addEventListener('click', () => {
      const [k, v] = el.getAttribute('data-cv').split(':');
      act.setCoachVoice({ [k]: v }); window.__render();
    }));
    root.querySelectorAll('[data-cvphrase]').forEach((el) => el.addEventListener('click', () => {
      const p = CV_PHRASES[+el.getAttribute('data-cvphrase')];
      const cur = Array.isArray((RT.coachVoice || {}).approved) ? RT.coachVoice.approved.slice() : CV_PHRASES.slice();
      const set = new Set(cur); set.has(p) ? set.delete(p) : set.add(p);
      act.setCoachVoice({ approved: [...set] }); window.__render();
    }));
    const prohibited = root.querySelector('#cv-prohibited');
    if (prohibited) prohibited.addEventListener('change', () => act.setCoachVoice({ prohibited: prohibited.value.trim() }));
  },
};

/* ---------- #trust-pass-policy · the team defaults grant_trust_pass reads (0097/0099) ---------- */
export const trustPassPolicy = {
  nav: 'coach', tab: 'profile',
  render() {
    const p = RT.trustPolicy || { length_days: 10, eligibility_days: 7 };
    const stepper = (label, key, val, lo, hi, unit) => `
    <div class="eyebrow">${label}</div>
    <section class="card" style="padding:10px 16px">
      <div class="lrow" style="cursor:default">
        <div class="lm"><div class="lt">${val} ${unit}</div><div class="ls">Range ${lo}–${hi}</div></div>
        <div class="seg" style="width:104px" data-tpp="${key}">
          <button data-step="-1" aria-label="Decrease ${label}">−</button>
          <button data-step="1" aria-label="Increase ${label}">+</button>
        </div>
      </div>
    </section>`;
    return `
    ${backHead('Trust Pass', 'The default reward every grant on your team uses.', 'coach-profile')}

    ${stepper('Pass length', 'length_days', p.length_days, 1, 60, p.length_days === 1 ? 'day' : 'days')}
    ${stepper('Earned after', 'eligibility_days', p.eligibility_days, 1, 30, 'photo-logged days')}

    <div style="height:10px"></div>
    <div class="sidebox">
      <div class="req-icon b" style="width:38px;height:38px">${icon('shield', 17)}</div>
      <div><div class="tt">How a Trust Pass works</div>
      <div class="ts">A pass lets a proven athlete one-tap their trailing nutrition median instead of a photo, for <b>${p.length_days}</b> ${p.length_days === 1 ? 'day' : 'days'}. You grant it by hand from an athlete’s profile, and only after they’ve photo-logged a meal on <b>${p.eligibility_days}</b> separate days — the server checks that every time, so a pass can never be earned from nothing.</div></div>
    </div>
    <div style="height:10px"></div>
    `;
  },
  mount(root) {
    root.querySelectorAll('[data-tpp]').forEach((seg) => {
      const key = seg.getAttribute('data-tpp');
      seg.querySelectorAll('[data-step]').forEach((b) => b.addEventListener('click', () => {
        const cur = (RT.trustPolicy || { length_days: 10, eligibility_days: 7 })[key];
        act.setTrustPolicy({ [key]: cur + Number(b.getAttribute('data-step')) });
        window.__render();
      }));
    });
  },
};

/* ---------- #week-pattern · which weekdays are training vs rest (0100 → day-type scoring) ---------- */
const WP_DAYS = [[1, 'Monday'], [2, 'Tuesday'], [3, 'Wednesday'], [4, 'Thursday'], [5, 'Friday'], [6, 'Saturday'], [0, 'Sunday']];
export const weekPattern = {
  nav: 'coach', tab: 'profile',
  render() {
    const p = Array.isArray(RT.weekPattern) && RT.weekPattern.length === 7
      ? RT.weekPattern : ['training', 'training', 'training', 'training', 'training', 'training', 'training'];
    const rows = WP_DAYS.map(([dow, label]) => {
      const rest = p[dow] === 'rest';
      return `
      <div class="lrow" style="cursor:default">
        <div class="lm"><div class="lt">${label}</div></div>
        <div class="seg" style="width:150px" data-wp="${dow}">
          <button class="${rest ? '' : 'on'}" data-wt="training">Training</button>
          <button class="${rest ? 'on' : ''}" data-wt="rest">Rest</button>
        </div>
      </div>`;
    }).join('');
    return `
    ${backHead('Training week', 'Mark rest days so day-only requirements don’t count against them.', 'coach-profile')}

    <section class="card" style="padding:6px 16px">${rows}</section>

    <div style="height:10px"></div>
    <div class="sidebox">
      <div class="req-icon b" style="width:38px;height:38px">${icon('clock', 17)}</div>
      <div><div class="tt">How this is used</div>
      <div class="ts">A requirement you tag as <b>training-only</b> or <b>rest-only</b> in the standards editor applies only on those days. On a rest day, training-only meals simply aren’t required — they don’t count against the athlete’s score. Leave every day “Training” for no change.</div></div>
    </div>
    <div style="height:10px"></div>
    `;
  },
  mount(root) {
    root.querySelectorAll('[data-wp]').forEach((seg) => {
      const dow = Number(seg.getAttribute('data-wp'));
      seg.querySelectorAll('[data-wt]').forEach((b) => b.addEventListener('click', () => {
        act.setWeekPattern(dow, b.getAttribute('data-wt'));
        window.__render();
      }));
    });
  },
};

/* ---------- #safety · Protective pattern flags (design preview, deliberately not simulated) ---------- */
export const safety = {
  nav: 'coach', tab: 'roster',
  render() {
    return `
    ${backHead('Wellness Flags', 'Protective, never punitive', 'coach-home')}

    <section class="card pad" style="border-color:var(--green-border)">
      <div style="display:flex;align-items:center;gap:13px">
        <div class="req-icon g" style="width:44px;height:44px">${icon('check', 20)}</div>
        <div><div style="font-size:15px;font-weight:800">No flags on your roster this week</div>
        <div style="font-size:12.5px;font-weight:600;color:var(--text-2);margin-top:2px">That's the sentence you want to read here.</div></div>
      </div>
    </section>

    <div class="eyebrow">What it watches for</div>
    <section class="card" style="padding:6px 16px">
      ${[
        ['bars', 'Severe restriction patterns', 'Sustained intake far below any goal profile, or meals shrinking week over week.'],
        ['clock', 'Compulsive logging', 'Obsessive re-logging, deleting, and re-photographing the same meals.'],
        ['scale', 'Weight fixation', 'Off-schedule weigh-ins spiking, especially on a cut.'],
      ].map(([ic, t, s]) => `
        <div class="lrow" style="cursor:default">
          <div class="lic">${icon(ic, 17)}</div>
          <div class="lm"><div class="lt">${t}</div><div class="ls" style="white-space:normal;line-height:1.4">${s}</div></div>
        </div>`).join('')}
    </section>

    <div class="eyebrow">What happens on a flag</div>
    <div class="sidebox" style="border-color:var(--purple-border)">
      <div class="req-icon p" style="width:38px;height:38px">${icon('heart', 17)}</div>
      <div><div class="tt">A quiet conversation, not a penalty</div>
      <div class="ts">Scoring pauses so the number can't feed the pattern. You and a parent get a private “worth a check-in” note with talking points. The athlete is never shamed, ranked, or flagged publicly.</div></div>
    </div>
    <div style="font-size:12px;font-weight:600;color:var(--text-3);margin-top:12px;padding:0 2px">Detection logic ships with the real backend and gets clinical review first. This screen commits the product to how it will behave.</div>
    <div style="height:10px"></div>
    `;
  },
};
