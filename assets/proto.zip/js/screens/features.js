import{S,RT,act,roleNav,roleProfileRoute,liveWeightPct}from"../state.js";import{icon}from"../icons.js";import{backHead,esc,errorState}from"../components.js";import*as roles from"../roles.js";import*as CD from"../coach-data.js";const ALLERGY_OPTS=["Peanuts","Tree nuts","Shellfish","Eggs","Fish","Soy","Wheat","Sesame"];const INTOLERANCE_OPTS=["Dairy","Gluten","Caffeine"];const PREFERENCE_OPTS=["Vegetarian","Vegan","Halal","Kosher","Pescatarian"];function currentRestrictions(){const r=RT.restrictions;if(r&&typeof r==="object"){return{allergies:Array.isArray(r.allergies)?r.allergies:[],intolerances:Array.isArray(r.intolerances)?r.intolerances:[],preferences:Array.isArray(r.preferences)?r.preferences:[]}}const out={allergies:[],intolerances:[],preferences:[]};for(const s of RT.allergies||[]){const name=String(s).split("\xB7")[0].trim();const severe=/severe/i.test(String(s));if(PREFERENCE_OPTS.includes(name))out.preferences.push(name);else if(INTOLERANCE_OPTS.includes(name))out.intolerances.push(name);else out.allergies.push({name,severity:severe?"severe":"moderate"})}return out}export const restrictions={tab:"profile",render(){const R=currentRestrictions();const has=(arr,n)=>arr.some(x=>(x.name||x)===n);const sevOf=n=>{const a=R.allergies.find(x=>x.name===n);return a?a.severity:"severe"};const chip=(n,on)=>`<span class="chip rx-chip ${on?"on":""}" data-name="${esc(n)}">${on?`${icon("check",12)} `:""}${esc(n)}</span>`;const customs=(arr,opts)=>arr.map(x=>x.name||x).filter(n=>!opts.includes(n));return`
    ${backHead("Food restrictions","Allergies, intolerances, and preferences, kept separate","profile")}

    <h2 class="eyebrow">Allergies \xB7 medical, taken seriously</h2>
    <div class="chip-row" id="rx-allergies">
      ${[...ALLERGY_OPTS,...customs(R.allergies,ALLERGY_OPTS)].map(n=>chip(n,has(R.allergies,n))).join("")}
    </div>
    <div id="rx-severity"></div>
    <div class="rx-add"><input class="input" id="rx-add-allergy" maxlength="30" placeholder="Add another allergen\u2026" aria-label="Add another allergen" /><button class="btn ghost sm rx-add-btn" data-add="allergy">Add</button></div>

    <h2 class="eyebrow">Intolerances</h2>
    <div class="chip-row" id="rx-intolerances">
      ${[...INTOLERANCE_OPTS,...customs(R.intolerances,INTOLERANCE_OPTS)].map(n=>chip(n,R.intolerances.includes(n))).join("")}
    </div>
    <div class="rx-add"><input class="input" id="rx-add-intolerance" maxlength="30" placeholder="Add an intolerance\u2026" aria-label="Add an intolerance" /><button class="btn ghost sm rx-add-btn" data-add="intolerance">Add</button></div>

    <h2 class="eyebrow">Dietary preferences</h2>
    <div class="chip-row" id="rx-preferences">
      ${[...PREFERENCE_OPTS,...customs(R.preferences,PREFERENCE_OPTS)].map(n=>chip(n,R.preferences.includes(n))).join("")}
    </div>
    <div class="rx-add"><input class="input" id="rx-add-preference" maxlength="30" placeholder="Add a preference\u2026" aria-label="Add a dietary preference" /><button class="btn ghost sm rx-add-btn" data-add="preference">Add</button></div>

    <h2 class="eyebrow">How checking works</h2>
    <section class="card" role="list" style="padding:6px 16px">
      ${[["camera","Detected foods are compared","The app compares detected foods and label entries with your saved restrictions. Detection may miss ingredients, preparation methods, or cross-contact."],["bell","Severe allergies warn loudest","A possible severe-allergen conflict warns you before you confirm the log. It names the allergen and tells you what it can\u2019t be sure of."],["shield","Always verify severe allergens yourself","This never replaces reading labels, asking staff, or medical guidance. Treat every severe allergen as unverified until you check it."]].map(([ic,t,s])=>`
        <div class="lrow" role="listitem" style="cursor:default">
          <div class="lic">${icon(ic,17)}</div>
          <div class="lm"><div class="lt">${t}</div><div class="ls" style="white-space:normal;line-height:1.4">${s}</div></div>
        </div>`).join("")}
    </section>

    <div style="height:16px"></div>
    <button class="btn primary" id="save-allergies">${icon("check",18)} Save</button>
    <div style="height:10px"></div>
    `},mount(root){const R=currentRestrictions();const severity={};R.allergies.forEach(a=>{severity[a.name]=a.severity||"severe"});const sevPanel=root.querySelector("#rx-severity");const paintSeverity=()=>{const on=[...root.querySelectorAll("#rx-allergies .chip.on")].map(c=>c.getAttribute("data-name"));sevPanel.innerHTML=on.length?`<section class="card" role="list" style="padding:4px 14px;margin-top:8px">${on.map(n=>`
        <div class="lrow" role="listitem" style="cursor:default">
          <div class="lm"><div class="lt" style="font-size:13px">${esc(n)}</div></div>
          <div class="seg" style="width:170px" data-sev="${esc(n)}" role="radiogroup" aria-label="${esc(n)} severity">
            <button role="radio" aria-checked="${(severity[n]||"severe")==="severe"}" class="${(severity[n]||"severe")==="severe"?"on":""}">Severe</button>
            <button role="radio" aria-checked="${(severity[n]||"severe")==="moderate"}" class="${(severity[n]||"severe")==="moderate"?"on":""}">Moderate</button>
          </div>
        </div>`).join("")}</section>`:"";sevPanel.querySelectorAll("[data-sev]").forEach(seg=>{const name=seg.getAttribute("data-sev");const[sv,md]=seg.querySelectorAll("button");const pick=(onBtn,offBtn)=>{onBtn.classList.add("on");onBtn.setAttribute("aria-checked","true");offBtn.classList.remove("on");offBtn.setAttribute("aria-checked","false")};sv.addEventListener("click",()=>{severity[name]="severe";pick(sv,md)});md.addEventListener("click",()=>{severity[name]="moderate";pick(md,sv)})})};const wireChip=ch=>ch.addEventListener("click",()=>{ch.classList.toggle("on");const on=ch.classList.contains("on");ch.innerHTML=`${on?`${icon("check",12)} `:""}${esc(ch.getAttribute("data-name"))}`;if(ch.closest("#rx-allergies"))paintSeverity()});root.querySelectorAll(".rx-chip").forEach(wireChip);paintSeverity();root.querySelectorAll(".rx-add-btn").forEach(btn=>btn.addEventListener("click",()=>{const kind=btn.getAttribute("data-add");const input=root.querySelector(`#rx-add-${kind}`);const name=(input.value||"").trim().slice(0,30);if(!name)return;input.value="";const wrap=root.querySelector(kind==="allergy"?"#rx-allergies":kind==="intolerance"?"#rx-intolerances":"#rx-preferences");if([...wrap.querySelectorAll(".chip")].some(c=>c.getAttribute("data-name").toLowerCase()===name.toLowerCase()))return;wrap.insertAdjacentHTML("beforeend",`<span class="chip rx-chip on" data-name="${esc(name)}">${icon("check",12)} ${esc(name)}</span>`);wireChip(wrap.lastElementChild);if(kind==="allergy")paintSeverity()}));root.querySelector("#save-allergies").addEventListener("click",()=>{const names=sel=>[...root.querySelectorAll(`${sel} .chip.on`)].map(c=>c.getAttribute("data-name"));const structured={allergies:names("#rx-allergies").map(n=>({name:n,severity:severity[n]||"severe"})),intolerances:names("#rx-intolerances"),preferences:names("#rx-preferences")};window.__act.saveRestrictions(structured);try{roles.saveDietaryRestrictions(RT.userId,RT.restrictions)}catch{}window.__back("profile")});const hasLocal=RT.restrictions&&((RT.restrictions.allergies||[]).length||(RT.restrictions.intolerances||[]).length||(RT.restrictions.preferences||[]).length);if(!hasLocal){roles.fetchMyDietary().then(server=>{if(server&&!server.error&&(server.allergies&&server.allergies.length||server.intolerances&&server.intolerances.length||server.preferences&&server.preferences.length)){RT.restrictions=server;if(window.__render)window.__render()}}).catch(()=>{})}}};let TD={loaded:false,failed:false,entries:[],byId:{},at:0};let tdLoading=false;async function loadTeamDiet(){if(tdLoading)return;tdLoading=true;try{await CD.loadCoachRoster();const entries=CD.entriesFor(CD.getScope())||[];const ids=entries.map(e=>e.row&&e.row.athleteId).filter(Boolean);const rows=await roles.fetchTeamDietary(ids);if(rows===null){TD={loaded:true,failed:true,entries,byId:{},at:0}}else{const byId={};for(const r of rows)if(r&&r.athlete_id)byId[r.athlete_id]=r.data||{};TD={loaded:true,failed:false,entries,byId,at:Date.now()}}}catch{TD={loaded:true,failed:true,entries:[],byId:{},at:0}}tdLoading=false;if(window.__render)window.__render()}function dietHasAny(d){return!!(d&&(Array.isArray(d.allergies)&&d.allergies.length||Array.isArray(d.intolerances)&&d.intolerances.length||Array.isArray(d.preferences)&&d.preferences.length))}function dietRow(name,d){const allergyPills=(d.allergies||[]).map(a=>{const nm=a&&a.name||a;const severe=a&&a.severity==="severe";const style=severe?"background:var(--red-surface);color:var(--red)":"background:rgba(var(--amber-rgb),0.16);color:var(--amber-bright)";return`<span class="status-pill" style="${style}">${esc(nm)}${a&&a.severity?` \xB7 ${esc(a.severity)}`:""}</span>`}).join(" ");const other=[...d.intolerances||[],...d.preferences||[]].map(x=>`<span class="status-pill">${esc(x)}</span>`).join(" ");return`<section class="card pad" style="margin-bottom:8px">
    <div style="font-size:14.5px;font-weight:800">${esc(name)}</div>
    <div style="display:flex;flex-wrap:wrap;gap:6px;margin-top:8px">${allergyPills}${other}</div>
  </section>`}export const teamDiet={nav:"coach",tab:"roster",render(){const head=backHead("Team Dietary Sheet","Every restriction, one screen. Travel-ready.","coach-home");if(!TD.loaded){return`${head}<div class="sidebox"><div class="req-icon b s38">${icon("bell",17)}</div><div><div class="tt">Loading declarations\u2026</div></div></div>`}if(TD.failed){return`${head}
      ${errorState({title:"Couldn't load the dietary sheet",body:"Declarations are safe on the server. Do not order from memory: reconnect and reload before the meal run.",retryId:"td-retry"})}
      <div style="height:10px"></div>`}const declared=TD.entries.filter(e=>dietHasAny(TD.byId[e.row&&e.row.athleteId]));const undeclared=TD.entries.length-declared.length;if(!declared.length){return`${head}
      <div class="state-demo"><div class="sd-ic">${icon("bell",24)}</div>
      <div class="sd-t">No declarations yet</div>
      <div class="sd-s">When your athletes declare restrictions and allergies in their profile, every one lands here: severity-flagged, one screen, travel-ready. Nothing shows until it's their real declaration; a dietary sheet is the last place for placeholder data.</div></div>
      <div style="height:10px"></div>`}return`${head}
    <h2 class="eyebrow">Declared \xB7 ${declared.length} of ${TD.entries.length}</h2>
    ${declared.map(e=>dietRow(e.row.name,TD.byId[e.row.athleteId])).join("")}
    ${undeclared?`<div style="text-align:center;font-size:12px;font-weight:600;color:var(--text-3);margin:6px 0 4px">${undeclared} athlete${undeclared===1?"":"s"} ${undeclared===1?"has":"have"} not declared restrictions</div>`:""}
    <div style="height:10px"></div>`},mount(root){const retry=root&&root.querySelector("#td-retry");if(retry)retry.addEventListener("click",()=>{TD={loaded:false,failed:false,entries:[],byId:{},at:0};window.__render();loadTeamDiet()});if(!TD.failed&&(!TD.loaded||Date.now()-TD.at>6e4))loadTeamDiet()}};const CV_PHRASES=["That\u2019s the standard.","Don\u2019t chase the scale, we\u2019re building.","Protein first is the standard this week.","Keep this structure."];export const coachVoice={get nav(){return roleNav()},tab:"profile",render(){const cv=RT.coachVoice||{};const enabled=cv.enabled!==false;const tone=cv.tone||"direct";const level=cv.level||"balanced";const length=cv.length||"standard";const approved=Array.isArray(cv.approved)?cv.approved:CV_PHRASES;const chip=(on,label,key,val)=>`<span class="chip ${on?"on":""}" data-cv="${key}:${val}">${label}</span>`;return`
    ${backHead("Nia \xB7 OnStandard Nutritionist","Make Nia coach the way you coach.",roleProfileRoute())}

    <section class="card" style="padding:6px 16px">
      <div class="lrow" style="cursor:default">
        <div class="lic nia-av"><span class="nia-n" aria-hidden="true">N</span></div>
        <div class="lm"><div class="lt">Coach Nia</div><div class="ls">${enabled?"On: always labeled as AI, never signed as you":"Off: Nia uses her default voice"}</div></div>
        <div class="seg" style="width:104px" id="cv-enabled" role="radiogroup" aria-label="Coach Nia"><button role="radio" aria-checked="${enabled}" class="${enabled?"on":""}">On</button><button role="radio" aria-checked="${!enabled}" class="${enabled?"":"on"}">Off</button></div>
      </div>
    </section>
    <div style="font-size:12px;font-weight:600;color:var(--text-3);margin:8px 2px 0;line-height:1.45">Shapes everything Nia says: meal reads, thread replies, answers to your questions, and nudges.</div>

    <h2 class="eyebrow">Tone</h2>
    <div class="chip-row" id="cv-tone">${chip(tone==="calm","Calm","tone","calm")}${chip(tone==="direct","Direct","tone","direct")}${chip(tone==="fired","Fired up","tone","fired")}</div>

    <h2 class="eyebrow">Accountability</h2>
    <div class="chip-row" id="cv-level">${chip(level==="supportive","Supportive","level","supportive")}${chip(level==="balanced","Balanced","level","balanced")}${chip(level==="hard","Hard-nosed","level","hard")}</div>

    <h2 class="eyebrow">Reply length \xB7 chat and questions</h2>
    <div class="chip-row" id="cv-length">${chip(length==="brief","Brief","length","brief")}${chip(length==="standard","Standard","length","standard")}${chip(length==="detailed","Detailed","length","detailed")}</div>

    <h2 class="eyebrow">Your instructions \xB7 optional</h2>
    <textarea id="cv-instructions" class="ob-input" maxlength="500" rows="3" style="min-height:76px;resize:vertical" aria-label="Your instructions for Nia" placeholder="e.g. Always push vegetables. Keep advice tied to our 4-meal structure. Talk like a strength coach, not a dietitian.">${esc(cv.instructions||"")}</textarea>
    <div style="font-size:11.5px;font-weight:600;color:var(--text-3);margin:6px 2px 0;line-height:1.4">Style guidance only. It can never change numbers, add requirements, or unlock medical advice.</div>

    <h2 class="eyebrow">Phrases Nia may echo \xB7 tap to approve</h2>
    <section class="card" style="padding:6px 16px" id="cv-approved">
      ${CV_PHRASES.map((p,i)=>{const on=approved.includes(p);return`
        <div class="lrow" data-cvphrase="${i}" style="cursor:pointer">
          <div class="xico sm ${on?"green":"gray"}">${on?icon("check",15):""}</div>
          <div class="lm"><div class="lt" style="font-weight:700">\u201C${esc(p)}\u201D</div></div>
        </div>`}).join("")}
    </section>

    <h2 class="eyebrow">Never say \xB7 comma-separated</h2>
    <input id="cv-prohibited" class="ob-input" maxlength="200" placeholder="e.g. skinny, fat, lazy" aria-label="Words Nia must never say, comma-separated" value="${esc(cv.prohibited||"")}" />

    <div style="height:14px"></div>
    <div class="sidebox">
      <div class="req-icon b s38">${icon("shield",17)}</div>
      <div><div class="tt">Hard limits</div>
      <div class="ts">Every message from Nia is labeled as AI and never signed as you. It reinforces rulings you already made, in your tone. It never creates requirements, changes deadlines, alters scores, or gives medical advice. New coaching always comes from you.</div></div>
    </div>
    <div id="cv-status" style="text-align:center;font-size:12px;font-weight:600;color:var(--text-3);min-height:16px;margin-top:8px"></div>
    <div style="height:10px"></div>
    `},mount(root){const saved=()=>{const el=root.querySelector("#cv-status");if(el){el.textContent="Saved";setTimeout(()=>{if(el.textContent==="Saved")el.textContent=""},1400)}};const seg=root.querySelector("#cv-enabled");if(seg){const[on,off]=seg.querySelectorAll("button");on.addEventListener("click",()=>{act.setCoachVoice({enabled:true});window.__render()});off.addEventListener("click",()=>{act.setCoachVoice({enabled:false});window.__render()})}root.querySelectorAll("[data-cv]").forEach(el=>el.addEventListener("click",()=>{const[k,v]=el.getAttribute("data-cv").split(":");act.setCoachVoice({[k]:v});window.__render()}));root.querySelectorAll("[data-cvphrase]").forEach(el=>el.addEventListener("click",()=>{const p=CV_PHRASES[+el.getAttribute("data-cvphrase")];const cur=Array.isArray((RT.coachVoice||{}).approved)?RT.coachVoice.approved.slice():CV_PHRASES.slice();const set=new Set(cur);set.has(p)?set.delete(p):set.add(p);act.setCoachVoice({approved:[...set]});window.__render()}));const prohibited=root.querySelector("#cv-prohibited");if(prohibited)prohibited.addEventListener("change",()=>{act.setCoachVoice({prohibited:prohibited.value.trim()});saved()});const instructions=root.querySelector("#cv-instructions");if(instructions)instructions.addEventListener("change",()=>{act.setCoachVoice({instructions:instructions.value.trim().slice(0,500)});saved()})}};export const trustPassPolicy={nav:"operator",tab:"profile",render(){const trainer=RT.authRole==="trainer";const p=RT.passPolicy||{default_credits:3,default_window_days:2,eligibility_days:7,max_credits:5};const stepper=(label,key,val,lo,hi,unit)=>`
    <h2 class="eyebrow">${label}</h2>
    <section class="card" style="padding:10px 16px">
      <div class="lrow" style="cursor:default">
        <div class="lm"><div class="lt">${val} ${unit}</div><div class="ls">Range ${lo}\u2013${hi}</div></div>
        <div class="seg" style="width:104px" data-tpp="${key}">
          <button data-step="-1" aria-label="Decrease ${label}">\u2212</button>
          <button data-step="1" aria-label="Increase ${label}">+</button>
        </div>
      </div>
    </section>`;return`
    ${backHead("Trust Pass","The default reward every grant on your book uses.",trainer?"trainer-profile":"coach-profile")}

    ${stepper("Default credits","default_credits",p.default_credits,1,14,p.default_credits===1?"meal":"meals")}
    ${stepper("Default window","default_window_days",p.default_window_days,1,14,p.default_window_days===1?"day":"days")}
    ${stepper("Earned after","eligibility_days",p.eligibility_days,1,30,"photo-logged days")}
    ${stepper("Max credits per grant","max_credits",p.max_credits,1,14,p.max_credits===1?"meal":"meals")}

    <div style="height:10px"></div>
    <div class="sidebox">
      <div class="req-icon b s38">${icon("shield",17)}</div>
      <div><div class="tt">How a Trust Pass works</div>
      <div class="ts">A pass lets a proven ${trainer?"client":"athlete"} skip the photo for a meal, or a whole weekend, and credits their trailing nutrition median instead. You grant it by hand from ${trainer?"a client\u2019s":"an athlete\u2019s"} profile, and only after they've photo-logged a meal on <b>${p.eligibility_days}</b> separate days. The server checks that every time, so a pass can never be earned from nothing.</div></div>
    </div>
    <div style="height:10px"></div>
    `},mount(root){root.querySelectorAll("[data-tpp]").forEach(seg=>{const key=seg.getAttribute("data-tpp");seg.querySelectorAll("[data-step]").forEach(b=>b.addEventListener("click",()=>{const cur=(RT.passPolicy||{default_credits:3,default_window_days:2,eligibility_days:7,max_credits:5})[key];act.setTrustPolicy({[key]:cur+Number(b.getAttribute("data-step"))});window.__render()}))})}};const WP_DAYS=[[1,"Monday"],[2,"Tuesday"],[3,"Wednesday"],[4,"Thursday"],[5,"Friday"],[6,"Saturday"],[0,"Sunday"]];export const weekPattern={nav:"coach",tab:"profile",render(){const p=Array.isArray(RT.weekPattern)&&RT.weekPattern.length===7?RT.weekPattern:["training","training","training","training","training","training","training"];const rows=WP_DAYS.map(([dow,label])=>{const rest=p[dow]==="rest";return`
      <div class="lrow" style="cursor:default">
        <div class="lm"><div class="lt">${label}</div></div>
        <div class="seg" style="width:150px" data-wp="${dow}">
          <button class="${rest?"":"on"}" data-wt="training">Training</button>
          <button class="${rest?"on":""}" data-wt="rest">Rest</button>
        </div>
      </div>`}).join("");return`
    ${backHead("Training week","Mark rest days so day-only requirements don\u2019t count against them.","coach-profile")}

    <section class="card" style="padding:6px 16px">${rows}</section>

    <div style="height:10px"></div>
    <div class="sidebox">
      <div class="req-icon b s38">${icon("clock",17)}</div>
      <div><div class="tt">How this is used</div>
      <div class="ts">A requirement you tag as <b>training-only</b> or <b>rest-only</b> in the standards editor applies only on those days. On a rest day, training-only meals simply aren\u2019t required; they don\u2019t count against the athlete\u2019s score. Leave every day \u201CTraining\u201D for no change.</div></div>
    </div>
    <div style="height:10px"></div>
    `},mount(root){root.querySelectorAll("[data-wp]").forEach(seg=>{const dow=Number(seg.getAttribute("data-wp"));seg.querySelectorAll("[data-wt]").forEach(b=>b.addEventListener("click",()=>{act.setWeekPattern(dow,b.getAttribute("data-wt"));window.__render()}))})}};export const safety={nav:"coach",tab:"roster",render(){return`
    ${backHead("Wellness flags","Protective, never punitive","coach-home")}

    <section class="card pad" style="border-color:var(--green-border)">
      <div style="display:flex;align-items:center;gap:13px">
        <div class="req-icon g" style="width:44px;height:44px">${icon("check",20)}</div>
        <div><div style="font-size:15px;font-weight:800">No flags on your roster this week</div>
        <div style="font-size:12.5px;font-weight:600;color:var(--text-2);margin-top:2px">That's the sentence you want to read here.</div></div>
      </div>
    </section>

    <h2 class="eyebrow">What it watches for</h2>
    <section class="card" role="list" style="padding:6px 16px">
      ${[["bars","Severe restriction patterns","Sustained intake far below any goal profile, or meals shrinking week over week."],["clock","Compulsive logging","Obsessive re-logging, deleting, and re-photographing the same meals."],["scale","Weight fixation","Off-schedule weigh-ins spiking, especially on a cut."]].map(([ic,t,s])=>`
        <div class="lrow" role="listitem" style="cursor:default">
          <div class="lic">${icon(ic,17)}</div>
          <div class="lm"><div class="lt">${t}</div><div class="ls" style="white-space:normal;line-height:1.4">${s}</div></div>
        </div>`).join("")}
    </section>

    <h2 class="eyebrow">What happens on a flag</h2>
    <div class="sidebox" style="border-color:var(--purple-border)">
      <div class="req-icon p s38">${icon("heart",17)}</div>
      <div><div class="tt">A quiet conversation, not a penalty</div>
      <div class="ts">Scoring pauses so the number can't feed the pattern. You and a parent get a private \u201Cworth a check-in\u201D note with talking points. The athlete is never shamed, ranked, or flagged publicly.</div></div>
    </div>
    <div style="font-size:12px;font-weight:600;color:var(--text-3);margin-top:12px;padding:0 2px">Detection logic ships with the real backend and gets clinical review first. This screen commits the product to how it will behave.</div>
    <div style="height:10px"></div>
    `}};
