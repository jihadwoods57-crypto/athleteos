import{S,RT}from"../state.js";import{icon}from"../icons.js";import{backHead,esc,safeImg}from"../components.js";import{dir,debounce}from"../ob-directory.js";function avatarEl(size=62){const a=S.athlete;return a.avatar&&safeImg(a.avatar)?`<div class="big-av" style="width:${size}px;height:${size}px;background-image:url('${safeImg(a.avatar)}');background-size:cover;background-position:center"></div>`:`<div class="big-av" style="width:${size}px;height:${size}px" data-avatar-uid="${esc(RT.userId||"")}" data-avatar-ver="${esc(RT.avatarVer||"")}"><span data-avatar-fallback>${esc(a.initials)}</span></div>`}function ext(href,ic,t,sub){return`
      <a class="lrow" href="${href}" target="_blank" rel="noopener" style="text-decoration:none;color:inherit">
        <div class="lic">${icon(ic,16)}</div>
        <div class="lm"><div class="lt">${t}</div><div class="ls">${sub}</div></div>
        ${icon("external",15,'class="chev-dim"')}
      </a>`}export default{tab:"profile",render(){const t=S.pass;return`
    <h1 class="screen-title">Profile</h1>

    <section class="card id-card">
      <div style="position:relative" id="avatar-wrap">
        ${avatarEl()}
        <!-- Pushed clear of the glyphs and given a canvas ring: at -6px the 28px badge overlapped
             the initials, so "MR" read as "MP". The 44px hit area is unchanged. -->
        <div id="avatar-btn" style="position:absolute;bottom:-10px;right:-10px;width:44px;height:44px;display:flex;align-items:center;justify-content:center;cursor:pointer" title="Upload photo" aria-label="Upload photo"><span class="req-badge b" style="position:static;width:26px;height:26px;place-items:center;border:2px solid var(--bg);box-shadow:0 2px 6px rgba(0,0,0,0.4)">${icon("camera",13)}</span></div>
        <input type="file" id="avatar-file" accept="image/*" style="display:none" />
      </div>
      <div class="id-txt">
        <div class="nm">${esc(S.athlete.name)}</div>
        ${S.audience==="client"?`
        <div class="meta">${esc(S.planGoalLabel||"Personal plan")}</div>
        ${S.coach.kind==="trainer"&&S.coach.team?`<div class="meta" style="margin-top:1px">${esc(S.coach.team)}</div>`:""}`:`
        <!-- When these are empty they read "Add your sport" / "Add your school": an instruction
             with nowhere to go, since only the Edit button was tappable. An empty prompt is a
             control; give it the affordance it was already claiming. -->
        ${[S.athlete.sport,S.athlete.position].filter(Boolean).length?`<div class="meta">${esc([S.athlete.sport,S.athlete.position].filter(Boolean).join(" \xB7 "))}</div>`:`<div class="meta meta-add" data-go="edit-profile" role="button" tabindex="0">Add your sport</div>`}
        ${S.athlete.school?`<div class="meta" style="margin-top:1px">${esc(S.athlete.school)}</div>`:`<div class="meta meta-add" data-go="edit-profile" role="button" tabindex="0" style="margin-top:1px">Add your school</div>`}`}
      </div>
      <button class="btn ghost sm" style="width:auto;padding:0 16px;height:44px" data-go="edit-profile">Edit</button>
    </section>

    ${t.active?`
    <div style="height:12px"></div>
    <div class="trust" data-go="trust" style="cursor:pointer">
      <div class="ic">${icon("shield",20)}</div>
      <div style="flex:1">
        <div class="tt">${t.kind==="credits"?`Trust Pass active \xB7 ${t.left} left`:`Trust Pass active \xB7 day ${t.day} of ${t.length}`}</div>
        <div class="ts">Earned with ${(RT.passPolicy||{eligibility_days:7}).eligibility_days} photo-logged days. Tap for the rules.</div>
      </div>
      ${icon("chevron",18,'style="color:var(--text-3)"')}
    </div>`:""}

    <h2 class="eyebrow">${S.coach.kind==="trainer"?"Trainer":"Coach"} Connection</h2>
    ${S.coach.hasCoach?`
    <section class="card rows">
      <div class="lrow" style="cursor:default">
        ${""}
        <div class="lic" style="background:linear-gradient(150deg,var(--blue),var(--blue-deep));color:#fff;font-weight:800;font-size:var(--t-base)">${esc(S.coach.initials)}</div>
        <div class="lm"><div class="lt">${esc(S.coach.name)}</div><div class="ls">${esc([S.coach.role,S.coach.team].filter(Boolean).join(" \xB7 "))}</div></div>
      </div>
      <div class="lrow" data-go="messages">
        <div class="lic">${icon("message",17)}</div>
        <div class="lm"><div class="lt">Messages</div><div class="ls">${esc(S.coach.name)}'s comments land on your meals</div></div>
        ${icon("chevron",17,'style="color:var(--text-3)"')}
      </div>
      <div class="lrow" data-go="privacy">
        <div class="lic">${icon("eye",17)}</div>
        <div class="lm"><div class="lt">View connection</div><div class="ls">Exactly what ${esc(S.coach.nameMid)} can see</div></div>
        ${icon("chevron",17,'style="color:var(--text-3)"')}
      </div>
    </section>`:`
    <section class="card pad">
      <div style="font-size:15.5px;font-weight:800">Connect your coach or trainer</div>
      <div style="font-size:12.5px;font-weight:600;color:var(--text-2);margin-top:4px;line-height:1.5">Share your execution, receive requirements, and communicate directly.</div>
      <div style="display:flex;gap:10px;margin-top:12px">
        <button class="btn primary sm" data-go="connect" style="width:auto;padding:0 22px">${icon("key",16)} Connect</button>
      </div>
    </section>`}

    ${""}
    <h2 class="eyebrow">Account</h2>
    <section class="card rows">
      <div class="lrow" data-go="edit-profile">
        <div class="lic">${icon("user",17)}</div>
        <div class="lm"><div class="lt">Personal details</div><div class="ls">Name, sport, position, school</div></div>
        ${icon("chevron",17,'class="chev-dim"')}
      </div>
      <div class="lrow" data-go="settings">
        <div class="lic">${icon("gear",18)}</div>
        <div class="lm"><div class="lt">Preferences</div><div class="ls">Units, appearance, Face ID, app tour</div></div>
        ${icon("chevron",17,'class="chev-dim"')}
      </div>
      <div class="lrow" data-go="billing">
        <div class="lic" style="background:var(--green-surface);color:var(--green-bright)">${icon("bolt",17)}</div>
        <div class="lm"><div class="lt">Plan &amp; billing</div><div class="ls">Your membership &amp; premium features</div></div>
        ${icon("chevron",17,'class="chev-dim"')}
      </div>
      <div class="lrow" data-go="invite-parent">
        <div class="lic">${icon("users",17)}</div>
        <div class="lm"><div class="lt">Invite a parent</div><div class="ls">Let a parent see your score &amp; streak</div></div>
        ${icon("chevron",17,'class="chev-dim"')}
      </div>
    </section>

    <h2 class="eyebrow">Goals &amp; tracking</h2>
    <section class="card rows">
      <div class="lrow" data-go="plan-style">
        <div class="lic">${icon("target",17)}</div>
        <div class="lm"><div class="lt">Plan style</div><div class="ls">${esc(S.planStyle.name)} \xB7 ${S.planStyle.canChoose?"yours to change":esc(S.planStyle.sourceLabel)}</div></div>
        ${icon("chevron",17,'class="chev-dim"')}
      </div>
      <div class="lrow" data-go="apple-health">
        <div class="lic">${icon("heart",17)}</div>
        <div class="lm"><div class="lt">Apple Health</div><div class="ls">Steps, workouts and sleep, from your phone</div></div>
        ${icon("chevron",17,'class="chev-dim"')}
      </div>
      <div class="lrow" data-go="notif-settings">
        <div class="lic">${icon("bell",18)}</div>
        <div class="lm"><div class="lt">Tracking reminders</div><div class="ls">Tone, quiet hours</div></div>
        ${icon("chevron",17,'class="chev-dim"')}
      </div>
      <div class="lrow" data-go="score-explained">
        <div class="lic" style="color:var(--blue-bright)">${icon("info",17)}</div>
        <div class="lm"><div class="lt">Score colors explained</div><div class="ls">What every tier and meal band means</div></div>
        ${icon("chevron",17,'class="chev-dim"')}
      </div>
    </section>

    <h2 class="eyebrow">Accountability</h2>
    <section class="card rows">
      <div class="lrow" data-go="streak">
        ${""}
        <div class="lic">${icon("flame",18)}</div>
        <div class="lm"><div class="lt">Streak</div><div class="ls">Days on standard \xB7 1 grace per rolling week</div></div>
        <span class="lv">${S.streakDays}d</span>${icon("chevron",17,'class="chev-dim"')}
      </div>
      <div class="lrow" data-go="history">
        <div class="lic">${icon("clipboard",17)}</div>
        <div class="lm"><div class="lt">Activity history</div><div class="ls">The proof trail, day by day</div></div>
        ${icon("chevron",17,'class="chev-dim"')}
      </div>
      <div class="lrow" data-go="connected-standards">
        <div class="lic" style="color:var(--blue-bright)">${icon("bolt",17)}</div>
        <div class="lm"><div class="lt">Activity standards</div><div class="ls">Steps, distance and workouts \xB7 verified from your device</div></div>
        ${icon("chevron",17,'class="chev-dim"')}
      </div>
    </section>

    ${""}
    ${S.audience==="client"&&S.coach.kind==="trainer"?"":`
    <h2 class="eyebrow">Proof &amp; recruiting</h2>
    <section class="card rows">
      <div class="lrow" data-go="recruiting">
        <div class="lic"${S.coach.hasCoach?' style="background:var(--green-surface);color:var(--green-bright)"':""}>${icon("shield",17)}</div>
        <div class="lm"><div class="lt">Discipline record</div><div class="ls">${S.coach.hasCoach?"Coach-verified \xB7 proof of the work":"Not verified yet \xB7 connect a coach to verify"}</div></div>
        ${icon("chevron",17,'class="chev-dim"')}
      </div>
      <div class="lrow" data-go="verified-profile">
        <div class="lic" style="color:var(--blue-bright)">${icon("share",17)}</div>
        <div class="lm"><div class="lt">Verified Profile</div><div class="ls">A public page recruiters can check</div></div>
        ${icon("chevron",17,'class="chev-dim"')}
      </div>
    </section>`}

    <h2 class="eyebrow">Health &amp; safety</h2>
    <section class="card rows">
      <div class="lrow" data-go="restrictions">
        <div class="lic" style="background:var(--red-surface);color:var(--red)">${icon("bell",17)}</div>
        <div class="lm"><div class="lt">Food restrictions &amp; allergies</div><div class="ls">${RT.allergies.length?esc(RT.allergies.join(" \xB7 ")):"None declared"}</div></div>
        ${icon("chevron",17,'class="chev-dim"')}
      </div>
    </section>

    <h2 class="eyebrow">Support &amp; legal</h2>
    <section class="card rows">
      <div class="lrow" data-go="feedback">
        <div class="lic">${icon("message",17)}</div>
        <div class="lm"><div class="lt">Request a feature</div><div class="ls">Or report a bug, or ask us anything</div></div>
        ${icon("chevron",17,'class="chev-dim"')}
      </div>
      ${""}
      ${ext("mailto:support@onstandard.app","mail","Support email","support@onstandard.app")}
      ${ext("https://onstandard.app/terms","clipboard","Terms and conditions","The full agreement")}
      ${ext("https://onstandard.app/privacy","lock","Privacy policy","What we collect and why")}
      <div class="lrow" data-go="privacy">
        <div class="lic">${icon("eye",17)}</div>
        <div class="lm"><div class="lt">Privacy &amp; visibility</div><div class="ls">Who sees what \xB7 download your data</div></div>
        ${icon("chevron",17,'class="chev-dim"')}
      </div>
    </section>

    <h2 class="eyebrow">Follow us</h2>
    <section class="card rows">
      ${ext("https://instagram.com/onstandard","camera","Instagram","@onstandard")}
      ${ext("https://x.com/onstandard","external","X","@onstandard")}
    </section>

    <h2 class="eyebrow">Account actions</h2>
    <section class="card rows">
      ${""}
      <div class="lrow" id="pf-signout" role="button" tabindex="0"><div class="lic">${icon("back",17)}</div><div class="lm"><div class="lt">Sign out</div><div class="ls" id="pf-signout-sub" style="display:none">You'll need your password to get back in.</div></div></div>
      <div class="lrow" data-go="delete-account"><div class="lic" style="color:var(--red)">${icon("trash",17)}</div><div class="lm"><div class="lt" style="color:var(--red)">Delete account</div></div>${icon("chevron",17,'class="chev-dim"')}</div>
    </section>

    <div style="height:10px"></div>
    `},mount(root){(async()=>{const slot=root.querySelector("#pf-arrival-state");if(!slot)return;const paint=(cls,label)=>{const el=document.createElement("span");el.className=`status-pill ${cls}`;el.textContent=label;slot.replaceWith(el)};if(RT.locationOptOut){paint("muted","Off");return}const loc=typeof window!=="undefined"&&window.OnStandardNative?window.OnStandardNative.location:null;if(!loc)return;let r=null;try{r=await loc.available()}catch{return}if(!slot.isConnected||!r||!r.available)return;if(r.state==="always")paint("g","On");else if(r.state==="when_in_use")paint("a","App open only");else if(r.state==="denied")paint("a","Blocked")})();const signout=root.querySelector("#pf-signout");if(signout){const lt=signout.querySelector(".lt");const sub=signout.querySelector("#pf-signout-sub");let armTimer=null;const disarm=()=>{if(armTimer){clearTimeout(armTimer);armTimer=null}if(lt)lt.textContent="Sign out";if(sub)sub.style.display="none"};signout.addEventListener("click",()=>{if(armTimer){disarm();window.__go("welcome");return}if(lt)lt.textContent="Tap again to sign out";if(sub)sub.style.display="";armTimer=setTimeout(disarm,5e3)})}const btn=root.querySelector("#avatar-btn");const file=root.querySelector("#avatar-file");if(btn&&file){const idTxt=root.querySelector(".id-card .id-txt");const err=document.createElement("div");err.id="avatar-err";err.className="id-err";idTxt?.insertAdjacentElement("beforeend",err);let busy=false;const setBusy=on=>{busy=on;btn.style.opacity=on?"0.5":"";btn.title=on?"Uploading photo\u2026":"Upload photo"};btn.addEventListener("click",e=>{e.stopPropagation();if(busy)return;file.click()});import("../avatar.js").then(({avatarReady})=>{if(S.athlete.avatar)return renderRemove();avatarReady(RT.userId,RT.avatarVer||"").then(url=>{if(url)renderRemove()});function renderRemove(){if(!err.isConnected||document.getElementById("avatar-remove"))return;const rm=document.createElement("button");rm.id="avatar-remove";rm.className="id-act";rm.type="button";rm.textContent="Remove photo";err.insertAdjacentElement("beforebegin",rm);rm.addEventListener("click",async()=>{if(busy)return;setBusy(true);rm.disabled=true;const ok=await window.__act.removeAvatar();setBusy(false);if(ok){window.__render()}else{rm.disabled=false;err.textContent="Couldn't remove it. Check your connection and try again."}})}});file.addEventListener("change",()=>{const f=file.files&&file.files[0];file.value="";if(!f)return;err.textContent="Uploading your photo\u2026";setBusy(true);const reader=new FileReader;reader.onerror=()=>{setBusy(false);err.textContent="Couldn't read that photo. Try a JPG or PNG."};reader.onload=()=>{const img=new Image;img.onerror=()=>{setBusy(false);err.textContent="Couldn't read that photo. Try a JPG or PNG from your library."};img.onload=async()=>{const c=document.createElement("canvas");const s=Math.min(img.width,img.height);c.width=256;c.height=256;const ctx=c.getContext("2d");ctx.drawImage(img,(img.width-s)/2,(img.height-s)/2,s,s,0,0,256,256);const ok=await window.__act.setAvatar(c.toDataURL("image/jpeg",.82));setBusy(false);if(ok){window.__render();return}const why=String(RT.avatarError||"");err.textContent=/403|policy|unauthori[sz]ed|row-level/i.test(why)?"The server wouldn't accept the photo. That's on us, not your connection; it's been reported.":/413|too large|size/i.test(why)?"That photo is too large even after resizing. Try a different one.":/415|mime|type/i.test(why)?"That file type is not supported. Try a JPG or PNG.":/network|fetch|timeout|threw/i.test(why)?"The photo didn't upload. Check your connection and try again.":"The photo didn't upload. Try again in a moment; if it keeps failing, it's on our side."};img.src=reader.result};reader.readAsDataURL(f)})}}};export const SPORT_POSITIONS={Football:["QB","RB","WR","TE","OL","DL","LB","DB","K","P","LS","Athlete"],Basketball:["Point Guard","Shooting Guard","Wing","Forward","Center"],Baseball:["Pitcher","Catcher","Infield","Outfield","Utility"],Soccer:["Goalkeeper","Defender","Midfielder","Forward"],Track:["Sprints","Hurdles","Middle Distance","Distance","Jumps","Throws","Multis"],Volleyball:["Setter","Libero","Middle Blocker","Outside Hitter","Opposite"]};export const editProfile={tab:"profile",render(){const a=S.athlete;const dob=RT.profile&&RT.profile.dob||"";const sport=a.sport&&SPORT_POSITIONS[a.sport]?a.sport:a.sport;const positions=SPORT_POSITIONS[sport]||null;return`
    ${backHead("Edit profile","Only what your coach and score need","profile")}

    <h2 class="eyebrow">Name</h2>
    <div style="display:flex;gap:10px">
      <input class="ob-input ep-field" id="ep-first" maxlength="40" value="${esc(a.first==="Athlete"&&!a.last?"":a.first)}" placeholder="First name" aria-label="First name" autocomplete="given-name" style="flex:1" />
      <input class="ob-input ep-field" id="ep-last" maxlength="40" value="${esc(a.last)}" placeholder="Last name" aria-label="Last name" autocomplete="family-name" style="flex:1" />
    </div>

    <h2 class="eyebrow">Date of birth</h2>
    ${""}
    <div class="ep-dob-wrap">
      <input class="ob-input ep-field${dob?"":" is-empty"}" id="ep-dob" type="date" value="${esc(dob)}" max="${new Date().toISOString().slice(0,10)}" aria-label="Date of birth" />
      ${dob?"":'<span class="ep-dob-hint" aria-hidden="true">Add your birth date</span>'}
    </div>

    <h2 class="eyebrow">Sport</h2>
    <div class="chip-row" id="ep-sport" data-toggle-group>
      ${Object.keys(SPORT_POSITIONS).map(s=>`<span class="chip ${sport===s?"on":""}">${s}</span>`).join("")}
    </div>

    <h2 class="eyebrow">${sport==="Track"?"Event group":"Position"}</h2>
    ${positions?`
    <div class="chip-row" id="ep-pos" data-toggle-group>
      ${positions.map(p=>`<span class="chip ${a.position===p?"on":""}">${p}</span>`).join("")}
    </div>`:`
    <div style="font-size:12.5px;font-weight:600;color:var(--text-3);padding:2px 2px 4px">Pick a sport first; positions follow the sport.</div>`}

    <h2 class="eyebrow">School / organization</h2>
    <input class="ob-input ep-field" id="ep-school" maxlength="80" value="${esc(a.school)}" placeholder="Search your school or team" aria-label="School or organization" autocomplete="off" />
    <div id="ep-school-results" class="ep-results" hidden></div>

    <div style="height:14px"></div>
    <div class="sidebox">
      <div class="req-icon b s38">${icon("lock",17)}</div>
      <div><div class="tt">That's all we ask for</div>
      <div class="ts">No bios, no socials, no feeds. Goals and weight live in your Standard; this is who your coach sees.</div></div>
    </div>

    <div style="height:16px"></div>
    <div id="ep-err" style="color:var(--red-bright);font-size:13px;font-weight:600;min-height:18px;text-align:center"></div>
    <button class="btn primary" id="ep-save" disabled style="opacity:.5">${icon("check",19)} Save</button>
    <div style="height:10px"></div>
    `},async mount(root){const btn=root.querySelector("#ep-save");const err=root.querySelector("#ep-err");let dirty=false;const markDirty=()=>{if(dirty)return;dirty=true;btn.disabled=false;btn.style.opacity="1";editProfile._dirty=true};editProfile._dirty=false;root.querySelectorAll(".ep-field").forEach(el=>el.addEventListener("input",markDirty));const dobEl=root.querySelector("#ep-dob");const dobHint=root.querySelector(".ep-dob-hint");if(dobEl){const syncDob=()=>{markDirty();if(dobHint)dobHint.hidden=!!dobEl.value;dobEl.classList.toggle("is-empty",!dobEl.value)};dobEl.addEventListener("change",syncDob);dobEl.addEventListener("input",syncDob)}root.querySelectorAll("#ep-sport .chip").forEach(ch=>ch.addEventListener("click",()=>{root.querySelectorAll("#ep-sport .chip").forEach(x=>x.classList.remove("on"));ch.classList.add("on");markDirty();const sport=ch.textContent;const posWrap=root.querySelector("#ep-pos");const list=SPORT_POSITIONS[sport]||[];if(posWrap){const prev=posWrap.querySelector(".on")?posWrap.querySelector(".on").textContent:"";posWrap.innerHTML=list.map(p=>`<span class="chip ${p===prev?"on":""}">${p}</span>`).join("");wirePos()}}));const wirePos=()=>{root.querySelectorAll("#ep-pos .chip").forEach(ch=>ch.addEventListener("click",()=>{root.querySelectorAll("#ep-pos .chip").forEach(x=>x.classList.remove("on"));ch.classList.add("on");markDirty()}))};wirePos();const school=root.querySelector("#ep-school");const results=root.querySelector("#ep-school-results");if(school&&results){const search=debounce(async()=>{const q=school.value.trim();if(q.length<3){results.hidden=true;return}try{const data=await dir.search(q);const orgs=data&&data.orgs||[];if(!orgs.length){results.hidden=true;return}results.innerHTML=orgs.slice(0,5).map(o=>`<div class="ep-result" data-name="${esc(o.name)}">${esc(o.name)}${o.city||o.state?`<span>${esc([o.city,o.state].filter(Boolean).join(", "))}</span>`:""}</div>`).join("");results.hidden=false;results.querySelectorAll(".ep-result").forEach(r=>r.addEventListener("click",()=>{school.value=r.getAttribute("data-name");results.hidden=true;markDirty()}))}catch{results.hidden=true}},300);school.addEventListener("input",search)}btn.addEventListener("click",async()=>{const first=root.querySelector("#ep-first").value.trim();const last=root.querySelector("#ep-last").value.trim();const dob=root.querySelector("#ep-dob").value;const schoolV=root.querySelector("#ep-school").value.trim();const sport=root.querySelector("#ep-sport .on")?.textContent||"";const position=root.querySelector("#ep-pos .on")?.textContent||"";if(!first){err.textContent="Add your first name: your coach sees it on every log.";return}if(!last){err.textContent="Add your last name.";return}if(dob){const d=new Date(dob+"T12:00:00");const age=(Date.now()-d.getTime())/(365.25*864e5);if(isNaN(d.getTime())||age<5||age>100){err.textContent="Check your date of birth.";return}const cur=RT.profile&&RT.profile.dob||"";const curMinor=cur?(Date.now()-new Date(cur+"T12:00:00").getTime())/(365.25*864e5)<18:false;if(age<18&&!curMinor&&editProfile._minorConfirm!==dob){editProfile._minorConfirm=dob;err.textContent="This birth date says you\u2019re under 18. That turns on the protections for minors, and only a parent or support can undo it. Tap Save again to confirm.";return}}err.textContent="";btn.disabled=true;const was=btn.innerHTML;btn.textContent="Saving\u2026";const name=`${first} ${last}`.trim();window.__act.saveProfile({name,school:schoolV,sport,position});const ok=await window.__act.saveIdentity({full_name:name,sport,position});let dobOk=true;if(dob){const r=await window.__act.setMyDob(dob);if(r.reason==="locked"){err.textContent="Your birth date is locked while you\u2019re under 18. A parent or support can correct it.";btn.disabled=false;btn.innerHTML=was;return}if(r.reason==="floor"){err.textContent="OnStandard is for athletes 13 and up.";btn.disabled=false;btn.innerHTML=was;return}dobOk=r.ok;if(r.ok)window.__act.saveProfile({dob})}if(dobOk===false&&ok!==false){err.textContent="Couldn\u2019t save your birth date. Check your connection and try again.";btn.disabled=false;btn.innerHTML=was;return}if(ok===false){err.textContent="Saved on this phone, couldn\u2019t reach the server. It\u2019ll sync when you\u2019re back online.";btn.disabled=false;btn.innerHTML=was;return}editProfile._dirty=false;btn.textContent="Saved";setTimeout(()=>window.__back("profile"),350)});root.querySelectorAll("[data-back]").forEach(el=>{el.addEventListener("click",e=>{if(editProfile._dirty&&!window.confirm("Discard your unsaved changes?")){e.stopImmediatePropagation();e.preventDefault()}else{editProfile._dirty=false}},{capture:true})})}};
