import { S, RT } from '../state.js';
import { icon } from '../icons.js';
import { backHead, esc, safeImg } from '../components.js';
import { dir, debounce } from '../ob-directory.js';

function avatarEl(size = 62) {
  const a = S.athlete;
  return a.avatar && safeImg(a.avatar)
    ? `<div class="big-av" style="width:${size}px;height:${size}px;background-image:url('${safeImg(a.avatar)}');background-size:cover;background-position:center"></div>`
    : `<div class="big-av" style="width:${size}px;height:${size}px" data-avatar-uid="${esc(RT.userId || '')}" data-avatar-ver="${esc(RT.avatarVer || '')}"><span data-avatar-fallback>${esc(a.initials)}</span></div>`;
}

export default {
  tab: 'profile',
  render() {
    const t = S.pass;
    return `
    <div class="screen-title">Profile</div>

    <section class="card id-card">
      <div style="position:relative" id="avatar-wrap">
        ${avatarEl()}
        <!-- Pushed clear of the glyphs and given a canvas ring: at -6px the 28px badge overlapped
             the initials, so "MR" read as "MP". The 44px hit area is unchanged. -->
        <div id="avatar-btn" style="position:absolute;bottom:-10px;right:-10px;width:44px;height:44px;display:flex;align-items:center;justify-content:center;cursor:pointer" title="Upload photo" aria-label="Upload photo"><span class="req-badge b" style="position:static;width:26px;height:26px;place-items:center;border:2px solid var(--bg);box-shadow:0 2px 6px rgba(0,0,0,0.4)">${icon('camera', 13)}</span></div>
        <input type="file" id="avatar-file" accept="image/*" style="display:none" />
      </div>
      <div class="id-txt">
        <div class="nm">${esc(S.athlete.name)}</div>
        ${S.audience === 'client' ? `
        <div class="meta">${esc(S.planGoalLabel || 'Personal plan')}</div>
        ${S.coach.kind === 'trainer' && S.coach.team ? `<div class="meta" style="margin-top:1px">${esc(S.coach.team)}</div>` : ''}` : `
        <!-- When these are empty they read "Add your sport" / "Add your school": an instruction
             with nowhere to go, since only the Edit button was tappable. An empty prompt is a
             control; give it the affordance it was already claiming. -->
        ${[S.athlete.sport, S.athlete.position].filter(Boolean).length
    ? `<div class="meta">${esc([S.athlete.sport, S.athlete.position].filter(Boolean).join(' · '))}</div>`
    : `<div class="meta meta-add" data-go="edit-profile" role="button" tabindex="0">Add your sport</div>`}
        ${S.athlete.school
    ? `<div class="meta" style="margin-top:1px">${esc(S.athlete.school)}</div>`
    : `<div class="meta meta-add" data-go="edit-profile" role="button" tabindex="0" style="margin-top:1px">Add your school</div>`}`}
      </div>
      <button class="btn ghost sm" style="width:auto;padding:0 16px;height:44px" data-go="edit-profile">Edit</button>
    </section>

    ${t.active ? `
    <div style="height:12px"></div>
    <div class="trust" data-go="trust" style="cursor:pointer">
      <div class="ic">${icon('shield', 20)}</div>
      <div style="flex:1">
        <div class="tt">${t.kind === 'credits' ? `Trust Pass active · ${t.left} left` : `Trust Pass active · day ${t.day} of ${t.length}`}</div>
        <div class="ts">Earned with ${(RT.passPolicy || { eligibility_days: 7 }).eligibility_days} photo-logged days. Tap for the rules.</div>
      </div>
      ${icon('chevron', 18, 'style="color:var(--text-3)"')}
    </div>` : ''}

    <h2 class="eyebrow">${S.coach.kind === 'trainer' ? 'Trainer' : 'Coach'} Connection</h2>
    ${S.coach.hasCoach ? `
    <section class="card" style="padding:6px 16px">
      <div class="lrow" style="cursor:default">
        ${/* Identity, not a warning: the person you answer to was painted in hardcoded amber — the
      hue this system reserves for "at risk / off pace" — so the coach read as a hazard tile on
      the athlete's own profile. Identity wears the brand spine. */''}
        <div class="lic" style="background:linear-gradient(150deg,var(--blue),var(--blue-deep));color:#fff;font-weight:800;font-size:var(--t-base)">${esc(S.coach.initials)}</div>
        <div class="lm"><div class="lt">${esc(S.coach.name)}</div><div class="ls">${esc([S.coach.role, S.coach.team].filter(Boolean).join(' · '))}</div></div>
      </div>
      <div class="lrow" data-go="messages">
        <div class="lic">${icon('message', 17)}</div>
        <div class="lm"><div class="lt">Messages</div><div class="ls">${esc(S.coach.name)}'s comments land on your meals</div></div>
        ${icon('chevron', 17, 'style="color:var(--text-3)"')}
      </div>
      <div class="lrow" data-go="privacy">
        <div class="lic">${icon('eye', 17)}</div>
        <div class="lm"><div class="lt">View connection</div><div class="ls">Exactly what ${esc(S.coach.nameMid)} can see</div></div>
        ${icon('chevron', 17, 'style="color:var(--text-3)"')}
      </div>
    </section>` : `
    <section class="card pad">
      <div style="font-size:15.5px;font-weight:800">Connect your coach or trainer</div>
      <div style="font-size:12.5px;font-weight:600;color:var(--text-2);margin-top:4px;line-height:1.5">Share your execution, receive requirements, and communicate directly.</div>
      <div style="display:flex;gap:10px;margin-top:12px">
        <button class="btn primary sm" data-go="connect" style="width:auto;padding:0 22px">${icon('key', 16)} Connect</button>
        <button class="btn ghost sm" data-go="get-a-coach" style="width:auto;padding:0 18px">${icon('users', 16)} Get a coach</button>
      </div>
    </section>`}

    <h2 class="eyebrow">Accountability</h2>
    <section class="card" style="padding:6px 16px">
      <div class="lrow" data-go="notif-settings">
        <div class="lic">${icon('bell', 18)}</div>
        <div class="lm"><div class="lt">Notifications</div><div class="ls">Pressure level, quiet hours</div></div>
        ${icon('chevron', 17, 'style="color:var(--text-3)"')}
      </div>
      <div class="lrow" data-go="streak">
        ${/* Default .lic treatment: amber is the warning hue, and a healthy streak is not a
              warning. The flame reads fine in the neutral icon well. */''}
        <div class="lic">${icon('flame', 18)}</div>
        <div class="lm"><div class="lt">Streak</div><div class="ls">Days on standard · 1 grace per rolling week</div></div>
        <span class="lv">${S.streakDays}d</span>${icon('chevron', 17, 'style="color:var(--text-3)"')}
      </div>
      <div class="lrow" data-go="history">
        <div class="lic">${icon('clipboard', 17)}</div>
        <div class="lm"><div class="lt">Activity history</div><div class="ls">The proof trail, day by day</div></div>
        ${icon('chevron', 17, 'style="color:var(--text-3)"')}
      </div>
      <div class="lrow" data-go="connected-standards">
        <div class="lic" style="color:var(--blue-bright)">${icon('bolt', 17)}</div>
        <div class="lm"><div class="lt">Activity standards</div><div class="ls">Steps, distance and workouts · verified from your device</div></div>
        ${icon('chevron', 17, 'class="chev-dim"')}
      </div>
      <div class="lrow" data-go="location-consent">
        <div class="lic">${icon('target', 17)}</div>
        ${/* "on/off lives here" was the only way to learn the state without opening the screen.
              The pill says it now, so the subtitle stops repeating it and stops wrapping to a
              second line at 390px next to the pill. */''}
        <div class="lm"><div class="lt">Arrival check-in</div><div class="ls">How showing up is confirmed</div></div>
        <span id="pf-arrival-state"></span>
        ${icon('chevron', 17, 'class="chev-dim"')}
      </div>
    </section>

    ${/* Split out of Accountability (critique 2026-08-15): that group ran 6 rows, over the ≤4
          chunk the groups below already keep, and these rows share a different job — what the
          work proves to outsiders, not the daily loop. Row count unchanged, like the split
          below. */''}
    ${S.audience === 'client' && S.coach.kind === 'trainer' ? `
    <h2 class="eyebrow">Coaching</h2>
    <section class="card" style="padding:6px 16px">
      <div class="lrow" data-go="my-trainer-offers">
        <div class="lic" style="background:var(--green-surface);color:var(--green-bright)">${icon('bolt', 17)}</div>
        <div class="lm"><div class="lt">Packages</div><div class="ls">${S.coach.isNamed ? `What ${esc(S.coach.nameMid)} offers` : 'Plans your trainer offers'}</div></div>
        ${icon('chevron', 17, 'style="color:var(--text-3)"')}
      </div>
    </section>` : `
    <h2 class="eyebrow">Proof &amp; recruiting</h2>
    <section class="card" style="padding:6px 16px">
      <div class="lrow" data-go="recruiting">
        <div class="lic"${S.coach.hasCoach ? ' style="background:var(--green-surface);color:var(--green-bright)"' : ''}>${icon('shield', 17)}</div>
        <div class="lm"><div class="lt">Discipline record</div><div class="ls">${S.coach.hasCoach ? 'Coach-verified · proof of the work' : 'Not verified yet · connect a coach to verify'}</div></div>
        ${icon('chevron', 17, 'style="color:var(--text-3)"')}
      </div>
      <div class="lrow" data-go="verified-profile">
        <div class="lic" style="color:var(--blue-bright)">${icon('share', 17)}</div>
        <div class="lm"><div class="lt">Verified Profile</div><div class="ls">A public page recruiters can check</div></div>
        ${icon('chevron', 17, 'style="color:var(--text-3)"')}
      </div>
    </section>`}

    <h2 class="eyebrow">Health & safety</h2>
    <section class="card" style="padding:6px 16px">
      <div class="lrow" data-go="restrictions">
        <div class="lic" style="background:var(--red-surface);color:var(--red)">${icon('bell', 17)}</div>
        <div class="lm"><div class="lt">Food restrictions & allergies</div><div class="ls">${RT.allergies.length ? esc(RT.allergies.join(' · ')) : 'None declared'}</div></div>
        ${icon('chevron', 17, 'style="color:var(--text-3)"')}
      </div>
      <div class="lrow" data-go="injury">
        <div class="lic" style="background:rgba(var(--amber-rgb),0.16);color:var(--amber-bright)">${icon('bolt', 17)}</div>
        <div class="lm"><div class="lt">Injury mode</div><div class="ls">${RT.injured ? 'Active · your Standard is adapted' : 'The Standard adapts when you’re hurt'}</div></div>
        ${icon('chevron', 17, 'style="color:var(--text-3)"')}
      </div>
    </section>

    ${/* Was ONE "Settings" group of nine consecutive rows, Plan & billing straight through to
          Sign out — more than double the ≤4 chunk working memory holds, with billing, a privacy
          audit and account deletion all reading as siblings. Three groups, each ≤4, each named
          for what its rows share; the destructive pair sits alone at the bottom where every
          platform convention puts it. Row count is unchanged — this is chunking, not burying. */''}
    <h2 class="eyebrow">Membership</h2>
    <section class="card" style="padding:6px 16px">
      <div class="lrow" data-go="billing"><div class="lic" style="background:var(--green-surface);color:var(--green-bright)">${icon('bolt', 17)}</div><div class="lm"><div class="lt">Plan &amp; billing</div><div class="ls">Your membership &amp; premium features</div></div>${icon('chevron', 17)}</div>
      <div class="lrow" data-go="redeem-code"><div class="lic">${icon('key', 17)}</div><div class="lm"><div class="lt">Redeem a code</div><div class="ls">Unlock premium with a sponsor code</div></div>${icon('chevron', 17)}</div>
      <div class="lrow" data-go="sponsor"><div class="lic" style="background:var(--green-surface);color:var(--green-bright)">${icon('bolt', 17)}</div><div class="lm"><div class="lt">Sponsor access</div><div class="ls">Fund premium for a group</div></div>${icon('chevron', 17)}</div>
    </section>

    <h2 class="eyebrow">Privacy &amp; app</h2>
    <section class="card" style="padding:6px 16px">
      <div class="lrow" data-go="invite-parent"><div class="lic">${icon('users', 17)}</div><div class="lm"><div class="lt">Invite a parent</div><div class="ls">Let a parent see your score &amp; streak</div></div>${icon('chevron', 17)}</div>
      <div class="lrow" data-go="privacy"><div class="lic">${icon('lock', 17)}</div><div class="lm"><div class="lt">Privacy & visibility</div><div class="ls">Who sees what · download your data</div></div>${icon('chevron', 17)}</div>
      <div class="lrow" data-go="settings"><div class="lic">${icon('gear', 18)}</div><div class="lm"><div class="lt">Units & appearance</div></div>${icon('chevron', 17)}</div>
      <div class="lrow" data-go="terms"><div class="lic">${icon('clipboard', 17)}</div><div class="lm"><div class="lt">Terms & privacy policy</div></div>${icon('chevron', 17)}</div>
    </section>

    <h2 class="eyebrow">Account</h2>
    <section class="card" style="padding:6px 16px">
      ${/* Two-tap confirm, wired in mount(): a single unguarded tap signed the athlete out, and
            on a shared phone that is one brush of a thumb. Disarms after ~5 seconds. */''}
      <div class="lrow" id="pf-signout" role="button" tabindex="0"><div class="lic">${icon('back', 17)}</div><div class="lm"><div class="lt">Sign out</div><div class="ls" id="pf-signout-sub" style="display:none">You'll need your password to get back in.</div></div></div>
      <div class="lrow" data-go="delete-account"><div class="lic" style="color:var(--red)">${icon('trash', 17)}</div><div class="lm"><div class="lt" style="color:var(--red)">Delete account</div></div>${icon('chevron', 17)}</div>
    </section>

    <div style="height:10px"></div>
    `;
  },
  mount(root) {
    /* Arrival check-in wears its own state, so "is this actually on" is readable from Profile
       without opening the screen (PRODUCT.md: glanceable truth in under 3 seconds). Before this
       the row read the same sentence whether the athlete had it armed, had never granted the
       permission, or had it blocked in iOS Settings, so the only way to learn the answer was to
       go looking for it.

       Probed live on every mount rather than cached: the athlete may have changed the grant in
       the Settings app since the last paint, and a row reporting last week's answer is worse
       than a row reporting nothing. The row renders stateless and only ever GAINS a pill, so a
       missing bridge, a refused probe, or an older build degrades to exactly today's appearance
       instead of an empty box or a wrong claim.

       Written straight into the slot instead of through __render(): mount() re-runs on every
       render, so re-rendering from here is the infinite loop connected-standards.js documents. */
    (async () => {
      const slot = root.querySelector('#pf-arrival-state');
      if (!slot) return;
      // Built with textContent, never an HTML sink. The labels below are literals today, but a
      // status pill is exactly the kind of thing someone later feeds a server string, and this
      // shape makes that safe by construction instead of by remembering.
      const paint = (cls, label) => {
        const el = document.createElement('span');
        el.className = `status-pill ${cls}`;
        el.textContent = label;
        slot.replaceWith(el);
      };
      // The athlete's own opt-out outranks the OS grant, exactly as it does on the screen itself:
      // "off" they chose has to READ as off even while iOS still says 'always'.
      if (RT.locationOptOut) { paint('muted', 'Off'); return; }
      const loc = (typeof window !== 'undefined' && window.OnStandardNative)
        ? window.OnStandardNative.location : null;
      if (!loc) return;
      let r = null;
      try { r = await loc.available(); } catch { return; }
      if (!slot.isConnected || !r || !r.available) return;
      if (r.state === 'always') paint('g', 'On');
      else if (r.state === 'when_in_use') paint('a', 'App open only');
      else if (r.state === 'denied') paint('a', 'Blocked');
    })();

    // Sign out arms on the first tap and executes on a second tap within 5 seconds; leaving it
    // alone (or tapping elsewhere and coming back) disarms. Keyboard activation comes from the
    // router's central promotion: no local keydown handler, it would double-fire.
    const signout = root.querySelector('#pf-signout');
    if (signout) {
      const lt = signout.querySelector('.lt');
      const sub = signout.querySelector('#pf-signout-sub');
      let armTimer = null;
      const disarm = () => {
        if (armTimer) { clearTimeout(armTimer); armTimer = null; }
        if (lt) lt.textContent = 'Sign out';
        if (sub) sub.style.display = 'none';
      };
      signout.addEventListener('click', () => {
        if (armTimer) { disarm(); window.__go('welcome'); return; }
        if (lt) lt.textContent = 'Tap again to sign out';
        if (sub) sub.style.display = '';
        armTimer = setTimeout(disarm, 5000);
      });
    }

    const btn = root.querySelector('#avatar-btn');
    const file = root.querySelector('#avatar-file');
    if (btn && file) {
      // Injected fresh on every mount, so it needs no data-go/data-act wiring — the
      // router only wires those at render time, but this element never touches render().
      // Both the error line and "Remove photo" live INSIDE the identity card, under the name.
      // They used to be injected after the card, which left a lone centred pill floating in
      // the gap between the card and "Coach connection" with nothing to tie it to the photo
      // it acts on (2026-09-01 polish capture).
      const idTxt = root.querySelector('.id-card .id-txt');
      const err = document.createElement('div');
      err.id = 'avatar-err';
      err.className = 'id-err';
      idTxt?.insertAdjacentElement('beforeend', err);

      let busy = false;
      const setBusy = (on) => {
        busy = on;
        btn.style.opacity = on ? '0.5' : '';
        btn.title = on ? 'Uploading photo…' : 'Upload photo';
      };

      btn.addEventListener('click', (e) => {
        e.stopPropagation();
        if (busy) return;
        file.click();
      });
      // "Remove photo" appears only once a photo exists (locally or on the server): a control for
      // undoing something that hasn't happened is noise.
      import('../avatar.js').then(({ avatarReady }) => {
        if (S.athlete.avatar) return renderRemove();
        avatarReady(RT.userId, RT.avatarVer || '').then((url) => { if (url) renderRemove(); });
        function renderRemove() {
          if (!err.isConnected || document.getElementById('avatar-remove')) return;
          const rm = document.createElement('button');
          rm.id = 'avatar-remove';
          rm.className = 'id-act';
          rm.type = 'button';
          rm.textContent = 'Remove photo';
          err.insertAdjacentElement('beforebegin', rm);
          rm.addEventListener('click', async () => {
            if (busy) return;
            setBusy(true);
            rm.disabled = true;
            const ok = await window.__act.removeAvatar();
            setBusy(false);
            if (ok) { window.__render(); }
            else { rm.disabled = false; err.textContent = "Couldn't remove it. Check your connection and try again."; }
          });
        }
      });
      file.addEventListener('change', () => {
        const f = file.files && file.files[0];
        // Let the SAME photo be picked again after a failed upload: a file input never fires
        // `change` for a value it already holds, so the second tap used to do nothing at all.
        file.value = '';
        if (!f) return;
        // Uploading is a state the athlete should see, not infer from a dimmed button. The
        // line clears on success (the repaint replaces it) and is overwritten on failure.
        err.textContent = 'Uploading your photo…';
        setBusy(true);
        const reader = new FileReader();
        reader.onerror = () => {
          setBusy(false);
          err.textContent = "Couldn't read that photo. Try a JPG or PNG.";
        };
        reader.onload = () => {
          const img = new Image();
          img.onerror = () => {
            setBusy(false);
            err.textContent = "Couldn't read that photo. Try a JPG or PNG from your library.";
          };
          img.onload = async () => {
            // 256px: 2x for the largest circle that renders it (the 62px id card on a 3x
            // display), and still ~15KB as JPEG. The canvas centre-crop is unchanged.
            const c = document.createElement('canvas');
            const s = Math.min(img.width, img.height);
            c.width = 256; c.height = 256;
            const ctx = c.getContext('2d');
            ctx.drawImage(img, (img.width - s) / 2, (img.height - s) / 2, s, s, 0, 0, 256, 256);
            // The server object is the real save — it is what every connected surface paints
            // from. The old path wrote localStorage only, so the photo died on sign-out and no
            // coach, parent or teammate ever saw it.
            const ok = await window.__act.setAvatar(c.toDataURL('image/jpeg', 0.82));
            setBusy(false);
            if (ok) { window.__render(); }
            else { err.textContent = "The photo didn't upload. Check your connection and try again."; }
          };
          img.src = reader.result;
        };
        reader.readAsDataURL(f);
      });
    }
  },
};

/* ---------- Edit profile (spec §11): real identity, sport-aware positions ---------- */
// Positions update dynamically with the sport (spec §11.2) — football positions never
// show before football is selected.
export const SPORT_POSITIONS = {
  Football: ['QB', 'RB', 'WR', 'TE', 'OL', 'DL', 'LB', 'DB', 'K', 'P', 'LS', 'Athlete'],
  Basketball: ['Point Guard', 'Shooting Guard', 'Wing', 'Forward', 'Center'],
  Baseball: ['Pitcher', 'Catcher', 'Infield', 'Outfield', 'Utility'],
  Soccer: ['Goalkeeper', 'Defender', 'Midfielder', 'Forward'],
  Track: ['Sprints', 'Hurdles', 'Middle Distance', 'Distance', 'Jumps', 'Throws', 'Multis'],
  Volleyball: ['Setter', 'Libero', 'Middle Blocker', 'Outside Hitter', 'Opposite'],
};

export const editProfile = {
  tab: 'profile',
  render() {
    const a = S.athlete;
    const dob = (RT.profile && RT.profile.dob) || '';
    const sport = a.sport && SPORT_POSITIONS[a.sport] ? a.sport : a.sport;
    const positions = SPORT_POSITIONS[sport] || null;
    return `
    ${backHead('Edit profile', 'Only what your coach and score need', 'profile')}

    <h2 class="eyebrow">Name</h2>
    <div style="display:flex;gap:10px">
      <input class="ob-input ep-field" id="ep-first" maxlength="40" value="${esc(a.first === 'Athlete' && !a.last ? '' : a.first)}" placeholder="First name" style="flex:1" />
      <input class="ob-input ep-field" id="ep-last" maxlength="40" value="${esc(a.last)}" placeholder="Last name" style="flex:1" />
    </div>

    <h2 class="eyebrow">Date of birth</h2>
    ${/* Wrapped because iOS WebKit paints an EMPTY date input as a blank box (it has no
          placeholder support): the hint overlay is the placeholder it refuses to draw, and
          mount() hides it the moment a date lands. */''}
    <div class="ep-dob-wrap">
      <input class="ob-input ep-field${dob ? '' : ' is-empty'}" id="ep-dob" type="date" value="${esc(dob)}" max="${new Date().toISOString().slice(0, 10)}" aria-label="Date of birth" />
      ${dob ? '' : '<span class="ep-dob-hint" aria-hidden="true">Add your birth date</span>'}
    </div>

    <h2 class="eyebrow">Sport</h2>
    <div class="chip-row" id="ep-sport" data-toggle-group>
      ${Object.keys(SPORT_POSITIONS).map(s =>
        `<span class="chp ${sport === s ? 'on' : ''}">${s}</span>`).join('')}
    </div>

    <h2 class="eyebrow">${sport === 'Track' ? 'Event group' : 'Position'}</h2>
    ${positions ? `
    <div class="chip-row" id="ep-pos" data-toggle-group>
      ${positions.map(p => `<span class="chp ${a.position === p ? 'on' : ''}">${p}</span>`).join('')}
    </div>` : `
    <div style="font-size:12.5px;font-weight:600;color:var(--text-3);padding:2px 2px 4px">Pick a sport first; positions follow the sport.</div>`}

    <h2 class="eyebrow">School / organization</h2>
    <input class="ob-input ep-field" id="ep-school" maxlength="80" value="${esc(a.school)}" placeholder="Search your school or team" autocomplete="off" />
    <div id="ep-school-results" class="ep-results" hidden></div>

    <div style="height:14px"></div>
    <div class="sidebox">
      <div class="req-icon b" style="width:38px;height:38px">${icon('lock', 17)}</div>
      <div><div class="tt">That's all we ask for</div>
      <div class="ts">No bios, no socials, no feeds. Goals and weight live in your Standard; this is who your coach sees.</div></div>
    </div>

    <div style="height:16px"></div>
    <div id="ep-err" style="color:var(--red-bright);font-size:13px;font-weight:600;min-height:18px;text-align:center"></div>
    <button class="btn primary" id="ep-save" disabled style="opacity:.5">${icon('check', 19)} Save</button>
    <div style="height:10px"></div>
    `;
  },
  async mount(root) {
    const btn = root.querySelector('#ep-save');
    const err = root.querySelector('#ep-err');
    let dirty = false;
    const markDirty = () => {
      if (dirty) return;
      dirty = true;
      btn.disabled = false;
      btn.style.opacity = '1';
      editProfile._dirty = true;
    };
    editProfile._dirty = false;
    root.querySelectorAll('.ep-field').forEach((el) => el.addEventListener('input', markDirty));

    // The native date picker reports through `change` (iOS does not reliably fire `input` for
    // it), and the empty-state hint has to leave the moment a date exists.
    const dobEl = root.querySelector('#ep-dob');
    const dobHint = root.querySelector('.ep-dob-hint');
    if (dobEl) {
      const syncDob = () => {
        markDirty();
        if (dobHint) dobHint.hidden = !!dobEl.value;
        // is-empty blanks the engine's own "mm/dd/yyyy" ghost (flows.css) so the hint above is
        // the ONLY placeholder; it has to leave with the hint or the typed value goes invisible.
        dobEl.classList.toggle('is-empty', !dobEl.value);
      };
      dobEl.addEventListener('change', syncDob);
      dobEl.addEventListener('input', syncDob);
    }

    // Sport chips re-render positions in place (spec §11.2): selecting a sport swaps the
    // position list; the previous selection only survives if it exists in the new sport.
    root.querySelectorAll('#ep-sport .chp').forEach((ch) => ch.addEventListener('click', () => {
      root.querySelectorAll('#ep-sport .chp').forEach((x) => x.classList.remove('on'));
      ch.classList.add('on');
      markDirty();
      const sport = ch.textContent;
      const posWrap = root.querySelector('#ep-pos');
      const list = SPORT_POSITIONS[sport] || [];
      if (posWrap) {
        const prev = posWrap.querySelector('.on') ? posWrap.querySelector('.on').textContent : '';
        posWrap.innerHTML = list.map((p) => `<span class="chp ${p === prev ? 'on' : ''}">${p}</span>`).join('');
        wirePos();
      }
    }));
    const wirePos = () => {
      root.querySelectorAll('#ep-pos .chp').forEach((ch) => ch.addEventListener('click', () => {
        root.querySelectorAll('#ep-pos .chp').forEach((x) => x.classList.remove('on'));
        ch.classList.add('on');
        markDirty();
      }));
    };
    wirePos();

    // School search (spec §11.3): the org directory as you type, free text as fallback.
    const school = root.querySelector('#ep-school');
    const results = root.querySelector('#ep-school-results');
    if (school && results) {
      const search = debounce(async () => {
        const q = school.value.trim();
        if (q.length < 3) { results.hidden = true; return; }
        try {
          const data = await dir.search(q);
          const orgs = (data && data.orgs) || [];
          if (!orgs.length) { results.hidden = true; return; }
          results.innerHTML = orgs.slice(0, 5).map((o) =>
            `<div class="ep-result" data-name="${esc(o.name)}">${esc(o.name)}${o.city || o.state ? `<span>${esc([o.city, o.state].filter(Boolean).join(', '))}</span>` : ''}</div>`).join('');
          results.hidden = false;
          results.querySelectorAll('.ep-result').forEach((r) => r.addEventListener('click', () => {
            school.value = r.getAttribute('data-name');
            results.hidden = true;
            markDirty();
          }));
        } catch { results.hidden = true; /* directory offline — free text still saves */ }
      }, 300);
      school.addEventListener('input', search);
    }

    btn.addEventListener('click', async () => {
      const first = root.querySelector('#ep-first').value.trim();
      const last = root.querySelector('#ep-last').value.trim();
      const dob = root.querySelector('#ep-dob').value;
      const schoolV = root.querySelector('#ep-school').value.trim();
      const sport = root.querySelector('#ep-sport .on')?.textContent || '';
      const position = root.querySelector('#ep-pos .on')?.textContent || '';
      // Inline validation (spec §11.4). Never let a blank name wipe the identity.
      if (!first) { err.textContent = 'Add your first name: your coach sees it on every log.'; return; }
      if (!last) { err.textContent = 'Add your last name.'; return; }
      if (dob) {
        const d = new Date(dob + 'T12:00:00');
        const age = (Date.now() - d.getTime()) / (365.25 * 86400000);
        if (isNaN(d.getTime()) || age < 5 || age > 100) { err.textContent = 'Check your date of birth.'; return; }
        // The server's 0210 age lock is one-way: once a birth date says "under 18" only a
        // parent or support can raise it again. So an under-18 date from someone the app
        // currently believes is an adult (or has no date for) takes a second, explicit Save —
        // an adult who fat-fingers the year shouldn't lock themselves out of their own account.
        const cur = (RT.profile && RT.profile.dob) || '';
        const curMinor = cur ? (Date.now() - new Date(cur + 'T12:00:00').getTime()) / (365.25 * 86400000) < 18 : false;
        if (age < 18 && !curMinor && editProfile._minorConfirm !== dob) {
          editProfile._minorConfirm = dob;
          err.textContent = 'This birth date says you’re under 18. That turns on the protections for minors, and only a parent or support can undo it. Tap Save again to confirm.';
          return;
        }
      }
      err.textContent = '';
      btn.disabled = true;
      const was = btn.innerHTML; // innerHTML, not textContent: the label carries the check icon SVG, and a failed save used to hand back a de-iconed button
      btn.textContent = 'Saving…';
      const name = `${first} ${last}`.trim();
      // Local first (instant), then the SERVER write the coach actually reads. dob is the
      // exception: the server can REFUSE it (0210 age lock), so it only lands locally after
      // the server takes it — otherwise this screen would show a birth date the server rejected.
      window.__act.saveProfile({ name, school: schoolV, sport, position });
      const ok = await window.__act.saveIdentity({ full_name: name, sport, position });
      let dobOk = true;
      if (dob) {
        const r = await window.__act.setMyDob(dob);
        if (r.reason === 'locked') { err.textContent = 'Your birth date is locked while you’re under 18. A parent or support can correct it.'; btn.disabled = false; btn.innerHTML = was; return; }
        if (r.reason === 'floor') { err.textContent = 'OnStandard is for athletes 13 and up.'; btn.disabled = false; btn.innerHTML = was; return; }
        dobOk = r.ok;
        if (r.ok) window.__act.saveProfile({ dob });
      }
      // dob has no background retry and (unlike the rest) wasn't kept locally on failure, so
      // "it'll sync" would be a lie for it — name that failure specifically.
      if (dobOk === false && ok !== false) { err.textContent = 'Couldn’t save your birth date. Check your connection and try again.'; btn.disabled = false; btn.innerHTML = was; return; }
      if (ok === false) { err.textContent = 'Saved on this phone, couldn’t reach the server. It’ll sync when you’re back online.'; btn.disabled = false; btn.innerHTML = was; return; }
      editProfile._dirty = false;
      btn.textContent = 'Saved';
      setTimeout(() => window.__back('profile'), 350);
    });

    // Unsaved-change warning (spec §11.4): leaving with edits asks once.
    root.querySelectorAll('[data-back]').forEach((el) => {
      el.addEventListener('click', (e) => {
        if (editProfile._dirty && !window.confirm('Discard your unsaved changes?')) {
          e.stopImmediatePropagation();
          e.preventDefault();
        } else {
          editProfile._dirty = false;
        }
      }, { capture: true });
    });
  },
};
