import{S,RT}from"../state.js";import{avatarControlHtml,wireAvatarUpload}from"../avatar-upload.js";import{icon}from"../icons.js";import{backHead,esc,safeImg}from"../components.js";import{dir,debounce}from"../ob-directory.js";function ext(href,ic,t,sub){return`
      <a class="lrow" href="${href}" target="_blank" rel="noopener" style="text-decoration:none;color:inherit">
        <div class="lic">${icon(ic,16)}</div>
        <div class="lm"><div class="lt">${t}</div><div class="ls">${sub}</div></div>
        ${icon("external",15,'class="chev-dim"')}
      </a>`}export default{tab:"profile",render(){const t=S.pass;const a=S.athlete;const e=S.exec||{};const scored=!S.notYetScored&&e.score!=null;const place=S.audience==="client"?[S.planGoalLabel||"Personal plan",S.coach.kind==="trainer"?S.coach.team:""].filter(Boolean).join(" \xB7 "):[a.sport,a.position,a.school].filter(Boolean).join(" \xB7 ");const placeLine=place?`<div class="pf-meta">${esc(place)}</div>`:`<div class="pf-meta meta-add" data-go="edit-profile" role="button" tabindex="0">Add your sport and school</div>`;const hero=`
    <section class="pf-hero">
      ${avatarControlHtml({uid:RT.userId,initials:a.initials,size:88,editable:true})}
      <div class="pf-id">
        <div class="pf-name">${esc(a.name)}</div>
        ${placeLine}
      </div>
      ${""}
      <div class="pf-stats">
        <button type="button" class="pf-stat" data-go="streak"><b>${S.streakDays}</b><small>day streak</small></button>
        <button type="button" class="pf-stat" data-go="score-breakdown"><b class="${scored?esc(S.tier.cls||""):"muted"}">${scored?e.score:"\u2013"}</b><small>today</small></button>
        <button type="button" class="pf-stat" data-go="score-explained"><b class="${scored?esc(S.tier.cls||""):"muted pf-stat-word"}">${scored?esc(S.tier.name||"\u2013"):"Not scored yet"}</b><small>standing</small></button>
      </div>
      <button class="btn ghost sm pf-edit" data-go="edit-profile">Edit profile</button>
    </section>`;const coachNoun=S.coach.kind==="trainer"?"Trainer":"Coach";const coach=S.coach.hasCoach?`
    <h2 class="eyebrow">${coachNoun} Connection</h2>
    <section class="card rows">
      ${""}
      <div class="lrow" data-go="messages">
        <div class="lic pf-coach-av"${S.coach.id?` data-avatar-uid="${esc(S.coach.id)}"`:""}><span data-avatar-fallback>${esc(S.coach.initials)}</span></div>
        <div class="lm"><div class="lt">${esc(S.coach.name)}</div><div class="ls">${esc([S.coach.role,S.coach.team].filter(Boolean).join(" \xB7 "))} \xB7 messages</div></div>
        ${icon("chevron",17,'class="chev-dim"')}
      </div>
    </section>`:`
    <h2 class="eyebrow">${coachNoun} Connection</h2>
    <section class="card pad pf-connect">
      <div class="pf-connect-t">Connect your coach or trainer</div>
      <div class="pf-connect-s">Share your execution, receive requirements, and communicate directly.</div>
      <button class="btn primary sm pf-connect-b" data-go="connect">${icon("key",16)} Connect</button>
    </section>`;const trust=t.active?`
    <div class="trust pf-trust" data-go="trust" role="button" tabindex="0">
      <div class="ic">${icon("shield",20)}</div>
      <div class="pf-trust-t">
        <div class="tt">${t.kind==="credits"?`Trust Pass active \xB7 ${t.left} left`:`Trust Pass active \xB7 day ${t.day} of ${t.length}`}</div>
        <div class="ts">Earned with ${(RT.passPolicy||{eligibility_days:7}).eligibility_days} photo-logged days. Tap for the rules.</div>
      </div>
      ${icon("chevron",18,'class="chev-dim"')}
    </div>`:"";const row=(go,ic,title,sub,extra="")=>`
      <div class="lrow" data-go="${go}">
        <div class="lic${extra}">${icon(ic,17)}</div>
        <div class="lm"><div class="lt">${title}</div><div class="ls">${sub}</div></div>
        ${icon("chevron",17,'class="chev-dim"')}
      </div>`;return`
    <h1 class="sr-only">Profile</h1>
    ${hero}
    ${trust}
    ${coach}

    ${""}
    <h2 class="eyebrow">Account</h2>
    <section class="card rows">
      <div class="lrow" data-go="account">
        <div class="lic">${icon("lock",17)}</div>
        <div class="lm"><div class="lt">Sign-in &amp; email</div><div class="ls">${esc(RT.email||"Password, email address")}</div></div>
        ${icon("chevron",17,'class="chev-dim"')}
      </div>
      ${row("billing","bolt","Plan &amp; billing","Your membership &amp; premium features")}
      ${row("invite-parent","users","Invite a parent","Let a parent see your score and your week")}
      ${row("settings","gear","App settings","Appearance, notifications, Face ID")}
    </section>

    <h2 class="eyebrow">Tracking</h2>
    <section class="card rows">
      ${row("plan-style","target","Plan style",`${esc(S.planStyle.name)} \xB7 ${S.planStyle.canChoose?"yours to change":esc(S.planStyle.sourceLabel)}`)}
      ${row("restrictions","shield","Food restrictions &amp; allergies",RT.allergies.length?esc(RT.allergies.join(" \xB7 ")):"None declared")}
      ${""}
      <div class="lrow" data-go="apple-health">
        <div class="lic">${icon("heart",17)}</div>
        <div class="lm"><div class="lt">Apple Health</div><div class="ls" id="pf-hk-state">Steps, workouts and sleep, from your phone</div></div>
        ${icon("chevron",17,'class="chev-dim"')}
      </div>
      ${row("connected-standards","bolt","Activity standards","Steps, distance and workouts \xB7 verified from your device")}
      ${row("location-consent","target","Location check-in","How showing up at a place is confirmed")}
    </section>

    <h2 class="eyebrow">Your record</h2>
    <section class="card rows">
      ${row("history","clock","Activity history","The proof trail, day by day")}
      ${S.audience==="client"&&S.coach.kind==="trainer"?"":`
      <div class="lrow" data-go="verified-profile">
        <div class="lic">${icon("share",17)}</div>
        <div class="lm"><div class="lt">Verified Profile</div><div class="ls">Your public page and discipline record</div></div>
        ${icon("chevron",17,'class="chev-dim"')}
      </div>`}
    </section>

    <h2 class="eyebrow">Support &amp; legal</h2>
    <section class="card rows">
      ${row("feedback","message","Request a feature","Or report a bug, or ask us anything")}
      ${ext("mailto:support@onstandard.app","mail","Support email","support@onstandard.app")}
      ${row("privacy","eye","Privacy &amp; your data","Who sees what \xB7 download your data")}
      ${ext("https://onstandard.app/terms","clipboard","Terms of Service","The full agreement")}
      ${ext("https://onstandard.app/privacy","lock","Privacy policy","What we collect and why")}
      ${""}
    </section>

    <h2 class="eyebrow">Account actions</h2>
    <section class="card rows">
      ${""}
      <div class="lrow" id="pf-signout" role="button" tabindex="0"><div class="lic">${icon("back",17)}</div><div class="lm"><div class="lt">Sign out</div><div class="ls pf-hidden" id="pf-signout-sub">You'll need your password to get back in.</div></div></div>
      <div class="lrow" data-go="delete-account"><div class="lic lic-danger">${icon("trash",17)}</div><div class="lm"><div class="lt pf-red">Delete account</div></div>${icon("chevron",17,'class="chev-dim"')}</div>
    </section>

    <div class="ac-tail"></div>
    `},mount(root){const signout=root.querySelector("#pf-signout");if(signout){const lt=signout.querySelector(".lt");const sub=signout.querySelector("#pf-signout-sub");let armTimer=null;const disarm=()=>{if(armTimer){clearTimeout(armTimer);armTimer=null}if(lt)lt.textContent="Sign out";if(sub)sub.classList.add("pf-hidden")};signout.addEventListener("click",()=>{if(armTimer){disarm();window.__go("welcome");return}if(lt)lt.textContent="Tap again to sign out";if(sub)sub.classList.remove("pf-hidden");armTimer=setTimeout(disarm,5e3)})}import("./apple-health.js").then(async({HK,probeHealth,hkLabel})=>{if(!HK.probed)await probeHealth();const el=root.querySelector("#pf-hk-state");if(el&&root.isConnected)el.textContent=hkLabel()}).catch(()=>{});wireAvatarUpload(root,{errHost:".pf-hero .pf-id",hasLocalPhoto:!!S.athlete.avatar})}};export const SPORT_POSITIONS={Football:["QB","RB","WR","TE","OL","DL","LB","DB","K","P","LS","Athlete"],Basketball:["Point Guard","Shooting Guard","Wing","Forward","Center"],Baseball:["Pitcher","Catcher","Infield","Outfield","Utility"],Soccer:["Goalkeeper","Defender","Midfielder","Forward"],Track:["Sprints","Hurdles","Middle Distance","Distance","Jumps","Throws","Multis"],Volleyball:["Setter","Libero","Middle Blocker","Outside Hitter","Opposite"]};export const editProfile={tab:"profile",render(){const a=S.athlete;const dob=RT.profile&&RT.profile.dob||"";const sport=a.sport&&SPORT_POSITIONS[a.sport]?a.sport:a.sport;const positions=SPORT_POSITIONS[sport]||null;return`
    ${backHead("Edit profile","Only what your coach and score need","profile")}

    <h2 class="eyebrow">Name</h2>
    <div style="display:flex;gap:10px">
      <input class="ob-input ep-field" id="ep-first" maxlength="40" value="${esc(a.first==="Athlete"&&!a.last?"":a.first)}" placeholder="First name" aria-label="First name" autocomplete="given-name" style="flex:1" />
      <input class="ob-input ep-field" id="ep-last" maxlength="40" value="${esc(a.last)}" placeholder="Last name" aria-label="Last name" autocomplete="family-name" style="flex:1" />
    </div>

    <h2 class="eyebrow">Date of birth</h2>
    ${""}
    <div class="ep-dob-wrap">
      <input class="ob-input ep-field${dob?"":" is-empty"}" id="ep-dob" type="date" value="${esc(dob)}" max="${new Date().toISOString().slice(0,10)}" aria-label="Date of birth" />
      ${dob?"":'<span class="ep-dob-hint" aria-hidden="true">Add your birth date</span>'}
    </div>

    <h2 class="eyebrow">Sport</h2>
    <div class="chip-row" id="ep-sport" data-toggle-group>
      ${Object.keys(SPORT_POSITIONS).map(s=>`<span class="chip ${sport===s?"on":""}">${s}</span>`).join("")}
    </div>

    <h2 class="eyebrow">${sport==="Track"?"Event group":"Position"}</h2>
    ${positions?`
    <div class="chip-row" id="ep-pos" data-toggle-group>
      ${positions.map(p=>`<span class="chip ${a.position===p?"on":""}">${p}</span>`).join("")}
    </div>`:`
    <div style="font-size:12.5px;font-weight:600;color:var(--text-3);padding:2px 2px 4px">Pick a sport first; positions follow the sport.</div>`}

    <h2 class="eyebrow">School / organization</h2>
    <input class="ob-input ep-field" id="ep-school" maxlength="80" value="${esc(a.school)}" placeholder="Search your school or team" aria-label="School or organization" autocomplete="off" />
    <div id="ep-school-results" class="ep-results" hidden></div>

    <div style="height:14px"></div>
    <div class="sidebox">
      <div class="req-icon b s38">${icon("lock",17)}</div>
      <div><div class="tt">That's all we ask for</div>
      <div class="ts">No bios, no socials, no feeds. Goals and weight live in your Standard; this is who your coach sees.</div></div>
    </div>

    <div style="height:16px"></div>
    <div id="ep-err" style="color:var(--red-bright);font-size:13px;font-weight:600;min-height:18px;text-align:center"></div>
    <button class="btn primary" id="ep-save" disabled style="opacity:.5">${icon("check",19)} Save</button>
    <div style="height:10px"></div>
    `},async mount(root){const btn=root.querySelector("#ep-save");const err=root.querySelector("#ep-err");let dirty=false;const markDirty=()=>{if(dirty)return;dirty=true;btn.disabled=false;btn.style.opacity="1";editProfile._dirty=true};editProfile._dirty=false;root.querySelectorAll(".ep-field").forEach(el=>el.addEventListener("input",markDirty));const dobEl=root.querySelector("#ep-dob");const dobHint=root.querySelector(".ep-dob-hint");if(dobEl){const syncDob=()=>{markDirty();if(dobHint)dobHint.hidden=!!dobEl.value;dobEl.classList.toggle("is-empty",!dobEl.value)};dobEl.addEventListener("change",syncDob);dobEl.addEventListener("input",syncDob)}root.querySelectorAll("#ep-sport .chip").forEach(ch=>ch.addEventListener("click",()=>{root.querySelectorAll("#ep-sport .chip").forEach(x=>x.classList.remove("on"));ch.classList.add("on");markDirty();const sport=ch.textContent;const posWrap=root.querySelector("#ep-pos");const list=SPORT_POSITIONS[sport]||[];if(posWrap){const prev=posWrap.querySelector(".on")?posWrap.querySelector(".on").textContent:"";posWrap.innerHTML=list.map(p=>`<span class="chip ${p===prev?"on":""}">${p}</span>`).join("");wirePos()}}));const wirePos=()=>{root.querySelectorAll("#ep-pos .chip").forEach(ch=>ch.addEventListener("click",()=>{root.querySelectorAll("#ep-pos .chip").forEach(x=>x.classList.remove("on"));ch.classList.add("on");markDirty()}))};wirePos();const school=root.querySelector("#ep-school");const results=root.querySelector("#ep-school-results");if(school&&results){const search=debounce(async()=>{const q=school.value.trim();if(q.length<3){results.hidden=true;return}try{const data=await dir.search(q);const orgs=data&&data.orgs||[];if(!orgs.length){results.hidden=true;return}results.innerHTML=orgs.slice(0,5).map(o=>`<div class="ep-result" data-name="${esc(o.name)}">${esc(o.name)}${o.city||o.state?`<span>${esc([o.city,o.state].filter(Boolean).join(", "))}</span>`:""}</div>`).join("");results.hidden=false;results.querySelectorAll(".ep-result").forEach(r=>r.addEventListener("click",()=>{school.value=r.getAttribute("data-name");results.hidden=true;markDirty()}))}catch{results.hidden=true}},300);school.addEventListener("input",search)}btn.addEventListener("click",async()=>{const first=root.querySelector("#ep-first").value.trim();const last=root.querySelector("#ep-last").value.trim();const dob=root.querySelector("#ep-dob").value;const schoolV=root.querySelector("#ep-school").value.trim();const sport=root.querySelector("#ep-sport .on")?.textContent||"";const position=root.querySelector("#ep-pos .on")?.textContent||"";if(!first){err.textContent="Add your first name: your coach sees it on every log.";return}if(!last){err.textContent="Add your last name.";return}if(dob){const d=new Date(dob+"T12:00:00");const age=(Date.now()-d.getTime())/(365.25*864e5);if(isNaN(d.getTime())||age<5||age>100){err.textContent="Check your date of birth.";return}const cur=RT.profile&&RT.profile.dob||"";const curMinor=cur?(Date.now()-new Date(cur+"T12:00:00").getTime())/(365.25*864e5)<18:false;if(age<18&&!curMinor&&editProfile._minorConfirm!==dob){editProfile._minorConfirm=dob;err.textContent="This birth date says you\u2019re under 18. That turns on the protections for minors, and only a parent or support can undo it. Tap Save again to confirm.";return}}err.textContent="";btn.disabled=true;const was=btn.innerHTML;btn.textContent="Saving\u2026";const name=`${first} ${last}`.trim();window.__act.saveProfile({name,school:schoolV,sport,position});const ok=await window.__act.saveIdentity({full_name:name,sport,position,school:schoolV});let dobOk=true;if(dob){const r=await window.__act.setMyDob(dob);if(r.reason==="locked"){err.textContent="Your birth date is locked while you\u2019re under 18. A parent or support can correct it.";btn.disabled=false;btn.innerHTML=was;return}if(r.reason==="floor"){err.textContent="OnStandard is for athletes 13 and up.";btn.disabled=false;btn.innerHTML=was;return}dobOk=r.ok;if(r.ok)window.__act.saveProfile({dob})}if(dobOk===false&&ok!==false){err.textContent="Couldn\u2019t save your birth date. Check your connection and try again.";btn.disabled=false;btn.innerHTML=was;return}if(ok===false){err.textContent="Saved on this phone, couldn\u2019t reach the server. It\u2019ll sync when you\u2019re back online.";btn.disabled=false;btn.innerHTML=was;return}editProfile._dirty=false;btn.textContent="Saved";setTimeout(()=>window.__back("profile"),350)});root.querySelectorAll("[data-back]").forEach(el=>{el.addEventListener("click",e=>{if(editProfile._dirty&&!window.confirm("Discard your unsaved changes?")){e.stopImmediatePropagation();e.preventDefault()}else{editProfile._dirty=false}},{capture:true})})}};
