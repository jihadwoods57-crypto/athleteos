import{S,RT,act,roleNav,roleProfileRoute,liveWeightPct}from"../state.js";import{canOpenExternalCheckout}from"../store-policy.js";import{icon}from"../icons.js";import{mapPressure}from"../exec.js";import{normalizePrefs}from"../notify-plan.js";import{normalizeCoachPrefs}from"../coach-notify-plan.js";import{backHead,esc,errorState,planStyleCard,skeletonRows}from"../components.js";import{STYLE_KEYS,styleLabel}from"../plan-style.js";import*as roles from"../roles.js";import{planById}from"../pricing.js";import{armReplay}from"../tour.js";import{normalizePressure}from"../ob-helpers.js";import{HK,probeHealth,hkLabel}from"./apple-health.js";function wirePressure(root,sel){const row=root.querySelector(sel);if(!row)return;const saved=RT.ob&&RT.ob.standard&&RT.ob.standard.pressure||"Hold me accountable";const chips=[...row.querySelectorAll(".chip")];const match=chips.find(c=>mapPressure(c.textContent.trim())===mapPressure(saved));if(match){chips.forEach(c=>c.classList.remove("on"));match.classList.add("on")}chips.forEach(c=>c.addEventListener("click",()=>{act.captureOb({standard:{...(RT.ob||{}).standard||{},pressure:normalizePressure(c.textContent.trim())}});act.syncNotifications()}))}export function smartReply(text,fallback){const t=text.toLowerCase();if(/(swap|instead|replace|substitute)/.test(t))return"Yes, swap it. Based on your plan: any protein for protein, any slow carb for slow carb, keep the portion the same. Rice, potatoes, oats, and tortillas are all interchangeable for you.";if(/(late|miss|forgot|skip)/.test(t))return"Honest answer: a late meal counts at half weight for punctuality, and a missed one just stays missed. Log it anyway. The trend matters more than one slot, and your coach respects a truthful log over a blank.";if(/(protein|macro)/.test(t))return"Aim protein-forward at every meal: a solid protein source plus a slow carb hits your plan. If a meal slot is still open, that\u2019s where to close any gap.";if(/(eat out|restaurant|chipotle|fast food|on the go)/.test(t))return"From your plan\u2019s approved list: Chipotle bowl (double chicken, rice, beans), a grilled sandwich, or a rice bowl. Order protein first, add the carb, skip nothing green.";if(/(score|point|tier)/.test(t))return`Your score comes from two honest parts: Nutrition ${liveWeightPct("nutrition")}%, and Recovery ${liveWeightPct("checkin")+liveWeightPct("recovery")}% (tonight's check-in plus how you answered it). Right now you\u2019re at ${S.score}; finishing what\u2019s still open tonight takes you toward ${S.possible}.`;return fallback}export function wireComposer(root,replyWho="ai",replyName="OnStandard AI",replyText="",onSend=null){const input=root.querySelector(".composer input");const send=root.querySelector(".composer .send");const thread=root.querySelector(".thread");if(!input||!send||!thread)return;const submit=()=>{const text=input.value.trim();if(!text)return;thread.insertAdjacentHTML("beforeend",`<div class="msg athlete"><div><div class="bubble">${esc(text)}</div></div></div>`);input.value="";if(onSend)onSend(text);setTimeout(()=>{if(replyWho==="delivery"){thread.insertAdjacentHTML("beforeend",`<div class="msg-status">${replyText}</div>`)}else{const av=icon("sparkle",15);thread.insertAdjacentHTML("beforeend",`<div class="msg ai"><div class="av">${av}</div><div><div class="who">${replyName}</div><div class="bubble">${smartReply(text,replyText)}</div></div></div>`)}thread.lastElementChild.scrollIntoView({behavior:"smooth",block:"end"})},650);thread.lastElementChild.scrollIntoView({behavior:"smooth",block:"end"})};send.addEventListener("click",submit);input.addEventListener("keydown",e=>{if(e.key==="Enter")submit()})}export const messages={tab:"plan",render(){const c=S.coach;if(!c.hasCoach){return`
      ${backHead("Your coach","No coach connected yet","plan")}
      <div class="state-demo">
        <div class="sd-ic">${icon("users",24)}</div>
        <div class="sd-t">No coach connected</div>
        <div class="sd-s">When you join a team, your coach shows up here, and sees your day.</div>
        <div class="sd-cta"><button class="btn ghost sm" data-go="connect">Connect a coach</button></div>
      </div>
      <div style="height:10px"></div>
      `}const sub=[c.role,c.team].filter(Boolean).join(" \xB7 ")||"Your coach";return`
    ${backHead(c.name,sub,"profile")}

    <div class="thread">
      <div class="msg-status">${esc(c.name)} talks to you on your meals: every comment and reaction lands in that meal's thread, and you reply right there.</div>
    </div>
    <div style="height:14px"></div>
    <button class="btn ghost" data-go="history">Open activity history</button>
    <div style="height:10px"></div>
    `}};export const settings={tab:"profile",get nav(){return roleNav()},render(){return`
    ${backHead("Units & appearance","",roleProfileRoute())}

    <h2 class="eyebrow">Units</h2>
    <section class="card" style="padding:6px 16px">
      ${""}
      <div class="lrow" style="cursor:default">
        <div class="lic">${icon("scale",17)}</div>
        <div class="lm"><div class="lt">Units \xB7 lb, 12-hour</div><div class="ls">US units for now.</div></div>
      </div>
    </section>

    <h2 class="eyebrow">Appearance</h2>
    <div class="chip-row" id="set-theme" data-toggle-group>
      ${["dark","light","system"].map(m=>`<span class="chip ${(RT.theme||"dark")===m?"on":""}" data-theme-pick="${m}">${m==="dark"?"Dark":m==="light"?"Light":"System"}</span>`).join("")}
    </div>

    ${""}
    ${RT.authRole==="athlete"?`
    <h2 class="eyebrow">Plan</h2>
    <section class="card rows">
      <div class="lrow" data-go="plan-style">
        <div class="lic">${icon("target",17)}</div>
        <div class="lm"><div class="lt">Plan style</div><div class="ls">${esc(S.planStyle.name)} \xB7 ${S.planStyle.canChoose?"yours to change":esc(S.planStyle.sourceLabel)}</div></div>
        ${icon("chevron",17,'class="chev-dim"')}
      </div>
    </section>

    ${""}
    <h2 class="eyebrow">Health</h2>
    <section class="card rows">
      <div class="lrow" data-go="apple-health">
        <div class="lic">${icon("heart",17)}</div>
        <div class="lm"><div class="lt">Apple Health</div><div class="ls" id="set-hk-state">${esc(hkLabel())}</div></div>
        ${icon("chevron",17,'class="chev-dim"')}
      </div>
    </section>`:""}

    <div id="set-bio-wrap" style="display:none">
      <h2 class="eyebrow">Security</h2>
      <section class="card" style="padding:6px 16px">
        <div class="lrow" id="set-bio" role="switch" tabindex="0" aria-checked="false" aria-label="Unlock with Face ID" aria-describedby="set-bio-sub">
          <div class="lic">${icon("lock",17)}</div>
          <div class="lm"><div class="lt">Unlock with Face ID</div><div class="ls" id="set-bio-sub">Required on app open</div></div>
          <div class="std-switch" aria-hidden="true"></div>
        </div>
      </section>
    </div>

    <h2 class="eyebrow">Help</h2>
    <section class="card" style="padding:6px 16px">
      <div class="lrow" id="set-tour" role="button" tabindex="0" style="cursor:pointer">
        <div class="lic">${icon("sparkle",17)}</div>
        <div class="lm"><div class="lt">Replay app tour</div><div class="ls">A quick walk through the app</div></div>
        ${icon("chevron",17,'style="color:var(--text-3)"')}
      </div>
    </section>

    <div style="height:18px"></div>
    <button class="btn ghost" data-back="${roleProfileRoute()}">Done</button>
    <div style="height:10px"></div>
    `},mount(root){wireToggles(root);wireSegAria(root);if(!HK.probed){probeHealth().then(()=>{const el=root.querySelector("#set-hk-state");if(el&&root.isConnected)el.textContent=hkLabel()}).catch(()=>{})}const tourRow=root.querySelector("#set-tour");if(tourRow)tourRow.addEventListener("click",()=>armReplay());root.querySelectorAll("[data-theme-pick]").forEach(el=>el.addEventListener("click",()=>{act.setTheme(el.getAttribute("data-theme-pick"));root.querySelectorAll("[data-theme-pick]").forEach(x=>x.classList.toggle("on",x===el))}));(async()=>{const N=window.OnStandardNative;if(!N||!N.biometrics)return;let ok=false;try{ok=await N.biometrics.available()}catch{}if(!ok)return;const wrap=root.querySelector("#set-bio-wrap");wrap.style.display="";const row=root.querySelector("#set-bio");const sw=row.querySelector(".std-switch");const paint=on=>{sw.classList.toggle("on",on);row.setAttribute("aria-checked",on?"true":"false")};try{paint(await N.secureStore.getItem("onstd-biolock")==="1")}catch{}row.addEventListener("click",()=>{const on=!sw.classList.contains("on");if(on)N.secureStore.setItem("onstd-biolock","1");else N.secureStore.removeItem("onstd-biolock");paint(on)})})()}};const OB_BACK={ob:"onboarding/7",cob:"coach-ob/5",tob:"trainer-ob/3",clob:"client-ob/6"};export const privacy={tab:"profile",hideTabs:true,render({sub}={}){const back=OB_BACK[sub]||roleProfileRoute();const rows=[];if(S.coach.hasCoach&&S.coach.kind==="coach"){rows.push({ic:"users",t:S.coach.isNamed?S.coach.name:"Your coach",pill:"View access",s:"Daily score, requirements, meal logs and photos, check-ins, weight trend",detail:[["Can see","Your daily score, requirement completion, meal logs and photos, check-ins, and weight trend."],["Can set","Your requirements, deadlines, targets, and reminder urgency."],["Required by team","Sharing execution with your coach is what connecting means."],["To revoke","Leave the team: ask your coach to remove you, or contact support@onstandard.app."]]})}if(RT.myTrainer){rows.push({ic:"bolt",t:RT.myTrainer.name||"Your trainer",pill:"Limited access",s:"Recovery, readiness, and nutrition consistency, not your full meal detail",detail:[["Can see","Recovery check-ins, readiness, and nutrition consistency."],["Cannot see","Your full meal photos and per-meal detail stay with you and your coach."],["To revoke","Leave the practice: ask your trainer, or contact support@onstandard.app."]]})}if(S.consent.minor||RT.consent&&RT.consent.guardianEmail){rows.push({ic:"heart",t:"Parent / guardian",pill:"Limited access",s:RT.consent&&RT.consent.guardianEmail?`${RT.consent.guardianEmail} \xB7 consent + account controls`:"Consent status and account controls, not your day-to-day logs",detail:[["Can do","Approve your account, request your data, or request deletion: legal guardian rights for minors."],["Cannot see","Your meal photos and daily logs are not mirrored to a guardian view."]]})}if(S.coach.hasCoach&&S.coach.kind==="coach"){const sharing=RT.shareSquadScore===true;rows.push({ic:"grid",t:"Teammates",pill:sharing?"Score only":"No access",s:sharing?"Teammates see your score number on the Squad board, nothing else":"Teammates cannot see anything about your day",detail:[["Can see",sharing?"Your name and daily score number on your team\u2019s Squad board. That is the whole disclosure.":"Nothing. The Squad board shows teammates who opted in; you haven\u2019t, so you appear only as a private count."],["Cannot see","Your meals, photos, weight, and check-ins are never visible to teammates, shared or not."],["Change it","The switch lives on the Squad screen (Progress \u2192 Squad), next to what it shows."]]})}return`
    ${backHead("Privacy & visibility","Who sees what: nothing is public",back)}

    ${rows.length?`
    <section class="card" style="padding:6px 16px">
      ${rows.map((r,i)=>`
        <details class="pv-row">
          ${""}
          <summary class="lrow">
            <div class="lic">${icon(r.ic,17)}</div>
            <div class="lm"><div class="lt">${esc(r.t)}</div><div class="ls">${esc(r.s)}</div></div>
            <span class="status-pill ${r.pill==="View access"?"g":r.pill==="No access"?"muted":"b"}">${r.pill}</span>
            <span class="pv-chev" aria-hidden="true">${icon("chevron",15)}</span>
          </summary>
          <div class="pv-detail">
            ${r.detail.map(([k,v])=>`<div class="pv-line"><b>${esc(k)}</b>${esc(v)}</div>`).join("")}
          </div>
        </details>`).join("")}
    </section>`:`
    <section class="card pad">
      <div style="font-size:15px;font-weight:800">No one is connected</div>
      <div style="font-size:12.5px;font-weight:600;color:var(--text-2);margin-top:4px;line-height:1.5">Right now your data is visible to you alone. Connecting a coach or trainer shares your execution with them; you'll see exactly what before you join.</div>
    </section>`}

    <div style="height:14px"></div>
    <div class="sidebox">
      <div class="req-icon b s38">${icon("lock",17)}</div>
      <div><div class="tt">Defaults that protect you</div>
      <div class="ts">Nothing is public. Meal photos never leave your coach connection. You can download or delete everything, below.</div></div>
    </div>

    <h2 class="eyebrow">Your data</h2>
    <section class="card" style="padding:6px 16px">
      <div class="lrow" id="pv-export" role="button" tabindex="0">
        <div class="lic">${icon("download",17)}</div>
        <div class="lm"><div class="lt">Download my data</div><div class="ls">Profile, days, and meal records as a JSON file</div></div>
        ${icon("chevron",17,'style="color:var(--text-3)"')}
      </div>
      <div class="lrow" data-go="delete-account">
        <div class="lic" style="color:var(--red)">${icon("trash",17)}</div>
        <div class="lm"><div class="lt" style="color:var(--red)">Delete my account</div><div class="ls">Permanent, in-app</div></div>
        ${icon("chevron",17,'style="color:var(--text-3)"')}
      </div>
    </section>
    <div id="pv-export-note" style="font-size:12px;font-weight:600;color:var(--text-3);min-height:16px;margin-top:8px;padding:0 2px"></div>

    <div style="height:14px"></div>
    <button class="btn ghost" data-back="${back}">Done</button>
    <div style="height:10px"></div>
    `},mount(root){const btn=root.querySelector("#pv-export");const note=root.querySelector("#pv-export-note");if(!btn)return;let busy=false;btn.addEventListener("click",async()=>{if(busy)return;busy=true;if(note){note.style.color="";note.textContent="Preparing your export\u2026"}const r=await act.exportMyData();if(note){note.style.color=r.ok?"var(--green-bright)":"var(--red-bright)";note.textContent=r.ok?"Export downloaded.":r.error||"Export failed."}busy=false})}};const BILL={sub:null,loaded:false,source:"none",active:null,failed:false};async function loadBilling(){const sub=await roles.fetchMySubscription();BILL.failed=!!(sub&&sub.error);BILL.sub=BILL.failed?null:sub;BILL.active=BILL.sub&&BILL.sub.tier==="team"?await roles.myActiveAthleteCount():null;try{if(BILL.failed){BILL.source="none"}else if(isPaid(BILL.sub)){BILL.source="subscription"}else{const src=await roles.myPremiumSource();if(src===null){BILL.failed=true;BILL.source="none"}else{BILL.source=src}}}catch{BILL.source="none"}BILL.loaded=true;if(window.__render)window.__render()}function coveredBy(){return BILL.source==="trainer"||BILL.source==="sponsor"?BILL.source:null}export const GRACE_DAYS=7;export function isPaid(sub,now=Date.now()){if(!sub)return false;const t=String(sub.tier||"").toLowerCase();const freeTier=t===""||t==="preview"||t==="free"||t==="none"||t==="trial_expired";if(freeTier)return false;if(sub.status==="active")return true;if(sub.status!=="past_due")return false;const failedAt=sub.payment_failed_at?Date.parse(sub.payment_failed_at):NaN;if(!Number.isFinite(failedAt))return true;return now-failedAt<GRACE_DAYS*864e5}function planLabel(sub){if(!isPaid(sub)){const by=coveredBy();if(by==="trainer")return"Premium \xB7 via your trainer";if(by==="sponsor")return"Premium \xB7 sponsored";return"Free"}const p=sub.plan_id?planById(sub.plan_id):null;if(p)return p.name;return sub.tier==="team"?"Team":"Premium"}function renewLine(sub){if(!isPaid(sub)){const by=coveredBy();if(by==="trainer")return"Included with your coaching. Nothing to pay here: your membership lasts as long as your plan with your trainer.";if(by==="sponsor")return"A sponsor covers your premium access. Nothing to pay while it lasts.";return"You have the free plan. Your stats are always yours; membership adds the written coaching."}const when=sub.current_period_end?(()=>{try{return new Date(sub.current_period_end).toLocaleDateString(void 0,{year:"numeric",month:"long",day:"numeric"})}catch{return""}})():"";if(sub.status==="past_due")return`Payment issue: update your payment method in the store to keep premium${when?` (grace ends ${when})`:""}.`;if(sub.cancel_at_period_end)return when?`Cancels ${when}. You keep premium until then.`:"Set to cancel at period end.";return when?`Renews ${when}.`:"Active."}function storeSubUrl(){return/android/i.test(navigator.userAgent||"")?"https://play.google.com/store/account/subscriptions":"https://apps.apple.com/account/subscriptions"}export const billing={tab:"profile",get nav(){return roleNav()},render(){const back=roleProfileRoute();if(!BILL.loaded){return`${backHead("Plan & billing","Your membership",back)}
      ${skeletonRows(3,"Loading your plan")}`}if(BILL.failed){return`${backHead("Plan & billing","Your membership",back)}
      ${errorState({title:"Couldn't check your plan",body:"Nothing changed with your membership; this screen just could not reach the server. Reconnect and try again.",retryId:"bill-retry"})}`}const sub=BILL.sub;const paid=isPaid(sub);const covered=coveredBy();const premium=paid||!!covered;const operator=RT.authRole==="coach"||RT.authRole==="trainer";const teamPlan=paid&&sub&&sub.tier==="team";const usage=teamPlan&&BILL.active!=null&&sub.seats?`<div style="height:8px"></div><div style="font-size:12px;font-weight:700;color:var(--text-2)">${BILL.active} active athlete${BILL.active===1?"":"s"} this month \xB7 ${sub.seats} included${BILL.active>sub.seats?` \xB7 ${BILL.active-sub.seats} over your included seats`:""}</div>`:"";return`${backHead("Plan & billing","Your membership",back)}

    <section class="card pad">
      <div class="bigstat"><span class="n" style="font-size:26px">${esc(planLabel(sub))}</span><span class="d">${premium?"Your plan":"Current plan"}</span></div>
      <div style="height:6px"></div>
      <div style="font-size:12.5px;font-weight:600;color:var(--text-2);line-height:1.45">${esc(renewLine(sub))}</div>
      ${usage}
      ${premium?`<div style="height:8px"></div><span class="status-pill g">Premium unlocked</span>`:""}
    </section>

    <div style="height:12px"></div>
    ${""}
    ${!paid&&covered?`
    <section class="card pad">
      <div style="font-size:12.5px;font-weight:600;color:var(--text-2);line-height:1.5;text-align:center">
        ${covered==="trainer"?"Nothing to set up here. If you stop your package with your trainer, this is where a plan of your own would go.":"Nothing to set up here. When the sponsorship ends, this is where a plan of your own would go."}
      </div>
    </section>`:paid?`
    <section class="card" style="padding:6px 16px">
      <div class="lrow" id="bill-manage" role="button" tabindex="0">
        <div class="lic">${icon("creditCard",18)}</div>
        <div class="lm"><div class="lt">Manage subscription</div><div class="ls">${teamPlan?"Change plan, card, or cancel in the Stripe portal":`Change plan or cancel in the ${/android/i.test(navigator.userAgent||"")?"Play Store":"App Store"}`}</div></div>
        ${icon("chevron",17,'style="color:var(--text-3)"')}
      </div>
      ${teamPlan?"":`<div class="lrow" id="bill-restore" role="button" tabindex="0">
        <div class="lic">${icon("rotate",17)}</div>
        <div class="lm"><div class="lt">Restore purchases</div><div class="ls">Moved devices? Restore your membership</div></div>
        ${icon("chevron",17,'style="color:var(--text-3)"')}
      </div>`}
    </section>`:operator?`
    <section class="card pad">
      <button class="btn primary" id="bill-upsell-pro" style="width:100%">See plans \xB7 free 14-day trial</button>
      <div style="height:10px"></div>
      <div style="font-size:12px;font-weight:600;color:var(--text-3);line-height:1.5;text-align:center">Every plan counts <b>active</b> athletes only; idle seats are free.</div>
    </section>`:`
    <section class="card pad">
      <button class="btn primary" id="bill-upsell" style="width:100%">See membership plans</button>
      <div style="height:10px"></div>
      <div class="lrow" data-go="redeem-code" style="cursor:pointer"><div class="lic">${icon("key",17)}</div><div class="lm"><div class="lt">Have a code?</div><div class="ls">From your trainer: redeem it to unlock premium</div></div>${icon("chevron",17)}</div>
      <div class="lrow" id="bill-restore" role="button" tabindex="0" style="cursor:pointer"><div class="lic">${icon("rotate",17)}</div><div class="lm"><div class="lt">Restore purchases</div><div class="ls">Already a member on another device?</div></div>${icon("chevron",17)}</div>
    </section>`}

    <div id="bill-msg" style="text-align:center;font-size:12px;font-weight:600;color:var(--text-3);min-height:16px;margin-top:12px"></div>
    <div style="height:10px"></div>
    `},mount(root){if(!BILL.loaded)loadBilling();const billRetry=root.querySelector("#bill-retry");if(billRetry)billRetry.addEventListener("click",()=>{BILL.loaded=false;BILL.failed=false;window.__render();loadBilling()});const msg=root.querySelector("#bill-msg");const manage=root.querySelector("#bill-manage");if(manage)manage.addEventListener("click",async()=>{if(BILL.sub&&BILL.sub.tier==="team"){if(!canOpenExternalCheckout()){if(msg)msg.textContent="Your Team plan is managed from your account on the web, not inside the app.";return}if(msg)msg.textContent="Opening your billing portal\u2026";const p=await roles.openBillingPortal();if(p.ok){if(window.OnStandardNative?.openUrl)window.OnStandardNative.openUrl(p.url);else location.href=p.url;if(msg)msg.textContent=""}else if(msg)msg.textContent=p.error;return}roles.openExternal(storeSubUrl())});const upsell=root.querySelector("#bill-upsell");if(upsell)upsell.addEventListener("click",()=>{if(window.__go)window.__go("paywall");else location.hash="#paywall"});const upsellPro=root.querySelector("#bill-upsell-pro");if(upsellPro)upsellPro.addEventListener("click",()=>{if(window.__go)window.__go("plan-upgrade");else location.hash="#plan-upgrade"});const restore=root.querySelector("#bill-restore");if(restore)restore.addEventListener("click",async()=>{if(msg)msg.textContent="Restoring\u2026";const res=await roles.restoreConsumerPurchases(RT.userId);if(res&&res.ok){if(msg){msg.style.color="var(--green-bright)";msg.textContent="Membership restored."}BILL.loaded=false;loadBilling()}else if(msg){msg.style.color="var(--text-3)";msg.textContent=res&&res.reason==="unavailable"?"Purchases restore once memberships are live.":"Nothing to restore on this account."}})}};export const notifSettings={tab:"profile",get nav(){return roleNav()},render(){const back=roleProfileRoute();const p=normalizePrefs(RT.notifPrefs);const qf=Math.round(p.quietFrom/60);const qt=Math.round(p.quietTo/60);return`
    ${backHead("Notifications","Your tone. Your quiet hours. Coach sets urgency.",back)}

    <section class="card" style="padding:6px 16px">
      ${""}
      <div class="lrow" id="ns-enabled" role="switch" tabindex="0" aria-checked="${p.enabled?"true":"false"}" aria-label="Accountability notifications" aria-describedby="ns-enabled-sub">
        <div class="lic">${icon("bell",17)}</div>
        <div class="lm"><div class="lt">Accountability notifications</div><div class="ls" id="ns-enabled-sub">${p.enabled?"On: reminders track what\u2019s actually still open":"Off"}</div></div>
        <div class="std-switch ${p.enabled?"on":""}" aria-hidden="true"></div>
      </div>
      <div class="lrow" id="ns-haptics" role="switch" tabindex="0" aria-checked="${RT.haptics!==false?"true":"false"}" aria-label="Haptics" aria-describedby="ns-haptics-sub">
        <div class="lic">${icon("vibrate",17)}</div>
        <div class="lm"><div class="lt">Haptics</div><div class="ls" id="ns-haptics-sub">A light tick on taps and logs</div></div>
        <div class="std-switch ${RT.haptics!==false?"on":""}" aria-hidden="true"></div>
      </div>
    </section>

    ${""}
    <div id="ns-off-note" role="status" style="font-size:var(--t-xs);font-weight:700;color:var(--text-3);margin:2px 2px 8px;${p.enabled?"display:none":""}">Off: nothing below fires until you turn it back on.</div>
    <div id="ns-deps"${p.enabled?"":' aria-disabled="true" style="opacity:.45;pointer-events:none"'}>
    ${""}
    <h2 class="eyebrow">Your tone \xB7 how often and how firmly it reminds you</h2>
    <div class="chip-row" id="ns-pressure" data-toggle-group>
      <span class="chip">Supportive</span><span class="chip on">Direct</span><span class="chip">Intense</span>
    </div>
    <div class="set-note">Supportive: one heads-up per item. Direct: a last call on the ones your plan marks high. Intense: a last call on everything.</div>

    <h2 class="eyebrow">Quiet hours</h2>
    ${""}
    ${""}
    <div class="set-note">Reminders from your plan and from team standards pause between your cutoff and the hour you pick. Deadline warnings can break through if you let them. Messages from your coach still come through.</div>
    <section class="card" style="padding:6px 16px">
      <div class="lrow" style="cursor:default">
        <div class="lic">${icon("moon",17)}</div>
        <div class="lm"><div class="lt">No pings after</div></div>
        <div class="seg" style="width:150px" id="ns-quiet"><button class="${qf===21?"on":""}">9 PM</button><button class="${qf===22?"on":""}">10 PM</button><button class="${qf===23?"on":""}">11 PM</button></div>
      </div>
      ${""}
      <div class="lrow">
        <div class="lic">${icon("bell",17)}</div>
        <div class="lm"><div class="lt">Back on at</div></div>
        <div class="seg" style="width:150px" id="ns-quietto"><button class="${qt===6?"on":""}">6 AM</button><button class="${qt===7?"on":""}">7 AM</button><button class="${qt===8?"on":""}">8 AM</button></div>
      </div>
      <div class="lrow" id="ns-deadline" role="switch" tabindex="0" aria-checked="${p.allowDeadline?"true":"false"}" aria-label="Deadline warnings" aria-describedby="ns-deadline-sub">
        <div class="lic">${icon("bell",17)}</div>
        <div class="lm"><div class="lt">Deadline warnings</div><div class="ls" id="ns-deadline-sub">The only ones that break quiet hours</div></div>
        <div class="std-switch ${p.allowDeadline?"on":""}" aria-hidden="true"></div>
      </div>
      <div class="lrow" id="ns-team" role="switch" tabindex="0" aria-checked="${p.teamPushes!==false?"true":"false"}" aria-label="Team standard reminders" aria-describedby="ns-team-sub">
        <div class="lic">${icon("users",17)}</div>
        <div class="lm"><div class="lt">Team standard reminders</div><div class="ls" id="ns-team-sub">Pushed by the server when a team standard is due</div></div>
        <div class="std-switch ${p.teamPushes!==false?"on":""}" aria-hidden="true"></div>
      </div>
    </section>

    ${(()=>{const reqs=(S.exec.items||[]).filter(i=>i&&i.required&&i.tracked&&!i.assigned);const meals=reqs.filter(i=>i.proof==="photo");const rest=reqs.filter(i=>i.proof!=="photo");const lvOf=r=>r.reminder==="high"?"High":"Medium";const rows=[];if(meals.length)rows.push(["utensils","Meals",meals.some(m=>m.reminder==="high")?"High":"Medium"]);for(const r of rest)rows.push([r.icon||"clipboard",r.title,lvOf(r)]);if(!rows.length)return"";return`
    <h2 class="eyebrow">Urgency per requirement${S.coach.hasCoach?` \xB7 set by ${esc(S.coach.nameMid)}`:" \xB7 from your plan"}</h2>
    <section class="card" style="padding:6px 16px" role="list">
      ${rows.map(([ic,t,lv])=>`
        <div class="lrow" role="listitem" style="cursor:default">
          <div class="lic">${icon(ic,17)}</div>
          <div class="lm"><div class="lt">${esc(t)}</div></div>
          <span class="status-pill ${lv==="High"?"a":"b"}" style="display:inline-flex;align-items:center;gap:5px">${icon("lock",11)} ${lv}</span>
        </div>`).join("")}
    </section>`})()}
    <div class="set-note">${icon("lock",11)} Urgency decides which items get a last call on Direct, and belongs to ${S.coach.hasCoach?"your coach":"your plan"}; your tone above sets how many reminders you get and how they read. Completed requirements never remind you; finishing one cancels its reminders immediately.</div>
    </div>
    ${typeof window!=="undefined"&&!window.OnStandardNative?`
    <div class="set-note">${icon("info",11)} Reminders are delivered by the phone app. In a browser these settings save, but nothing is scheduled on this device.</div>`:""}
    <div style="height:10px"></div>
    `},async mount(root){wireToggles(root);wireSegAria(root);wirePressure(root,"#ns-pressure");const flip=el=>{const pill=el.querySelector(".std-switch")||el;const on=!pill.classList.contains("on");pill.classList.toggle("on",on);el.setAttribute("aria-checked",on?"true":"false");return on};const hsw=root.querySelector("#ns-haptics");if(hsw)hsw.addEventListener("click",()=>{act.setHaptics(flip(hsw))});const sw=(sel,patch,after)=>{const el=root.querySelector(sel);if(!el)return;el.addEventListener("click",()=>{const on=flip(el);act.setNotifPrefs(patch(on));if(after)after(on)})};const seg=(sel,value,after)=>{const row=root.querySelector(sel);if(!row)return;const btns=[...row.querySelectorAll("button")];btns.forEach(b=>b.addEventListener("click",()=>{btns.forEach(x=>x.classList.remove("on"));b.classList.add("on");act.setNotifPrefs(value(b.textContent.trim()));if(after)after(b.textContent.trim())}))};sw("#ns-enabled",on=>({enabled:on}),on=>{const ls=root.querySelector("#ns-enabled")?.querySelector(".ls");if(ls)ls.textContent=on?"On: reminders track what\u2019s actually still open":"Off";const deps=root.querySelector("#ns-deps");if(deps){deps.style.opacity=on?"":".45";deps.style.pointerEvents=on?"":"none";if(on)deps.removeAttribute("aria-disabled");else deps.setAttribute("aria-disabled","true")}const note=root.querySelector("#ns-off-note");if(note)note.style.display=on?"none":""});sw("#ns-deadline",on=>({allowDeadline:on}));sw("#ns-team",on=>({teamPushes:on}));seg("#ns-quiet",t=>({quietFrom:(t==="9 PM"?21:t==="11 PM"?23:22)*60}));seg("#ns-quietto",t=>({quietTo:(t==="6 AM"?6:t==="8 AM"?8:7)*60}))}};const COACH_PRESETS={Essential:{enabled:true,briefing:false,recap:false,hourly:false,immediateCritical:true,quietFrom:21*60},Balanced:{enabled:true,briefing:true,briefingAt:7*60+30,recap:true,recapAt:20*60+30,hourly:false,immediateCritical:true,quietFrom:22*60},"Hands-on":{enabled:true,briefing:true,briefingAt:7*60,recap:true,recapAt:20*60,hourly:true,immediateCritical:true,quietFrom:23*60}};function presetFor(p){const hit=Object.entries(COACH_PRESETS).find(([,b])=>Object.entries(b).every(([k,v])=>p[k]===v));return hit?hit[0]:null}export const coachNotifSettings={nav:"operator",tab:"profile",render(){const p=normalizeCoachPrefs(RT.coachNotifPrefs);const qf=Math.round(p.quietFrom/60);const qt=Math.round((p.quietTo!=null?p.quietTo:7*60)/60);const preset=presetFor(p);return`
    ${backHead("Notifications","When and how you get alerts about your team.",roleProfileRoute())}

    <h2 class="eyebrow">Quick setup</h2>
    <div class="chip-row" id="cns-preset" data-toggle-group>
      ${Object.keys(COACH_PRESETS).map(k=>`<span class="chip ${preset===k?"on":""}">${k}</span>`).join("")}
    </div>
    <div style="font-size:11.5px;font-weight:600;color:var(--text-3);margin:0 2px 6px">Pick a starting point, then fine-tune below.</div>

    <section class="card" style="padding:6px 16px">
      <div class="lrow" id="cns-enabled" role="switch" tabindex="0" aria-checked="${p.enabled?"true":"false"}" aria-label="Coach notifications" aria-describedby="cns-enabled-sub">
        <div class="lic">${icon("bell",17)}</div>
        <div class="lm"><div class="lt">Coach notifications</div><div class="ls" id="cns-enabled-sub">${p.enabled?"On":"Off"}</div></div>
        <div class="std-switch ${p.enabled?"on":""}" aria-hidden="true"></div>
      </div>
    </section>

    <h2 class="eyebrow">Morning briefing</h2>
    <div class="chip-row" id="cns-briefing" data-toggle-group>
      <span class="chip ${!p.briefing?"on":""}">Off</span>
      <span class="chip ${p.briefing&&p.briefingAt===7*60?"on":""}">7:00</span>
      <span class="chip ${p.briefing&&p.briefingAt===7*60+30?"on":""}">7:30</span>
      <span class="chip ${p.briefing&&p.briefingAt===8*60?"on":""}">8:00</span>
    </div>

    <h2 class="eyebrow">Evening recap</h2>
    <div class="chip-row" id="cns-recap" data-toggle-group>
      <span class="chip ${!p.recap?"on":""}">Off</span>
      <span class="chip ${p.recap&&p.recapAt===20*60?"on":""}">8:00 PM</span>
      <span class="chip ${p.recap&&p.recapAt===20*60+30?"on":""}">8:30 PM</span>
      <span class="chip ${p.recap&&p.recapAt===21*60?"on":""}">9:00 PM</span>
    </div>
    ${""}
    <div style="height:12px"></div>

    <section class="card" style="padding:6px 16px">
      <div class="lrow" id="cns-hourly" role="switch" tabindex="0" aria-checked="${p.hourly?"true":"false"}" aria-label="Overdue digest" aria-describedby="cns-hourly-sub">
        <div class="lic">${icon("clock",17)}</div>
        <div class="lm"><div class="lt">Overdue digest</div><div class="ls" id="cns-hourly-sub">Only while something is overdue</div></div>
        <div class="std-switch ${p.hourly?"on":""}" aria-hidden="true"></div>
      </div>
      <div class="lrow" id="cns-critical" role="switch" tabindex="0" aria-checked="${p.immediateCritical?"true":"false"}" aria-label="Immediate critical" aria-describedby="cns-critical-sub">
        <div class="lic">${icon("bolt",17)}</div>
        <div class="lm"><div class="lt">Immediate critical</div><div class="ls" id="cns-critical-sub">One ping when a new group goes overdue</div></div>
        <div class="std-switch ${p.immediateCritical?"on":""}" aria-hidden="true"></div>
      </div>
    </section>

    <h2 class="eyebrow">Quiet hours</h2>
    <section class="card" style="padding:6px 16px">
      <div class="lrow" style="cursor:default">
        <div class="lic">${icon("moon",17)}</div>
        <div class="lm"><div class="lt">No pings after</div></div>
        <div class="seg" style="width:150px" id="cns-quiet"><button class="${qf===21?"on":""}">9 PM</button><button class="${qf===22?"on":""}">10 PM</button><button class="${qf===23?"on":""}">11 PM</button></div>
      </div>
      <div class="lrow" style="cursor:default">
        <div class="lic">${icon("bell",17)}</div>
        <div class="lm"><div class="lt">Back on at</div></div>
        <div class="seg" style="width:150px" id="cns-quietto"><button class="${qt===6?"on":""}">6 AM</button><button class="${qt===7?"on":""}">7 AM</button><button class="${qt===8?"on":""}">8 AM</button></div>
      </div>
      <div class="lrow" id="cns-myroom" role="switch" tabindex="0" aria-checked="${p.myRoomOnly?"true":"false"}" aria-label="My room only" aria-describedby="cns-myroom-sub">
        <div class="lic">${icon("users",17)}</div>
        <div class="lm"><div class="lt">My room only</div><div class="ls" id="cns-myroom-sub">Follow my scope instead of the whole team</div></div>
        <div class="std-switch ${p.myRoomOnly?"on":""}" aria-hidden="true"></div>
      </div>
    </section>
    <div style="height:10px"></div>
    `},mount(root){wireToggles(root);wireSegAria(root);const seg2=(sel,patch,after)=>{const el=root.querySelector(sel);if(!el)return;el.addEventListener("click",()=>{const pill=el.querySelector(".std-switch")||el;const on=!pill.classList.contains("on");pill.classList.toggle("on",on);el.setAttribute("aria-checked",on?"true":"false");act.setCoachNotifPrefs(patch(on));if(after)after(on)})};seg2("#cns-enabled",on=>({enabled:on}),on=>{const ls=root.querySelector("#cns-enabled")?.querySelector(".ls");if(ls)ls.textContent=on?"On":"Off"});seg2("#cns-hourly",on=>({hourly:on}));seg2("#cns-critical",on=>({immediateCritical:on}));seg2("#cns-myroom",on=>({myRoomOnly:on}));const quiet=root.querySelector("#cns-quiet");if(quiet){const btns=[...quiet.querySelectorAll("button")];const atHour={"9 PM":21*60,"10 PM":22*60,"11 PM":23*60};btns.forEach(b=>b.addEventListener("click",()=>{btns.forEach(x=>x.classList.remove("on"));b.classList.add("on");act.setCoachNotifPrefs({quietFrom:atHour[b.textContent.trim()]})}))}const quietTo=root.querySelector("#cns-quietto");if(quietTo){const btns=[...quietTo.querySelectorAll("button")];const atHour={"6 AM":6*60,"7 AM":7*60,"8 AM":8*60};btns.forEach(b=>b.addEventListener("click",()=>{btns.forEach(x=>x.classList.remove("on"));b.classList.add("on");act.setCoachNotifPrefs({quietTo:atHour[b.textContent.trim()]})}))}const presetRow=root.querySelector("#cns-preset");if(presetRow){presetRow.querySelectorAll(".chip").forEach(c=>c.addEventListener("click",()=>{const b=COACH_PRESETS[c.textContent.trim()];if(b){act.setCoachNotifPrefs(b);window.__render()}}))}const chipTime=(sel,flag,atMap)=>{const row=root.querySelector(sel);if(!row)return;const chips=[...row.querySelectorAll(".chip")];chips.forEach(c=>c.addEventListener("click",()=>{chips.forEach(x=>x.classList.remove("on"));c.classList.add("on");const t=c.textContent.trim();if(t==="Off")act.setCoachNotifPrefs({[flag]:false});else act.setCoachNotifPrefs({[flag]:true,[`${flag}At`]:atMap[t]})}))};chipTime("#cns-briefing","briefing",{"7:00":7*60,"7:30":7*60+30,"8:00":8*60});chipTime("#cns-recap","recap",{"8:00 PM":20*60,"8:30 PM":20*60+30,"9:00 PM":21*60})}};export const deleteAccount={get nav(){return roleNav()},hideTabs:true,render(){const WHAT={coach:"Your account, your sign-in, and everything only you own. Your team's standards, templates, and history stay with the team, with your name removed from them. Your athletes keep their own logs and scores. This cannot be undone.",trainer:"Your account, your practice, and its client code. Your clients keep their own logs and scores, but they lose their connection to you, and any premium access funded through your packages ends immediately. This cannot be undone.",parent:"Your account, your sign-in, and your links to your athletes. Your athletes keep their accounts and everything in them; they just lose your view. Any plan you fund is billed separately and does not cancel itself: cancel it under Funded plans first. This cannot be undone."};const what=WHAT[RT.authRole]||"Your account, every meal photo, every log, every score, your coach connection, and your spot on your team's Squad board. Your coach keeps nothing of yours. This cannot be undone.";return`
    ${backHead("Delete account","Permanent. We mean it.",roleProfileRoute())}

    <div class="state-demo err-box" style="text-align:left">
      <div class="sd-t">What gets deleted</div>
      <div class="sd-s">${what}</div>
    </div>
    <div id="del-sub-note"></div>
    <div class="sidebox">
      <div class="req-icon b s38">${icon("clipboard",17)}</div>
      <div><div class="tt">Want your data first?</div>
      <div class="ts">Download everything before you delete: <span class="link" data-go="privacy" role="button" tabindex="0">open Privacy &amp; visibility</span>. Deletion completes within 30 days everywhere, immediately in the app.</div></div>
    </div>
    <div style="height:18px"></div>
    <button id="del-acct" class="btn danger">${icon("trash",18)} Delete my account</button>
    ${""}
    <div id="del-confirm" style="display:none">
      <div style="text-align:center;font-size:var(--t-sm);font-weight:700;color:var(--red-bright);margin-bottom:10px">Delete everything? This cannot be undone.</div>
      <div style="display:flex;gap:10px">
        <button id="del-cancel" class="btn ghost" style="flex:1">Cancel</button>
        <button id="del-go" class="btn danger" style="flex:1">Delete everything</button>
      </div>
    </div>
    <div id="del-status" style="text-align:center;font-size:13px;font-weight:600;color:var(--text-3);min-height:18px;margin-top:10px"></div>
    <button class="btn ghost" data-go="${roleProfileRoute()}">Keep my account</button>
    <div style="height:10px"></div>
    `},mount(root){const btn=root.querySelector("#del-acct");const status=root.querySelector("#del-status");if(!btn)return;const subNote=root.querySelector("#del-sub-note");if(subNote&&RT.authRole!=="parent"){(async()=>{const sub=await roles.fetchMySubscription();const failed=!!(sub&&sub.error);if(!failed&&!isPaid(sub))return;const team=!failed&&sub.tier==="team";const store=/android/i.test(navigator.userAgent||"")?"Play Store":"App Store";const manageLabel=team?"Open the billing portal":`Manage it in the ${store}`;subNote.innerHTML=`
        <div class="sidebox">
          <div class="req-icon a s38">${icon("creditCard",17)}</div>
          <div><div class="tt">${failed?"Paying for a membership?":team?"Your Team plan keeps billing":"Your membership keeps billing"}</div>
          <div class="ts">Deleting your account does not cancel it. <span class="link" id="del-sub-manage" role="button" tabindex="0" style="font-weight:700">${manageLabel}</span> first.</div></div>
        </div>`;const manage=subNote.querySelector("#del-sub-manage");const go=async()=>{if(team){if(!canOpenExternalCheckout()){if(status)status.textContent="Your Team plan is managed from your account on the web, not inside the app.";return}const p=await roles.openBillingPortal();if(p.ok){if(window.OnStandardNative?.openUrl)window.OnStandardNative.openUrl(p.url);else location.href=p.url}else if(status){status.textContent=p.error||"Could not open the billing portal."}return}roles.openExternal(storeSubUrl())};manage.addEventListener("click",go);manage.addEventListener("keydown",e=>{if(e.key==="Enter"||e.key===" "){e.preventDefault();go()}})})()}const confirmRow=root.querySelector("#del-confirm");const cancelBtn=root.querySelector("#del-cancel");const goBtn=root.querySelector("#del-go");let armTimer=null;const onOutside=e=>{if(confirmRow&&!confirmRow.contains(e.target))disarm()};const disarm=()=>{if(armTimer){clearTimeout(armTimer);armTimer=null}document.removeEventListener("pointerdown",onOutside,true);if(confirmRow)confirmRow.style.display="none";btn.style.display=""};btn.addEventListener("click",()=>{btn.style.display="none";if(confirmRow)confirmRow.style.display="";armTimer=setTimeout(disarm,5e3);setTimeout(()=>document.addEventListener("pointerdown",onOutside,true),0)});if(cancelBtn)cancelBtn.addEventListener("click",disarm);if(goBtn)goBtn.addEventListener("click",async()=>{if(armTimer){clearTimeout(armTimer);armTimer=null}document.removeEventListener("pointerdown",onOutside,true);goBtn.disabled=true;if(cancelBtn)cancelBtn.disabled=true;goBtn.textContent="Deleting\u2026";const serverOk=await window.__act.deleteAccount();if(serverOk===false){if(status){status.style.color="var(--red-bright)";status.textContent="Couldn't reach the server. You're signed out, but your account may still exist. Try again online."}goBtn.disabled=false;if(cancelBtn)cancelBtn.disabled=false;goBtn.textContent="Delete everything";disarm();return}if(status)status.textContent="Account deleted.";location.hash="#welcome"})}};export const terms={hideTabs:true,render({sub}={}){const back=OB_BACK[sub]||roleProfileRoute();const ext=(href,ic,t,s)=>`
      <a class="lrow" href="${href}" target="_blank" rel="noopener" style="text-decoration:none;color:inherit">
        <div class="lic">${icon(ic,16)}</div>
        <div class="lm"><div class="lt">${t}</div><div class="ls">${s}</div></div>
        ${icon("external",15,'style="color:var(--text-3)"')}
      </a>`;return`
    ${backHead("Terms & Privacy","The documents, and what they mean",back)}
    <section class="card" style="padding:6px 16px">
      ${ext("https://onstandard.app/terms","clipboard","Terms of Service","The full agreement")}
      ${ext("https://onstandard.app/privacy","lock","Privacy Policy","What we collect and why")}
      <div class="lrow" data-go="privacy"><div class="lic">${icon("download",16)}</div><div class="lm"><div class="lt">Data export</div><div class="ls">Download everything you own, in-app</div></div>${icon("chevron",16)}</div>
      ${""}
      <div class="lrow" data-go="verified-profile"><div class="lic">${icon("shield",16)}</div><div class="lm"><div class="lt">What recruiters can see</div><div class="ls">Your public page and your discipline record, each with its own switch</div></div>${icon("chevron",16)}</div>
      <div class="lrow" data-go="delete-account"><div class="lic" style="color:var(--red)">${icon("trash",16)}</div><div class="lm"><div class="lt">Account deletion</div><div class="ls">Permanent, in-app</div></div>${icon("chevron",16)}</div>
      <div class="lrow" data-go="feedback"><div class="lic">${icon("message",16)}</div><div class="lm"><div class="lt">Send feedback</div><div class="ls">Report a bug, ask something, or tell us an idea</div></div>${icon("chevron",16)}</div>
      ${""}
      ${ext("mailto:support@onstandard.app","clipboard","Email us instead","support@onstandard.app")}
    </section>
    <h2 class="eyebrow">The short version</h2>
    <section class="card" style="padding:6px 16px" role="list">
      ${[["Your photos are yours","Meal photos are private to your account and your coach connection. They are not public and not sold."],["Health & AI disclaimer","OnStandard gives execution feedback, not medical or dietary advice. AI meal reads are estimates; verify anything health-critical yourself."],["Children & guardians","Under 13 requires a parent or guardian. A guardian of a minor can request access to or deletion of the minor\u2019s data at any time."],["No ad tracking","No ad trackers or third-party ad identifiers in the app."],["Delete anytime","Full in-app account deletion. Export first if you want your history."]].map(([t,s])=>`
        <div class="lrow" role="listitem" style="cursor:default">
          <div class="lic">${icon("check",16)}</div>
          <div class="lm"><div class="lt">${t}</div><div class="ls" style="white-space:normal;line-height:1.4">${s}</div></div>
        </div>`).join("")}
    </section>
    <div style="height:10px"></div>
    `}};export function wireToggles(root){root.querySelectorAll("[data-toggle-group]").forEach(g=>{const items=g.querySelectorAll("button, .chip, .choice");if(!g.hasAttribute("role"))g.setAttribute("role","radiogroup");labelGroup(g);const syncAria=()=>items.forEach(x=>{if(!x.hasAttribute("role"))x.setAttribute("role","radio");x.setAttribute("aria-checked",x.classList.contains("on")?"true":"false")});items.forEach(el=>{if(el.tagName!=="BUTTON"&&!el.hasAttribute("tabindex"))el.setAttribute("tabindex","0");el.addEventListener("keydown",e=>{if(e.key==="Enter"||e.key===" "){e.preventDefault();el.click()}});el.addEventListener("click",e=>{e.stopPropagation();g.querySelectorAll(".on").forEach(x=>x.classList.remove("on"));el.classList.add("on");syncAria()})});syncAria()})}function labelGroup(g){if(g.hasAttribute("aria-label")||g.hasAttribute("aria-labelledby")||g.hasAttribute("data-stepper"))return;const row=g.closest?g.closest(".lrow"):null;const lt=row&&row.querySelector(".lt");const t=lt&&lt.textContent.trim();if(t)g.setAttribute("aria-label",t)}export function wireSegAria(root){const sync=()=>root.querySelectorAll(".seg").forEach(g=>{if(g.hasAttribute("data-stepper"))return;if(!g.hasAttribute("role"))g.setAttribute("role","radiogroup");labelGroup(g);g.querySelectorAll("button").forEach(b=>{if(!b.hasAttribute("role"))b.setAttribute("role","radio");b.setAttribute("aria-checked",b.classList.contains("on")?"true":"false")})});root.addEventListener("click",e=>{if(e.target.closest&&e.target.closest(".seg"))requestAnimationFrame(sync)});sync()}export const planStylePicker={tab:"profile",hideTabs:true,render(){const PS=S.planStyle;const choosing=PS.canChoose;const current=PS.key;const selected=choosing?current:PS.preference||current;return`
    ${backHead("Plan style",choosing?"How much structure helps you succeed":esc(PS.sourceLabel),"settings")}

    ${planStyleCard(PS,{compact:true})}

    <h2 class="eyebrow">${choosing?"Choose your style":"Tell your "+esc(S.coach.noun)+" what you prefer"}</h2>
    ${!choosing?`<div class="ps-note lead">Your ${esc(S.coach.noun)} sets the plan you're scored on. What you pick here is shared with them; it doesn't change your scoring on its own.</div>`:""}

    <section class="card" style="padding:6px 16px" id="ps-options">
      ${STYLE_KEYS.map(k=>{const L=styleLabel(k);const on=selected===k;return`
        <div class="lrow" data-ps-pick="${k}" role="radio" tabindex="0" aria-checked="${on?"true":"false"}">
          <div class="lic">${icon(k==="structured"?"clipboard":k==="guided"?"target":"heart",17)}</div>
          <div class="lm"><div class="lt">${esc(L.name)}${on?` <span class="status-pill ${choosing?"g":"muted"}" style="margin-left:6px">${choosing?"Selected":"Preferred"}</span>`:""}</div>
          <div class="ls">${esc(L.how)}</div></div>
        </div>`}).join("")}
    </section>
    <div id="ps-save-status" role="status" class="ps-note err"></div>

    <div class="ps-note" style="margin-top:4px">
      Changing your style applies from today forward. Days you've already scored keep the score you earned; they were measured by the plan you were on then.
    </div>

    <div style="height:16px"></div>
    <button class="btn ghost" data-back="settings">Done</button>
    <div style="height:10px"></div>`},mount(root){root.querySelectorAll("[data-ps-pick]").forEach(el=>el.addEventListener("click",async()=>{const p=act.setPlanStyle(el.getAttribute("data-ps-pick"));window.__render&&window.__render();const ok=await p;if(!ok){const status=document.getElementById("ps-save-status");if(status)status.textContent="That change didn't save. Check your connection and try again."}}))}};
