import{RT}from"../state.js";import{icon}from"../icons.js";import{esc,backHead,skeletonRows,errorState,emptyState,statusMsg,alertMsg,copyText,sayStatus}from"../components.js";import*as roles from"../roles.js";import{priceLabel}from"../funded.js";import{shortDate}from"../fmt-date.js";const SHARE_BASE="https://onstandard.app/t?t=";let G={practiceId:null,page:null,offers:null,apps:null,connect:null,payments:null,funded:null,claims:null,fail:{},loaded:false};let UI={editing:null,connecting:false,confirmRefund:null,payMsg:""};function practiceId(){return RT.practice&&RT.practice.id||G.practiceId||null}async function loadGrow(force){if(G.loaded&&!force)return;let pid=practiceId();if(!pid){const id=await roles.fetchMyPracticeIdentity();if(id&&id.id){G.practiceId=pid=id.id}}if(!pid){G.loaded=true;if(window.__render)window.__render();return}const[page,offers,apps,connect,payments,funded,claims]=await Promise.all([roles.fetchMyTrainerPage(pid),roles.fetchMyOffers(pid),roles.fetchMyApplications(pid),roles.fetchConnectStatus(pid),roles.fetchPracticePayments(pid),roles.fetchFundedClients(pid),roles.fetchPendingClaims(pid)]);const isErr=x=>!!(x&&!Array.isArray(x)&&x.error);G.fail={page:isErr(page),offers:isErr(offers),apps:isErr(apps),connect:isErr(connect),payments:isErr(payments),funded:isErr(funded),claims:isErr(claims)};if(!G.fail.page)G.page=page;if(!G.fail.offers)G.offers=Array.isArray(offers)?offers:[];if(!G.fail.apps)G.apps=Array.isArray(apps)?apps:[];if(!G.fail.connect)G.connect=connect||{status:"none"};if(!G.fail.payments)G.payments=Array.isArray(payments)?payments:[];if(!G.fail.funded)G.funded=Array.isArray(funded)?funded:[];if(!G.fail.claims)G.claims=Array.isArray(claims)?claims:[];G.loaded=true;if(window.__render)window.__render()}function sectionErr(what){return`<div class="lrow" style="cursor:default">
    <div class="lm"><div class="lt" style="color:var(--red)">Couldn't load ${esc(what)}</div>
      <div class="ls">Check your connection, then retry.</div></div>
    <button class="btn ghost sm" data-tg="retry" style="width:auto;padding:0 12px;height:44px">Retry</button>
  </div>`}const CONNECT_LABEL={none:{pill:"Not set up",color:"var(--text-3)",cta:"Connect Stripe to get paid",tone:"green"},pending:{pill:"Setup in progress",color:"var(--text-2)",cta:"Continue setup",tone:"ghost"},active:{pill:"Connected",color:"var(--green-bright)",cta:"Manage on Stripe",tone:"ghost"},restricted:{pill:"Action needed",color:"var(--red)",cta:"Fix on Stripe",tone:"green"}};function connectSection(){const status=G.connect&&G.connect.status||"none";const meta=CONNECT_LABEL[status]||CONNECT_LABEL.none;const sub=status==="active"?"Client payments for your offers deposit to your bank account on Stripe\u2019s schedule.":status==="pending"?"Finish the steps Stripe asked for to start accepting payments.":status==="restricted"?"Stripe paused payouts: a document or detail needs attention.":"Connect a Stripe account so clients can pay for your offers right in the app.";return`
    <div class="lrow" style="cursor:default;padding:0 0 10px">
      <div class="lm"><div class="lt">Stripe account</div><div class="ls">${esc(sub)}</div></div>
      <span class="status-pill" style="background:var(--surface-2);color:${meta.color}">${meta.pill}</span>
    </div>
    <button class="btn ${meta.tone} sm" id="tg-connect"${UI.connecting?' disabled aria-busy="true"':""} style="width:auto;padding:0 16px;height:44px">${UI.connecting?"\u2026":meta.cta}</button>
    ${statusMsg({id:"tg-connect-msg",style:"margin-left:10px"})}
    <div class="sidebox flat" style="margin:12px 0 0"><div class="req-icon g" style="width:34px;height:34px">${icon("check",15)}</div>
      ${""}
      <div><div class="tt">Bill through OnStandard, and your clients ride free</div>
      <div class="ts">A client on a recurring package gets full OnStandard membership included, and you are not charged a seat for them. One bill for them, no seat bill for you. OnStandard keeps a platform fee from each payment. You see the exact split on every payout below.</div></div></div>
  `}function fundedSection(){const rows=G.funded||[];const live=rows.filter(r=>r.is_active).length;const lapsed=rows.filter(r=>!r.is_active);if(!rows.length){return`<div class="ls" style="padding:10px 0">No one yet. Share your page link: anyone who buys a monthly or weekly package is covered automatically, and never counts toward your seats.</div>`}return`
    <div class="lrow" style="cursor:default;padding:6px 0 10px">
      <div class="lm"><div class="lt">${live} covered${lapsed.length?` \xB7 ${lapsed.length} lapsed`:""}</div>
        <div class="ls">Covered clients have membership included and cost you no seat.</div></div>
    </div>
    ${rows.map(r=>`
    <div class="lrow" style="cursor:default">
      <div class="lm"><div class="lt">${esc(r.full_name||"Client")}</div>
        <div class="ls">${r.offer_name?esc(r.offer_name)+" \xB7 ":""}${r.is_active?"Renews "+shortDate(r.expires_at):"Lapsed "+shortDate(r.expires_at)}</div></div>
      <span class="status-pill" style="background:${r.is_active?"var(--green-surface)":"var(--surface-2)"};color:${r.is_active?"var(--green-bright)":"var(--red)"}">${r.is_active?"Covered":"Lapsed"}</span>
    </div>`).join("")}`}export function newApps(){return(G.apps||[]).filter(a=>a.status==="new").length}export const trainerGrow={nav:"trainer",tab:"profile",badge(){return newApps()},render(){const head=backHead("Grow","Your page, offers & applications","trainer-profile");if(!G.loaded&&!navigator.onLine){return`${head}${errorState({title:"You're offline",body:"Your page, offers and payments load right here when you reconnect.",retryId:"tg-retry"})}`}if(!G.loaded){return`${head}${skeletonRows(4,"Loading your practice")}`}const F=G.fail||{};if(F.page&&F.offers&&F.apps&&!G.page&&!(G.offers||[]).length&&!(G.apps||[]).length){return`${head}${errorState({title:"Couldn't load your practice",body:"Nothing was lost. Reconnect and everything loads right here.",retryId:"tg-retry"})}`}if(!practiceId()){return`${head}${emptyState({icon:"heart",title:"Set up your practice first",body:"Your public page and offers hang off your practice. Finish your trainer profile to get started.",action:{label:"Finish your trainer profile",go:"trainer-profile"}})}`}const p=G.page||{};const published=!!p.published;const slug=p.public_slug||"";const shareUrl=slug?SHARE_BASE+slug:"";return`${head}

    <h2 class="eyebrow">Your public page</h2>
    <section class="card tg-page" style="padding:16px">
      <div class="lrow" style="cursor:default;padding:0 0 10px">
        <div class="lm"><div class="lt">Acquisition page</div>
          <div class="ls">${published?"Live: anyone with your link can apply":"Draft: publish to get a shareable link"}</div></div>
        <span class="status-pill" style="background:${published?"var(--green-surface)":"var(--surface-2)"};color:${published?"var(--green-bright)":"var(--text-3)"}">${published?"Published":"Draft"}</span>
      </div>
      ${published&&shareUrl?`
      <div class="code-boxes" style="display:flex;gap:8px;align-items:center;margin:4px 0 12px">
        <input id="tg-link" readonly aria-label="Your public page link" value="${esc(shareUrl)}" style="flex:1;font-size:var(--t-sm);letter-spacing:0;text-align:left;padding:0 10px;height:44px">
        <button class="btn ghost sm" id="tg-copy" style="width:auto;padding:0 12px;height:44px">Copy</button>
      </div>`:""}
      ${""}
      <label class="tg-l" for="tg-name">Display name</label><input id="tg-name" maxlength="60" value="${esc(p.display_name||RT.profile&&RT.profile.full_name||"")}" placeholder="Your name">
      <label class="tg-l" for="tg-spec">Specialty</label><input id="tg-spec" maxlength="80" value="${esc(p.specialty||"")}" placeholder="Sports-performance nutrition & accountability">
      <label class="tg-l" for="tg-head">Headline (your promise)</label><input id="tg-head" maxlength="100" value="${esc(p.headline||"")}" placeholder="Turn your training into daily execution you can see.">
      <label class="tg-l" for="tg-bio">About you</label><textarea id="tg-bio" maxlength="600" placeholder="Who you coach, how you work\u2026">${esc(p.bio||"")}</textarea>
      <label class="tg-l" for="tg-cta">Apply button label</label><input id="tg-cta" maxlength="30" value="${esc(p.cta_label||"Apply to work with me")}" placeholder="Apply to work with me">
      <div style="display:flex;gap:8px;margin-top:14px">
        <button class="btn ghost sm" id="tg-save" style="width:auto;padding:0 16px;height:44px">Save</button>
        <button class="btn ${published?"ghost":"green"} sm" id="tg-pub" style="width:auto;padding:0 16px;height:44px">${published?"Unpublish":"Save & publish"}</button>
        ${""}
        ${statusMsg({id:"tg-msg",style:"align-self:center"})}
      </div>
    </section>

    <h2 class="eyebrow">Get paid</h2>
    <section class="card" style="padding:16px">
      ${F.connect&&!G.connect?sectionErr("your Stripe status"):connectSection()}
    </section>

    ${""}
    <h2 class="eyebrow">Your offers</h2>
    ${(G.offers||[]).length||UI.editing==="new"||F.offers&&!(G.offers||[]).length?`
    <section class="card" style="padding:6px 16px">
      ${F.offers&&!(G.offers||[]).length?sectionErr("your offers"):""}
      ${(G.offers||[]).map(o=>UI.editing===o.id?offerForm(o):`
      <div class="lrow" style="cursor:default">
        <div class="lm"><div class="lt">${esc(o.name)} ${o.active?"":'<span class="ls">\xB7 hidden</span>'}</div>
          <div class="ls">${esc(priceLabel(o))}${o.blurb?" \xB7 "+esc(o.blurb):""}</div></div>
        <button class="btn ghost sm" data-tg="edit" data-id="${esc(o.id)}" style="width:auto;padding:0 12px;height:44px">Edit</button>
      </div>`).join("")}
      ${UI.editing==="new"?offerForm(null):`<div style="padding:10px 0"><button class="btn ghost sm" data-tg="add" style="width:auto;padding:0 14px;height:44px">${icon("plus",15)} Add an offer</button></div>`}
    </section>`:`
    <div class="ls" style="margin:0 2px;line-height:1.5">No offers yet. Add your first package: prospects apply to it from your page.</div>
    <button class="btn ghost sm" data-tg="add" style="width:auto;padding:0 14px;height:44px;margin-top:12px">${icon("plus",15)} Add an offer</button>`}

    <h2 class="eyebrow">Applications ${newApps()?`<span class="status-pill" style="background:rgba(var(--blue-rgb),0.14);color:var(--blue-bright);margin-left:6px">${newApps()} new</span>`:""}</h2>
    ${!(G.apps||[]).length&&!F.apps?`
    <div class="ls" style="margin:0 2px;line-height:1.5">No applications yet. Publish your page and share the link. Applications land here.</div>`:`
    <section class="card" style="padding:6px 16px">
      ${F.apps&&!(G.apps||[]).length?sectionErr("applications"):""}
      ${(G.apps||[]).map(a=>`
      <div class="lrow" style="cursor:default;align-items:flex-start">
        <div class="lm" style="flex:1">
          <div class="lt">${esc(a.applicant_name)} <span class="ls">\xB7 ${esc(a.applicant_contact)}</span></div>
          ${a.message?`<div class="ls" style="margin-top:2px">${esc(a.message)}</div>`:""}
          <div class="ls" style="margin-top:3px;color:var(--text-3)">${a.status==="new"?"New":a.status==="accepted"?"Accepted":"Declined"} \xB7 ${timeAgo(a.created_at)}</div>
        </div>
        ${a.status==="new"?`
        <div style="display:flex;gap:6px;flex:none">
          <button class="btn ghost sm" data-tg="decline" data-id="${esc(a.id)}" style="width:auto;padding:0 10px;height:44px">Decline</button>
          <button class="btn primary sm" data-tg="accept" data-id="${esc(a.id)}" style="width:auto;padding:0 10px">Accept</button>
        </div>`:""}
      </div>`).join("")}
      ${(G.apps||[]).some(a=>a.status==="accepted")&&RT.practice&&RT.practice.code?`
      <div class="sidebox flat" style="margin:10px 0 0"><div class="req-icon b" style="width:34px;height:34px">${icon("lock",15)}</div>
        <div><div class="tt">Connect an accepted client</div><div class="ts">Send them your practice code <b>${esc(RT.practice.code)}</b>. They enter it after signing up to join your practice and unlock coaching.</div></div></div>`:""}
    </section>`}

    ${F.claims&&!(G.claims||[]).length?`
    <h2 class="eyebrow">Paid, waiting to join</h2>
    <section class="card" style="padding:6px 16px">${sectionErr("pending buyers")}</section>`:""}
    ${(G.claims||[]).length?`
    <h2 class="eyebrow">Paid, waiting to join <span class="status-pill" style="background:rgba(var(--amber-rgb),0.16);color:var(--amber-bright);margin-left:6px">${G.claims.length}</span></h2>
    <section class="card" style="padding:6px 16px">
      <div class="lrow" style="cursor:default;padding:6px 0 10px">
        <div class="lm"><div class="lt">They have paid you but haven't set up their app</div>
          <div class="ls">Until they enter the code they're being billed for something they can't open. Read them the code, or refund them from Payments below.</div></div>
      </div>
      ${G.claims.map(c=>`
      <div class="lrow" style="cursor:default">
        <div class="lm"><div class="lt">${esc(c.payer_email||"Buyer")}</div>
          <div class="ls">${c.offer_name?esc(c.offer_name)+" \xB7 ":""}waiting ${esc(String(c.days_waiting))}d</div></div>
        <button class="btn ghost sm" data-tg="copycode" data-code="${esc(c.code)}" style="width:auto;padding:0 12px;height:44px;font-family:ui-monospace,SFMono-Regular,Menlo,Consolas,monospace">${esc(c.code)}</button>
      </div>`).join("")}
    </section>`:""}

    ${G.connect&&G.connect.status==="active"?`
    <h2 class="eyebrow">Covered clients</h2>
    <section class="card" style="padding:6px 16px">
      ${F.funded&&!(G.funded||[]).length?sectionErr("covered clients"):fundedSection()}
    </section>

    <h2 class="eyebrow">Payments</h2>
    <section class="card" style="padding:6px 16px">
      ${F.payments&&!(G.payments||[]).length?sectionErr("payments"):""}
      ${(G.payments||[]).length?G.payments.map(p2=>`
      <div class="lrow" style="cursor:default">
        <div class="lm"><div class="lt">$${(p2.amount_cents/100).toFixed(2)} <span class="ls">${p2.status==="refunded"?"\xB7 refunded":""}</span></div>
          <div class="ls">${timeAgo(p2.created_at)} \xB7 fee $${(p2.application_fee_cents/100).toFixed(2)}${p2.beneficiary_name?` \xB7 parent-funded for ${esc(p2.beneficiary_name)}`:""}</div>
          ${UI.confirmRefund===p2.id?`<div class="ls" style="color:var(--red);margin-top:2px">Sends $${(p2.amount_cents/100).toFixed(2)} back to the client. This can't be undone.</div>`:""}</div>
        ${p2.status==="paid"?UI.confirmRefund===p2.id?`
        <div style="display:flex;gap:6px;flex:none">
          <button class="btn ghost sm" data-tg="refundkeep" style="width:auto;padding:0 10px;height:44px">Keep</button>
          <button class="btn danger sm" data-tg="refundgo" data-id="${esc(p2.id)}" style="width:auto;padding:0 12px">Confirm refund</button>
        </div>`:`<button class="btn ghost sm" data-tg="refund" data-id="${esc(p2.id)}" style="width:auto;padding:0 12px;height:44px">Refund</button>`:""}
      </div>`).join(""):F.payments?"":`<div class="ls" style="padding:10px 0">No payments yet.</div>`}
      ${""}
      ${UI.payMsg?alertMsg({text:UI.payMsg,style:"color:var(--red);padding:6px 0 10px"}):""}
    </section>`:""}
    <div style="height:16px"></div>
    `},mount(root){loadGrow();const pid=practiceId();const $=id=>root.querySelector("#"+id);const msg=(t,err)=>{const m=$("tg-msg");if(m)sayStatus(m,t,{error:!!err})};const connectBtn=$("tg-connect");if(connectBtn)connectBtn.addEventListener("click",async()=>{const cmsg=$("tg-connect-msg");const status=G.connect&&G.connect.status||"none";if(status==="active"){roles.openExternal("https://dashboard.stripe.com/express");return}UI.connecting=true;if(window.__render)window.__render();const r=await roles.startConnectOnboarding(pid);UI.connecting=false;if(r&&r.url){roles.openExternal(r.url);await loadGrow(true)}else{if(cmsg)cmsg.textContent=r&&r.error||"Could not start setup";if(window.__render)window.__render()}});const copyBtn=$("tg-copy");if(copyBtn)copyBtn.addEventListener("click",()=>{const v=$("tg-link")&&$("tg-link").value;if(v){copyText(v).then(ok=>{copyBtn.textContent=ok?"Copied":"Couldn\u2019t copy";setTimeout(()=>copyBtn.textContent="Copy",1400)})}});function pageFields(){return{display_name:($("tg-name")||{}).value||"",specialty:($("tg-spec")||{}).value||"",headline:($("tg-head")||{}).value||"",bio:($("tg-bio")||{}).value||"",cta_label:($("tg-cta")||{}).value||"Apply to work with me"}}const saveBtn=$("tg-save");if(saveBtn)saveBtn.addEventListener("click",async()=>{saveBtn.disabled=true;msg("Saving\u2026");const r=await roles.saveMyTrainerPage(pid,pageFields());saveBtn.disabled=false;if(r.ok){msg("Saved");await loadGrow(true)}else msg(r.error||"Save failed",true)});const pubBtn=$("tg-pub");if(pubBtn)pubBtn.addEventListener("click",async()=>{pubBtn.disabled=true;msg("Saving\u2026");await roles.saveMyTrainerPage(pid,pageFields());const willPublish=!(G.page&&G.page.published);const r=await roles.publishMyTrainerPage(pid,willPublish);pubBtn.disabled=false;if(r.ok){msg(willPublish?"Published":"Unpublished");await loadGrow(true)}else msg(r.error||"Failed",true)});root.querySelectorAll("[data-tg]").forEach(b=>b.addEventListener("click",async()=>{const act=b.getAttribute("data-tg"),id=b.getAttribute("data-id");if(act==="copycode"){const code=b.getAttribute("data-code")||"";if(code&&await copyText(code)){b.textContent="Copied";setTimeout(()=>{b.textContent=code},1400)}return}if(act==="add"){UI.editing="new";if(window.__render)window.__render();return}if(act==="edit"){UI.editing=id;if(window.__render)window.__render();return}if(act==="cancel"){UI.editing=null;if(window.__render)window.__render();return}if(act==="del"){b.disabled=true;await roles.deleteOffer(id);UI.editing=null;await loadGrow(true);return}if(act==="osave"){b.disabled=true;const g=s=>{const e=root.querySelector(".tg-of #"+s);return e?e.value:""};const dollars=g("of-price").trim();const offer={id:id==="new"?void 0:id,practice_id:pid,name:g("of-name").trim()||"Package",blurb:g("of-blurb").trim(),price_cents:dollars===""?null:Math.round(parseFloat(dollars)*100),cadence:g("of-cad")||"month",features:g("of-feat").split("\n").map(s=>s.trim()).filter(Boolean),active:root.querySelector(".tg-of #of-active").checked,sort:(G.offers||[]).length};if(offer.price_cents!=null&&!isFinite(offer.price_cents))offer.price_cents=null;const r=await roles.saveOffer(offer);if(r.ok){UI.editing=null;await loadGrow(true)}else{b.disabled=false}return}if(act==="accept"||act==="decline"){b.disabled=true;b.textContent="\u2026";await roles.setApplicationStatus(id,act==="accept"?"accepted":"declined");await loadGrow(true)}if(act==="refund"){UI.confirmRefund=id;UI.payMsg="";if(window.__render)window.__render();return}if(act==="refundkeep"){UI.confirmRefund=null;if(window.__render)window.__render();return}if(act==="refundgo"){b.disabled=true;b.textContent="\u2026";const r=await roles.refundOfferPayment(id);UI.confirmRefund=null;if(!r||!r.ok){UI.payMsg=r&&r.error||"The refund didn't go through. Nothing was returned; try again.";if(window.__render)window.__render();return}UI.payMsg="";await loadGrow(true)}if(act==="retry"){b.disabled=true;b.textContent="\u2026";await loadGrow(true)}}));const retryBtn=$("tg-retry");if(retryBtn)retryBtn.addEventListener("click",async()=>{retryBtn.disabled=true;if(!G.loaded){if(window.__render)window.__render()}await loadGrow(true)})}};function offerForm(o){o=o||{};const dollars=o.price_cents==null?"":o.price_cents/100;const cad=o.cadence||"month";const opt=(v,l)=>`<option value="${v}" ${cad===v?"selected":""}>${l}</option>`;return`<div class="tg-of">
    <label class="tg-l" for="of-name">Name</label><input id="of-name" maxlength="60" value="${esc(o.name||"")}" placeholder="Light Accountability">
    <label class="tg-l" for="of-blurb">One-line description</label><input id="of-blurb" maxlength="120" value="${esc(o.blurb||"")}" placeholder="Automated analysis + a weekly read on your week.">
    <div class="row2">
      <div style="flex:1"><label class="tg-l" for="of-price">Price ($, blank = contact)</label><input id="of-price" inputmode="decimal" value="${dollars}" placeholder="29"></div>
      <div style="width:130px"><label class="tg-l" for="of-cad">Per</label><select id="of-cad">${opt("month","month")}${opt("week","week")}${opt("one-time","one-time")}${opt("session","session")}</select></div>
    </div>
    <div class="ls" style="margin-top:8px;color:var(--text-3)">${cad==="month"||cad==="week"?"Priced monthly or weekly, so clients can buy this straight from your page, and their OnStandard membership is included at no seat cost to you.":"One-time and per-session packages are apply-only: membership is covered for as long as a package renews, so a one-off has no period to cover."}</div>
    <label class="tg-l" for="of-feat">What's included (one per line)</label><textarea id="of-feat" maxlength="600" placeholder="Weekly check-in&#10;Direct meal feedback">${esc((o.features||[]).join("\n"))}</textarea>
    <label class="tg-l" style="display:flex;align-items:center;gap:8px;margin-top:12px"><input type="checkbox" id="of-active" ${o.active===false?"":"checked"} style="width:auto"> Visible on your page</label>
    <div style="display:flex;gap:8px;margin-top:12px">
      <button class="btn primary sm" data-tg="osave" data-id="${esc(o.id||"new")}" style="width:auto;padding:0 16px">Save offer</button>
      <button class="btn ghost sm" data-tg="cancel" style="width:auto;padding:0 14px;height:44px">Cancel</button>
      ${o.id?`<button class="btn ghost danger sm" data-tg="del" data-id="${esc(o.id)}" style="width:auto;padding:0 12px;margin-left:auto">Delete</button>`:""}
    </div>
  </div>`}function timeAgo(ts){if(!ts)return"";const s=Math.max(0,(Date.now()-new Date(ts).getTime())/1e3);if(s<90)return"just now";if(s<3600)return Math.round(s/60)+"m ago";if(s<86400)return Math.round(s/3600)+"h ago";return Math.round(s/86400)+"d ago"}
