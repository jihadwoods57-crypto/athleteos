import{icon}from"../icons.js";import{DAYS_LONG}from"../fmt-date.js";import{track,EVENTS}from"../analytics.js";import{backHead,esc,errorState}from"../components.js";import{initialsOf}from"../initials.js";import{RT}from"../state.js";import{CD,bookId,loadBook,bookKindFor}from"../coach-data.js";import{allowedCreateKeys,isReadonly}from"../staff-access.js";import{boardCounts,needsAttention,csStatus,fmtValue,unitNoun,metricLabel,sourceRule,toCanonical,toDisplay}from"../connected-standards.js";import{CS,loadBoard,loadOwnerStandards,saveStandard,setStandardActive,reviewManual,staffSetResult,todayISO}from"../connected-standard-data.js";const PILL={green:"g",cyan:"b",blue:"b",purple:"p",amber:"a",red:"r",slate:"muted"};const pillFor=s=>PILL[csStatus(s).tone]||"muted";const hhmm=iso=>{if(!iso)return"";const d=new Date(iso);if(isNaN(d))return"";return d.toLocaleTimeString([],{hour:"numeric",minute:"2-digit"})};const canSet=()=>{if(CD.kind==="practice")return true;const role=CD.extras?CD.extras.myRole:null;if(!CD.extras)return true;return!isReadonly(role)&&allowedCreateKeys(role).includes("standards")};const SEGMENTS=[{key:"complete",cls:"g",dot:"g",label:"met"},{key:"inProgress",cls:"b",dot:"b",label:"still going"},{key:"awaitingReview",cls:"p",dot:"p",label:"waiting on you"},{key:"gap",cls:"a",dot:"a",label:"waiting on a device"},{key:"missed",cls:"r",dot:"r",label:"short"},{key:"excused",cls:"d",dot:"d",label:"excused"}];function segmentCounts(c){return{complete:c.complete,inProgress:c.inProgress,awaitingReview:c.awaitingReview,gap:c.awaitingSync+c.disconnected+c.insufficient,missed:c.missed,excused:c.excused}}function standingBar(c){const s=segmentCounts(c);const total=SEGMENTS.reduce((t,x)=>t+(s[x.key]||0),0);if(!total)return"";return`<div class="co-standing">${SEGMENTS.filter(x=>s[x.key]>0).map(x=>`<div class="seg ${x.cls}" style="flex:${s[x.key]}"></div>`).join("")}</div>`}function standingLegend(c){const s=segmentCounts(c);return`<div class="co-legend">${SEGMENTS.filter(x=>s[x.key]>0).map(x=>`<span class="it"><span class="dot ${x.dot}"></span><b>${s[x.key]}</b> ${esc(x.label)}</span>`).join("")}</div>`}export function standardsBoardCard(){const rows=CS.board;if((!rows||!rows.length)&&CS.boardError){return`<section class="card pad" style="border-color:var(--amber-border);margin-bottom:10px">
      <div class="cs-h">Activity standards didn\u2019t load</div>
      <div class="cs-p" style="padding-top:4px">This isn\u2019t a count of zero. We couldn\u2019t reach the server. Try again in a moment.</div>
    </section>`}if(!rows||!rows.length)return"";return rows.map(inst=>{const c=boardCounts(inst.rows||[]);if(!c.total)return"";const allIn=c.complete===c.total;const waiting=c.awaitingReview;return`
    <section class="card pad cs-board" data-go="coach-standards/${esc(inst.instance_id)}">
      <div class="cs-board-head">
        ${""}
        <span class="cs-eyebrow">${esc(inst.title||"Activity standard")}</span>
        <span class="cs-ask">${esc(`${fmtValue(inst.target,inst.metric,inst.display_unit)} ${unitNoun(inst.metric,inst.display_unit,inst.target)}`)}</span>
      </div>
      <div class="cs-count sm ${allIn?"done":""}">
        <span class="n">${c.complete}</span>
        <span class="u">of ${c.total} ${esc(inst.period==="week"?"this week":"today")}</span>
        <span class="cs-grow"></span>
        ${waiting?`<span class="status-pill p">${waiting} waiting on you</span>`:""}
      </div>
      ${standingBar(c)}
    </section>`}).join("")}export function paintStandardsBoard(root,slotId="#cs-board-slot"){const slot=root.querySelector(slotId);if(!slot)return;const paint=()=>{if(slot.isConnected)slot.innerHTML=standardsBoardCard()};paint();const id=bookId();if(id)loadBoard(CD.kind==="practice"?null:id,CD.kind==="practice"?id:null).then(paint)}function athleteRow(r,inst){const st=csStatus(r.status);const pct=Math.max(0,Math.min(100,Number(r.progress_pct)||0));const why=r.status==="awaiting_sync"?`No data since ${hhmm(r.last_synced_at)||"yesterday"}`:r.status==="disconnected"?"Health access off":r.status==="insufficient_data"?"Never reported":r.status==="awaiting_review"?esc(r.manual_note||"Submitted by hand"):r.status==="completed_manually"?`Reported by the ${CD.noun}`:r.status==="excused"?esc(r.excused_reason||"Excused"):r.status==="verified_complete"?"":`${pct}% of target`;const showBar=r.status==="in_progress"||r.status==="missed";return`<div class="lrow" data-cs-row="${esc(r.result_id)}">
    <div class="lic cs-ini"${r.athlete_id?` data-avatar-uid="${esc(r.athlete_id)}"`:""}><span data-avatar-fallback>${esc(initials(r.name))}</span></div>
    <div class="lm">
      <div class="lt">${esc(r.name||"Athlete")}</div>
      ${why||r.disputed_at?`<div class="ls">${why}${r.disputed_at?`${why?" \xB7 ":""}disputed`:""}</div>`:""}
      ${showBar?`<div class="cs-mini"><i style="width:${pct}%"></i></div>`:""}
    </div>
    <span class="status-pill ${pillFor(r.status)}">${esc(st.label)}</span>
  </div>`}const initials=name=>initialsOf(name,"?");let BOARD_SIG=null;export const ensureBook=()=>{if(bookId())return true;loadBook(false,bookKindFor(RT.authRole));return false};const bookWord=()=>bookKindFor(RT.authRole)==="practice"?"practice":"team";export const bookBack=()=>bookKindFor(RT.authRole)==="practice"?"trainer":"coach-home";export const bookless=(title,back)=>{const offline=CD.roster&&CD.roster.offline;return`${backHead(title,offline?"Can't reach your "+bookWord():"Loading\u2026",back)}
  ${offline?`<div class="state-demo"><div class="sd-ic">${icon("wifiOff",24)}</div>
    <div class="sd-t">Can't reach your ${esc(bookWord())}</div>
    <div class="sd-s">Check your connection and try again. Nothing is lost.</div>
    <div class="sd-cta"><button class="btn primary sm" id="book-retry">Try again</button></div></div>`:CD.roster?`<div class="state-demo"><div class="sd-ic">${icon("clipboard",24)}</div>
    <div class="sd-t">No ${esc(bookWord())} yet</div>
    <div class="sd-s">Standards live on your ${esc(bookWord())}. Set one up first and the board opens here.</div></div>`:`<section class="card pad"><div class="cs-p">Loading\u2026</div></section>`}`};export const wireBookRetry=root=>{const rt=root.querySelector("#book-retry");if(rt)rt.addEventListener("click",()=>{rt.disabled=true;loadBook(true,bookKindFor(RT.authRole))})};export const coachStandards={nav:"operator",render({sub}){const back=bookBack();const inst=(CS.board||[]).find(b=>b.instance_id===sub)||(CS.board||[])[0];if(!inst){if(!bookId())return bookless("Activity standard",back);if(CS.boardError){return`${backHead("Activity standard","Can't reach the board",back)}
        ${errorState({title:"Can't reach the board",body:"Nothing is lost. Check your connection and try again.",retryId:"cs-board-retry"})}`}if(CS.boardAt){return`${backHead("Activity standard","Nothing scheduled today",back)}
        <div class="state-demo"><div class="sd-ic">${icon("clipboard",24)}</div>
        <div class="sd-t">No activity standard today</div>
        <div class="sd-s">When a standard is scheduled, everyone's verified results land here in real time.</div>
        <div class="sd-cta" style="margin-top:16px"><button class="btn primary sm" data-go="coach-standards-manage">${icon("clipboard",16)} Manage standards</button></div></div>`}return`${backHead("Activity standard","Loading\u2026",back)}
      <section class="card pad"><div class="cs-p">Loading the board\u2026</div></section>`}const rows=inst.rows||[];const c=boardCounts(rows);const review=rows.filter(r=>r.status==="awaiting_review");const disputed=rows.filter(r=>r.disputed_at&&r.status!=="awaiting_review");const gaps=needsAttention(rows).filter(r=>r.status!=="awaiting_review"&&!r.disputed_at);const flagged=new Set([...review,...disputed,...gaps]);const rest=rows.filter(r=>!flagged.has(r));return`${backHead(inst.title||"Activity standard",[inst.audience_label||(CD.kind==="practice"?"All clients":"Entire team"),`${fmtValue(inst.target,inst.metric,inst.display_unit)} ${unitNoun(inst.metric,inst.display_unit,inst.target)}`].join(" \xB7 "),back)}

    <section class="card pad">
      <div class="cs-count ${c.complete===c.total?"done":""}">
        <span class="n">${c.complete}</span>
        <span class="u">of ${c.total} complete</span>
      </div>
      ${standingBar(c)}
      ${standingLegend(c)}
      ${inst.deadline_at?`<div class="cs-p muted" style="margin-top:12px">Due by ${esc(hhmm(inst.deadline_at))}</div>`:""}
    </section>

    ${!review.length&&!disputed.length&&!gaps.length?`
    <section class="card pad">
      <div class="cs-clear">
        <div class="ic">${icon("check",19)}</div>
        <div>
          <div class="cs-h">Nothing waiting on you</div>
          <div class="cs-p">Every ${CD.noun} either met this or has a reason on file.</div>
        </div>
      </div>
    </section>`:""}

    ${review.length?`
    <h2 class="eyebrow">Waiting on you \xB7 ${review.length}</h2>
    <section class="card" style="padding:2px 16px">${review.map(r=>`
      ${athleteRow(r,inst)}
      <div style="display:flex;gap:8px;padding:0 0 12px">
        <button class="btn primary sm" data-cs-ok="${esc(r.result_id)}" style="flex:1">Approve</button>
        <button class="btn ghost sm" data-cs-no="${esc(r.result_id)}" style="flex:1">Not this time</button>
      </div>`).join("")}
    </section>`:""}

    ${disputed.length?`
    <h2 class="eyebrow">Disputed \xB7 ${disputed.length}</h2>
    <section class="card" style="padding:2px 16px">${disputed.map(r=>`
      ${athleteRow(r,inst)}
      ${r.dispute_note?`<div class="cs-p" style="padding:0 0 10px">\u201C${esc(r.dispute_note)}\u201D</div>`:""}`).join("")}
    </section>
    <div class="cs-p" style="padding:8px 20px 0">Nothing changed on its own. The record still reads as it did. Correcting it is yours to do, and your name goes on it.</div>`:""}

    ${gaps.length?`
    <h2 class="eyebrow">Couldn\u2019t be verified \xB7 ${gaps.length}</h2>
    <section class="card" style="padding:2px 16px">${gaps.map(r=>athleteRow(r,inst)).join("")}</section>
    <div class="sidebox" style="margin-top:12px">
      <div class="req-icon b s38">${icon("shield",19)}</div>
      <div><div class="cs-h">These are device problems, not misses</div>
      <div class="cs-p">A phone that never reported produces no evidence either way, so these leave the completion rate entirely rather than counting against the athlete. Mark one missed only if you know the work wasn\u2019t done.</div></div>
    </div>`:""}

    ${rest.length?`
    <h2 class="eyebrow">Roster</h2>
    <section class="card" style="padding:2px 16px">${rest.map(r=>athleteRow(r,inst)).join("")}</section>`:""}

    <div class="cs-p" style="text-align:center;padding:14px 20px 24px">
      You see progress toward the target you set. Never anyone\u2019s raw health data.
    </div>`},mount(root,{sub}){if(!ensureBook()&&!(CS.board||[]).length){wireBookRetry(root);return}const id=bookId();if(id)loadBoard(CD.kind==="practice"?null:id,CD.kind==="practice"?id:null,todayISO()).then(rows=>{const sig=JSON.stringify((rows||[]).map(b=>[b.instance_id,(b.rows||[]).map(r=>`${r.result_id}:${r.status}:${r.progress_pct}`)]));if(sig===BOARD_SIG)return;BOARD_SIG=sig;if(root.isConnected&&window.__render)window.__render()});const boardRetry=root.querySelector("#cs-board-retry");if(boardRetry)boardRetry.addEventListener("click",async()=>{boardRetry.disabled=true;const bid=bookId();if(bid)await loadBoard(CD.kind==="practice"?null:bid,CD.kind==="practice"?bid:null,todayISO(),true);if(window.__render)window.__render()});const act=(attr,fn,busy)=>root.querySelectorAll(`[${attr}]`).forEach(el=>el.addEventListener("click",async()=>{if(el.disabled)return;const label=el.textContent;el.disabled=true;el.textContent=busy;const r=await fn(el.getAttribute(attr));if(!r||!r.ok){el.disabled=false;el.textContent=label;const wrap=el.parentElement;if(wrap&&!(wrap.nextElementSibling&&wrap.nextElementSibling.classList&&wrap.nextElementSibling.classList.contains("cs-act-err"))){wrap.insertAdjacentHTML("afterend",`<div class="cs-act-err" style="color:var(--red);font-size:var(--t-xs);font-weight:700;padding:0 0 10px">Couldn't save that ruling. Try again.</div>`)}return}const bid=bookId();if(bid)await loadBoard(CD.kind==="practice"?null:bid,CD.kind==="practice"?bid:null,todayISO(),true);if(window.__render)window.__render()}));act("data-cs-ok",rid=>reviewManual(rid,true).then(r=>{if(r.ok)track(EVENTS.CS_REVIEWED,{approve:true});return r}),"Approving\u2026");act("data-cs-no",rid=>reviewManual(rid,false).then(r=>{if(r.ok)track(EVENTS.CS_REVIEWED,{approve:false});return r}),"Saving\u2026")}};const METRICS=[{key:"steps",label:"Steps",unit:"steps",preset:1e4},{key:"distance",label:"Distance",unit:"mi",preset:2.5},{key:"workouts",label:"Workouts",unit:"workouts",preset:3},{key:"workout_minutes",label:"Workout minutes",unit:"min",preset:150},{key:"active_minutes",label:"Active minutes",unit:"min",preset:30}];const DOW=["S","M","T","W","T","F","S"];const DOW_FULL=DAYS_LONG;const DEADLINES=[{min:null,label:"End of day"},{min:1020,label:"5:00 PM"},{min:1140,label:"7:00 PM"},{min:1260,label:"9:00 PM"}];const sw=(key,on,title,sub)=>`
  <div class="std-switch-row cs-sw-row" role="switch" tabindex="0"
       aria-checked="${on?"true":"false"}" data-cs-toggle="${esc(key)}">
    <div class="std-sw-m">
      <div class="std-sw-t">${esc(title)}</div>
      ${sub?`<div class="std-sw-s">${esc(sub)}</div>`:""}
    </div>
    <div class="std-switch ${on?"on":""}" aria-hidden="true"></div>
  </div>`;const chip=(attr,on,label,multi,name)=>`
  <span class="${on?"on":""}" role="${multi?"checkbox":"radio"}" tabindex="0"
        aria-checked="${on?"true":"false"}"${name?` aria-label="${esc(name)}"`:""} ${attr}>${esc(label)}</span>`;let DRAFT=null;const blank=()=>({id:null,metric:"steps",display_unit:"steps",target:1e4,period:"day",repeat_days:[1,2,3,4,5],deadline_min:null,deliberate_workout:false,workout_min_duration_min:null,title:"",allow_manual:true,manual_requires_approval:false,audience_kind:"team",audience_value:null});export const coachStandardEdit={nav:"operator",render({sub}){const back="coach-standards-manage";if(!canSet()){return`${backHead("Activity standard","View only",back)}
      <section class="card pad"><div class="cs-h">You can see these, not set them</div>
      <div class="cs-p" style="padding-top:4px">Your role can view the board. Ask a head coach to set or change a standard.</div></section>`}if(!DRAFT||sub&&DRAFT.id!==sub){const def=sub?(CS.defs||[]).find(d2=>d2.id===sub):null;DRAFT=def?{id:def.id,metric:def.metric,display_unit:def.display_unit,target:toDisplay(def.target_value,def.metric,def.display_unit),period:def.period,repeat_days:def.repeat_days||[1,2,3,4,5],deadline_min:def.deadline_min,deliberate_workout:!!def.deliberate_workout,workout_min_duration_min:def.workout_min_duration_min,title:def.title||"",allow_manual:def.allow_manual!==false,manual_requires_approval:!!def.manual_requires_approval,audience_kind:def.audience_kind||"team",audience_value:def.audience_value||null}:blank()}const d=DRAFT;const preview={metric:d.metric,display_unit:d.display_unit,target:toCanonical(d.target,d.metric,d.display_unit),progress:0};return`${backHead(d.id?"Edit standard":"New activity standard",CD.kind==="practice"?"For your clients":"For your team",back)}

    <section class="card pad">
      <div class="cs-knob">
        <div class="cs-knob-label" id="cs-lb-metric">WHAT YOU\u2019RE ASKING FOR</div>
        <div class="cs-seg" role="radiogroup" aria-labelledby="cs-lb-metric">${METRICS.map(m=>chip(`data-cs-metric="${esc(m.key)}"`,m.key===d.metric,m.label)).join("")}
        </div>
      </div>

      ${d.metric==="distance"?`<div class="cs-knob">
        <div class="cs-knob-label" id="cs-lb-counts">WHAT COUNTS</div>
        <div class="cs-seg" role="radiogroup" aria-labelledby="cs-lb-counts">
          ${chip('data-cs-delib="0"',!d.deliberate_workout,"Any walking or running")}
          ${chip('data-cs-delib="1"',!!d.deliberate_workout,"A recorded workout")}
        </div>
        <div class="cs-p muted" style="margin-top:8px">${esc(sourceRule(d.metric,d.deliberate_workout,d.workout_min_duration_min))}</div>
      </div>`:""}

      <div class="cs-knob">
        <label class="cs-knob-label" for="cs-target">TARGET</label>
        <input class="input" id="cs-target" type="number" inputmode="decimal" min="1" value="${esc(String(d.target))}">
        <div class="cs-p muted" style="margin-top:6px">${esc(unitNoun(d.metric,d.display_unit,2))} per ${d.period==="week"?"week":"day"}</div>
      </div>

      <div class="cs-knob">
        <div class="cs-knob-label" id="cs-lb-often">HOW OFTEN</div>
        <div class="cs-seg" role="radiogroup" aria-labelledby="cs-lb-often">
          ${chip('data-cs-period="day"',d.period==="day","Every day")}
          ${chip('data-cs-period="week"',d.period==="week","Across the week")}
        </div>
      </div>

      ${d.period==="day"?`
      <div class="cs-knob">
        <div class="cs-knob-label" id="cs-lb-days">WHICH DAYS</div>
        ${""}
        <div class="cs-seg" role="group" aria-labelledby="cs-lb-days">${DOW.map((lab,i)=>chip(`data-cs-dow="${i}"`,d.repeat_days.includes(i),lab,true,DOW_FULL[i])).join("")}
        </div>
      </div>
      <div class="cs-knob">
        <div class="cs-knob-label" id="cs-lb-due">DUE BY</div>
        <div class="cs-seg" role="radiogroup" aria-labelledby="cs-lb-due">${DEADLINES.map(x=>chip(`data-cs-due="${x.min===null?"":x.min}"`,d.deadline_min===x.min,x.label)).join("")}
        </div>
      </div>`:""}

      <div class="cs-knob">
        <div class="cs-knob-label">IF THE WATCH FAILS</div>
        ${sw("allow_manual",d.allow_manual,"Allow manual backup",d.allow_manual?"An athlete whose device fails can log it by hand. It shows as reported rather than verified.":"Only device data will count. An athlete with a dead battery has no way to complete this.")}
        ${d.allow_manual?sw("manual_requires_approval",d.manual_requires_approval,"Manual entries need my approval","They wait in your review queue instead of counting straight away."):""}
      </div>

      <div class="cs-knob">
        <label class="cs-knob-label" for="cs-title">NAME IT</label>
        <input class="input" id="cs-title" maxlength="60" value="${esc(d.title)}" placeholder="${esc(defaultTitle(d))}">
      </div>
    </section>

    <h2 class="eyebrow">Athletes will see</h2>
    <section class="card cs-card">
      <div class="cs-row" style="padding-top:0">
        <div class="cs-top">
          <span class="cs-title">${esc((d.title||"").trim()||defaultTitle(d))}</span>
          <span class="status-pill b">In progress</span>
        </div>
        <div class="cs-bar"><i style="transform:scaleX(0)"></i></div>
        <div class="cs-nums"><span class="cs-prog">0 of ${esc(fmtValue(preview.target,d.metric,d.display_unit))} ${esc(unitNoun(d.metric,d.display_unit,preview.target))}</span></div>
        <div class="cs-meta">${esc(metricLabel(d.metric,d.deliberate_workout))} \xB7 Tracked, not scored</div>
      </div>
    </section>

    <div style="padding:12px 20px 0">
      <button class="btn" id="cs-save">${d.id?"Save changes":"Set this standard"}</button>
      ${d.id?`<button class="btn ghost" id="cs-off" style="margin-top:8px">Turn this off</button>`:""}
    </div>
    <div style="height:24px"></div>`},mount(root){ensureBook();const set=patch=>{DRAFT={...DRAFT,...patch};if(window.__render)window.__render()};root.querySelectorAll("[data-cs-metric]").forEach(el=>el.addEventListener("click",()=>{const m=METRICS.find(x=>x.key===el.getAttribute("data-cs-metric"))||METRICS[0];set({metric:m.key,display_unit:m.unit,target:m.preset,deliberate_workout:false})}));root.querySelectorAll("[data-cs-delib]").forEach(el=>el.addEventListener("click",()=>set({deliberate_workout:el.getAttribute("data-cs-delib")==="1"})));root.querySelectorAll("[data-cs-period]").forEach(el=>el.addEventListener("click",()=>set({period:el.getAttribute("data-cs-period")})));root.querySelectorAll("[data-cs-due]").forEach(el=>el.addEventListener("click",()=>{const raw=el.getAttribute("data-cs-due");set({deadline_min:raw===""?null:Number(raw)})}));root.querySelectorAll("[data-cs-dow]").forEach(el=>el.addEventListener("click",()=>{const i=Number(el.getAttribute("data-cs-dow"));const days=DRAFT.repeat_days.includes(i)?DRAFT.repeat_days.filter(x=>x!==i):[...DRAFT.repeat_days,i].sort();set({repeat_days:days.length?days:DRAFT.repeat_days})}));root.querySelectorAll("[data-cs-toggle]").forEach(el=>{const flip=()=>set({[el.getAttribute("data-cs-toggle")]:!DRAFT[el.getAttribute("data-cs-toggle")]});el.addEventListener("click",flip);el.addEventListener("keydown",ev=>{if(ev.key===" "||ev.key==="Enter"){ev.preventDefault();flip()}})});const target=root.querySelector("#cs-target");if(target)target.addEventListener("input",()=>{DRAFT.target=Number(target.value)||0});const title=root.querySelector("#cs-title");if(title)title.addEventListener("input",()=>{DRAFT.title=title.value});const save=root.querySelector("#cs-save");if(save)save.addEventListener("click",async()=>{if(save.disabled)return;const d=DRAFT;if(!(Number(d.target)>0)){save.textContent="Enter a target first";return}save.disabled=true;save.textContent="Saving\u2026";const id=bookId();if(!id){loadBook(true,bookKindFor(RT.authRole));save.disabled=false;save.textContent="Couldn\u2019t save. Try again";return}const res=await saveStandard({id:d.id||void 0,team_id:CD.kind==="practice"?void 0:id,practice_id:CD.kind==="practice"?id:void 0,title:(d.title||"").trim()||defaultTitle(d),metric:d.metric,display_unit:d.display_unit,target_value:toCanonical(d.target,d.metric,d.display_unit),deliberate_workout:!!d.deliberate_workout,workout_min_duration_min:d.workout_min_duration_min||void 0,period:d.period,repeat_days:d.period==="day"?d.repeat_days:[0,1,2,3,4,5,6],deadline_min:d.deadline_min==null?void 0:d.deadline_min,audience_kind:d.audience_kind,audience_value:d.audience_value||void 0,allow_manual:!!d.allow_manual,manual_requires_approval:!!d.manual_requires_approval});if(res.ok){track(EVENTS.CS_SET,{metric:d.metric,period:d.period,audience:d.audience_kind});DRAFT=null;location.hash="#coach-standards-manage"}else{save.disabled=false;save.textContent="Couldn\u2019t save. Try again"}});const off=root.querySelector("#cs-off");if(off){let armed=false;off.addEventListener("click",async()=>{if(off.disabled)return;if(!armed){armed=true;off.textContent="Turn off this standard?";return}off.disabled=true;off.textContent="Turning off\u2026";const r=await setStandardActive(DRAFT.id,false);if(!r||!r.ok){off.disabled=false;armed=false;off.textContent="Couldn\u2019t turn it off. Try again";return}DRAFT=null;location.hash="#coach-standards-manage"})}}};let MANAGE={rows:[],loaded:false,error:false};export const coachStandardsManage={nav:"operator",render(){const back=bookBack();if(!bookId()&&!MANAGE.rows.length)return bookless("Activity standards",back);const rows=MANAGE.rows.filter(r=>r.active);return`${backHead("Activity standards","Verified from athlete devices",back)}
    ${MANAGE.error&&!rows.length?errorState({title:"Couldn't load your standards",body:"They are safe. Reconnect and they load right here.",retryId:"cs-manage-retry"}):rows.length?`<section class="card" style="padding:2px 16px">${rows.map(r=>`
      <div class="lrow" data-go="coach-standard-edit/${esc(r.id)}">
        <div class="lic" style="color:var(--blue-bright)">${icon("bolt",18)}</div>
        <div class="lm">
          <div class="lt">${esc(r.title)}</div>
          <div class="ls">${esc(`${fmtValue(r.target_value,r.metric,r.display_unit)} ${unitNoun(r.metric,r.display_unit,r.target_value)} \xB7 ${r.period==="week"?"per week":"per day"}`)}</div>
        </div>
        ${icon("chevron",17,'style="color:var(--text-3)"')}
      </div>`).join("")}</section>`:MANAGE.loaded?`<section class="card pad">
        <div class="cs-h">No activity standards yet</div>
        <div class="cs-p" style="padding-top:4px">Set one and it verifies itself from your athletes\u2019 phones and watches. No screenshots, no check-ins.</div>
      </section>`:`<section class="card pad"><div class="cs-p">Loading your standards\u2026</div></section>`}
    ${canSet()?`<div style="padding:12px 20px">
      <button class="btn" data-go="coach-standard-edit">Set a standard</button>
    </div>`:""}
    <div style="height:20px"></div>`},mount(root){if(!ensureBook()&&!MANAGE.rows.length){wireBookRetry(root);return}const id=bookId();if(id)loadOwnerStandards(CD.kind==="practice"?null:id,CD.kind==="practice"?id:null).then(rows=>{if(rows===null){if(!MANAGE.error){MANAGE.error=true;if(root.isConnected&&window.__render)window.__render()}return}const sig=rows.map(r=>`${r.id}:${r.active}`).join("|");const was=MANAGE.rows.map(r=>`${r.id}:${r.active}`).join("|");const cleared=MANAGE.error||!MANAGE.loaded;MANAGE.rows=rows;MANAGE.error=false;MANAGE.loaded=true;if((sig!==was||cleared)&&root.isConnected&&window.__render)window.__render()});const retry=root.querySelector("#cs-manage-retry");if(retry)retry.addEventListener("click",()=>{window.__render&&window.__render()})}};function defaultTitle(d){if(d.metric==="steps")return d.period==="week"?"Weekly Steps":"Daily Movement";if(d.metric==="distance")return d.period==="week"?"Weekly Distance":"Daily Distance";if(d.metric==="workouts")return d.period==="week"?"Weekly Workouts":"Daily Workout";return d.period==="week"?"Weekly Activity":"Daily Activity"}
