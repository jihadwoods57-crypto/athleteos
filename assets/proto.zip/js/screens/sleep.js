import{backHead,esc,skeletonRows}from"../components.js";import{icon}from"../icons.js";import{DAY}from"../day.js";import{HK,probeHealth}from"./apple-health.js";import{buildNights,baselineOf,baselineState,nightsUntilBaseline,deltaFrom,fmtDuration,qualityWord,sleepState}from"../sleep.js";const DAYS_SHOWN=14;function recentDates(n){const out=[];for(let i=0;i<n;i++){const d=new Date;d.setHours(12,0,0,0);d.setDate(d.getDate()-i);out.push(d.toISOString().slice(0,10))}return out}function whenLabel(dateStr,index){if(index===0)return"Last night";const d=new Date(`${dateStr}T12:00:00`);if(Number.isNaN(d.getTime()))return dateStr;return d.toLocaleDateString(void 0,{weekday:"long"})}function qualityByDate(){const out={};for(const row of DAY.scoreHistory||[]){const v=row&&row.checkin&&row.checkin.sleep;if(row&&row.date&&v!=null)out[row.date]=v}if(DAY.ciSubmitted&&DAY.ci&&DAY.ci.sleep!=null)out[DAY.date]=DAY.ci.sleep;return out}function measuredByDate(){const out={};for(const row of DAY.scoreHistory||[]){const h=row&&row.sleepHours;if(row&&row.date&&typeof h==="number"&&Number.isFinite(h)&&h>0)out[row.date]=h}const hrs=HK.recovery&&HK.recovery.sleepHours;if(typeof hrs==="number"&&Number.isFinite(hrs)&&hrs>0)out[DAY.date]=hrs;return out}function avgBlock(nights,screenState){if(screenState==="no-device"||screenState==="no-data")return"";const base=baselineOf(nights);const state=baselineState(nights);if(state==="none"){const left=nightsUntilBaseline(nights);return`
    <div class="sl-avg learning">
      <div class="sl-avg-k">Your average</div>
      <div class="sl-avg-wait">Still learning your normal</div>
      <div class="sl-avg-s">${left===1?"One more measured night":`${left} more measured nights`}. An average of a couple of nights is just those nights.</div>
    </div>`}return`
    <div class="sl-avg">
      <div class="sl-avg-k">Your average</div>
      <div class="sl-avg-v">${esc(fmtDuration(base))}</div>
      <div class="sl-avg-s">${state==="provisional"?"Provisional, from your first measured nights. It will settle.":"Your own normal, from your measured nights. Never anybody else\u2019s."}</div>
    </div>`}function nightRow(n,index,base,markGaps){const said=qualityWord(n.quality);const delta=deltaFrom(n.hours,base);const dur=n.measured?`<div class="sl-dur">${esc(fmtDuration(n.hours))}</div>`:markGaps?'<div class="sl-dur none">No reading</div>':"";return`
    <div class="sl-night" role="listitem">
      <div class="sl-l">
        <div class="sl-when">${esc(whenLabel(n.date,index))}</div>
        ${said?`<div class="sl-said">You said ${esc(said)}</div>`:'<div class="sl-said none">No check-in</div>'}
      </div>
      <div class="sl-r">
        ${dur}
        ${delta?`<div class="sl-delta ${delta.dir}">${esc(delta.text)}</div>`:""}
      </div>
    </div>`}function leadFor(state){if(state==="no-device"){return`<div class="sl-lead">
      <div class="sl-lead-ic">${icon("moon",18)}</div>
      <div><div class="sl-lead-t">Your own read is the record</div>
      <div class="sl-lead-s">No wearable is sharing sleep with OnStandard, so this is what you told the check-in. Connect a ring or a watch and the hours land beside it.</div></div>
    </div>`}if(state==="no-data"){return`<div class="sl-lead">
      <div class="sl-lead-ic">${icon("alert",18)}</div>
      <div><div class="sl-lead-t">Connected, nothing shared yet</div>
      <div class="sl-lead-s">Apple never tells an app which categories you allowed. Turn Sleep on for OnStandard in the Health app, then check again.</div>
      <button class="btn ghost sm sl-lead-act" data-go="apple-health">Open Apple Health settings</button></div>
    </div>`}return""}export default{tab:"profile",hideTabs:true,render(){const head=backHead("Sleep","What you got, and what you said","profile");if(!HK.probed)return`${head}${skeletonRows(4,"Checking sleep")}`;const dates=recentDates(DAYS_SHOWN);const nights=buildNights(dates,measuredByDate(),qualityByDate());const state=sleepState({available:HK.available!==false,nights});const base=baselineOf(nights);if(!nights.length){return`${head}
      <div class="sl-lead">
        <div class="sl-lead-ic">${icon("moon",18)}</div>
        <div><div class="sl-lead-t">Nothing to show yet</div>
        <div class="sl-lead-s">Your nightly check-in asks how you slept. Answer it tonight and this becomes a record.</div></div>
      </div>`}return`${head}
    ${leadFor(state)}
    ${avgBlock(nights,state)}
    <h2 class="eyebrow">Last ${DAYS_SHOWN} nights</h2>
    <section class="card rows sl-list" role="list">
      ${nights.map(n=>nightRow(n,dates.indexOf(n.date),base,state==="reading")).join("")}
    </section>
    <div class="sl-foot">Sleep is not scored. Your Recovery points come from answering the check-in, and hours are here so the answer has something to sit against.</div>`},async mount(root){if(!HK.probed){await probeHealth();if(root.isConnected&&window.__render)window.__render()}}};
