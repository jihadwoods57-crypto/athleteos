import{S,RT,tier}from"../state.js";import{FILTERED_NOTE}from"../content-filter.js";import{DAY,MEAL_KEYS}from"../day.js";import{icon}from"../icons.js";import{backHead,esc,safeImg,emptyState,errorState,skeletonRows,segBar}from"../components.js";import{tierColor,ON_STANDARD,qualityAccent}from"../score-band.js";import{cachedMealPhoto,warmMealPhotos,resolveMealPhoto}from"../photo-store.js";import{shortDate,weekdayLong}from"../fmt-date.js";import{fetchRecentMeals,daysAgoISO,fetchMealComments,postMealComment,deleteMealComment,uploadChatPhoto,fetchThreadParticipants,signedMealPhotoUrl,signedMealPhotoUrls,notifyMyCoach}from"../roles.js";import{attachedPhoto,isPhotoOnly,bubblePhotoHtml,hydrateThreadPhotos,wireComposerAttach,postChatMessage}from"../chat-attach.js";import{threadMessages,reactionGroups,REACTION_EMOJI,normalizeDetected}from"../meal-intel.js";import{wireTapback}from"../tapback.js";import{mealReadHtml,wireReadControls}from"./meal.js";import{layoutThread,MUTED_HIDDEN_NOTE,authorName,initialsFor,isAnalysisUpdate,isEscalated,quotedFor,dayLabelOf,participantList,participantSummary,msgRowClass,timeSepHtml,deliveredHtml,msgTimeHtml,richText,isCorrectionReceipt,receiptCardHtml,reactionAnchor,replyQuote,replyQuoteHtml,replyTargetMeta,personText,visibleThread,workingLabel}from"../chat-view.js";import{wireChatTimes}from"../chat-times.js";import{beginSend,endSend,takeFailed,setAiWorking,setReply,replyOf,clearReply,paintReplyChip,noteArrivals,syncLive,syncJump,bindLive,wireThreadTaps}from"../chat-live.js";import{openMembersSheet}from"../members-sheet.js";import{decideAiTurn}from"../ai-thread.js";import{hydrateAvatars}from"../avatar.js";const mvClock=iso=>{if(!iso)return"";const d=new Date(iso);if(isNaN(d.getTime()))return"";let h=d.getHours();const mm=String(d.getMinutes()).padStart(2,"0");const ap=h>=12?"PM":"AM";h=h%12||12;return`${h}:${mm} ${ap}`};const mvDay=ms=>{const d=new Date(ms);return`${d.getFullYear()}-${d.getMonth()}-${d.getDate()}`};import{composer}from"../components.js";import{openImageViewer}from"../image-viewer.js";import{focusComposer,scrollThreadToEnd}from"../keyboard.js";export const trust={tab:"home",render(){const t=S.pass;const coachNote=t.note?`<section class="card pad tp-quote"><div class="q">\u201C${esc(t.note)}\u201D</div><div class="by">From your coach</div></section>`:"";if(!t.active){const need=(RT.passPolicy||{eligibility_days:7}).eligibility_days;const have=Math.min(need,t.eligible||0);const earned=have>=need;return`${backHead("Trust Pass",earned?"Earned, waiting on your coach":"Camera-free meals, earned with photos")}
      <section class="rfig">
        <div class="rfig-n">${have}<span class="rfig-u">of ${need} photo-logged days</span></div>
        ${segBar(have,need,`${have} of ${need} photo-logged days`)}
        <div class="rfig-s">${earned?"You have the days. Your coach can grant a pass any time from your profile.":"Show the pattern with photos first. Then your coach can give you camera-free meals, credited from your real history."}</div>
      </section>`}if(t.kind==="credits"){return`
      ${backHead("Trust Pass","Camera-free meals from your coach")}
      <section class="rfig">
        <div class="rfig-n">${icon("shield",22)}${t.left}<span class="rfig-u">of ${t.total} left</span></div>
        <div class="rfig-s">Spend one on any meal from the hub. Expires ${esc(t.expires)}.</div>
      </section>
      ${coachNote}

      <h2 class="eyebrow">How it scores</h2>
      <section class="card" style="padding:6px 16px">
        <div class="lrow" style="cursor:default">
          <div class="lic" style="background:var(--blue-surface);color:var(--blue-bright)">${icon("bars",17)}</div>
          <div class="lm"><div class="lt">Your trailing-10 median</div><div class="ls">Credit comes from your recent photo-earned days for that slot, up to the last 10. One hero plate can't inflate it, and a covered day never counts toward the median itself.</div></div>
        </div>
      </section>

      <h2 class="eyebrow">Change your mind</h2>
      <section class="card" style="padding:6px 16px">
        <div class="lrow" style="cursor:default">
          <div class="lic" style="background:var(--green-surface);color:var(--green-bright)">${icon("check",17)}</div>
          <div class="lm"><div class="lt">Log it anyway</div><div class="ls">Take the photo and the pass comes straight back. Nothing is lost by logging.</div></div>
        </div>
      </section>
      <div style="height:10px"></div>
      `}return`
    ${backHead("Trust Pass","Every meal is covered")}
    <section class="rfig">
      <div class="rfig-n">${icon("shield",22)}Day ${t.day}<span class="rfig-u">of ${t.length}</span></div>
      <div class="rfig-s">Nothing to tap. Your score keeps moving from your real logging history through ${esc(t.covers_until)}.</div>
    </section>
    ${coachNote}

    <h2 class="eyebrow">How it scores</h2>
    <section class="card" style="padding:6px 16px">
      <div class="lrow" style="cursor:default">
        <div class="lic" style="background:var(--blue-surface);color:var(--blue-bright)">${icon("bars",17)}</div>
        <div class="lm"><div class="lt">Your trailing-10 median</div><div class="ls">Each meal credits your recent photo-earned days for that slot, up to the last 10. One hero plate can't inflate it, and a covered day never counts toward the median itself.</div></div>
      </div>
    </section>
    <div style="height:10px"></div>
    `}};export const streak={tab:"progress",render(){const cal=S.streakCalendar;const graceAvailable=S.streak.graceUsedRecently?0:1;return`
    ${backHead("Streak","Your run of days at 80 or better","progress")}

    ${""}
    <section class="rfig">
      <div class="rfig-n">${icon("flame",22)}${S.streakDays}<span class="rfig-u">day${S.streakDays===1?"":"s"}</span></div>
      ${S.score>=ON_STANDARD?`<div class="rfig-s g">Today is above the bar.${S.streakDays>0?" It locks at midnight.":" Your streak starts when today locks at midnight."}</div>`:'<div class="rfig-s a">Today is still live. Reach 80 before the day closes to keep the run.</div>'}
      <div class="rfig-k">Weekly grace available: ${graceAvailable}${graceAvailable?"":` \xB7 used ${S.streak.label.replace("grace used ","")}`}</div>
    </section>

    <h2 class="eyebrow">This week</h2>
    <section class="card pad">
      <div class="stk-week">
        ${cal.map(x=>`
          <div class="stk-day ${x.on?"on":x.future?"future":x.today?"":"miss"}${x.today?" today":""}">
            <span class="d">${x.label}</span>
            <span class="s">${x.score!=null?x.score:"\u2014"}</span>
            ${x.grace?'<span class="g">Grace</span>':""}
          </div>`).join("")}
      </div>
      ${""}
      <div class="rfig-s">Your real day scores, Monday through Sunday.</div>
    </section>

    <h2 class="eyebrow">The rules</h2>
    <section class="card" style="padding:6px 16px" role="list">
      <div class="lrow" role="listitem" style="cursor:default">
        <div class="lic" style="background:var(--green-surface);color:var(--green-bright)">${icon("target",17)}</div>
        <div class="lm"><div class="lt">80 is the bar</div><div class="ls">A streak day is 80 or better. Not close, not almost.</div></div>
      </div>
      <div class="lrow" role="listitem" style="cursor:default">
        <div class="lic" style="background:var(--blue-surface);color:var(--blue-bright)">${icon("shield",17)}</div>
        <div class="lm"><div class="lt">One grace per rolling 7 days</div><div class="ls">A single miss is bridged after the day closes: the chain survives, the day never counts. A second miss inside the week ends the run.</div></div>
      </div>
      <div class="lrow" role="listitem" style="cursor:default">
        <div class="lic" style="background:var(--surface-2);color:var(--text-2)">${icon("clock",17)}</div>
        <div class="lm"><div class="lt">Absent days count as misses</div><div class="ls">Not opening the app isn't a loophole. The calendar is the judge.</div></div>
      </div>
    </section>
    <div style="height:10px"></div>
    `}};let HIST={rows:null,at:0,uid:null,failed:false};export function histMealById(id){return(HIST.rows||[]).find(m=>String(m.id)===String(id))||null}function pastDayTotalsThrough(m){if(!m||!m.logged_at||!m.day_date||!HIST.rows)return null;const cut=new Date(m.logged_at).getTime();if(isNaN(cut))return null;let protein=m.protein||0,kcal=m.kcal||0;for(const r of HIST.rows){if(!r||String(r.id)===String(m.id))continue;if(String(r.day_date)!==String(m.day_date))continue;const at=r.logged_at?new Date(r.logged_at).getTime():NaN;if(isNaN(at)||at>cut)continue;protein+=r.protein||0;kcal+=r.kcal||0}return{protein:Math.round(protein),cals:Math.round(kcal)}}const fmtLoggedAt=iso=>{if(!iso)return"";const d=new Date(iso);if(isNaN(d))return"";let h=d.getHours()%12;if(h===0)h=12;return`${h}:${String(d.getMinutes()).padStart(2,"0")} ${d.getHours()<12?"AM":"PM"}`};function histCard(m,isToday){const img=m.photo_path?cachedMealPhoto(m.photo_path):null;const late=typeof m.minutes_late==="number"&&m.minutes_late>0;const time=fmtLoggedAt(m.logged_at);const route=isToday&&MEAL_KEYS.includes(m.type)?`meal-detail/${m.type}`:`meal-view/${m.id}`;return`<div class="hist-card" data-go="${route}">
    ${img&&safeImg(img)?`<div class="hist-thumb" style="background-image:url('${safeImg(img)}')"></div>`:`<div class="hist-thumb icon">${icon("utensils",20)}</div>`}
    <div class="hist-main">
      <div class="t">${esc(m.name||(m.type?m.type.charAt(0).toUpperCase()+m.type.slice(1):"Meal"))}</div>
      <div class="s">${time?`${time} \xB7 `:""}${late?`${m.minutes_late} min late`:"On time"}${m.photo_path?"":" \xB7 No photo submitted"}</div>
    </div>
    ${m.quality!=null?`<div class="hist-score ${qualityAccent(m.quality)}">${m.quality}<small>/100</small></div>`:""}
    ${icon("chevron",15,'style="color:var(--text-3);flex:none"')}
  </div>`}export const history={tab:"progress",render(){const dayHead=(label,score,tierName)=>`
      <h2 class="eyebrow" style="display:flex;justify-content:space-between;align-items:baseline">
        <span>${label}</span>
        ${score!=null?`<span style="text-transform:none;letter-spacing:0;font-size:13px;font-weight:800;color:${tierColor(score)}">${score}${tierName?` \xB7 ${tierName}`:""}</span>`:""}
      </h2>`;const todayLabel=`Today \xB7 ${weekdayLong(new Date)}`;const rows=HIST.rows;let body;if(HIST.failed&&rows===null){body=errorState({title:"Couldn't load your history",body:"Your logged meals are safe on the server. Reconnect and they load right here.",retryId:"hist-retry"})}else if(rows===null){body=skeletonRows(4,"Loading your history")}else if(!rows.length){body=emptyState({icon:"clipboard",title:"Your proof trail builds here",body:"Every meal you log, with its photo, time and score, becomes part of your record.",action:{label:"Log a meal",go:"camera"}})}else{const scoreBy={};for(const h of S.history)scoreBy[h.iso]=h;const todayISO=String(DAY.date);const groups=[];for(const m of rows){const g=groups.find(x=>x.date===m.day_date);if(g)g.meals.push(m);else groups.push({date:m.day_date,meals:[m]})}body=groups.map(g=>{const isToday=g.date===todayISO;const label=isToday?todayLabel:`${weekdayLong(g.date)} \xB7 ${shortDate(g.date)}`;const h=scoreBy[g.date];const score=isToday?S.score:h?h.score:null;const tierName=isToday?S.tier.name:h?h.tier:null;return dayHead(label,score,tierName)+`<section class="card" style="padding:4px 12px">${g.meals.map(m=>histCard(m,isToday)).join("")}</section>`}).join("")}return`
    ${backHead("Activity history","The proof trail, day by day","progress")}
    ${body}
    <div style="height:10px"></div>
    `},mount(root){if(!RT.userId)return;const retry=root&&root.querySelector("#hist-retry");if(retry)retry.addEventListener("click",()=>{HIST={rows:null,at:0,uid:null,failed:false};window.__render()});const fresh=HIST.uid===RT.userId&&Date.now()-HIST.at<6e4;if(fresh){warmMealPhotos((HIST.rows||[]).map(m=>m.photo_path).filter(Boolean));return}fetchRecentMeals(RT.userId,daysAgoISO(14)).then(rows=>{if(rows===null){const keep=HIST.uid===RT.userId?HIST.rows:null;HIST={rows:keep,at:0,uid:RT.userId,failed:true}}else{HIST={rows,at:Date.now(),uid:RT.userId,failed:false};warmMealPhotos(rows.map(m=>m.photo_path).filter(Boolean))}if(location.hash.startsWith("#history"))window.__render()})}};let DIRECT={id:null,row:null};async function warmHistory(){if(!RT.userId||HIST.rows||HIST.uid===RT.userId)return;HIST={...HIST,uid:RT.userId};const rows=await fetchRecentMeals(RT.userId,daysAgoISO(14));if(rows===null){HIST={rows:null,at:0,uid:RT.userId,failed:true};return}HIST={rows,at:Date.now(),uid:RT.userId,failed:false};if(window.__render)window.__render()}async function fetchMealById(id){if(!id||!window.sb||DIRECT.id===id)return;try{const{data}=await window.sb.from("meals").select("id,athlete_id,type,name,quality,protein,carbs,fat,kcal,detected,note,analysis,photo_path,day_date,logged_at,minutes_late").eq("id",id).maybeSingle();DIRECT={id,row:data||null};if(data)window.__render&&window.__render()}catch{}}function mountThread(root,mealId,meal){const threadEl=root.querySelector("#mv-thread");const input=root.querySelector("#mv-msg");const send=root.querySelector("#mv-send");const note=root.querySelector("#mv-note");if(!threadEl)return;let rows=[];let participants=[];const paint=()=>{const msgs=threadMessages(rows);if(!msgs.length){threadEl.innerHTML='<div class="msg-status">No messages on this meal yet.</div>';placeLive();return}const items=layoutThread(msgs,{muted:RT.mutedUsers,fmtTime:mvClock,fmtDay:mvDay,fmtDayLabel:dayLabelOf});if(!items.length){threadEl.innerHTML=`<div class="msg-status">${MUTED_HIDDEN_NOTE}</div>`;return}const msgItems=items.filter(i=>i.type!=="time");const lastMsg=msgItems.length?msgItems[msgItems.length-1].comment:null;const visible=msgItems.map(i=>i.comment);const{fresh,added}=noteArrivals(mealId,visible,RT.userId);const rxAt=reactionAnchor(visible);threadEl.innerHTML=items.map(item=>{if(item.type==="time")return timeSepHtml(item,esc);const c=item.comment;if(isCorrectionReceipt(c))return receiptCardHtml(c,esc,{fresh:fresh.has(String(c.id))});const mine=c.role==="athlete"&&(!c.author_id||c.author_id===RT.userId);const who=authorName(c,participants,RT.userId,S.coach.noun);const update=isAnalysisUpdate(c);const escalated=isEscalated(c);const quoted=update?quotedFor(c,visible):null;const rq=quoted?"":replyQuoteHtml(replyQuote(c,visible,RT.mutedUsers,x=>x.role==="athlete"&&(!x.author_id||x.author_id===RT.userId)?"You":authorName(x,participants,RT.userId,S.coach.noun)),esc);const photo=attachedPhoto(c);const photoOnly=isPhotoOnly(c);const rx=c===rxAt?reactionGroups(rows):[];return`
        <div class="${msgRowClass({mine,role:c.role,firstOfRun:item.firstOfRun,lastOfRun:item.lastOfRun,hasRx:rx.length>0,photoOnly})}${fresh.has(String(c.id))?" in":""}" data-cid="${esc(String(c.id||""))}">
          ${!mine&&item.lastOfRun?`<div class="av"${c.role!=="ai"&&c.author_id?` data-avatar-uid="${esc(c.author_id)}"`:""}>${c.role==="ai"?icon("sparkle",15):`<span data-avatar-fallback>${esc(initialsFor(who))}</span>`}</div>`:'<div class="av-sp"></div>'}
          <div class="stack">
            ${item.firstOfRun&&!mine?`<div class="who">${esc(who)}</div>`:""}
            ${quoted?`<div class="quote"><span class="stem"></span><span class="qtext">${esc(quoted.text)}</span></div>`:rq}
            ${""}
            <div class="bubble">${escalated?'<span class="esc">Sent to your coach</span>':""}${bubblePhotoHtml(photo,esc)}${photoOnly?"":c.role==="ai"?richText(c.text,esc):personText(c.text,esc)}${rx.length?`<span class="rxo">${rx.map(r=>`${esc(r.emoji)} ${r.count}`).join(" ")}</span>`:""}</div>
            ${deliveredHtml({mine,isLast:c===lastMsg})}
          </div>
          ${msgTimeHtml(c,mvClock,esc)}
        </div>`}).join("");void hydrateThreadPhotos(threadEl,{signedMealPhotoUrl,signedMealPhotoUrls});hydrateAvatars(threadEl);placeLive();syncJump(threadEl,mealId,{dock:root.querySelector("#meal-disc .chat-dock"),added})};const placeLive=()=>{if(!threadEl.isConnected)return;const sending=syncLive(threadEl,mealId,{esc,imgSrc:safeImg});if(sending)scrollThreadToEnd(threadEl,{force:true})};threadEl.addEventListener("click",ev=>{const im=ev.target&&ev.target.closest?ev.target.closest("img.bimg"):null;if(!im||!im.src)return;openImageViewer(im.src,"Photo attached to this message",im)});const membersSlot=root.querySelector("#mv-members-slot");let membersPainted=-1;const paintMembers=()=>{if(!membersSlot)return;const people=participantList(participants,RT.userId);if(people.length===membersPainted)return;membersPainted=people.length;membersSlot.innerHTML=`
      <button class="facepile disc-fp" id="mv-members" aria-label="Who can see this conversation">
        <span class="fp">${people.slice(0,4).map(p=>`<span class="fpav ${esc(p.kind==="ai"?"ai":p.self?"self":"other")}"${p.kind!=="ai"&&p.id?` data-avatar-uid="${esc(p.id)}"`:""}>${p.kind==="ai"?icon("sparkle",13):`<span data-avatar-fallback>${esc(initialsFor(p.name))}</span>`}</span>`).join("")}</span>
        <span class="names"><b>Team discussion</b><small>${esc(participantSummary(people))}</small></span>
      </button>`;const btn=membersSlot.querySelector("#mv-members");if(btn)btn.addEventListener("click",()=>openMembersSheet(participantList(participants,RT.userId)));hydrateAvatars(membersSlot)};const refresh=async()=>{const[fetched,people]=await Promise.all([fetchMealComments(mealId).catch(()=>[]),participants.length?Promise.resolve(participants):fetchThreadParticipants(RT.userId).catch(()=>[])]);rows=Array.isArray(fetched)?fetched:[];participants=Array.isArray(people)?people:[];if(root.isConnected){paintMembers();paint()}};void refresh();let rxBusy=false;const tapReply={fn:null};wireTapback({root,scope:"#mv-thread",onReply:row=>{if(tapReply.fn)tapReply.fn(row)},emoji:REACTION_EMOJI,mine:()=>new Set((rows||[]).filter(c=>c&&c.kind==="reaction"&&c.author_id===RT.userId).map(c=>String(c.text))),onReact:async emoji=>{if(!emoji||rxBusy)return;rxBusy=true;const existing=(rows||[]).find(c=>c&&c.kind==="reaction"&&c.author_id===RT.userId&&String(c.text)===emoji);const ok=existing?await deleteMealComment(existing.id).catch(()=>false):await postMealComment(mealId,meal.athlete_id||RT.userId,RT.userId,"athlete",emoji,"reaction").catch(()=>false);if(ok)await refresh();else if(note)note.textContent="Couldn't save that reaction. Try again.";rxBusy=false}});const attach=wireComposerAttach({root,attachId:"mv-attach",pendingId:"mv-attach-pending",safeImg,onNote:m=>{if(note)note.textContent=m||""}});const deliver=async item=>{const text=item.text;const res=await postChatMessage({postMealComment,uploadChatPhoto},{mealId,athleteId:meal.athlete_id||RT.userId,authorId:RT.userId,role:"athlete",text,photo:item.photo,replyTo:item.replyTo||null});endSend(mealId,item.lid,{ok:res.ok});if(!res.ok){if(res.error==="filtered"){takeFailed(mealId,item.lid);if(input&&!input.value)input.value=text;if(note)note.textContent=FILTERED_NOTE}else if(note){note.textContent=res.error==="upload"?"Couldn't upload that photo. Tap the message to try again.":""}return}if(note)note.textContent="";if(S.coach.hasCoach){void notifyMyCoach({kind:`athlete_message:${mealId}`,urgent:true,title:`${S.athlete.first||"Your athlete"} ${!text?"sent a photo about":"asked about"} ${meal.name||meal.type||"a meal"}`,body:`${(text||"Sent a photo").slice(0,140)} \xB7 Tap to open the conversation.`,route:`coach-meal/${mealId}`})}await refresh();const photoPath=res.photoPath||null;const turn=decideAiTurn({text,comments:rows,participants,self:{id:RT.userId,name:S.athlete.first||"Athlete",role:"athlete"},athleteName:S.athlete.first||"Athlete",fallbackNoun:S.coach.noun,photo:!!photoPath});if(!turn.decision.shouldRespond)return;setAiWorking(mealId,true,{label:photoPath?"Reading the photo":workingLabel(visibleThread(threadMessages(rows),RT.mutedUsers))});try{await window.sb.functions.invoke("meal-chat",{body:{mealId,question:text||"I sent a photo. What do you make of it?",...photoPath?{photoPath}:{},speaker:turn.outgoing,addressing:turn.decision,participants:turn.participants,context:{meal:{name:meal.name||meal.type,slot:meal.type,quality:meal.quality,macros:{protein:meal.protein,carbs:meal.carbs,fat:meal.fat,cals:meal.kcal},note:meal.note},plan:{goal:RT.primaryGoal||null,allergies:RT.allergies},thread:turn.thread}}});setAiWorking(mealId,false);await refresh()}catch{setAiWorking(mealId,false);if(note)note.textContent="Sent. The reply will appear when the connection is back."}};const submit=async()=>{const text=input&&input.value.trim()||"";const pendingPhoto=attach.get();if(!text&&!pendingPhoto)return;const claim=beginSend(mealId,{text,photo:pendingPhoto,replyTo:replyOf(mealId)});if(!claim.ok){if(claim.reason==="duplicate"&&note)note.textContent="You just sent that.";return}if(note)note.textContent="";if(input)input.value="";attach.clear();clearReply(mealId);paintReplyChip(root.querySelector("#meal-disc .chat-dock"),mealId,esc);await deliver(claim.item)};const retryItem=async item=>{const claim=beginSend(mealId,{text:item.text,photo:item.photo,replyTo:item.replyTo});if(claim.ok)await deliver(claim.item)};bindLive(mealId,{sync:placeLive,onRetry:retryItem});paintReplyChip(root.querySelector("#meal-disc .chat-dock"),mealId,esc);wireThreadTaps({root,scope:"#mv-thread",key:mealId});const startReply=row=>{const id=row&&row.getAttribute("data-cid");const c=threadMessages(rows).find(x=>x&&String(x.id)===id);if(!c)return;const mineRow=c.role==="athlete"&&(!c.author_id||c.author_id===RT.userId);const who=mineRow?"You":authorName(c,participants,RT.userId,S.coach.noun);setReply(mealId,replyTargetMeta(c,who));paintReplyChip(root.querySelector("#meal-disc .chat-dock"),mealId,esc);focusComposer(input)};wireChatTimes({root,scope:"#mv-thread",onReply:startReply});tapReply.fn=startReply;if(send)send.addEventListener("click",submit);if(input)input.addEventListener("keydown",e=>{if(e.key==="Enter"&&!e.isComposing){e.preventDefault();void submit()}})}export function pastMealDetail(m){const cap=x=>x?x.charAt(0).toUpperCase()+x.slice(1):"Meal";const nz=v=>v==null?null:v;const late=typeof m.minutes_late==="number"?Math.max(0,m.minutes_late):0;const rich=normalizeDetected(m.detected);return{slot:m.type||"meal",name:cap(m.type),dish:m.name||"",logged:true,mealId:m.id,loggedAt:fmtLoggedAt(m.logged_at)||null,minutesLate:late,late:late>0,score:m.quality!=null?m.quality:null,macros:{protein:m.protein||0,carbs:m.carbs||0,fat:m.fat||0,cals:m.kcal||0},macrosRaw:{protein:nz(m.protein),carbs:nz(m.carbs),fat:nz(m.fat),cals:nz(m.kcal)},fiber:m.fiber||0,detectedRich:rich,foods:rich.map(d=>d.name),source:m.photo_path?null:"manual",hasPhoto:!!m.photo_path,img:null,live:true,flagged:null,note:m.note||"",userNote:"",analysis:m.analysis||"",styleApplied:m.styleApplied||null,photoQ:null,pending:false,pendingQuestions:null,analysisFailed:null,rereadError:null,corrections:[],orig:null}}export const mealView={tab:"progress",hideTabs:true,render({sub}){const m=histMealById(sub)||(DIRECT.id===sub?DIRECT.row:null);if(!m){return`${backHead("Meal","Not available","history")}
      <div class="sidebox"><div class="req-icon b s38">${icon("clipboard",17)}</div>
      <div><div class="tt">Couldn't open this meal</div><div class="ts">Open it from your Activity History.</div></div></div>`}const M=pastMealDetail(m);const when=String(m.day_date);const dayRow=(S.history||[]).find(h=>h&&h.iso===when)||null;const dayScore=dayRow&&dayRow.score!=null?dayRow.score:null;const dayTier=dayScore!=null?tier(dayScore):null;const lateLabel=M.minutesLate>0?`${M.minutesLate} min late`:"On time";const statusBits=[...M.dish?[`<span class="lm-slot">${esc(M.name)}</span>`]:[],`<span>${esc(weekdayLong(when))}, ${esc(shortDate(when))}</span>`,...M.loggedAt?[`<span>${esc(M.loggedAt)}</span>`]:[],`<span class="${M.minutesLate>0?"late":"ontime"}">${esc(lateLabel)}</span>`,...dayScore!=null?[`<span>Day <b class="lm-dayscore ${dayTier.cls}">${dayScore}</b></span>`]:[]].join('<span class="lm-dot">\xB7</span>');const execTop=`
    <div class="lm-status">
      <span class="lm-ck">${icon("check",12)}</span>
      ${statusBits}
    </div>`;const{photoBlock,breakdown}=mealReadHtml(M,{exec:null,past:true,dayTotals:pastDayTotalsThrough(m)});const discussion=`
    <section class="disc" id="meal-disc" aria-labelledby="disc-title">
    <h2 class="sr-only" id="disc-title">Team discussion</h2>
    <div class="disc-head">
      <div id="mv-members-slot" style="flex:1;min-width:0"><div class="disc-fp"><span class="names"><b>Team discussion</b></span></div></div>
      <button type="button" class="disc-open" id="open-full-chat" aria-label="Open the full conversation at this meal">Open ${icon("chevron",14)}</button>
    </div>
    <div class="thread" id="mv-thread" role="log" aria-label="Meal conversation">
      <div class="msg-status">Loading\u2026</div>
    </div>
    <div class="chat-dock disc-dock">
    ${composer({inputId:"mv-msg",sendId:"mv-send",placeholder:"Ask about this meal\u2026",sendLabel:"Send",attachId:"mv-attach",atEnd:true})}
    <div class="composer-attach-pending" id="mv-attach-pending" hidden></div>
    <div id="mv-note" style="min-height:18px"></div>
    </div>
    </section>`;const foot=`<div class="meal-foot">
      <button class="btn ghost meal-back" data-go="history" aria-label="Back to history">${icon("back",16)} Back to History</button>
    </div>`;return`<div class="meal-screen">${backHead(M.dish||M.name,"","history")}${execTop}${photoBlock}${breakdown}${discussion}${foot}</div>`},mount(root,{sub}){wireReadControls(root,mealView);const m=histMealById(sub)||(DIRECT.id===sub?DIRECT.row:null);if(!m){void fetchMealById(sub);return}void warmHistory();mountThread(root,sub,m);const tell=root.querySelector("#tell-ai");if(tell)tell.addEventListener("click",()=>focusComposer(root.querySelector("#mv-msg")));const open=root.querySelector("#open-full-chat");if(open)open.addEventListener("click",()=>{const dest=`nutrition-chat/${m.id}`;if(window.__navigate)window.__navigate(dest);else location.hash=`#${dest}`});const photo=root.querySelector("#meal-photo");const hero=root.querySelector("#meal-hero");if(!m.photo_path){if(hero&&photo){photo.style.display="none";hero.classList.add("ph-nophoto")}return}resolveMealPhoto(m.photo_path).then(url=>{if(!url||!root.isConnected||!photo)return;photo.onerror=()=>{photo.style.display="none";if(hero)hero.classList.add("ph-nophoto")};photo.src=url;photo.style.display="block";const back=root.querySelector("#meal-backdrop-img");if(back)back.src=url;if(hero){hero.style.cursor="zoom-in";hero.setAttribute("tabindex","0");hero.setAttribute("role","button");hero.setAttribute("aria-label","View photo full screen");hero.addEventListener("click",()=>openImageViewer(url,"Meal photo",hero))}})}};
