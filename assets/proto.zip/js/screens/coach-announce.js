import{backHead,esc,errorState,skeletonRows,sayStatus}from"../components.js";import{objectionable,FILTERED_NOTE}from"../content-filter.js";import{icon}from"../icons.js";import*as roles from"../roles.js";import{CD,loadCoachRoster}from"../coach-data.js";import{fmtWhen}from"../notif-feed.js";const ANN={scopeKind:"team",scopeValue:null,title:"",body:""};let ARM=false;let HIST=null;let histLoadingId=null;export function audienceLabel(scopeKind,scopeValue,groups){if(scopeKind==="team")return"Entire team";if(scopeKind==="position")return`${scopeValue} room`;if(scopeKind==="group"){const g=(groups||[]).find(x=>x.id===scopeValue);return g?g.name:"Group"}if(scopeKind==="athlete")return"One athlete";return"Team"}async function loadHistory(teamId,force){if(!teamId)return;if(HIST&&HIST.teamId===teamId&&!force)return;if(histLoadingId===teamId)return;histLoadingId=teamId;try{const rows=await roles.fetchAnnouncements(teamId,10);HIST=rows===null?{teamId,rows:[],offline:true}:{teamId,rows}}catch{HIST={teamId,rows:[],offline:true}}finally{histLoadingId=null}if(location.hash.startsWith("#coach-announce"))window.__render()}export const coachAnnounce={nav:"coach",tab:"create",transient:true,render({sub}={}){const rows=CD.roster?CD.roster.rows:[];const groups=CD.extras&&CD.extras.groups||[];if(sub&&ANN.scopeKind!=="athlete"){ANN.scopeKind="athlete";ANN.scopeValue=sub}if(!sub&&ANN.scopeKind==="athlete"){ANN.scopeKind="team";ANN.scopeValue=null}const positions=[...new Set(rows.map(r=>(r.unit||"").trim().toUpperCase()).filter(Boolean))];const target=ANN.scopeKind==="athlete"?rows.find(r=>r.athleteId===ANN.scopeValue):null;const group=ANN.scopeKind==="group"?groups.find(g=>g.id===ANN.scopeValue):null;const chip=(on,label,act,arg)=>`<span class="chip ${on?"on":""}" role="radio" aria-checked="${on?"true":"false"}" tabindex="0" data-ann="${act}${arg!=null?":"+esc(String(arg)):""}">${label}</span>`;const teamId=CD.roster&&CD.roster.teams[0]&&CD.roster.teams[0].id;const histRows=HIST&&HIST.teamId===teamId?HIST.rows:null;const sendLabel=ANN.scopeKind==="athlete"?`Send to ${esc(target?target.name:"this athlete")}`:ANN.scopeKind==="position"?`Send to the ${esc(ANN.scopeValue||"")} room`:ANN.scopeKind==="group"?`Send to ${esc(group?group.name:"the group")}`:"Send to the whole team";const armCount=ANN.scopeKind==="athlete"?1:ANN.scopeKind==="position"?rows.filter(r=>(r.unit||"").trim().toUpperCase()===ANN.scopeValue).length:ANN.scopeKind==="group"?(group&&group.athlete_ids||[]).length:rows.length;if(CD.roster&&!CD.roster.offline&&!rows.length){return`${backHead("Announcement","Lands in every selected athlete\u2019s feed","coach-create")}
      <div class="sidebox"><div class="req-icon b s38">${icon("users",17)}</div>
      <div><div class="tt">No athletes yet</div><div class="ts">Announcements go to the athletes on your roster. Share your team code and this opens up as they join.</div></div></div>
      <div class="ro-gap"></div>
      <button class="btn primary" data-go="coach-profile/code">${icon("share",17)} Share athlete code</button>`}return`
    ${backHead("Announcement","Lands in every selected athlete\u2019s feed","coach-create")}

    ${""}
    ${target?`<div id="an-target" class="an-target" data-name="${esc(target.name)}"></div>`:""}

    <h2 class="eyebrow">Who</h2>
    <div class="chip-row" id="an-who" role="radiogroup" aria-label="Who">
      ${chip(ANN.scopeKind==="team",`Whole team${rows.length?` \xB7 ${rows.length}`:""}`,"team")}
      ${positions.map(p=>{const n=rows.filter(r=>(r.unit||"").trim().toUpperCase()===p).length;return chip(ANN.scopeKind==="position"&&ANN.scopeValue===p,`${esc(p)} room \xB7 ${n}`,"position",p)}).join("")}
      ${groups.map(g=>chip(ANN.scopeKind==="group"&&ANN.scopeValue===g.id,`${esc(g.name)} \xB7 ${(g.athlete_ids||[]).length}`,"group",g.id)).join("")}
    </div>

    <h2 class="eyebrow" id="an-title-l">Title</h2>
    <input id="an-title" class="ob-input" aria-labelledby="an-title-l" maxlength="80" placeholder="e.g. Lift moved to 6am" value="${esc(ANN.title||"")}" />

    <h2 class="eyebrow" id="an-body-l">Message</h2>
    <textarea id="an-body" class="ob-input" aria-labelledby="an-body-l" maxlength="500" rows="4" placeholder="What they need to know" style="height:auto;padding-top:10px;padding-bottom:10px">${esc(ANN.body||"")}</textarea>

    <div style="height:16px"></div>
    ${ARM?`
    ${""}
    <div class="an-arm" role="group" aria-label="Confirm the send">
      <div class="an-arm-t">${icon("alert",16)} They get this in their feed and on their phone. It can't be recalled.</div>
      <div class="an-arm-acts">
        <button class="btn ghost" id="an-cancel">Cancel</button>
        <button class="btn primary" id="an-send">${icon("share",18)} ${armCount?`Send to ${armCount} athlete${armCount===1?"":"s"} now`:"Send now"}</button>
      </div>
    </div>`:`
    <button class="btn primary" id="an-send">${icon("share",18)} ${sendLabel}</button>`}
    <div id="an-status" class="an-status"></div>

    <h2 class="eyebrow" style="margin-top:18px">Recent announcements</h2>
    ${HIST&&HIST.teamId===teamId&&HIST.offline?errorState({title:"Couldn't load history",body:"Your sent announcements are safe. Reconnect to see them.",retryId:"an-hist-retry"}):histRows===null?skeletonRows(2,"Loading announcements"):histRows.length?`
    <section class="card" role="list" style="padding:6px 16px">
      ${histRows.map(a=>`
      <div class="lrow" role="listitem" style="cursor:default">
        <div class="lic">${icon("share",17)}</div>
        <div class="lm"><div class="lt">${esc(a.title)}</div><div class="ls">${esc(audienceLabel(a.scope_kind,a.scope_value,groups))} \xB7 ${esc(fmtWhen(a.created_at,Date.now()))}${a.sent_count!=null?` \xB7 Reached ${a.sent_count}`:""}</div></div>
      </div>`).join("")}
    </section>`:`
    <div class="an-none">Nothing sent yet. Your first one shows up here.</div>`}
    <div style="height:10px"></div>
    `},mount(root){loadCoachRoster().then(()=>{const teamId=CD.roster&&CD.roster.teams[0]&&CD.roster.teams[0].id;if(teamId)loadHistory(teamId)});const histRetry=root.querySelector("#an-hist-retry");if(histRetry)histRetry.addEventListener("click",()=>{const teamId=CD.roster&&CD.roster.teams[0]&&CD.roster.teams[0].id;if(teamId){histRetry.disabled=true;loadHistory(teamId,true)}});const say=(msg,isErr)=>{const el=root.querySelector("#an-status");if(el)sayStatus(el,msg,{error:!!isErr})};const tgt=root.querySelector("#an-target");if(tgt)sayStatus(tgt,`Sending to ${tgt.getAttribute("data-name")||"this athlete"} only.`);const keep=()=>{ANN.title=(root.querySelector("#an-title")||{}).value||"";ANN.body=(root.querySelector("#an-body")||{}).value||""};root.querySelectorAll("[data-ann]").forEach(el=>el.addEventListener("click",()=>{keep();ARM=false;const[act,arg]=el.getAttribute("data-ann").split(":");if(act==="team"){ANN.scopeKind="team";ANN.scopeValue=null}if(act==="position"){ANN.scopeKind="position";ANN.scopeValue=arg}if(act==="group"){ANN.scopeKind="group";ANN.scopeValue=arg}window.__render()}));const cancel=root.querySelector("#an-cancel");if(cancel)cancel.addEventListener("click",()=>{keep();ARM=false;window.__render()});const send=root.querySelector("#an-send");if(send)send.addEventListener("click",async()=>{keep();const title=ANN.title.trim();const body=ANN.body.trim();if(title.length<2){say("Give it a title first.",true);return}if(!body.length){say("Add what they need to know. The message can\u2019t be blank.",true);return}const teamId=CD.roster&&CD.roster.teams[0]&&CD.roster.teams[0].id;if(!teamId){say("Your roster hasn\u2019t loaded yet. Give it a second and try again.",true);return}if(!CD.caps.announcements){ARM=false;say("Your plan has lapsed, so this won\u2019t send. Your draft is safe. Funding the team turns announcements back on.",true);return}if(objectionable(title)||objectionable(body)){ARM=false;say(FILTERED_NOTE,true);return}if(!ARM){ARM=true;window.__render();return}ARM=false;send.disabled=true;say("Sending\u2026");const r=await roles.postAnnouncement({teamId,scopeKind:ANN.scopeKind,scopeValue:ANN.scopeValue,title,body});send.disabled=false;if(!r.ok){say(r.error||"Could not send. Try again.",true);return}roles.pushAnnouncement(r.id).catch(()=>{});const count=r.count||0;const msg=`Sent to ${count} athlete${count===1?"":"s"}.`;ANN.title="";ANN.body="";await loadHistory(teamId,true);say(msg)})}};
