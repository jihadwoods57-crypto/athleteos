import{S,RT,act,slotHasPhoto,liveWeightPct}from"../state.js";import{icon}from"../icons.js";import{initialsOf}from"../initials.js";import{weekdayLong}from"../fmt-date.js";import{identityLine}from"../identity-line.js";import{appHead,scoreRing,esc,safeImg,collapseSection,emailVerifyBanner,wireEmailVerifyBanner,emptyState}from"../components.js";import{reveal}from"../motion.js";import{qualityAccent}from"../score-band.js";import{maybeShowLock}from"../lock-moment.js";import{DAY,MEAL_KEYS,daySetWakeup}from"../day.js";import{fetchMyDayReceipts,fetchRecentMeals,signedMealPhotoUrl,daysAgoISO,todayISO,fetchMyReplyInputs}from"../roles.js";import{unreadCoachReplies,replyRow}from"../coach-replies.js";import{wakeupReceipt,receiptHtml}from"../wakeup-handoff.js";import{myWakeupForDay}from"../wakeup-morning.js";import{syncWakeAlarms}from"../wake-alarms.js";import{canClear,isCleared,clearReceipts}from"../receipts.js";import{WAKEUP_TYPE}from"../wakeup-morning.js";import{warmMealPhotos,todayMealPhotoPath}from"../photo-store.js";import{shouldNudge,nudgeSignature,nudgeData}from"../coach-nudge.js";import{deriveCommitment,presenceOf,PRESENCE,tomorrowRollcall}from"../commitments.js";import{VC,loadMine,todayISO as vcToday}from"../commitment-data.js";import{commitmentCard,mountCommitmentCard,commitmentOfflineCard,tomorrowCard}from"./roll-call.js";import{standardsCard,mountStandardsCard,standardsOfflineCard}from"./standards-card.js";import{CS,loadMine as loadStandards,todayISO as csToday}from"../connected-standard-data.js";import{maybeStartTour}from"../tour.js";import{pressTilt}from"../tilt.js";let PRESENCE_RECEIPT={day:null,data:null,seenMarked:false};function paintPresenceReceipt(root){const slot=root.querySelector("#presence-row");if(!slot||!slot.isConnected)return;const day=String(DAY.date);if(PRESENCE_RECEIPT.day!==day)PRESENCE_RECEIPT={day,data:null,seenMarked:false};let justFound=false;if(!PRESENCE_RECEIPT.data){const seen=act.presenceSeenIds(day);const row2=(Array.isArray(RT.vcRows)?RT.vcRows:[]).find(r=>r&&r.asks_arrival&&r.occurs_on===day&&presenceOf(r)===PRESENCE.CONFIRMED&&(r.min_dwell_min?true:r.arrival_source==="geofence")&&seen.indexOf(r.instance_id)<0);if(row2){const t=Date.parse(row2.arrived_at||"");PRESENCE_RECEIPT.data={where:row2.location_name||"the facility",mins:row2.min_dwell_min||0,at:isFinite(t)?new Date(t).toLocaleTimeString([],{hour:"numeric",minute:"2-digit"}):"",instanceId:row2.instance_id};justFound=true}}const d=PRESENCE_RECEIPT.data;if(!d){slot.replaceChildren();return}const card=document.createElement("div");card.className="seen-receipt presence";const ic=document.createElement("span");ic.className="sic";ic.innerHTML=icon("pin",15);const tx=document.createElement("span");tx.className="stx";const b=document.createElement("b");b.textContent=d.where;if(d.mins)tx.append("You were at ",b,` for the full ${d.mins} minutes`);else tx.append("Your phone checked you in at ",b);const tm=document.createElement("span");tm.className="stm";tm.textContent=d.at;card.append(ic,tx,tm);if(!justFound)card.style.animation="none";slot.replaceChildren(card);if(!PRESENCE_RECEIPT.seenMarked&&d.instanceId){const markSeen=()=>{if(PRESENCE_RECEIPT.seenMarked)return;PRESENCE_RECEIPT.seenMarked=true;act.markPresenceSeen(day,d.instanceId)};if(typeof IntersectionObserver==="function"){const io=new IntersectionObserver(entries=>{if(entries.some(en=>en.isIntersecting)){markSeen();io.disconnect()}},{threshold:.6});io.observe(card)}else markSeen()}}let REPLY={uid:null,at:0,inputs:null,loading:false};const REPLY_DAYS=7;function unreadReplies(){if(!REPLY.inputs||REPLY.uid!==RT.userId)return[];return unreadCoachReplies({...REPLY.inputs,localViewedAt:RT.mealViewedAt})}function paintCoachReply(root){const slot=root.querySelector("#reply-row");if(!slot||!RT.userId)return;const draw=()=>{if(!slot.isConnected)return;const row2=replyRow(unreadReplies(),{todayISO:String(DAY.date),mealKeys:MEAL_KEYS,noun:S.coach&&S.coach.noun||"coach"});if(!row2){slot.replaceChildren();return}const btn=document.createElement("button");btn.type="button";btn.className="seen-receipt reply";btn.setAttribute("aria-label",`${row2.title}. ${row2.sub}`);const ic=document.createElement("span");ic.className="sic";ic.innerHTML=icon("message",15);const tx=document.createElement("span");tx.className="stx";const b=document.createElement("b");b.textContent=row2.title;const sm=document.createElement("small");sm.textContent=row2.sub;tx.append(b,sm);const tm=document.createElement("span");tm.className="stm";tm.textContent=row2.ts?tsClock(new Date(row2.ts).toISOString()):"";btn.append(ic,tx,tm);btn.addEventListener("click",()=>{act.markThreadViewed(row2.mealId);slot.replaceChildren();if(window.__go)window.__go(row2.route);else location.hash=`#${row2.route}`});slot.replaceChildren(btn)};draw();const fresh=REPLY.uid===RT.userId&&REPLY.inputs&&Date.now()-REPLY.at<6e4;if(fresh||REPLY.loading)return;REPLY.loading=true;const since=new Date(Date.now()-REPLY_DAYS*864e5).toISOString();fetchMyReplyInputs(RT.userId,since).then(inputs=>{REPLY.loading=false;if(inputs===null)return;REPLY={uid:RT.userId,at:Date.now(),inputs,loading:false};draw()}).catch(()=>{REPLY.loading=false})}if(typeof window!=="undefined"&&typeof window.addEventListener==="function"){window.addEventListener("hashchange",()=>{const unread=unreadReplies();if(!unread.length)return;const h=String(location.hash||"");let id=null;const past=/^#meal-view\/([A-Za-z0-9-]+)/.exec(h);if(past)id=past[1];else{const live=/^#meal-detail\/([a-z]+)/.exec(h);const u=live&&unread.find(x=>x.type===live[1]&&x.dayDate===String(DAY.date));if(u)id=u.mealId}if(id&&unread.some(x=>x.mealId===id))act.markThreadViewed(id)})}const RECEIPTS={seen:null,ids:[]};function paintClearReceipts(root){const slot=root&&root.querySelector("#rcpt-clear");if(!slot)return;const n=(RECEIPTS.seen?1:0)+RECEIPTS.ids.length;if(!n){slot.innerHTML="";return}slot.innerHTML=`<button class="rcpt-clear" type="button" aria-label="Clear ${n} receipt${n===1?"":"s"} from today">
    ${icon("check",14)} Clear ${n===1?"receipt":`${n} receipts`}
  </button>`;const btn=slot.firstElementChild;if(!btn)return;btn.addEventListener("click",()=>{const day=vcToday();const ids=RECEIPTS.ids.slice();if(RECEIPTS.seen)ids.push(RECEIPTS.seen);clearReceipts(RT.userId,day,ids);RECEIPTS.seen=null;RECEIPTS.ids=[];const seen=root.querySelector("#seen-row");if(seen)seen.innerHTML="";paintCommitments(root)})}const seenReceiptId=seenAt=>`seen:${seenAt||""}`;function paintCommitments(root){const slot=root.querySelector("#vc-slot");if(!slot)return;const paint=()=>{if(!slot.isConnected)return;const now=new Date().toISOString();paintPresenceReceipt(root);const today=vcToday();const evening=new Date().getHours()>=16;const derived=VC.today(today).map(r=>deriveCommitment(r,now));const clearable=derived.filter(d=>d&&d.visible&&canClear(d)&&d.instance_id);const shown=derived.filter(d=>!(canClear(d)&&isCleared(RT.userId,today,d.instance_id)));RECEIPTS.ids=clearable.filter(d=>!isCleared(RT.userId,today,d.instance_id)).map(d=>String(d.instance_id));const html=shown.map(d=>commitmentCard(d)).filter(Boolean).join("")+(evening?tomorrowCard(tomorrowRollcall(VC.mine,today)):"");slot.innerHTML=html||(VC.mineError?commitmentOfflineCard():"");if(html)mountCommitmentCard(slot,()=>paintCommitments(root));paintClearReceipts(root);const retry=slot.querySelector("[data-vc-retry]");if(retry)retry.addEventListener("click",()=>{retry.disabled=true;paintCommitments(root)})};paint();const onFg=()=>{if(!slot.isConnected)return;loadMine(true).then(rows=>{RT.vcRows=rows;publishWakeup(rows);paint()})};window.addEventListener("onstd:foreground",onFg);const prevCleanup=window.__screenCleanup;window.__screenCleanup=()=>{window.removeEventListener("onstd:foreground",onFg);if(typeof prevCleanup==="function")prevCleanup()};loadMine().then(rows=>{RT.vcRows=rows;publishWakeup(rows);paint()})}function publishWakeup(rows){try{daySetWakeup(myWakeupForDay(rows,DAY.date),RT.userId||null)}catch(_){}try{void syncWakeAlarms(rows)}catch(_){}}function paintStandards(root){const slot=root.querySelector("#cs-slot");if(!slot)return;const paint=()=>{if(!slot.isConnected)return;const html=standardsCard(CS.mine,csToday());slot.innerHTML=html||(CS.mineError?standardsOfflineCard():"");if(html)mountStandardsCard(slot);const retry=slot.querySelector("[data-cs-retry]");if(retry)retry.addEventListener("click",()=>{retry.disabled=true;paintStandards(root)})};paint();loadStandards().then(()=>{RT.csRows=CS.mine;paint()})}let nudgeInFlight=null;function coachNudgeHtml(text){return`
  <div class="trust" style="margin:12px 0 10px;background:linear-gradient(100deg, rgba(var(--purple-rgb), 0.12), rgba(var(--blue-rgb), 0.05));border-color:var(--purple-border, rgba(var(--purple-rgb), 0.35))">
    <div class="ic" style="background:rgba(var(--purple-rgb), 0.18);color:var(--purple-bright)">${icon("sparkle",20)}</div>
    <div style="flex:1"><div class="tt" style="display:flex;align-items:center;gap:6px">Your coach<span class="status-pill muted" style="font-size:var(--t-eyebrow);padding:1px 6px">AI</span></div>
    <div class="ts">${esc(text)}</div></div>
  </div>`}function cachedNudge(e){const c=RT.voiceNudge;if(!c||!c.text||!shouldNudge(e))return"";return c.sig===nudgeSignature(String(DAY.date),e)?coachNudgeHtml(c.text):""}function maybeCoachNudge(e){const slot=typeof document!=="undefined"?document.getElementById("cv-nudge"):null;if(!slot)return;if(!shouldNudge(e)||!RT.userId||!RT.team||!window.sb)return;const sig=nudgeSignature(String(DAY.date),e);const cached=RT.voiceNudge;if(cached&&cached.sig===sig){if(cached.text)slot.innerHTML=coachNudgeHtml(cached.text);return}if(nudgeInFlight===sig)return;nudgeInFlight=sig;window.sb.functions.invoke("coach-voice-nudge",{body:{data:nudgeData(e,String(DAY.date))}}).then(({data})=>{nudgeInFlight=null;const text=data&&typeof data.nudge==="string"&&data.nudge?data.nudge:null;act.setVoiceNudge(sig,text);if(!text)return;const s=document.getElementById("cv-nudge");if(s)s.innerHTML=coachNudgeHtml(text)}).catch(()=>{nudgeInFlight=null})}const MEAL_TINT=["rgba(var(--green-rgb), 0.22)","rgba(var(--green-rgb), 0.08)","var(--green-bright)"];const RECOVERY_TINT=["rgba(var(--purple-rgb), 0.24)","rgba(var(--blue-rgb), 0.10)","var(--purple-bright)"];const ACT_MEDIA={droplet:["rgba(var(--cyan-rgb), 0.28)","rgba(var(--blue-rgb), 0.16)","var(--cyan)"],moon:RECOVERY_TINT,moonStar:RECOVERY_TINT,scale:["rgba(var(--blue-rgb), 0.22)","rgba(var(--blue-rgb), 0.10)","var(--blue-bright)"],utensils:MEAL_TINT,breakfast:MEAL_TINT,lunch:MEAL_TINT,dinner:MEAL_TINT,snack:MEAL_TINT};const RES_K={"Morning Weight":"Weight","Recovery check-in":"Status"};function resCard(a){const[c1,c2,fg]=ACT_MEDIA[a.icon]||ACT_MEDIA.droplet;const carries=/^meal-(view|thread|detail)\//.test(a.route||"")?` data-vt="plate" data-vt-id="${a.route.replace(/[^A-Za-z0-9:_.-]/g,"_")}"`:"";const media=a.img&&safeImg(a.img)?`<div class="res-media"${carries} style="background-image:url('${safeImg(a.img)}')"></div>`:`<div class="res-media icon"${carries} style="background:linear-gradient(150deg, ${c1}, ${c2});color:${fg}">${icon(a.icon||"droplet",30)}${a.noPhoto?'<span class="res-nophoto">No photo submitted</span>':""}</div>`;const metrics=a.qualityLabel?`<div class="res-m"><span class="k">Quality</span><span class="v ${a.vClass}">${a.value}<small>${a.unit}</small></span></div>
      ${""}
      ${""}
      ${a.impact>0?`<div class="res-m"><span class="k">Score credit</span><span class="v muted">+${a.impact}</span></div>`:""}`:`<div class="res-m"><span class="k">${RES_K[a.type]||"Status"}</span><span class="v ${a.vClass}">${a.value}</span></div>`;return`<div class="res-card" ${a.route?`data-go="${a.route}"`:""}>
    ${media}
    <div class="res-body">
      <div class="res-t">${esc(a.type)}</div>
      <div class="res-time">${esc(a.time)}</div>
      ${metrics}
    </div>
  </div>`}function outcomeBand(){if(S.audience!=="client")return"";const W=S.weight;if(W.current==null||W.start==null)return"";const delta=Number(W.current)-W.start;const deltaLabel=Math.abs(delta)<.05?"No change yet":`${delta>0?"+":""}${delta.toFixed(1)} lb since you started`;const days=S.streakDays;return`<section class="card pad" data-go="progress" style="cursor:pointer;margin-top:12px">
    <h2 class="eyebrow" style="margin:0 0 8px">Your progress</h2>
    <div style="display:flex;justify-content:space-between;align-items:baseline">
      <div class="bigstat"><span class="n" style="font-size:var(--t-3xl)">${esc(W.current)}<small style="font-size:var(--t-sm);font-weight:700;color:var(--text-3)"> lb</small></span></div>
      ${W.pace?`<span class="status-pill ${W.pace==="On pace"?"g":"a"}">${W.pace}</span>`:""}
    </div>
    <div style="font-size:var(--t-sm);font-weight:600;color:var(--text-2);margin-top:2px">${esc(deltaLabel)}${W.target!=null?` \xB7 goal ${W.target} lb`:""}</div>
    ${days>0?`<div style="display:flex;align-items:center;gap:5px;font-size:var(--t-sm);font-weight:800;color:var(--text);margin-top:8px">${icon("flame",14)}${days}-day streak</div>`:""}
  </section>`}let PAST={uid:null,rows:null,at:0};async function warmPastResults(uid){if(!uid||!window.sb)return;if(PAST.uid===uid&&PAST.rows&&Date.now()-PAST.at<6e4)return;const today=todayISO();const fetched=await fetchRecentMeals(uid,daysAgoISO(2));if(fetched===null){PAST={uid,rows:PAST.uid===uid?PAST.rows:null,at:0};return}const rows=Array.isArray(fetched)?fetched:[];const past=rows.filter(r=>r&&r.day_date&&String(r.day_date)<today);await Promise.all(past.map(async r=>{if(r.photo_path)r._img=await signedMealPhotoUrl(r.photo_path).catch(()=>null)}));PAST={uid,rows:past,at:Date.now()};if(/^#?(home)?$/.test(location.hash))window.__render&&window.__render()}const tsClock=ts=>{const d=new Date(ts);if(isNaN(d))return"";const h=(d.getHours()+11)%12+1;return`${h}:${String(d.getMinutes()).padStart(2,"0")} ${d.getHours()<12?"AM":"PM"}`};const pastDayLabel=isoStr=>{const[y,m,dd]=String(isoStr).split("-").map(Number);const d=new Date(y,m-1,dd);if(isNaN(d))return String(isoStr);const today=new Date;today.setHours(0,0,0,0);const diff=Math.round((today-d)/864e5);return diff===1?"Yesterday":weekdayLong(d)};const pastResults=()=>{const rows=PAST.uid===RT.userId&&PAST.rows?PAST.rows:[];if(!rows.length)return"";const byDay=new Map;for(const r of rows){const k=String(r.day_date);if(!byDay.has(k))byDay.set(k,[]);byDay.get(k).push(r)}return[...byDay.keys()].sort().reverse().slice(0,2).map(d=>{const label=pastDayLabel(d);const cards=byDay.get(d).map(r=>{const clock=r.logged_at?tsClock(r.logged_at):"";return resCard({noPhoto:!r.photo_path,time:clock?`${label} \xB7 ${clock}`:label,type:r.type||"Meal",icon:"utensils",value:r.quality!=null?String(r.quality):"Logged",unit:r.quality!=null?"/100":null,qualityLabel:r.quality!=null,vClass:r.quality!=null?qualityAccent(r.quality):"muted",impact:0,img:r._img||null,route:r.id?`meal-view/${r.id}`:"history"})}).join("");return`<h2 class="eyebrow" style="margin-top:14px">${esc(label)}</h2><div class="res-rail">${cards}</div>`}).join("")};const recentResults=()=>{const rows=S.activity.filter(a=>!a.dim);const past=pastResults();if(!rows.length&&!past)return"";return`
    ${rows.length?`
    <h2 class="eyebrow">Recent Results <span class="link" data-go="history">View all</span></h2>
    <div class="res-rail">${rows.map(resCard).join("")}</div>`:""}
    ${past}`};const whyHtml=why=>esc(why).replace(/\*\*(.+?)\*\*/,"<b>$1</b>");const VERB={form:"Complete",scale:"Log",photo:"Log",counter:"Add"};const CTA_ICON={form:"moonStar",scale:"scale",photo:"camera",counter:"droplet"};export const PILL_TONE={gold:"a",gray:"muted",green:"g",red:"r",blue:"b",purple:"p"};export const pillTone=c=>PILL_TONE[c]||"muted";function nowCard(e){const n=e.now;const od=n.state==="overdue";const closing=!od&&n.minsLeft!=null&&n.minsLeft<=45;const isCheck=!n.proof||n.proof==="check";const label=isCheck?`Mark ${esc(n.title)} done`:`${VERB[n.proof]} ${esc(n.title)}${od?" late":""}`;const ctaIcon=isCheck?"check":CTA_ICON[n.proof];const missed=od&&n.color==="red";const pill=od||closing?"":`<span class="status-pill ${pillTone(n.color)}">${n.pill}</span>`;const hue=missed||od||closing?"":{g:"g",p:"p",b:"b",c:"c",muted:"b"}[n.accent]||"";return`<section class="xnow ${missed?"red":""}${closing?" closing":""}${hue?` ${hue}`:""}">
    <div class="xlab"><span class="xl">${od?missed?"MISSED":"LATE":closing?"NOW \xB7 CLOSING SOON":"NOW"}</span>${pill}</div>
    <div class="xmain">
      <div class="xico ${n.color}">${icon(n.icon,21)}</div>
      <div><div class="xt">${esc(n.title)}</div><div class="xwhy">${whyHtml(n.why)}</div></div>
    </div>
    <div class="xcount">
      ${od?`<span class="xdl lead">${esc(n.sub)}</span>`:`<span class="xcd" data-cd>${esc(n.countdown)}</span><span class="xdl">${n.countdown?"left \xB7 ":""}${esc(n.dueLabel)}</span>`}
    </div>
    <button class="xcta" data-go="${n.route}">${icon(ctaIcon,18)} ${label}</button>
  </section>`}const row=(i,hidePill)=>`<div class="xrow-item ${i.color==="green"?"green":i.color==="red"?"red":""}" data-go="${i.route}">
    <div class="xico sm ${i.color}">${icon(i.icon,17)}</div>
    <div class="xr"><div class="xa">${esc(i.title)}</div><div class="xb">${esc(i.sub)}</div></div>
    ${hidePill?"":`<span class="status-pill ${pillTone(i.color)}">${i.pill}</span>`}
  </div>`;function keepRecordCard(){if(!RT.hadRoster||RT.keepRecordSeen)return"";if(RT.myCoach&&RT.myCoach.teamId||RT.myTrainer&&RT.myTrainer.practiceId)return"";return`<div class="lrow" id="keep-record" style="margin:12px 0 10px;background:linear-gradient(100deg, rgba(var(--green-rgb),0.10), rgba(var(--blue-rgb),0.05));border:1px solid var(--green-border);border-radius:var(--r-card-sm);padding:12px 13px;cursor:pointer">
    <div class="xico sm green">${icon("shield",16)}</div>
    <div class="xr"><div class="xa">Your record stays yours</div>
    <div class="xb" style="white-space:normal;line-height:1.45">Your roster ended. Every day you proved is still here. See Individual Plus to keep it going.</div></div>
    <span class="status-pill g">See plans</span>
  </div>`}function syncBanner(){const issue=S.syncIssue;if(issue==="blocked"){const em=S.consent.guardianEmail;return`<div class="lrow" data-go="guardian" style="margin:12px 0 10px;background:rgba(var(--amber-rgb), 0.10);border:1px solid var(--amber-border);border-radius:var(--r-card-sm);padding:12px 13px">
      <div class="xico sm" style="background:rgba(var(--amber-rgb), 0.18);color:var(--amber-bright)">${icon("lock",16)}</div>
      <div class="xr"><div class="xa">${em?"Waiting on your parent":"One step before your day syncs"}</div>
      <div class="xb">${em?"Everything you log is safe on this phone until they approve.":"You\u2019re under 18, so a parent approves before your day reaches your coach. Tap to send it."}</div></div>
      ${icon("chevron",16,'style="color:var(--text-3)"')}
    </div>`}if(issue==="error"){return`<div class="lrow" style="margin:12px 0 10px;background:rgba(var(--blue-rgb), 0.08);border:1px solid var(--hairline);border-radius:var(--r-card-sm);padding:12px 13px;cursor:default">
      <div class="xico sm gray">${icon("wifiOff",16)}</div>
      <div class="xr"><div class="xa">Waiting to sync</div>
      <div class="xb">Your entry is saved and will upload automatically when you reconnect.</div></div>
    </div>`}return""}function trustShield(){const t=S.pass;if(!t.active)return"";const label=t.kind==="credits"?`${t.left} left`:`day ${t.day} of ${t.length}`;const note=t.note||(t.kind==="credits"?"Camera-free meals you can spend whenever you want.":"Camera-free through the window, credited from your real logging history.");return`<div class="tp-wrap">
    <button class="iconbtn tp-btn" id="tp-btn" aria-expanded="false" aria-haspopup="true" aria-label="Trust Pass, ${esc(label)}. Show quick info">${icon("shield",20)}</button>
    <div class="tp-pop" id="tp-pop" hidden>
      <div class="tp-h">${icon("shield",15)} Trust Pass \xB7 <b>${esc(label)}</b></div>
      <div class="tp-n">${esc(note)}</div>
      <div class="tp-link" data-go="trust">Full details ${icon("chevron",14)}</div>
    </div>
  </div>`}function headSub(e){if(e.celebration)return"Locked in for today";const d=new Date;return identityLine(weekdayLong(d),RT.myCoach&&RT.myCoach.teamName,S.athlete.school)}function nextLabel(e){const n=e.now;if(n)return!n.proof||n.proof==="check"?`Mark ${n.title} done`:`${VERB[n.proof]} ${n.title}`;const locked=e.later.find(i=>i.state==="locked");if(locked)return`${locked.title} \xB7 ${locked.sub.charAt(0).toLowerCase()}${locked.sub.slice(1)}`;return""}function deltaChip(score){const y=S.scoreYesterday;if(y==null||score===y)return"";const up=score>y;return`<span class="xh-delta ${up?"up":"down"}">${icon(up?"arrowUp":"arrowDown",11)} ${up?"+":"\u2212"}${Math.abs(score-y)} <span class="m">vs yesterday</span></span>`}export function scoreSummary({score,yesterday,streakDays}){const live=streakDays>0;const delta=yesterday!=null&&score!==yesterday?(()=>{const up=score>yesterday;return`<div class="xscore-c"><span class="xscore-k ${up?"up":"down"}">${icon(up?"arrowUp":"arrowDown",12)} ${up?"+":"\u2212"}${Math.abs(score-yesterday)}</span><span class="xscore-s">vs yesterday</span></div>`})():"";return`<div class="xscore">${delta}<div class="xscore-c"><span class="xscore-k streak${live?" on":""}">${icon("flame",12)} ${live?`Day ${streakDays}`:"Starts tonight"}</span><span class="xscore-s">locks at midnight</span></div></div>`}let lastHomeScore=null;let homeEntrance=true;window.addEventListener("hashchange",()=>{if((location.hash||"#home").slice(1).split("/")[0]!=="home")homeEntrance=true});let SEEN={uid:null,date:null,rows:null,at:0};function hero(e,backdrop=false){return liveHero(e,{backdrop})}function inProgressHero(e){return liveHero(e,{inProgress:true})}const HERO_RING=280,HERO_STROKE=17;function liveHero(e,{inProgress=false,backdrop=false}={}){const decided=!inProgress;const notStarted=inProgress&&e.met===0;const next=decided?nextLabel(e):"";const parts=S.breakdown;const segs=decided?parts.filter(b=>b.earned>0).map(b=>`<i class="${b.accent}" style="width:${b.earned}%"></i>`).join(""):"";const gain=decided&&!backdrop&&lastHomeScore!=null&&e.score>lastHomeScore?e.score-lastHomeScore:0;if(decided&&!backdrop)lastHomeScore=e.score;const line=decided?`<b>${e.met}</b> of <b>${e.total}</b> completed <span class="sep">\xB7</span> max today <b>${e.possible}</b>`:e.met===0&&e.total>0?"Log your first requirement to start your score":`<b>${e.met}</b> of <b>${e.total}</b> done today`;const aria=decided?`Daily Score ${e.score}, ${S.tier.name}. ${e.met} of ${e.total} completed. Open score breakdown`:`Daily Score ${notStarted?"not started yet":e.score}, in progress. ${e.met} of ${e.total} completed. Open score breakdown`;return`<section class="xhero" data-tour="score" data-go="score-breakdown" role="button" aria-label="${aria}">
    <div class="xh-ring">
      ${scoreRing({score:e.score,possible:e.possible,size:HERO_RING,stroke:HERO_STROKE,tierName:decided?S.tier.name:null,tierCls:decided?S.tier.cls:"b",uid:"hero",vt:"score",notStarted})}
      ${gain>0?`<span class="xh-float" aria-hidden="true">+${gain}</span>`:""}
    </div>
    <div class="xh-under">
      ${decided?deltaChip(e.score)?`<div class="xrow">${deltaChip(e.score)}</div>`:"":'<div class="xrow"><span class="status-pill inprog">In progress</span></div>'}
      <div class="${decided?"xh-line":"xh-flow"}">${line} <span class="xstrip-chev">${icon("chevron",15)}</span></div>
    </div>
    ${decided?`<div class="xh-formula">
      <div class="xf-bar" role="img" aria-label="Score parts: ${parts.map(b=>`${b.key} ${b.earned} of ${b.possible}`).join(", ")}">${segs}</div>
    </div>`:""}
    ${next?`<div class="xh-next">${icon("arrowRight",14)}<span>Next: <b>${esc(next)}</b></span></div>`:""}
  </section>`}const grow=(i,{hidePill,chev,checkIcon}={})=>{const spendable=i.proof==="photo"&&i.state!=="done"&&i.state!=="done_late"&&i.state!=="not_required"&&S.pass.active&&S.pass.kind==="credits"&&S.pass.left>0;return`<div class="xg-row" data-go="${i.route}">
    <div class="xico sm ${i.color}">${icon(checkIcon?"checkCircle":i.icon,17)}</div>
    <div class="xr"><div class="xa">${esc(i.title)}</div><div class="xb">${esc(i.sub)}</div></div>
    ${spendable?`<button class="btn ghost micro" data-spend="${esc(i.id)}" style="width:auto;height:44px">${icon("shield",13)} Use a pass</button>`:""}
    ${hidePill?"":`<span class="status-pill ${pillTone(i.color)}">${i.pill}</span>`}
    ${chev?icon("chevron",16,'style="color:var(--text-3)"'):""}
  </div>`};function celebration(e){return`<div class="xcelebwrap">
    <section class="hero" style="padding-bottom:8px" data-go="score-breakdown" role="button"
      aria-label="Daily Score ${e.score}, ${S.tier.name}. Every requirement complete. Open score breakdown">
      ${scoreRing({score:e.score,tierName:S.tier.name,tierCls:S.tier.cls,vt:"score",size:HERO_RING,stroke:HERO_STROKE})}
    </section>
    <div style="font-size:var(--t-xl);font-weight:800;letter-spacing:-.02em;margin-top:2px">You're OnStandard.</div>
    <!-- One meta row, no echoes: the ring already says the score and (by color) the tier; the
         record list below already proves every requirement is in. Everything left that's UNIQUE
         lives here: delta, streak, and when it locks.
         This was a single centered flex row of dot-joined spans that wrapped mid-phrase at phone
         width, so "+55 vs yesterday" and "your streak starts when today locks at midnight" landed
         as two unrelated fragments. scoreSummary stacks each fact over its own label and splits
         them with a hairline; it owns all four shapes, including a down-day, which the old copy
         here got right only because it delegated to deltaChip. Its own margins close the gap to
         the eyebrow below, so the 14px spacer div that used to sit here is gone. -->
    ${scoreSummary({score:e.score,yesterday:S.scoreYesterday,streakDays:S.streakDays})}
    <h2 class="eyebrow" style="align-self:flex-start">Today's record</h2>
    <div class="xrecord" style="width:100%;box-sizing:border-box">
      ${""}
      ${e.doneItems.map(d=>`<div class="xrec"${d.route?` data-go="${esc(d.route)}"`:""}><span class="xtk">${icon("check",12)}</span>${esc(d.title)}<span class="xtm">${esc((d.sub||"").replace(/^Logged at /,""))}</span></div>`).join("")}
    </div>
  </div>`}function fmtClock(m){if(m==null)return"";const h24=Math.floor(m/60),mm=m%60;const h=(h24+11)%12+1;return`${h}:${String(mm).padStart(2,"0")} ${h24<12?"AM":"PM"}`}function notScoredHero(){return`<section class="xhero" style="cursor:default">
    <div class="xh-ring">${scoreRing({score:0,uid:"notscored",notStarted:true,size:HERO_RING,stroke:HERO_STROKE})}</div>
    <div class="xh-under">
      <div class="xrow"><span class="status-pill muted">Not scored yet</span></div>
      <div class="xh-flow">Ready to begin. Your score starts with your next action.</div>
    </div>
  </section>`}function firstActionCard(n){const hue={g:"g",p:"p",b:"b",c:"c",muted:"b"}[n.accent]||"b";const isCheck=!n.proof||n.proof==="check";const label=isCheck?`Mark ${esc(n.title)} done`:`${VERB[n.proof]} ${esc(n.title)}`;const ctaIcon=isCheck?"check":CTA_ICON[n.proof];return`<section class="xnow ${hue}">
    <div class="xlab"><span class="xl">NOW</span><span class="note">Start here</span></div>
    <div class="xmain"><div class="xico">${icon(n.icon,21)}</div>
      <div><div class="xt">${esc(n.title)}</div><div class="xwhy">Your score starts moving with your first log. ${whyHtml(n.why)}</div></div></div>
    <div style="height:10px"></div>
    <button class="xcta" data-go="${n.route}">${icon(ctaIcon,18)} ${label}</button>
  </section>`}function fairnessNote(activationMin){const t=fmtClock(activationMin);return`<div class="sidebox" style="margin-top:12px">
    <div class="req-icon b s38">${icon("shield",17)}</div>
    <div><div class="tt">You're set up${t?` \xB7 joined at ${t}`:""}</div>
    <div class="ts">Anything scheduled before now won't count against you today. Your first full score starts fresh tomorrow.</div></div>
  </div>`}export default{tab:"home",render({backdrop=false}={}){const e=S.exec;if(S.notYetScored){const first=e.now;const done=e.doneItems;const upcoming2=[...e.next?[e.next]:[],...e.later].filter(i=>i.state!=="not_required");const excused=e.items.filter(i=>i.state==="not_required");const grp=(label,rows,opts)=>rows.length?`<h2 class="xgrp">${label}</h2><div class="xgroup">${rows.map(i=>grow(i,opts||{})).join("")}</div>`:"";return`
      ${appHead("Your standard is ready",trustShield())}
      ${emailVerifyBanner()}
      ${notScoredHero()}
      ${syncBanner()}
      ${first?firstActionCard(first):`<div class="sidebox"><div class="req-icon g s38">${icon("check",17)}</div><div><div class="tt">You're all set for today</div><div class="ts">Your first scored day begins tomorrow. Rest up.</div></div></div>`}
      ${grp("Logged today",done,{checkIcon:true,chev:true})}
      ${grp("Later today",upcoming2,{hidePill:false})}
      ${grp("Not counted today",excused)}
      ${fairnessNote(S.activation.activationMin)}
      <div style="height:12px"></div>`}if(RT.day0&&!RT.day0Breakfast){const rest=e.items.filter(i=>i.id!=="breakfast");const lateRows=rest.filter(i=>i.required&&i.state==="overdue").sort((a,b)=>(a.window?a.window.due:1e9)-(b.window?b.window.due:1e9));const upcoming2=rest.filter(i=>!(i.required&&i.state==="overdue"));return`
      ${appHead(headSub(e),trustShield())}
      ${emailVerifyBanner()}
      ${!S.dayDecided&&S.tier.cls==="r"?inProgressHero(e):hero(e,backdrop)}
      ${syncBanner()}
      <section class="xnow g">
        <div class="xlab"><span class="xl">NOW</span><span class="note">Start here</span></div>
        <div class="xmain"><div class="xico">${icon("camera",21)}</div>
        <div><div class="xt">Breakfast</div><div class="xwhy">Your score starts moving with your first log. <b>Nutrition \xB7 ${liveWeightPct("nutrition")}% of score.</b></div></div></div>
        <div style="height:10px"></div>
        <button class="xcta" data-go="camera">${icon("camera",18)} Log Breakfast</button>
      </section>
      ${lateRows.length?`<h2 class="xgrp">${e.decided?"Missed today":"Late \xB7 still counts"}</h2>${lateRows.map(i=>row(i)).join("")}`:""}
      ${upcoming2.length?`<h2 class="xgrp">Upcoming</h2>
      <div class="xgroup">${upcoming2.map(i=>grow(i,{hidePill:i.state==="locked"})).join("")}</div>`:""}
      <h2 class="eyebrow">Recent Results</h2>
      ${emptyState({icon:"camera",title:"No logs yet",body:"Your proof trail builds here as you log. Take a photo to begin today's standard.",action:{label:"Log a meal",go:"camera"}})}
      <div style="height:8px"></div>`}if(e.celebration){return`
      ${appHead(headSub(e),trustShield())}
      ${emailVerifyBanner()}
      ${celebration(e)}
      ${outcomeBand()}
      <div id="presence-row"></div>
      <div id="seen-row" style="width:100%"></div>
      ${""}
      ${receiptHtml(wakeupReceipt(VC.today().find(i=>i.type===WAKEUP_TYPE)||null,RT.userId),esc)}
      <div id="reply-row"></div>
      ${recentResults()}
      <div style="height:20px"></div>`}const nextRows=e.next?[e.next]:[];const open=RT.homeOpenSections||{};const sync=syncBanner();const attention=sync||keepRecordCard();const demoted="";const upcoming=e.later;const laterHtml=upcoming.length?collapseSection("later","Upcoming",upcoming.length,`<div class="xgroup">${upcoming.map(i=>grow(i,{hidePill:i.state==="locked"})).join("")}</div>`,open.later===true):"";const doneHtml=e.doneItems.length?collapseSection("done","Completed",e.doneItems.length,`<div class="xgroup">${e.doneItems.map(i=>grow(i,{hidePill:true,chev:true,checkIcon:true})).join("")}</div>`,open.done===true):"";return`
    ${appHead(headSub(e),trustShield())}
    ${emailVerifyBanner()}
    ${!S.dayDecided&&S.tier.cls==="r"?inProgressHero(e):hero(e,backdrop)}
    ${outcomeBand()}
    ${""}
    <div id="presence-row"></div>
    <div id="seen-row" data-tour="coach-seen"></div>
    ${""}
    ${receiptHtml(wakeupReceipt(VC.today().find(i=>i.type===WAKEUP_TYPE)||null,RT.userId),esc)}
      <div id="reply-row"></div>
    <div id="vc-slot"></div>
    ${""}
    <div id="rcpt-clear"></div>
    <div id="cs-slot" data-tour="standards"></div>
    ${attention}
    <div id="cv-nudge">${cachedNudge(e)}</div>
    ${e.overdue.filter(o=>o.id!==(e.now&&e.now.id)&&o.id!==(e.next&&e.next.id)).map(i=>row(i)).join("")}
    ${e.now?nowCard(e):""}
    ${nextRows.length?`<h2 class="xgrp">${e.next.state==="overdue"?"Also overdue":"Next"}</h2>${nextRows.map(row).join("")}`:""}
    ${laterHtml}
    ${doneHtml}
    ${demoted}
    ${recentResults()}
    <div style="height:20px"></div>`},mount(root){wireEmailVerifyBanner(root);reveal(root,{key:`day:${DAY.date}:${S.exec.score}`,haptic:null});pressTilt(root.querySelector(".xhero"));const keep=root.querySelector("#keep-record");if(keep)keep.addEventListener("click",()=>{act.markKeepRecordSeen();if(window.__go)window.__go("paywall");else location.hash="#paywall"});maybeShowLock(S.streakDays);act.syncNotifications();paintCommitments(root);paintStandards(root);paintCoachReply(root);maybeCoachNudge(S.exec);if(RT.userId){warmMealPhotos(MEAL_KEYS.filter(k=>DAY.meals[k]&&slotHasPhoto(k)).map(k=>todayMealPhotoPath(RT.userId,String(DAY.date),k)));warmPastResults(RT.userId)}const tpBtn=root.querySelector("#tp-btn");if(tpBtn){const pop=root.querySelector("#tp-pop");const setOpen=open=>{pop.hidden=!open;tpBtn.setAttribute("aria-expanded",String(open))};tpBtn.addEventListener("click",ev=>{ev.stopPropagation();setOpen(pop.hidden)});const vp=root.querySelector("#viewport");if(vp)vp.addEventListener("click",ev=>{if(!pop.hidden&&!ev.target.closest(".tp-wrap"))setOpen(false)})}let armed=null,armTimer=null;const disarm=()=>{if(armTimer){clearTimeout(armTimer);armTimer=null}if(armed&&armed.isConnected){armed.innerHTML=armed.dataset.idle;armed.classList.remove("armed")}armed=null};root.querySelectorAll("[data-spend]").forEach(b=>{b.dataset.idle=b.innerHTML;b.addEventListener("click",async ev=>{ev.stopPropagation();if(armed!==b){disarm();armed=b;b.classList.add("armed");b.innerHTML=`${icon("shield",13)} Spend 1 of ${S.pass.left}?`;armTimer=setTimeout(disarm,4200);return}disarm();const slot=b.getAttribute("data-spend");const idle=b.dataset.idle;b.disabled=true;b.textContent="Applying\u2026";const r=await act.spendPass(slot);if(!r.ok){b.disabled=false;b.textContent=r.error||"Could not apply it";setTimeout(()=>{if(b.isConnected)b.innerHTML=idle},2200)}})});root.addEventListener("click",ev=>{if(armed&&!ev.target.closest("[data-spend]"))disarm()},true);const reduceMotion=typeof matchMedia==="function"&&matchMedia("(prefers-reduced-motion: reduce)").matches;const playSeenIn=homeEntrance&&!reduceMotion;if(homeEntrance&&!reduceMotion){const view=root.querySelector("#view");if(view)Array.from(view.children).slice(0,9).forEach((el,i)=>{el.style.animation=`home-in .38s var(--ease-out) ${i*45}ms backwards`})}homeEntrance=false;root.querySelectorAll("details.xcollapse").forEach(d=>{d.addEventListener("toggle",()=>act.setHomeSection(d.getAttribute("data-sec"),d.open))});const seenRow=root.querySelector("#seen-row");if(seenRow&&RT.userId){const seenDay=String(DAY.date);const injectReceipt=rows=>{if(!rows||!rows.length||!seenRow.isConnected)return;if(isCleared(RT.userId,seenDay,seenReceiptId(rows[0]&&rows[0].seen_at))){seenRow.innerHTML="";RECEIPTS.seen=null;paintClearReceipts(root);return}const fmt=iso=>{const d=new Date(iso);let h=d.getHours()%12;if(h===0)h=12;return`${h}:${String(d.getMinutes()).padStart(2,"0")} ${d.getHours()<12?"AM":"PM"}`};const first=rows[0];const who=(first.viewer_name||S.coach.name).trim()||S.coach.name;const extra=rows.length>1?` + ${rows.length-1} more`:"";const viewerUid=S.coach.id&&(!first.viewer_name||first.viewer_name.trim()===String(S.coach.name||"").trim())?S.coach.id:"";seenRow.innerHTML=`
          <div class="seen-receipt">
            <span class="sic${viewerUid?" sic-face":""}"${viewerUid?` data-avatar-uid="${esc(viewerUid)}"`:""}>${viewerUid?`<span data-avatar-fallback>${esc(initialsOf(who,"C"))}</span>`:icon("eye",15)}</span>
            <span class="stx"><b>${esc(who)}</b> saw your day${esc(extra)}</span>
            <span class="stm">${fmt(first.seen_at)}</span>
          </div>`;if(!playSeenIn){const card=seenRow.firstElementChild;if(card)card.style.animation="none"}RECEIPTS.seen=seenReceiptId(first.seen_at);paintClearReceipts(root)};const seenFresh=SEEN.uid===RT.userId&&SEEN.date===seenDay&&SEEN.rows&&Date.now()-SEEN.at<6e4;if(seenFresh){injectReceipt(SEEN.rows)}else{fetchMyDayReceipts(RT.userId,seenDay).then(rows=>{if(rows)SEEN={uid:RT.userId,date:seenDay,rows,at:Date.now()};injectReceipt(rows)}).catch(()=>{})}}const key=()=>{const e=S.exec;return JSON.stringify([e.now&&e.now.id,e.now&&e.now.countdown,e.met,e.celebration,e.overdue.map(o=>o.id),e.items.map(i=>i.id+":"+i.state)])};let last=key();let rolling=false;window.__execTick=setInterval(()=>{const t=new Date;const iso=`${t.getFullYear()}-${String(t.getMonth()+1).padStart(2,"0")}-${String(t.getDate()).padStart(2,"0")}`;if(iso!==String(DAY.date)){if(rolling)return;rolling=true;act.hydrateDay().then(()=>window.__render()).catch(()=>{rolling=false});return}const k=key();if(k!==last){last=k;window.__render()}},3e4);maybeStartTour()}};
