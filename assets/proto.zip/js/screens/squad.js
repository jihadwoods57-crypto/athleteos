import{S,RT,act}from"../state.js";import{icon}from"../icons.js";import{backHead,esc,emptyState,errorState,skeletonRows}from"../components.js";import{scoreColor}from"../score-band.js";import*as roles from"../roles.js";import{openMembersSheet}from"../members-sheet.js";let BOARD=null,boardGen=0,boardLoadedAt=0;const BOARD_FRESH_MS=2e4;async function loadBoard(force){const teamId=RT.myCoach&&RT.myCoach.teamId;if(!teamId){BOARD={rows:[]};return}if(BOARD&&BOARD.rows&&!force&&Date.now()-boardLoadedAt<BOARD_FRESH_MS)return;const gen=++boardGen;const rows=await roles.fetchSquadBoard(teamId);if(gen!==boardGen)return;BOARD=rows===null?{offline:true}:{rows};if(rows!==null)boardLoadedAt=Date.now();const me=rows&&rows.find(r=>r.athlete_id===RT.userId);if(me)RT.shareSquadScore=!!me.shared;if(location.hash==="#squad")window.__render()}function boardRow(r,rank,today){const me=r.athlete_id===RT.userId;const first=(r.athlete_name||"You").split(" ")[0];const fresh=r.day_date===today;const scoreCell=r.score==null?`<span class="status-pill" style="color:var(--text-3)">No log yet</span>`:`<div style="text-align:right"><div style="font-size:var(--t-lg);font-weight:800;color:${scoreColor(r.score)}">${r.score}</div>${fresh?"":`<div style="font-size:var(--t-micro);font-weight:700;color:var(--text-3)">yesterday</div>`}</div>`;return`
    <div class="lrow" role="${me?"listitem":"button"}"${me?"":` tabindex="0" data-squad-uid="${esc(r.athlete_id||"")}" data-squad-name="${esc(r.athlete_name||"Teammate")}"`} style="cursor:${me?"default":"pointer"}${me?";background:var(--blue-surface);margin:0 -16px;padding-left:16px;padding-right:16px;border-radius:12px":""}">
      <div class="lic" style="${me?"background:var(--blue-surface);color:var(--blue-bright)":""}"><b>${rank}</b></div>
      <div class="lm"><div class="lt">${esc(me?`${first} \xB7 You`:first)}</div>
      <div class="ls">${esc(r.position||(me?"Your number is on the board":""))}</div></div>
      ${scoreCell}
    </div>`}export default{tab:"progress",async mount(root){loadBoard(false);const sw=root&&root.querySelector("#squad-share");if(sw)sw.addEventListener("click",async()=>{const on=!(RT.shareSquadScore===true);RT.shareSquadScore=on;window.__restate();const ok=await roles.setShareSquadScore(RT.userId,on);if(!ok){RT.shareSquadScore=!on;window.__render();return}loadBoard(true)});if(root)root.addEventListener("click",e=>{const row=e.target.closest&&e.target.closest("[data-squad-uid]");if(!row||!row.getAttribute("data-squad-uid"))return;openMembersSheet([{id:row.getAttribute("data-squad-uid"),name:row.getAttribute("data-squad-name")||"Teammate",kind:"teammate"}],{teamId:RT.myCoach&&RT.myCoach.teamId})});const retry=root&&root.querySelector("#squad-retry");if(retry)retry.addEventListener("click",()=>{BOARD=null;window.__render();loadBoard(true)})},render(){const team=RT.myCoach;if(!team||!team.teamId)return`
    ${backHead("Squad","Your team, side by side","progress")}
    ${emptyState({icon:"users",title:"No squad yet",body:"The Squad board unlocks when you join a team. Ask your coach for their team code, then connect it from your Profile.",action:{label:"Connect a coach",go:"connect"}})}
    <div style="height:10px"></div>`;const sharing=RT.shareSquadScore===true;const toggle=`
    <section class="card" style="padding:6px 16px">
      ${""}
      <div class="std-switch-row" id="squad-share" role="switch" tabindex="0" aria-checked="${sharing}" aria-label="Show my number to the squad" aria-describedby="squad-share-sub">
        <div class="std-sw-m"><div class="std-sw-t">Show my number to the squad</div>
        <div class="std-sw-s" id="squad-share-sub">${sharing?"Your name and daily score are on the board. Nothing else ever is.":"Off. Teammates see you only as a private count. Flip it and they see your name and daily score. Never meals, photos, or check-ins."}</div></div>
        <div class="std-switch ${sharing?"on":""}" aria-hidden="true"></div>
      </div>
    </section>`;if(BOARD===null)return`
    ${backHead("Squad",esc(team.teamName||"Your team"),"progress")}
    ${toggle}
    ${skeletonRows(4,"Pulling the board")}`;if(BOARD.offline)return`
    ${backHead("Squad",esc(team.teamName||"Your team"),"progress")}
    ${toggle}
    ${errorState({title:"Can't reach the board",body:"Nothing is invented while it's down. Your own score is still counting either way.",retryId:"squad-retry"})}`;const today=roles.todayISO();const shared=(BOARD.rows||[]).filter(r=>r.shared||r.athlete_id===RT.userId);const privateN=(BOARD.rows||[]).length-shared.length;return`
    ${backHead("Squad",`${esc(team.teamName||"Your team")} \xB7 ${shared.length} on the board`,"progress")}
    ${toggle}

    <h2 class="eyebrow">Today's board</h2>
    ${shared.length?`<section class="card" style="padding:6px 16px" role="list">
      ${shared.map((r,i)=>boardRow(r,i+1,today)).join("")}
    </section>`:""}
    ${shared.length===1&&shared[0].athlete_id===RT.userId?`
    <div style="font-size:12px;font-weight:600;color:var(--text-3);margin:6px 2px 0;line-height:1.45">You're first on the board. Teammates appear as they flip their own switch. Nobody is shown without it.</div>`:""}
    ${privateN>0?`
    <div style="font-size:12px;font-weight:600;color:var(--text-3);margin:8px 2px 0">${privateN} teammate${privateN>1?"s keep":" keeps"} their number private.</div>`:""}
    <div style="height:10px"></div>`}};
