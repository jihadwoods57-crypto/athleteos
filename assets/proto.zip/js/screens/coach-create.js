import{backHead,esc}from"../components.js";import{icon}from"../icons.js";import{CD,loadBook}from"../coach-data.js";import{allowedCreateKeys,isReadonly}from"../staff-access.js";import{ROLLCALL_OFF}from"../commitments.js";const OPTIONS=[{grp:"standard",key:"assign",cap:"assignments",icon:"clipboard",title:"Assign a one-off task",sub:"Team, room, group, or the people you pick",go:"coach-assign"},{grp:"tell",key:"announce",cap:"announcements",icon:"share",title:"Send an announcement",sub:"Feed + push to the room you pick",go:"coach-announce"},{grp:"tell",key:"message_athlete",cap:null,icon:"message",title:"Message an athlete",sub:"Pick from the roster",go:"coach-roster"},{grp:"tell",key:"message_group",cap:"announcements",icon:"users",title:"Message a group",sub:"Announce to a custom group",go:"coach-announce"},{grp:"standard",key:"standards",cap:"standards",icon:"bars",title:"Standards & templates",sub:"Meals, windows, check-ins by room",go:"coach-plan"},{grp:"standard",key:"schedule",cap:"exceptions",icon:"clock",title:"Adjust a schedule",sub:"Mark travel or an excused stretch",go:"coach-roster"},{grp:"standard",key:"commitments",cap:null,icon:"sun",title:"Roll call",sub:"Wake-up, arrival, or both. A live board of who\u2019s in",go:"rollcall-new"},{grp:"standard",key:"commitments",cap:null,icon:"clock",title:"Schedule a commitment",sub:"Practice, lift, study hall. Verified",go:"coach-commit-manage"},{grp:"standard",key:"activity",cap:"standards",icon:"bolt",title:"Set an activity standard",sub:"Steps, distance or workouts. Verified by their watch",go:"coach-standards-manage"},{grp:"roster",key:"add_athlete",cap:null,icon:"user",title:"Add an athlete",sub:"Share your team code",go:"coach-profile/code"},{grp:"roster",key:"invite_staff",cap:"staffRoles",icon:"users",title:"Invite staff",sub:"Coordinator, room, or view-only",go:"coach-profile/staff"},{grp:"standard",key:"team_diet",cap:"recruiting",icon:"heart",title:"Team diet",sub:"Meal-plan tools",go:"team-diet"}];const TRAINER_GO={message_athlete:"trainer-roster",add_athlete:"trainer-profile"};const TRAINER_SUB={add_athlete:"Share your practice code",message_athlete:"Pick from your clients",assign:"All clients, or the ones you pick",standards:"Meals, windows, and check-ins"};const TRAINER_TITLE={message_athlete:"Message a client",add_athlete:"Add a client"};export const coachCreate={nav:"operator",tab:"create",transient:true,render(){const practice=CD.kind==="practice";const back=practice?"trainer":"coach-home";const myRole=CD.extras?CD.extras.myRole:null;if(!practice&&CD.extras&&isReadonly(myRole)){return`${backHead("Create","What do you want to put in motion?",back)}
      <div class="sidebox">
        <div class="req-icon b s38">${icon("eye",17)}</div>
        <div><div class="tt">You have view-only access</div>
        <div class="ts">You can see the roster, standards, and activity for your scope. Creating and assigning is for the coaching staff. Ask the head coach if that should change.</div></div>
      </div>`}const allowed=practice?OPTIONS.map(o=>o.key):allowedCreateKeys(myRole);const opts=OPTIONS.filter(o=>allowed.includes(o.key)&&(!o.cap||CD.caps[o.cap])&&!(ROLLCALL_OFF&&o.key==="commitments"));const row=o=>`
      <div class="lrow" data-go="${practice&&TRAINER_GO[o.key]||o.go}" style="cursor:pointer">
        <div class="lic" style="background:var(--blue-surface);color:var(--blue-bright)">${icon(o.icon,17)}</div>
        <div class="lm"><div class="lt">${esc(practice&&TRAINER_TITLE[o.key]||o.title)}</div><div class="ls">${esc(practice&&TRAINER_SUB[o.key]||o.sub)}</div></div>
        ${icon("chevron",14,'style="color:var(--text-3)"')}
      </div>`;const group=(grp,heading)=>{const rows=opts.filter(o=>o.grp===grp);if(!rows.length)return"";return`<h2 class="eyebrow">${heading}</h2>
      <section class="card" style="padding:6px 16px">${rows.map(row).join("")}</section>`};return`${backHead("Create","What do you want to put in motion?",back)}
    ${group("tell","Tell someone something")}
    ${group("standard","Set the standard")}
    ${group("roster",practice?"Grow your book":"Grow the roster")}
    ${""}
    ${practice?`
    <div style="height:12px"></div>
    <div class="sidebox">
      <div class="req-icon b s38">${icon("lock",17)}</div>
      <div><div class="tt">Built for teams</div>
      <div class="ts">Broadcast announcements and staff roles are team tools. A practice is 1:1, so everything on this menu works on your book right now.</div></div>
    </div>`:""}`},mount(){loadBook(false,CD.kind)}};
