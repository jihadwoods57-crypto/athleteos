import{icon}from"../icons.js";import{track,EVENTS}from"../analytics.js";import{backHead,esc,skeletonRows}from"../components.js";import{fmtMin}from"../requirements.js";import{deriveCommitment,TYPE_LABEL,fmtAt,offsetFor,VERDICT,wakeupPhase,deadlineOf,closesAtOf,opensAtOf,graceMinOf,sourceOf,SOURCE,athleteRollcallRoute,boardRoute}from"../commitments.js";import{VC,loadMine,ackCommitment,disputeResponse,completeCommitment,ackRefusal,subscribeMine,todayISO}from"../commitment-data.js";import{pushTokenState,RT,S,act}from"../state.js";import{wakeAlarmState}from"../wake-alarms.js";const VERIFY_REASON=new Map;const SAVE_FAILED=new Map;const ICON_FOR={morning_roll_call:"sun",practice:"bolt",strength:"bolt",speed:"bolt",team_meeting:"users",study_hall:"clipboard",tutoring:"clipboard",class:"clipboard",rehab:"heart",nutrition:"utensils"};const iconFor=t=>ICON_FOR[t]||"clipboard";function stageStrip(d){if(!d.stages||d.stages.length<2)return"";return`<ol class="vc-track">${d.stages.map(s=>`
    <li class="vc-step${s.done?" on":""}">
      <span class="vc-node">${s.done?icon("check",9):""}</span>
      <span class="vc-sl">${esc(s.label)}</span>
      <span class="vc-st">${s.at?esc(s.at):""}</span>
    </li>`).join("")}</ol>`}function boardFor(row){return!!row&&!!row.instance_id&&athleteRollcallRoute(row,todayISO())===boardRoute(row.instance_id)}export function commitmentCard(d){if(!d||!d.visible)return"";const id=esc(d.instance_id||"");const go=boardFor(d)?`rollcall-board/${id}`:`roll-call/${id}`;if(d.collapsed){if(d.pendingSync&&d.type==="morning_roll_call"){return`<div class="xrow-item" data-go="${go}">
      <div class="xico sm muted">${icon("clock",16)}</div>
      <div class="xr"><div class="xa">${esc(d.title)}</div>
      <div class="xb">Answered on this phone \xB7 sends when you reconnect</div></div>
      <span class="status-pill muted">Sending</span>
    </div>`}if(d.stage==="completed"&&d.presence==="left_early"){return`<div class="xrow-item warn" data-go="${go}">
      <div class="xico sm gold">${icon("clock",16)}</div>
      <div class="xr"><div class="xa">${esc(d.title)}</div>
      <div class="xb">${esc(d.confirmLine)}</div></div>
      <span class="status-pill a">Left early</span>
    </div>`}if(d.stage==="acknowledged"&&d.verdict===VERDICT.LATE){return`<div class="xrow-item warn" data-go="${go}">
      <div class="xico sm gold">${icon("clock",16)}</div>
      <div class="xr"><div class="xa">${esc(d.title)}</div>
      <div class="xb">${esc(d.confirmLine)}</div></div>
      <span class="status-pill a">Late${d.lateMin?` \xB7 ${d.lateMin} min`:""}</span>
    </div>`}if(d.stage==="review"){return`<div class="xrow-item" data-go="${go}">
      <div class="xico sm muted">${icon("clock",16)}</div>
      <div class="xr"><div class="xa">${esc(d.title)}</div>
      <div class="xb">${esc(d.confirmLine)} \xB7 Your coach will review it</div></div>
      <span class="status-pill p">Under review</span>
    </div>`}if(d.stage==="acknowledged"&&d.source===SOURCE.OVERRIDE){return`<div class="xrow-item green" data-go="${go}">
      <div class="xico sm green">${icon("check",16)}</div>
      <div class="xr"><div class="xa">${esc(d.title)}</div>
      <div class="xb">${esc(d.confirmLine)}</div></div>
      <span class="status-pill b">Override</span>
    </div>`}const excused=d.stage==="excused";const pill=d.stage==="completed"?"Completed":excused?"Excused":d.type==="morning_roll_call"?"On Standard":"Checked in";return`<div class="xrow-item ${excused?"":"green"}" data-go="${go}">
      <div class="xico sm" style="${excused?"background:var(--surface-2);color:var(--text-3)":"background:var(--green-surface);color:var(--green-bright)"}">${icon("check",16)}</div>
      <div class="xr"><div class="xa">${esc(d.title)}</div>
      <div class="xb">${esc(d.confirmLine)}</div></div>
      <span class="status-pill ${excused?"muted":"g"}">${pill}</span>
    </div>`}if(d.stage==="upcoming"){return`<div class="xrow-item" data-go="${go}">
      <div class="xico sm blue">${icon("sun",16)}</div>
      <div class="xr"><div class="xa">${esc(d.title)}</div>
      <div class="xb">${esc(d.confirmLine)}${d.coach_name?esc(` \xB7 ${d.coach_name}`):""}</div></div>
      <span class="status-pill b">Soon</span>
    </div>`}if(d.stage==="late_open"){return`<section class="xnow vc-card late" data-vc-open="${id}">
    <div class="xlab">
      <span class="xl">YOU\u2019RE LATE</span>
      <span class="status-pill a">Late</span>
    </div>
    <div class="xmain">
      <div class="xico">${icon("bolt",20)}</div>
      <div>
        <div class="xt">${esc(d.title)}</div>
        <div class="xwhy">You haven\u2019t answered. A check-in still counts, as late.</div>
      </div>
    </div>
    <div class="vc-ctx">${icon("clock",13)} ${esc(d.confirmLine)}${d.closesAt?esc(` \xB7 Late check-in until ${fmtAt(d.closesAt,offsetFor(d,new Date().toISOString()))}`):""}</div>
    <button class="xcta" data-vc-ack="${id}">${icon("check",18)} ${esc(d.actionLabel)}</button>
    ${SAVE_FAILED.get(d.instance_id)?`<div class="vc-ctx wk-savefail">${icon("bolt",13)} ${esc(SAVE_FAILED.get(d.instance_id))}</div>`:""}
  </section>`}if(d.stage==="left_early"){return`<div class="xrow-item warn" data-go="${go}">
      <div class="xico sm gold">${icon("clock",16)}</div>
      <div class="xr"><div class="xa">${esc(d.title)}</div>
      <div class="xb">${esc(d.confirmLine)} \xB7 Counts unless corrected</div></div>
      <span class="status-pill a">Left early</span>
    </div>`}if(d.stage==="missed"||d.stage==="unverified"){const un=d.stage==="unverified";const reason=un?VERIFY_REASON.get(d.instance_id):null;const line=reason?`Couldn\u2019t verify: ${reason}`:d.confirmLine;const sub=un?`${line} \xB7 Doesn\u2019t count against you`:`${line} \xB7 Tap if this is wrong`;const wakeMissed=!un&&d.type==="morning_roll_call";return`<div class="xrow-item${un?"":wakeMissed?" red":" warn"}" data-go="${go}">
      <div class="xico sm" style="${un?"background:var(--surface-2);color:var(--text-3)":wakeMissed?"background:var(--red-surface);color:var(--red)":"background:var(--amber-surface);color:var(--amber-bright)"}">${icon(un?"shield":"bolt",16)}</div>
      <div class="xr"><div class="xa">${esc(d.title)}</div>
      <div class="xb">${esc(sub)}</div></div>
      <span class="status-pill ${un?"muted":wakeMissed?"r":"a"}">${un?"Unverified":wakeMissed?"Missed":"No response"}</span>
    </div>`}const action=d.canAck?`data-vc-ack="${id}"`:d.canArrive?`data-vc-arrive="${id}"`:d.canComplete?`data-vc-complete="${id}"`:"";const actionText=d.canAck?d.actionLabel:d.canArrive?d.actionLabel&&d.stage!=="open"?"I\u2019m here":d.actionLabel:"Mark complete";const deadlineStillMatters=d.stage==="open"||d.stage==="awaiting_arrival";const deadline=!deadlineStillMatters?"":d.stage==="awaiting_arrival"&&d.arrive_by_min!=null?`Arrive by ${esc(d.deadlineLine.replace(/^Arrive by /,""))}`:esc(d.deadlineLine);const eyebrow=TYPE_LABEL[d.type]||"Commitment";const eyebrowEarnsItsPlace=eyebrow.trim().toLowerCase()!==String(d.title||"").trim().toLowerCase();const hue=d.statusColor==="g"?" g":d.statusColor==="b"?" b":"";const wake=d.type==="morning_roll_call";return`<section class="xnow vc-card${hue}" data-vc-open="${id}">
    <div class="xlab">
      <span class="xl">${wake?esc(String(d.title).toUpperCase()):eyebrowEarnsItsPlace?esc(eyebrow.toUpperCase()):""}</span>
      ${deadline?`<span class="status-pill muted">${deadline}</span>`:""}
    </div>
    <div class="xmain">
      <div class="xico">${icon(iconFor(d.type),20)}</div>
      <div>
        ${""}
        ${wake?`<div class="xt">${esc(d.coach_name||d.title)}</div>`:`<div class="xt">${esc(d.title)}</div>`}
        ${d.message?`<div class="xwhy vc-msg">${esc(d.message)}</div>`:""}
      </div>
    </div>
    ${d.contextLine?`<div class="vc-ctx">${icon("clock",13)} ${esc(d.contextLine)}</div>`:""}
    ${""}
    ${d.confirmLine&&(d.stage==="awaiting_arrival"||d.stage==="arrived")?`<div class="vc-ctx">${icon(d.presence==="provisional"?"clock":"check",13)} ${esc(d.confirmLine)}</div>`:""}
    ${stageStrip(d)}
    ${action?`<button class="xcta" ${action}>${icon("check",18)} ${esc(actionText)}</button>`:""}
    ${action&&SAVE_FAILED.get(d.instance_id)?`<div class="vc-ctx" style="color:var(--amber-bright)">${icon("bolt",13)} ${esc(SAVE_FAILED.get(d.instance_id))}</div>`:""}
  </section>`}export function commitmentOfflineCard(){return`<div class="xrow-item" style="border-color:var(--hairline)">
    <div class="xico sm" style="background:var(--surface-2);color:var(--text-3)">${icon("wifiOff",16)}</div>
    <div class="xr"><div class="xa">Coach check-in isn\u2019t loading</div>
    <div class="xb">If your coach scheduled one, it shows the moment you reconnect. Nothing is lost.</div></div>
    <button class="btn ghost sm" data-vc-retry style="width:auto;padding:0 14px;height:44px;flex:none">Try again</button>
  </div>`}export function tomorrowCard(t){if(!t||!t.instance_id)return"";const id=esc(t.instance_id);if(t.skipped){return`<div class="xrow-item" data-go="roll-call/${id}">
      <div class="xico sm muted">${icon("sun",16)}</div>
      <div class="xr"><div class="xa">Tomorrow \xB7 ${esc(t.title)}</div>
      <div class="xb">${esc(t.coach_name?`${t.coach_name} called it off for tomorrow.`:"Your coach called it off for tomorrow.")}</div></div>
      <span class="status-pill muted">Off</span>
    </div>`}const time=t.startsMin!=null?fmtMin(t.startsMin):"";const line=[time,t.moved?"moved for tomorrow":"",t.coach_name].filter(Boolean).join(" \xB7 ");return`<div class="xrow-item" data-go="roll-call/${id}">
    <div class="xico sm blue">${icon("sun",16)}</div>
    <div class="xr"><div class="xa">Tomorrow \xB7 ${esc(t.title)}</div>
    <div class="xb">${esc(line||"Tomorrow morning.")}</div></div>
    <span class="status-pill ${t.moved?"a":"b"}">${esc(t.moved?"Moved":time||"Tomorrow")}</span>
  </div>`}export function mountCommitmentCard(root,rerender){const go=(attr,fn)=>root.querySelectorAll(`[${attr}]`).forEach(el=>{el.addEventListener("click",async ev=>{ev.stopPropagation();if(el.disabled)return;el.disabled=true;el.textContent="Saving\u2026";const id=el.getAttribute(attr);let ok=false;try{ok=await fn(id)}catch{ok=false}if(ok&&typeof ok==="object"&&ok.note){SAVE_FAILED.set(id,ok.note)}else if(ok){SAVE_FAILED.delete(id);try{if(navigator.vibrate)navigator.vibrate(14)}catch{}}else{SAVE_FAILED.set(id,"Didn\u2019t save. Check your signal and tap again.")}if(rerender)rerender()})});go("data-vc-ack",id=>{const row=VC.instance(id)||{};return ackCommitment(id).then(at=>{if(at&&act&&act.notifyCoachEvent)act.notifyCoachEvent({kind:`rollcall_answered:${id}`,title:`${S.athlete&&S.athlete.first||"Your athlete"} answered the roll call`,body:`${row.title||"Roll call"} \xB7 Tap to see who is in.`,route:`rollcall-board/${id}`});if(at)track(EVENTS.VC_ACKNOWLEDGED,{type:row.type,minsEarly:row.respond_by_at?Math.round((Date.parse(row.respond_by_at)-Date.parse(at))/6e4):null});return!!at})});go("data-vc-complete",id=>completeCommitment(id,"manual").then(Boolean));go("data-vc-arrive",async id=>{const place=(VC.instance(id)||{}).location_name||"the check-in spot";const{imHere}=await import("../location.js");const r=await imHere(id);if(r&&r.error==="unavailable")return{note:"Update OnStandard to check in with location."};if(!r||r.error)return false;await loadMine(true);if(r.within){VERIFY_REASON.delete(id);track(EVENTS.VC_ARRIVED,{source:"manual"});return true}VERIFY_REASON.set(id,typeof r.distance_m==="number"?`${Math.round(r.distance_m)} m from ${place}`:r.reason||"Couldn\u2019t confirm your location");track(EVENTS.VC_UNVERIFIED,{reason:"distance"});return true});root.querySelectorAll("[data-vc-open]").forEach(el=>el.addEventListener("click",ev=>{if(ev.target.closest("button"))return;const vid=el.getAttribute("data-vc-open");location.hash=boardFor(VC.instance(vid))?`#rollcall-board/${vid}`:`#roll-call/${vid}`}))}function pushWarning(phase){if(phase==="closed")return"";const s=pushTokenState();if(s!=="denied")return"";return`
  <div class="sidebox wk-warn">
    <div class="req-icon a s38">${icon("bell",19)}</div>
    <div>
      <div class="tt">Lock-screen check-in is off on this phone</div>
      <div class="ts">Notifications are off for OnStandard, so the roll call won\u2019t reach your lock screen. Turn them on in your phone\u2019s Settings, or open the app at the time and check in here. Either counts the same.</div>
    </div>
  </div>`}async function paintAlarmLine(root,row){const slot=root&&root.querySelector("#wk-alarm-line");if(!slot||!row)return;const st=await wakeAlarmState();if(!st||!st.supported||!slot.isConnected)return;const off=offsetFor(row,new Date().toISOString());const at=fmtAt(row.starts_at,off);const denied=st.authorization==="denied";const coachOff=row.alarm===false;const text=coachOff?`Your coach set this to arrive as a notification, not an alarm.`:denied?`Alarms are off for OnStandard, so this arrives as a notification a Sleep Focus can silence. Turn them on in Settings to be woken at ${at}.`:Number(st.armed)>0?`Your phone rings at ${at}, through Do Not Disturb and silent mode.`:`Your phone will ring at ${at} once it syncs. Open the app tonight if it has not.`;slot.innerHTML=`<div class="vc-ctx wk-alarmline${denied?" off":""}">${icon(denied?"alert":"sun",13)} ${esc(text)}</div>`}function howItWorks(row,clock,d){const grace=graceMinOf(row);return`
  <details class="wk-how">
    <summary>${icon("info",14)} How roll call works</summary>
    <div class="wk-how-body">
      <p>Your coach set the time. At ${esc(clock(row.starts_at))} the roll call opens on your lock screen. Tap <b>${esc(d.actionLabel)}</b> there or here.</p>
      <p>By ${esc(clock(deadlineOf(row)))} is <b>On Standard</b>${grace!=null?` (${grace} minutes of grace)`:""}. After that is <b>Late</b>, counted to the minute, until it closes at ${esc(clock(closesAtOf(row)))}. No answer by then is <b>Missed</b>, and stays missed.</p>
      <p>OnStandard records the exact moment your tap reaches it, on its own clock. Nothing else: no location, no phone data. The first tap stands. If your phone was offline and the tap arrived late, your coach reviews it before it counts either way.</p>
    </div>
  </details>`}function wakeupDetail(row,d){const nowISO=new Date().toISOString();const off=offsetFor(row,nowISO);const clock=iso=>fmtAt(iso,off);const phase=wakeupPhase(row,nowISO);const dl=deadlineOf(row);const close=closesAtOf(row);const refusal=ackRefusal(row.instance_id);const failNote=SAVE_FAILED.get(row.instance_id);const source=sourceOf(row);const note=`
    <div class="coachnote wk-note">
      <div class="who"><div class="nm">${esc(row.coach_name||"Your coach")}</div><div class="rl">${esc(d.title)}${row.starts_min!=null?` \xB7 ${esc(fmtMin(row.starts_min))}`:""}</div></div>
      ${d.message?`<p class="wk-msgp">${esc(d.message)}</p>`:`<div class="ts">No message this morning. The roll call stands.</div>`}
    </div>`;const card=(cls,verdict,stamp,sub,cta)=>`
    <section class="card pad wk-state ${cls}">
      <div class="wk-verdict">${verdict}</div>
      ${stamp?`<div class="wk-stamp">${stamp}</div>`:""}
      ${sub?`<div class="ts wk-statesub">${sub}</div>`:""}
      ${cta||""}
    </section>`;let state="";if(d.verdict===VERDICT.EXCUSED){state=card("","Excused by coach","",esc(row.excused_reason||"Your coach excused you from this one.")+" It doesn\u2019t count either way.")}else if(d.verdict===VERDICT.REVIEW){state=card("review","Under review",`Tapped ${esc(clock(row.device_tapped_at))} on your phone`,`It reached OnStandard at ${esc(clock(row.acknowledged_at))}, after the ${esc(clock(dl))} grace. Your phone was offline or slow. Your coach will review it before it counts either way.`)}else if(row.acknowledged_at){const late=d.verdict===VERDICT.LATE;const prov=source===SOURCE.OVERRIDE?`Coach override${row.corrected_by_name?` by ${esc(row.corrected_by_name)}`:""}${row.correction_note?`: \u201C${esc(row.correction_note)}\u201D`:""}. Not your tap; your coach marked you in.`:source===SOURCE.ACCEPTED?`Tap time accepted${row.reviewer_name?` by ${esc(row.reviewer_name)}`:""}. You tapped at ${esc(clock(row.device_tapped_at))}; it reached us at ${esc(clock(row.acknowledged_at))}.`:row.review_resolution==="late"?`Kept as late by your coach: the tap reached us at ${esc(clock(row.acknowledged_at))}.`:source===SOURCE.LOCKSCREEN?"Recorded from your lock screen.":source===SOURCE.APP?"Recorded in the app.":"";if(source===SOURCE.OVERRIDE){state=card("on",`${icon("check",16)} Coach override \xB7 On Standard`,`Marked at ${esc(clock(row.acknowledged_at))}`,prov)}else if(late){state=card("late",`Late \xB7 ${d.lateMin||1} min`,`Checked in at ${esc(clock(row.acknowledged_at))}`,`The grace ended at ${esc(clock(dl))}. ${prov}`)}else{state=card("on",`${icon("check",16)} On Standard`,`Checked in at ${esc(clock(source===SOURCE.ACCEPTED?row.device_tapped_at||row.acknowledged_at:row.acknowledged_at))}`,prov)}}else if(phase==="before"){state=card("",`Opens at ${esc(clock(opensAtOf(row)))}`,"",`On Standard until ${esc(clock(dl))}. Nothing to do until it opens.`)}else if(phase==="open"){state=card("live","Roll call is open","",`On Standard until ${esc(clock(dl))}.`,`<button class="btn primary wk-cta" data-vc-ack="${esc(row.instance_id)}">${icon("check",20)} ${esc(d.actionLabel)}</button>`)}else if(phase==="late"){state=card("late","You\u2019re late","",`The grace ended at ${esc(clock(dl))}. A check-in still counts, as late, until ${esc(clock(close))}. Your coach can see your status.`,`<button class="btn wk-cta" data-vc-ack="${esc(row.instance_id)}">${icon("check",20)} ${esc(d.actionLabel)}</button>`)}else{state=card("missed","Missed","",`No response before the ${esc(clock(close))} close. This is recorded. If it\u2019s wrong, tell your coach below.`)}const refusalLine=refusal==="not_open"?`Not open yet. It opens at ${clock(opensAtOf(row))}.`:refusal==="closed"?`This roll call closed at ${clock(close)}. It can\u2019t be answered now.`:refusal==="cancelled"?"Your coach cancelled this one.":"";const disputable=d.verdict===VERDICT.MISSED||row.acknowledged_at&&d.verdict===VERDICT.LATE&&source!==SOURCE.OVERRIDE;return`
  ${backHead(d.title,row.coach_name?`From ${row.coach_name}`:"","home")}
  ${note}
  <div class="wk-gap"></div>
  ${state}
  ${refusalLine?`<div class="vc-ctx wk-refusal">${icon("alert",13)} ${esc(refusalLine)}</div>`:""}
  ${failNote&&!refusalLine?`<div class="vc-ctx wk-refusal">${icon("bolt",13)} ${esc(failNote)}</div>`:""}
  ${pushWarning(phase)}
  ${""}
  ${!row.acknowledged_at&&(phase==="before"||phase==="open")?'<div id="wk-alarm-line"></div>':""}
  ${disputable?!row.disputed_at?`
    <div class="wk-gap"></div>
    <input class="input" id="vc-dispute-note" maxlength="200" placeholder="What actually happened? (optional)" aria-label="What actually happened" autocomplete="off">
    <button class="btn ghost wk-dispute-btn" id="vc-dispute">Something wrong? Tell your coach</button>`:`
    <div class="wk-gap"></div><div class="ts wk-center">Reported. Your coach can see this and correct it.</div>`:""}
  ${""}
  ${phase!=="before"?`
    <div class="wk-gap"></div>
    <section class="card rows">
      <div class="lrow" data-go="${esc(boardRoute(row.instance_id))}" role="button" tabindex="0">
        <div class="lic">${icon("users",15)}</div>
        <div class="lm"><div class="lt">See the team board</div><div class="ls">Who\u2019s up, who\u2019s late, first up</div></div>
        ${icon("chevron",14,'class="ic-chevron"')}
      </div>
    </section>`:""}
  ${howItWorks(row,clock,d)}
  <div class="wk-foot"></div>`}const RESOLVE=new Map;const RESOLVE_COOLDOWN_MS=3e4;const LIVE_MINE={stop:null,phase:null};export function shouldResolve(sub,now=Date.now(),m=RESOLVE){const k=String(sub||"");const s=m.get(k);if(s&&(s.pending||now-s.at<RESOLVE_COOLDOWN_MS))return false;m.set(k,{at:now,pending:true});return true}export function resolveDone(sub,m=RESOLVE){const s=m.get(String(sub||""));if(s)s.pending=false}export function resolveState(sub,m=RESOLVE){const s=m.get(String(sub||""));return!s?"never":s.pending?"pending":"settled"}export default{tab:"home",redirect({sub}){const row=VC.instance(sub);return boardFor(row)?boardRoute(row.instance_id):null},render({sub}){const row=VC.instance(sub);if(!row){if(resolveState(sub)==="settled"){return`${backHead("Check-in","","home")}
        <section class="card pad">
          <div class="tt">This check-in isn\u2019t available</div>
          <div class="ts" style="padding-top:6px">Your coach may have cancelled it, or it\u2019s old enough that we no longer keep the record. Nothing is counted against you.</div>
        </section>
        <div style="height:12px"></div>
        <button class="btn ghost" data-go="home" style="width:100%">Back to home</button>`}return`${backHead("Roll call","Loading\u2026","home")}${skeletonRows(4,"Loading your check-in")}`}const d=deriveCommitment(row,new Date().toISOString());if(row.type==="morning_roll_call")return wakeupDetail(row,d);const asksArrival=!!row.asks_arrival;const line=(label,time,on,offText)=>`
      <div class="vc-line ${on?"on":""}">
        <span class="vc-dot">${on?icon("check",11):""}</span>
        <div class="vc-lt"><div class="vc-la">${esc(label)}</div>
        <div class="vc-lb">${on?esc(time):esc(offText||"\u2014")}</div></div>
      </div>`;const off=offsetFor(row,new Date().toISOString());const clock=iso=>fmtAt(iso,off);return`
    ${backHead(d.title,d.contextLine||TYPE_LABEL[row.type]||"","home")}

    ${d.message?`<div class="coachnote"><p>${esc(d.message)}</p>
      <div class="ts" style="padding-top:6px">From ${esc(row.coach_name||"your coach")}</div></div>
      <div style="height:12px"></div>`:""}

    <h2 class="eyebrow">Today</h2>
    <section class="card pad">
      ${line("Checked in",clock(row.acknowledged_at),!!row.acknowledged_at)}
      ${asksArrival?line(`Arrived at ${row.location_name||"the facility"}`,clock(row.arrived_at),!!row.arrived_at):""}
      ${""}
      ${asksArrival&&row.min_dwell_min?line(`Stayed ${row.min_dwell_min} minutes`,"Met",d.presence==="confirmed",d.presence==="left_early"?`Left at ${clock(row.departed_at)}`:row.arrived_at?"Still going":"\u2014"):""}
      ${row.type!=="morning_roll_call"?line("Completed",clock(row.completed_at),!!row.completed_at):""}
    </section>

    ${d.canAck?`<div style="height:12px"></div>
      <button class="btn green" data-vc-ack="${esc(row.instance_id)}" style="width:100%">${icon("check",19)} ${esc(d.actionLabel)}</button>`:""}
    ${d.canComplete?`<div style="height:12px"></div>
      <button class="btn green" data-vc-complete="${esc(row.instance_id)}" style="width:100%">${icon("check",19)} Mark complete</button>`:""}
    ${""}
    ${SAVE_FAILED.get(row.instance_id)?`<div class="vc-ctx" style="color:var(--amber-bright);margin-top:10px">${icon("bolt",13)} ${esc(SAVE_FAILED.get(row.instance_id))}</div>`:""}


    ${(d.stage==="unverified"||d.stage==="missed"||row.arrived_at)&&!row.disputed_at?`
      <div style="height:14px"></div>
      ${""}
      <input class="input" id="vc-dispute-note" maxlength="200" placeholder="What actually happened? (optional)" aria-label="What actually happened" autocomplete="off">
      <button class="btn ghost" id="vc-dispute" style="width:100%;margin-top:10px">Something wrong? Tell your coach</button>`:""}
    ${row.disputed_at?`<div style="height:14px"></div>
      <div class="ts" style="text-align:center">Reported. Your coach can see this and correct it.</div>`:""}
    <div style="height:20px"></div>`},mount(root,{sub}){if(boardFor(VC.instance(sub))){location.replace(`#${boardRoute(sub)}`);return}if(!VC.instance(sub)&&shouldResolve(sub)){const settle=()=>{resolveDone(sub);if(root.isConnected)window.__render&&window.__render()};loadMine(true).then(settle,settle)}mountCommitmentCard(root,()=>window.__render&&window.__render());void paintAlarmLine(root,VC.instance(sub));window.addEventListener("onstd:push-token",()=>{if(root.isConnected)window.__render&&window.__render()},{once:true});const row0=VC.instance(sub);if(row0&&row0.type==="morning_roll_call"&&RT.userId){if(LIVE_MINE.stop){LIVE_MINE.stop();LIVE_MINE.stop=null}let last=JSON.stringify(row0);const w=subscribeMine(RT.userId,async()=>{if(!root.isConnected)return;await loadMine(true);const cur=JSON.stringify(VC.instance(sub)||null);const phaseNow=wakeupPhase(VC.instance(sub)||row0,new Date().toISOString());if(cur!==last||phaseNow!==LIVE_MINE.phase){last=cur;LIVE_MINE.phase=phaseNow;if(root.isConnected)window.__render&&window.__render()}},()=>wakeupPhase(VC.instance(sub)||row0,new Date().toISOString())==="closed");LIVE_MINE.stop=()=>w.stop();LIVE_MINE.phase=wakeupPhase(row0,new Date().toISOString());const dog=setInterval(()=>{if(!root.isConnected){clearInterval(dog);if(LIVE_MINE.stop){LIVE_MINE.stop();LIVE_MINE.stop=null}}},5e3);const onFg=()=>{if(root.isConnected)loadMine(true).then(()=>{if(root.isConnected)window.__render&&window.__render()})};window.addEventListener("onstd:foreground",onFg);const prevCleanup=window.__screenCleanup;window.__screenCleanup=()=>{window.removeEventListener("onstd:foreground",onFg);if(typeof prevCleanup==="function")prevCleanup()}}const dis=root.querySelector("#vc-dispute");if(dis)dis.addEventListener("click",async()=>{dis.disabled=true;dis.textContent="Sending\u2026";const note=root.querySelector("#vc-dispute-note");const said=note&&note.value.trim();const ok=await disputeResponse(sub,said||"Athlete reports this record is wrong.");if(ok){track(EVENTS.VC_DISPUTED,{});window.__render&&window.__render()}else{dis.disabled=false;dis.textContent="Couldn\u2019t send. Tap to try again"}})}};
