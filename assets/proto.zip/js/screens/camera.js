import{S,RT,act,MEAL,slotTitle,mealDueState}from"../state.js";import{icon}from"../icons.js";import{esc,safeImg,nonLiveBadge}from"../components.js";import{photoAgeBadge}from"../photo-hash.js";import{photoStats,photoQuality}from"../meal-intel.js";function encodeToJpeg(source,srcW,srcH,maxDim,quality){let w=srcW,h=srcH;const scale=Math.min(1,maxDim/Math.max(w,h));w=Math.max(1,Math.round(w*scale));h=Math.max(1,Math.round(h*scale));const cv=document.createElement("canvas");cv.width=w;cv.height=h;cv.getContext("2d").drawImage(source,0,0,w,h);const dataUrl=cv.toDataURL("image/jpeg",quality);let stats=null;try{const sw=Math.max(1,Math.min(96,w)),sh=Math.max(1,Math.round(sw*(h/w)));const sc=document.createElement("canvas");sc.width=sw;sc.height=sh;const sctx=sc.getContext("2d");sctx.drawImage(cv,0,0,sw,sh);const d=sctx.getImageData(0,0,sw,sh);stats=photoStats(d.data,sw,sh)}catch{}return{dataUrl,base64:dataUrl.split(",")[1],stats}}function downscaleToJpeg(file,maxDim,quality){return new Promise((resolve,reject)=>{const url=URL.createObjectURL(file);const img=new Image;img.onload=()=>{URL.revokeObjectURL(url);try{resolve(encodeToJpeg(img,img.width,img.height,maxDim,quality))}catch(e){reject(e)}};img.onerror=reject;img.src=url})}const hapticTap=style=>{try{window.OnStandardNative&&window.OnStandardNative.haptic(style||"medium")}catch{}};export default{tab:"camera",hideTabs:true,fill:true,bleed:true,transient:true,render({sub}={}){const L=S.logging;const slotName=sub?slotTitle(sub):L.name;const slotKey=sub||S.currentSlot;const upTo=slotKey?S.mealUpTo(slotKey):0;const due=slotKey?mealDueState(slotKey):{label:L.due,tone:"quiet"};if(!RT.camPrimed){return`
      <div class="ob" style="padding-top:40px">
        <h1 class="sr-only">Camera, for proof</h1>
        <div class="standard-set prime-body">
          <div class="halo"><div class="core" style="background:linear-gradient(155deg, var(--green), var(--green-deep))">${icon("camera",34)}</div></div>
          <div class="ob-title" style="margin-top:22px">Camera, for proof.</div>
          <div class="ob-sub" style="padding:0 8px">OnStandard uses your camera to capture meal photos. They go to your coach connection only: never public, never sold, never used to train anything without asking.</div>
        </div>
        <div class="ob-foot" style="margin-top:auto">
          <button class="btn primary" data-act="primeCamera" data-then="camera">Continue</button>
          <button class="cam-textlink" type="button" data-go="food-search">Log without a camera</button>
        </div>
      </div>`}return`
    <div class="cam">
      <h1 class="sr-only">Log ${esc(slotName)}</h1>
      <div class="cam-head">
        <button class="bk iconbtn" type="button" data-back="home" aria-label="Back">${icon("back",20)}</button>
        <div class="meta">
          <div class="t">Log ${esc(slotName)}</div>
          <div class="s">
            <span class="due-pill tone-${due.tone}">${esc(due.label)}</span>
            ${upTo>0?`<span>up to ${upTo} point${upTo===1?"":"s"}</span>`:""}
          </div>
        </div>
      </div>

      <!-- data-vt="plate": the frame is the one thing that does NOT change when the shutter fires.
           Marking it on both this stage and the confirm screen's photo makes the live view cross-fade
           into the still INSIDE a box that holds still, which is what a shutter actually does. -->
      <div class="cam-stage" id="viewfinder" data-vt="plate">
        <video id="vf-video" autoplay playsinline muted style="display:none"></video>
        <div class="vf-flash" id="vf-flash"></div>
        <div class="vf-empty" id="vf-fallback" data-mode="starting">
          <div class="vf-lens">${icon("camera",30)}</div>
          <div class="vf-state" data-when="starting">
            <div class="vf-prompt">Opening the camera</div>
            <div class="vf-hint">One second.</div>
          </div>
          <div class="vf-state" data-when="offline">
            <div class="vf-prompt">Take a photo to analyze</div>
            <div class="vf-hint">Tap the shutter, your camera opens.</div>
          </div>
          ${""}
          <div class="vf-state" data-when="denied">
            <div class="vf-prompt">Camera access is off for OnStandard</div>
            <div class="vf-hint">Turn it on in your phone's Settings, or use Gallery or Search food below.</div>
          </div>
        </div>
      </div>

      <input type="file" accept="image/*" capture="environment" id="cam-file" style="display:none" />
      <input type="file" accept="image/*" id="cam-gallery" style="display:none" />
      <div class="cam-deck">
        <div class="cam-guide">
          <b>Everything you're having, in one frame.</b>
          <span>Plate \xB7 Drink \xB7 Sides \xB7 Sauces \xB7 Supplements</span>
        </div>
        <div id="cam-note" class="cam-alert"></div>
        <div class="cam-actions">
          <button class="cam-side" type="button" id="gallery-btn"><span class="cbtn">${icon("image",19)}</span>Gallery</button>
          <button class="shutter" type="button" id="shutter" aria-label="Take the photo"><span class="inner">${icon("camera",26)}</span></button>
          <button class="cam-side" type="button" data-go="food-search"><span class="cbtn">${icon("search",20)}</span>Search food</button>
        </div>
      </div>
    </div>`},mount(root,{sub}={}){if(!RT.camPrimed)return;const file=root.querySelector("#cam-file");const gallery=root.querySelector("#cam-gallery");const shutter=root.querySelector("#shutter");const galleryBtn=root.querySelector("#gallery-btn");const video=root.querySelector("#vf-video");const fallbackUi=root.querySelector("#vf-fallback");const flash=root.querySelector("#vf-flash");let stream=null;let liveReady=false;const stopStream=()=>{liveReady=false;if(stream){try{stream.getTracks().forEach(t=>t.stop())}catch{}stream=null}if(video){try{video.srcObject=null}catch{}}};const onHide=()=>{if(document.visibilityState!=="visible")stopStream()};document.addEventListener("visibilitychange",onHide);window.__screenCleanup=()=>{document.removeEventListener("visibilitychange",onHide);stopStream();stopWatchdog()};const goOffline=()=>{if(fallbackUi)fallbackUi.dataset.mode="offline"};const goDenied=()=>{if(fallbackUi)fallbackUi.dataset.mode="denied"};let wake=setTimeout(goOffline,2500);const stopWatchdog=()=>{clearTimeout(wake);wake=null};const startLive=async()=>{if(!(navigator.mediaDevices&&navigator.mediaDevices.getUserMedia)||!video){stopWatchdog();goOffline();return}try{stream=await navigator.mediaDevices.getUserMedia({video:{facingMode:"environment",width:{ideal:1920},height:{ideal:1440}},audio:false});video.srcObject=stream;await video.play().catch(()=>{});const armed=()=>{if(video.videoWidth>0){liveReady=true;stopWatchdog();video.style.display="block";if(fallbackUi)fallbackUi.style.display="none"}};if(video.videoWidth>0)armed();else video.addEventListener("loadedmetadata",armed,{once:true})}catch(err){stopStream();stopWatchdog();const name=err&&err.name;if(name==="NotAllowedError"||name==="PermissionDeniedError"||name==="SecurityError")goDenied();else goOffline()}};void startLive();const failNote=()=>{shutter.style.opacity="1";const note=root.querySelector("#cam-note");if(note){note.innerHTML=`Couldn't get the photo. Check camera access, or <span class="lnk">log without a camera</span>.`;note.querySelector(".lnk").addEventListener("click",()=>window.__go("food-search"))}};const pick=(inputEl,live)=>async()=>{const f=inputEl.files&&inputEl.files[0];if(!f)return;shutter.style.opacity="0.5";try{let takenAt=null;if(!live){try{const{exifDateTimeOriginal}=await import("../photo-hash.js");takenAt=exifDateTimeOriginal(new Uint8Array(await f.arrayBuffer()))}catch{}}const{base64,dataUrl,stats}=await downscaleToJpeg(f,1e3,.82);act.captureMeal(base64,dataUrl,sub||void 0,live,{takenAt,stats});window.__go("camera-confirm",{dir:"push",vt:"plate"})}catch{failNote()}};const captureLiveFrame=()=>{try{hapticTap("medium");if(flash){flash.classList.remove("on");void flash.offsetWidth;flash.classList.add("on")}const{base64,dataUrl,stats}=encodeToJpeg(video,video.videoWidth,video.videoHeight,1e3,.82);act.captureMeal(base64,dataUrl,sub||void 0,true,{stats});stopStream();setTimeout(()=>window.__go("camera-confirm",{dir:"push",vt:"plate"}),120)}catch{failNote()}};if(shutter){shutter.addEventListener("click",()=>{if(liveReady&&video&&video.videoWidth>0)captureLiveFrame();else if(file)file.click()})}if(file)file.addEventListener("change",pick(file,true));if(gallery&&galleryBtn){galleryBtn.addEventListener("click",()=>gallery.click());gallery.addEventListener("change",pick(gallery,false))}}};export const cameraConfirm={tab:"camera",hideTabs:true,fill:true,bleed:true,transient:true,render(){if(!MEAL.photoDataUrl){if(location.hash.startsWith("#camera-confirm"))location.hash="#camera";return""}const gallery=MEAL.source==="gallery";const age=gallery?photoAgeBadge(MEAL.takenAt,Date.now()):null;const slotName=MEAL.key&&slotTitle(MEAL.key)||MEAL.mealType||"Meal";const due=MEAL.key?mealDueState(MEAL.key):null;const pq=photoQuality(MEAL.photoQ);return`
    <div class="cam cam-confirm">
      <h1 class="sr-only">Review photo</h1>
      <div class="cam-head">
        <button class="bk iconbtn" type="button" id="cc-back" aria-label="Back">${icon("back",20)}</button>
        <div class="meta">
          <div class="t">Review photo</div>
          ${""}
          <div class="s">
            <span class="due-pill">${icon("utensils",13)} ${esc(slotName)}</span>
            ${due?`<span class="due-pill tone-${due.tone}">${icon("clock",13)} ${esc(due.label)}</span>`:""}
          </div>
        </div>
      </div>
      ${""}
      <div class="cam-stage">
        ${""}
        <div class="cc-frame">
          <img class="cc-photo" data-vt="plate" src="${safeImg(MEAL.photoDataUrl)}" alt="The ${esc(slotName)} photo you are about to log" />
          ${""}
          ${gallery?`<div class="cc-badges">${nonLiveBadge()}${age?`<span class="status-pill ${age.cls}">${icon("clock",12)} ${esc(age.text)}</span>`:""}</div>`:""}
        </div>
        ${""}
        <div class="cc-check">
          <span class="cc-check-ic">${icon("checkCircle",26)}</span>
          <span class="cc-check-txt"><b>Everything included?</b><span>Make sure all food and drinks are visible.</span></span>
        </div>
      </div>
      <div class="cam-deck">
        ${""}
        ${pq&&pq.state!=="met"?`<div class="cam-alert">${esc(pq.hint)}</div>`:""}
        <div id="cc-note" class="cam-alert"></div>
        ${""}
        <details class="cc-details"${MEAL.userNote?" open":""}>
          <summary>
            <span class="cc-details-ic">${icon("edit",18)}</span>
            <span class="cc-details-txt"><b>Add meal details</b><span>Sauces, portions, ingredients, restaurant, etc.</span></span>
            <span class="opt">Optional</span>
            <span class="cc-details-chev">${icon("chevron",18)}</span>
          </summary>
          <div class="cc-details-body">
            <textarea id="cc-user-note" aria-label="Meal details" maxlength="240" rows="2"
              placeholder="Sauce type, cooking method, oil used, portion changes, refills\u2026">${esc(MEAL.userNote||"")}</textarea>
            <div class="cc-details-hint">Notes improve the analysis, but everything consumed should still be shown in the photo.</div>
          </div>
        </details>
        ${""}
        <div class="cc-actions">
          <button class="btn primary" type="button" id="cc-analyze">${icon("camera",20)} Use this photo</button>
          <button class="cc-alt" type="button" id="cc-retake">${gallery?"Choose another":"Retake"}</button>
        </div>
      </div>
      <input type="file" accept="image/*" id="cc-repick" style="display:none" />
    </div>`},async mount(root){if(!MEAL.photoDataUrl)return;const gallery=MEAL.source==="gallery";const noteField=root.querySelector("#cc-user-note");const saveNote=()=>{if(noteField)act.setMealNote(noteField.value)};if(noteField)noteField.addEventListener("change",saveNote);const retake=()=>{saveNote();const slot=MEAL.key;act.clearMeal();window.__go(slot?`camera/${slot}`:"camera")};const repick=root.querySelector("#cc-repick");const rePickNow=async()=>{const f=repick.files&&repick.files[0];if(!f)return;try{let takenAt=null;try{const{exifDateTimeOriginal}=await import("../photo-hash.js");takenAt=exifDateTimeOriginal(new Uint8Array(await f.arrayBuffer()))}catch{}const{base64,dataUrl,stats}=await downscaleToJpeg(f,1e3,.82);act.captureMeal(base64,dataUrl,MEAL.key||void 0,false,{takenAt,stats});window.__render&&window.__render()}catch{}};const back=root.querySelector("#cc-back");const rt=root.querySelector("#cc-retake");if(back)back.addEventListener("click",retake);if(rt){if(gallery&&repick){rt.addEventListener("click",()=>{saveNote();repick.click()});repick.addEventListener("change",rePickNow)}else rt.addEventListener("click",retake)}const analyzeBtn=root.querySelector("#cc-analyze");const note=root.querySelector("#cc-note");if(analyzeBtn)analyzeBtn.addEventListener("click",()=>{saveNote();const slot=MEAL.key||"dinner";act.logMeal(slot);window.__go("analyzing/"+slot,{dir:"push",vt:"plate"})});try{const r=await act.checkPhotoReuse();if(r&&r.reused&&root.isConnected){const p=r.prior||{};const when=p.day_date?`as ${String(p.meal_type||"a meal")} on ${String(p.day_date)}`:"once";if(note)note.textContent=`This exact photo was already logged ${when}. Pick a different photo, repeats don't count.`;if(analyzeBtn){analyzeBtn.disabled=true;analyzeBtn.textContent="Already logged"}}}catch{}}};
