import { S, RT, act, MEAL, slotTitle, mealDueState } from '../state.js';
import { icon } from '../icons.js';
import { esc, safeImg, nonLiveBadge } from '../components.js';
import { photoAgeBadge } from '../photo-hash.js';
import { photoStats, photoQuality } from '../meal-intel.js';

/* ---- shared JPEG encode: one canvas pipeline for live frames AND picked files ----
   Downscale (max side) + JPEG-encode → { dataUrl, base64 }. Keeps the upload well under the
   8MB analyze-meal limit and fast to send. Also MEASURES photo quality (brightness + edge
   energy on a 96px sample of the same canvas — real numbers, ~1ms) so the review step can
   give honest capture feedback and the rubric can carry a measured photo-quality row. */
function encodeToJpeg(source, srcW, srcH, maxDim, quality) {
  let w = srcW, h = srcH;
  const scale = Math.min(1, maxDim / Math.max(w, h));
  w = Math.max(1, Math.round(w * scale)); h = Math.max(1, Math.round(h * scale));
  const cv = document.createElement('canvas'); cv.width = w; cv.height = h;
  cv.getContext('2d').drawImage(source, 0, 0, w, h);
  const dataUrl = cv.toDataURL('image/jpeg', quality);
  let stats = null;
  try {
    const sw = Math.max(1, Math.min(96, w)), sh = Math.max(1, Math.round(sw * (h / w)));
    const sc = document.createElement('canvas'); sc.width = sw; sc.height = sh;
    const sctx = sc.getContext('2d');
    sctx.drawImage(cv, 0, 0, sw, sh);
    const d = sctx.getImageData(0, 0, sw, sh);
    stats = photoStats(d.data, sw, sh);
  } catch { /* measurement is best-effort — capture always proceeds */ }
  return { dataUrl, base64: dataUrl.split(',')[1], stats };
}
function downscaleToJpeg(file, maxDim, quality) {
  return new Promise((resolve, reject) => {
    const url = URL.createObjectURL(file);
    const img = new Image();
    img.onload = () => {
      URL.revokeObjectURL(url);
      try { resolve(encodeToJpeg(img, img.width, img.height, maxDim, quality)); } catch (e) { reject(e); }
    };
    img.onerror = reject;
    img.src = url;
  });
}

const hapticTap = (style) => { try { window.OnStandardNative && window.OnStandardNative.haptic(style || 'medium'); } catch { /* web */ } };

export default {
  tab: 'camera',
  hideTabs: true,
  fill: true,  // owns its own vertical rhythm: the stage takes the slack, the deck anchors bottom
  bleed: true, // the stage runs to the screen edges; .cam-head / .cam-deck own their safe areas
  transient: true, // flow interstitial: never a back-target — Done/Back from the flow returns to the pre-camera origin
  render({ sub } = {}) {
    const L = S.logging;
    const slotName = sub ? slotTitle(sub) : L.name; // coach-standard title, never raw "Meal-5"
    const slotKey = sub || S.currentSlot;
    const upTo = slotKey ? S.mealUpTo(slotKey) : 0;
    // The deadline must come from THIS slot, not S.logging's — logging re-derives the next open
    // slot by clock, so arriving from Home's Dinner row before 5:00 PM used to print the SNACK
    // deadline under a "Log Dinner" header ("Opens 6:00 PM" on Home vs "Due by 5:00 PM" here).
    // mealDueState adds the honest read on top: this line used to be amber at every hour of the
    // day, so an athlete an hour PAST the window saw the same colour as one two hours early.
    const due = slotKey ? mealDueState(slotKey) : { label: L.due, tone: 'quiet' };
    // Apple-style permission priming: explain BEFORE the OS ever asks
    if (!RT.camPrimed) {
      return `
      <div class="ob" style="padding-top:40px">
        <h1 class="sr-only">Camera, for proof</h1>
        <div class="standard-set" style="padding-top:10px">
          <div class="halo"><div class="core" style="background:linear-gradient(155deg, var(--green), var(--green-deep))">${icon('camera', 34)}</div></div>
          <div class="ob-title" style="margin-top:22px">Camera, for proof.</div>
          <div class="ob-sub" style="padding:0 8px">OnStandard uses your camera to capture meal photos. They go to your coach connection only: never public, never sold, never used to train anything without asking.</div>
        </div>
        <div class="ob-foot" style="margin-top:auto">
          <button class="btn primary" data-act="primeCamera" data-then="camera">Allow camera</button>
          <button class="cam-textlink" type="button" data-go="food-search">Log without a camera</button>
        </div>
      </div>`;
    }
    // LIVE-FIRST: mount() tries getUserMedia and, on success, reveals #vf-video and hides the
    // fallback prompt — the camera is already open and the green shutter captures THIS frame.
    // On any failure the prompt stays and the shutter opens the native camera exactly as before.
    return `
    <div class="cam">
      <h1 class="sr-only">Log ${esc(slotName)}</h1>
      <div class="cam-head">
        <button class="bk iconbtn" type="button" data-back="home" aria-label="Back">${icon('back', 20)}</button>
        <div class="meta">
          <div class="t">Log ${esc(slotName)}</div>
          <div class="s">
            <span class="due-pill tone-${due.tone}">${esc(due.label)}</span>
            ${upTo > 0 ? `<span>up to ${upTo} point${upTo === 1 ? '' : 's'}</span>` : ''}
          </div>
        </div>
      </div>

      <!-- data-vt="plate": the frame is the one thing that does NOT change when the shutter fires.
           Marking it on both this stage and the confirm screen's photo makes the live view cross-fade
           into the still INSIDE a box that holds still, which is what a shutter actually does. -->
      <div class="cam-stage" id="viewfinder" data-vt="plate">
        <video id="vf-video" autoplay playsinline muted style="display:none"></video>
        <div class="vf-flash" id="vf-flash"></div>
        <div class="vf-empty" id="vf-fallback" data-mode="starting">
          <div class="vf-lens">${icon('camera', 30)}</div>
          <div class="vf-state" data-when="starting">
            <div class="vf-prompt">Opening the camera</div>
            <div class="vf-hint">One second.</div>
          </div>
          <div class="vf-state" data-when="offline">
            <div class="vf-prompt">Take a photo to analyze</div>
            <div class="vf-hint">Tap the shutter, your camera opens.</div>
          </div>
          ${''/* Denied is its own state, not "starting" forever: getUserMedia said NO, and the only
               fix lives in the OS Settings app. Honest copy plus the two paths that still work. */}
          <div class="vf-state" data-when="denied">
            <div class="vf-prompt">Camera access is off for OnStandard</div>
            <div class="vf-hint">Turn it on in your phone's Settings, or use Gallery or Search food below.</div>
          </div>
        </div>
      </div>

      <input type="file" accept="image/*" capture="environment" id="cam-file" style="display:none" />
      <input type="file" accept="image/*" id="cam-gallery" style="display:none" />
      <div class="cam-deck">
        <div class="cam-guide">
          <b>Everything you're having, in one frame.</b>
          <span>Plate · Drink · Sides · Sauces · Supplements</span>
        </div>
        <div id="cam-note" class="cam-alert"></div>
        <div class="cam-actions">
          <button class="cam-side" type="button" id="gallery-btn"><span class="cbtn">${icon('image', 19)}</span>Gallery</button>
          <button class="shutter" type="button" id="shutter" aria-label="Take the photo"><span class="inner">${icon('camera', 26)}</span></button>
          <button class="cam-side" type="button" data-go="food-search"><span class="cbtn">${icon('search', 20)}</span>Search food</button>
        </div>
      </div>
    </div>`;
  },
  mount(root, { sub } = {}) {
    if (!RT.camPrimed) return; // priming screen has no capture wiring
    const file = root.querySelector('#cam-file');
    const gallery = root.querySelector('#cam-gallery');
    const shutter = root.querySelector('#shutter');
    const galleryBtn = root.querySelector('#gallery-btn');
    const video = root.querySelector('#vf-video');
    const fallbackUi = root.querySelector('#vf-fallback');
    const flash = root.querySelector('#vf-flash');

    /* ---- live preview (getUserMedia inside the WebView; ProtoApp grants the permission) ---- */
    let stream = null;
    let liveReady = false;
    const stopStream = () => {
      liveReady = false;
      if (stream) { try { stream.getTracks().forEach((t) => t.stop()); } catch { /* already dead */ } stream = null; }
      if (video) { try { video.srcObject = null; } catch { /* detached */ } }
    };
    const onHide = () => { if (document.visibilityState !== 'visible') stopStream(); };
    document.addEventListener('visibilitychange', onHide);
    // Router calls window.__screenCleanup before every re-render/route change — the stream must
    // never keep the camera light on behind another screen.
    window.__screenCleanup = () => { document.removeEventListener('visibilitychange', onHide); stopStream(); stopWatchdog(); };

    // Until getUserMedia answers, the frame is genuinely "starting", not "no camera here" — the
    // fallback copy used to render as the FIRST thing every athlete saw, so the normal path
    // opened on a message describing the failure path. goOffline() is the only thing that
    // promotes it to the real fallback.
    const goOffline = () => { if (fallbackUi) fallbackUi.dataset.mode = 'offline'; };
    // Permission DENIED is not "still starting" and not the generic fallback: nothing here will
    // ever produce a frame until the athlete flips the OS switch, so the copy says that.
    const goDenied = () => { if (fallbackUi) fallbackUi.dataset.mode = 'denied'; };
    // A permission grant is not a frame. A track can resolve and then never arm — the OS prompt
    // sits open, the device is held by another app, the track has zero dimensions — and none of
    // those reject, so waiting on the catch alone leaves the athlete reading "Opening the camera"
    // with no way forward. After 2.5s the copy tells the truth instead: tap the shutter and the
    // native camera opens, which is a path that has always worked. If the frame arms later,
    // armed() hides this whole block anyway, so the watchdog costs nothing when the camera is fine.
    let wake = setTimeout(goOffline, 2500);
    const stopWatchdog = () => { clearTimeout(wake); wake = null; };
    const startLive = async () => {
      if (!(navigator.mediaDevices && navigator.mediaDevices.getUserMedia) || !video) { stopWatchdog(); goOffline(); return; }
      try {
        stream = await navigator.mediaDevices.getUserMedia({
          video: { facingMode: 'environment', width: { ideal: 1920 }, height: { ideal: 1440 } },
          audio: false,
        });
        video.srcObject = stream;
        await video.play().catch(() => { /* autoplay policies — frame still renders muted */ });
        // Only claim "live" once real frames exist; a zero-dimension track falls back silently.
        const armed = () => {
          if (video.videoWidth > 0) {
            liveReady = true;
            stopWatchdog();
            video.style.display = 'block';
            if (fallbackUi) fallbackUi.style.display = 'none';
          }
        };
        if (video.videoWidth > 0) armed();
        else video.addEventListener('loadedmetadata', armed, { once: true });
      } catch (err) {
        stopStream(); stopWatchdog();
        // NotAllowedError (and WebKit's older spellings) = the permission is off. Everything
        // else (device busy, no camera) keeps the generic file-input fallback copy.
        const name = err && err.name;
        if (name === 'NotAllowedError' || name === 'PermissionDeniedError' || name === 'SecurityError') goDenied();
        else goOffline();
      }
    };
    void startLive();

    /* ---- capture paths: live frame OR picked file, both land on #camera-confirm ---- */
    const failNote = () => {
      shutter.style.opacity = '1';
      const note = root.querySelector('#cam-note');
      // food-search, not 'log': the Action Hub's photo hero routes straight back to the
      // camera that just failed — matching the primed screen's no-camera path. The router
      // only wires [data-go] at render time, so this post-mount injection wires its own tap.
      if (note) {
        note.innerHTML = `Couldn't get the photo. Check camera access, or <span class="lnk">log without a camera</span>.`;
        note.querySelector('.lnk').addEventListener('click', () => window.__go('food-search'));
      }
    };

    const pick = (inputEl, live) => async () => {
      const f = inputEl.files && inputEl.files[0];
      if (!f) return;
      shutter.style.opacity = '0.5';
      try {
        // Gallery picks: read EXIF DateTimeOriginal from the ORIGINAL bytes before the canvas
        // re-encode strips it — powers the staleness transparency badge (0062).
        let takenAt = null;
        if (!live) {
          try {
            const { exifDateTimeOriginal } = await import('../photo-hash.js');
            takenAt = exifDateTimeOriginal(new Uint8Array(await f.arrayBuffer()));
          } catch { /* EXIF absent/unreadable — normal, no badge */ }
        }
        const { base64, dataUrl, stats } = await downscaleToJpeg(f, 1000, 0.82);
        act.captureMeal(base64, dataUrl, sub || undefined, live, { takenAt, stats });
        window.__go('camera-confirm', { dir: 'push', vt: 'plate' });
      } catch { failNote(); }
    };

    const captureLiveFrame = () => {
      try {
        hapticTap('medium');
        if (flash) { flash.classList.remove('on'); void flash.offsetWidth; flash.classList.add('on'); }
        const { base64, dataUrl, stats } = encodeToJpeg(video, video.videoWidth, video.videoHeight, 1000, 0.82);
        act.captureMeal(base64, dataUrl, sub || undefined, true, { stats });
        stopStream();
        // Let the flash read as a shutter click before the route swap.
        setTimeout(() => window.__go('camera-confirm', { dir: 'push', vt: 'plate' }), 120);
      } catch { failNote(); }
    };

    if (shutter) {
      shutter.addEventListener('click', () => {
        if (liveReady && video && video.videoWidth > 0) captureLiveFrame();
        else if (file) file.click(); // silent fallback: native OS camera, exactly as before
      });
    }
    if (file) file.addEventListener('change', pick(file, true));
    if (gallery && galleryBtn) {
      galleryBtn.addEventListener('click', () => gallery.click());
      gallery.addEventListener('change', pick(gallery, false));
    }
  },
};

/* ---------- Capture confirm — "is this the photo you want analyzed?" ----------
   One gate for EVERY path (live frame, native camera, gallery). Nothing has been logged or
   analyzed yet: Analyze runs the 0062 duplicate pre-check, then hands off to #analyzing;
   Retake clears the staged capture and returns to the viewfinder. */
export const cameraConfirm = {
  tab: 'camera',
  hideTabs: true,
  fill: true,  // same skeleton as the viewfinder: stage takes the slack, deck anchors bottom
  bleed: true, // the photo runs to the screen edges, exactly where the live preview was
  transient: true,
  render() {
    if (!MEAL.photoDataUrl) {
      // Deep link / stale entry with nothing staged: back to capture, never a blank screen.
      if (location.hash.startsWith('#camera-confirm')) location.hash = '#camera';
      return '';
    }
    const gallery = MEAL.source === 'gallery';
    // Escalating provenance: a 20-hour-old photo filed as this morning's breakfast is the most
    // important fact on this screen and used to wear the same grey as a four-minute-old one.
    const age = gallery ? photoAgeBadge(MEAL.takenAt, Date.now()) : null;
    const slotName = (MEAL.key && slotTitle(MEAL.key)) || MEAL.mealType || 'Meal';
    const due = MEAL.key ? mealDueState(MEAL.key) : null;
    // Measured capture feedback (spec §4.7): brightness + sharpness from the capture canvas — a
    // gentle nudge, never a block. Silent when the photo reads clear.
    const pq = photoQuality(MEAL.photoQ);
    return `
    <div class="cam cam-confirm">
      <h1 class="sr-only">Review photo</h1>
      <div class="cam-head">
        <button class="bk iconbtn" type="button" id="cc-back" aria-label="Back">${icon('back', 20)}</button>
        <div class="meta">
          <div class="t">Review photo</div>
          ${''/* Two facts, two pills (redesign 2026-09-02, founder reference): the meal slot and its
               deadline sit side by side in the same vocabulary instead of a grey word next to a
               pill. The due pill keeps its earned hue. */}
          <div class="s">
            <span class="due-pill">${icon('utensils', 13)} ${esc(slotName)}</span>
            ${due ? `<span class="due-pill tone-${due.tone}">${icon('clock', 13)} ${esc(due.label)}</span>` : ''}
          </div>
        </div>
      </div>
      ${''/* The caption belongs to the PHOTO, so it lives in the stage with it. In the deck it
           anchored to the deck's top edge instead, which on a wide plate left 130px of nothing
           between the image and the line describing it. As one unit the pair can also centre in
           whatever space the header and deck leave. */}
      <div class="cam-stage">
        ${''/* .cc-frame shrinks to the pixels the photo actually paints, so the stamps below can
             be positioned against the IMAGE rather than against its box. Without it a portrait
             photo (letterboxed inside a full-width box) left the stamps hanging 4px off the
             picture and onto the page. */}
        <div class="cc-frame">
          <img class="cc-photo" data-vt="plate" src="${safeImg(MEAL.photoDataUrl)}" alt="The ${esc(slotName)} photo you are about to log" />
          ${''/* Provenance is STAMPED ON THE EVIDENCE (founder call), not filed in the header: it
               describes this photograph, not the state of the screen, and reads like a mark on a
               document rather than another status row. Two stamps, because source and age are two
               facts a coach may care about independently. They keep the escalating age band, and
               .cc-badges gives them an opaque ground so a red stamp survives a white plate.
               Absolutely positioned, so they cost the photo no height. */}
          ${gallery ? `<div class="cc-badges">${nonLiveBadge()}${age
            ? `<span class="status-pill ${age.cls}">${icon('clock', 12)} ${esc(age.text)}</span>`
            : ''}</div>` : ''}
        </div>
        ${''/* The completeness check reads as a checklist item (founder reference, 2026-09-02):
             a green check mark, a question, and the one thing to look for. It is the only
             instruction on the screen and it now looks like one. */}
        <div class="cc-check">
          <span class="cc-check-ic">${icon('checkCircle', 26)}</span>
          <span class="cc-check-txt"><b>Everything included?</b><span>Make sure all food and drinks are visible.</span></span>
        </div>
      </div>
      <div class="cam-deck">
        ${''/* The capture screen taught "everything in one frame" seconds ago; repeating the
             full two-line guide here was the clutter. The completeness reminder (§5.4) survives
             as the check row above, and only the conditional alerts may speak here. */}
        ${pq && pq.state !== 'met' ? `<div class="cam-alert">${esc(pq.hint)}</div>` : ''}
        <div id="cc-note" class="cam-alert"></div>
        ${''/* A card row, not a bare disclosure line: icon tile, title, what to put in it,
             an Optional pill, and a chevron that turns when open. The textarea lives inside the
             same card so opening it never adds a second box. */}
        <details class="cc-details"${MEAL.userNote ? ' open' : ''}>
          <summary>
            <span class="cc-details-ic">${icon('edit', 18)}</span>
            <span class="cc-details-txt"><b>Add meal details</b><span>Sauces, portions, ingredients, restaurant, etc.</span></span>
            <span class="opt">Optional</span>
            <span class="cc-details-chev">${icon('chevron', 18)}</span>
          </summary>
          <div class="cc-details-body">
            <textarea id="cc-user-note" aria-label="Meal details" maxlength="240" rows="2"
              placeholder="Sauce type, cooking method, oil used, portion changes, refills…">${esc(MEAL.userNote || '')}</textarea>
            <div class="cc-details-hint">Notes improve the analysis, but everything consumed should still be shown in the photo.</div>
          </div>
        </details>
        ${''/* One decision, full width, in the app's blue action accent; the alternative is a quiet
             text action beneath it rather than a second button competing at equal weight. */}
        <div class="cc-actions">
          <button class="btn primary" type="button" id="cc-analyze">${icon('camera', 20)} Use this photo</button>
          <button class="cc-alt" type="button" id="cc-retake">${gallery ? 'Choose another' : 'Retake'}</button>
        </div>
      </div>
      <input type="file" accept="image/*" id="cc-repick" style="display:none" />
    </div>`;
  },
  async mount(root) {
    if (!MEAL.photoDataUrl) return;
    const gallery = MEAL.source === 'gallery';
    const noteField = root.querySelector('#cc-user-note');
    const saveNote = () => { if (noteField) act.setMealNote(noteField.value); };
    if (noteField) noteField.addEventListener('change', saveNote);
    const retake = () => {
      saveNote();
      const slot = MEAL.key;
      act.clearMeal();
      window.__go(slot ? `camera/${slot}` : 'camera');
    };
    // Gallery source: "Choose another" re-picks in place — no round-trip through the camera.
    const repick = root.querySelector('#cc-repick');
    const rePickNow = async () => {
      const f = repick.files && repick.files[0];
      if (!f) return;
      try {
        let takenAt = null;
        try {
          const { exifDateTimeOriginal } = await import('../photo-hash.js');
          takenAt = exifDateTimeOriginal(new Uint8Array(await f.arrayBuffer()));
        } catch { /* EXIF absent — no badge */ }
        const { base64, dataUrl, stats } = await downscaleToJpeg(f, 1000, 0.82);
        act.captureMeal(base64, dataUrl, MEAL.key || undefined, false, { takenAt, stats });
        window.__render && window.__render();
      } catch { /* keep the current photo */ }
    };
    const back = root.querySelector('#cc-back');
    const rt = root.querySelector('#cc-retake');
    if (back) back.addEventListener('click', retake);
    if (rt) {
      if (gallery && repick) {
        rt.addEventListener('click', () => { saveNote(); repick.click(); });
        repick.addEventListener('change', rePickNow);
      } else rt.addEventListener('click', retake);
    }
    const analyzeBtn = root.querySelector('#cc-analyze');
    const note = root.querySelector('#cc-note');
    // LOG FIRST, READ AFTER. The athlete's day is theirs again immediately: the meal is committed
    // now (photo + timing credit, exactly as a manually-logged meal scores) and the analysis
    // continues in the background, landing in the thread. The old flow held them on a spinner for
    // the whole vision call before anything counted.
    if (analyzeBtn) analyzeBtn.addEventListener('click', () => {
      saveNote();
      const slot = MEAL.key || 'dinner';
      act.logMeal(slot);
      // …by way of the scan. Log-first is right and stays: the meal is already committed here and
      // the outbox owns the read. But cutting straight to the thread meant the athlete's photo was
      // never visibly LOOKED at — the most satisfying feedback in the app disappeared, and logging
      // started to feel like nothing happened. #analyzing now shows the work for a beat with a hard
      // ceiling, and hands off whether or not the read has landed. It starts no analysis of its own.
      window.__go('analyzing/' + slot, { dir: 'push', vt: 'plate' });
    });
    // Duplicate pre-check (0062), free and before the paid analyze call. Fail-open: offline the
    // button stays enabled and the server's unique index still backstops at insert time.
    try {
      const r = await act.checkPhotoReuse();
      if (r && r.reused && root.isConnected) {
        const p = r.prior || {};
        const when = p.day_date ? `as ${String(p.meal_type || 'a meal')} on ${String(p.day_date)}` : 'once';
        // textContent, so the server strings render inert — no escaping needed here.
        if (note) note.textContent = `This exact photo was already logged ${when}. Pick a different photo, repeats don't count.`;
        // `.btn:disabled` already owns the disabled treatment; an inline opacity on top of it was
        // a second vocabulary for the same state.
        if (analyzeBtn) { analyzeBtn.disabled = true; analyzeBtn.textContent = 'Already logged'; }
      }
    } catch { /* pre-check is best-effort */ }
  },
};
