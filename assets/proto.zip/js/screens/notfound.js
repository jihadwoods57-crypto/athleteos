import{RT,routeForRole}from"../state.js";import{emptyState}from"../components.js";export default{hideTabs:true,anyRole:true,render({sub}={}){const home=routeForRole(RT.authRole||"athlete");const hash=(location.hash||"").replace(/^#/,"")||"(empty)";return`
    <h1 class="sr-only">Screen not found</h1>
    <div class="nf-wrap">
      ${emptyState({icon:"search",title:"That screen doesn't exist",body:`Nothing lives at "${hash}". The link is probably out of date. Your home screen is one tap away and nothing you logged was lost.`,action:{label:"Go to my home",go:home}})}
    </div>`},mount(){console.warn("[router] no screen registered for hash",location.hash)}};
