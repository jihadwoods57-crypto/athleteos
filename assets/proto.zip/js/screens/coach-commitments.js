import{RT}from"../state.js";import{icon}from"../icons.js";import{DAYS_SHORT}from"../fmt-date.js";import{track,EVENTS}from"../analytics.js";import{backHead,esc,errorState,skeletonRows,segBar,emptyState}from"../components.js";import{CD,bookId}from"../coach-data.js";import{statusColor}from"../status.js";const cap=s=>s?s.charAt(0).toUpperCase()+s.slice(1):s;import{ensureBook,bookless,wireBookRetry,bookBack}from"./coach-connected.js";import{allowedCreateKeys,isReadonly}from"../staff-access.js";import{boardCounts,missingFrom,TYPE_LABEL,presenceOf,PRESENCE,groupByVerdict,verdictCounts,deadlineOf,closesAtOf,opensAtOf,graceMinOf,offsetFor,fmtAt,summarizeOccurrences,wakeupPhase,VERDICT,SOURCE,dayLabel,scheduleState,nextRollcall,reachCounts,ROLLCALL_OFF}from"../commitments.js";import{fmtMin}from"../requirements.js";import{VC,loadBoard,loadCommitments,loadLocations,saveCommitment,saveLocation,setResponse,remindMissing,setCommitmentActive,todayISO,pingAthlete,setInstanceMessage,loadRollcallSummary,resolveSyncReview,subscribeBoard,loadUpcoming,setInstanceSchedule,notifyScheduleChange}from"../commitment-data.js";import{editWakeup}from"./coach-wakeup.js";const hhmm=iso=>{if(!iso)return"";const d=new Date(iso);if(isNaN(d))return"";return d.toLocaleTimeString([],{hour:"numeric",minute:"2-digit"})};const canSchedule=()=>{if(CD.kind==="practice")return true;const role=CD.extras?CD.extras.myRole:null;if(!CD.extras)return true;return!isReadonly(role)&&allowedCreateKeys(role).includes("commitments")};export function commitmentBoardCard(){const rows=VC.board;if((!rows||!rows.length)&&VC.boardError){return`<section class="card pad" style="border-color:var(--amber-border);margin-bottom:10px">
      <div class="tt">Roll call didn\u2019t load</div>
      <div class="ts" style="padding-top:4px">This isn\u2019t a count of zero; we couldn\u2019t reach the server. It retries the next time you open this screen.</div>
    </section>`}if(!rows||!rows.length)return nextRollcallCard();return rows.map(inst=>{if(inst.type==="morning_roll_call")return wakeupHomeCard(inst);const c=boardCounts(inst.rows||[]);if(!c.total)return"";const ctx=[inst.audience_label||(CD.kind==="practice"?"All clients":"Entire team"),inst.linked_title&&inst.linked_starts_min!=null?`${inst.linked_title} at ${fmtMin(inst.linked_starts_min)}`:inst.starts_min!=null?fmtMin(inst.starts_min):""].filter(Boolean).join(" \xB7 ");const allIn=c.awaiting===0;return`
    <section class="card pad vc-board" data-go="coach-commitments/${esc(inst.instance_id)}" style="cursor:pointer;margin-bottom:10px">
      <h2 class="eyebrow" style="margin:0 0 6px">${esc(inst.title||TYPE_LABEL[inst.type]||"Commitment")}</h2>
      <div class="ts" style="padding-bottom:10px">${esc(ctx)}</div>
      ${segBar(c.responded,c.total,`${c.responded} of ${c.total} responded`)}
      <div style="display:flex;align-items:baseline;gap:10px;padding-top:8px">
        <div style="font-size:var(--t-2xl);font-weight:800;letter-spacing:-.02em;color:${allIn?statusColor({key:"on_standard"}):"var(--text)"}">
          ${c.responded} of ${c.total}</div>
        <div style="font-size:var(--t-sm);font-weight:700;color:var(--text-2)">in</div>
        <div style="flex:1"></div>
        <span class="status-pill ${allIn?"g":"a"}">${allIn?"All in":`${c.awaiting} awaiting`}</span>
      </div>
      ${c.excused||c.unverified||c.leftEarly?`<div class="ts" style="padding-top:8px">${[c.excused?`${c.excused} excused`:"",c.unverified?`${c.unverified} unverified`:"",c.leftEarly?`${c.leftEarly} left early`:""].filter(Boolean).join(" \xB7 ")}</div>`:""}
    </section>`}).filter(Boolean).join("")+nextRollcallCard()}function wakeupHomeCard(inst){const now=new Date().toISOString();const c=verdictCounts(inst,now);const phase=wakeupPhase(inst,now);if(!c.total){return`
    <section class="card pad vc-board wk-homecard" data-go="coach-commitments/${esc(inst.instance_id)}">
      <h2 class="eyebrow wk-cardh">${esc(inst.title||"Roll call")}</h2>
      <div class="wk-ctx">${esc(inst.audience_label||(CD.kind==="practice"?"All clients":"Entire team"))}</div>
      <div class="wk-homeline"><div class="wk-homel">Nobody is on this roll call yet. Open it to set who gets it.</div></div>
    </section>`}const ctx=[inst.audience_label||(CD.kind==="practice"?"All clients":"Entire team"),inst.starts_min!=null?fmtMin(inst.starts_min):""].filter(Boolean).join(" \xB7 ");const out=c.pending+c.stillOut+c.missed;const pill=c.review?`<span class="status-pill p">${c.review} to review</span>`:phase==="closed"?out?`<span class="status-pill r">${out} missed</span>`:'<span class="status-pill g">All in</span>':phase==="late"?out?`<span class="status-pill r">${out} still out</span>`:'<span class="status-pill g">All in</span>':out?`<span class="status-pill muted">${out} pending</span>`:'<span class="status-pill g">All in</span>';const target=phase==="closed"?"wakeup-morning":`coach-commitments/${esc(inst.instance_id)}`;return`
    <section class="card pad vc-board wk-homecard" data-go="${target}">
      <h2 class="eyebrow wk-cardh">${esc(inst.title||"Roll call")}</h2>
      <div class="wk-ctx">${esc(ctx)}</div>
      ${""}
      ${segBar(c.accountedFor,c.total,`${c.accountedFor} of ${c.total} accounted for`)}
      <div class="wk-homeline">
        <div class="wk-homen ${out||c.review?"":"g"}">${c.accountedFor} of ${c.total}</div>
        <div class="wk-homel">accounted for${c.overrides?` \xB7 ${c.overrides} override${c.overrides===1?"":"s"}`:""}</div>
        <div class="wk-spacer"></div>
        ${pill}
      </div>
      ${c.late||c.excused?`<div class="wk-sub">${[c.late?`${c.late} late`:"",c.excused?`${c.excused} excused`:""].filter(Boolean).join(" \xB7 ")}</div>`:""}
    </section>`}const SUMMARY={forId:null,rows:null,failed:false};let HIST_ALL=false;const BOARD_DAY_FOR=new Map;const LIVE={stop:null,phase:null};const UPCOMING={forId:null,rows:null,failed:false};const NEXT={forBook:null,commitmentId:null};let SKIP_ARMED=null;function dayStrip(inst){const rows=UPCOMING.forId===inst.commitment_id?UPCOMING.rows||[]:[];if(!rows.length)return"";const today=todayISO();return`<div class="wk-strip" role="tablist" aria-label="Which day">
    ${rows.map(o=>{const st=scheduleState(o);const on=o.instance_id===inst.instance_id;const label=dayLabel(o.occurs_on,today);const short=label==="Today"||label==="Tomorrow"?label:label.split(",")[0];return`<button class="chip ${on?"on":""} ${st.kind==="skipped"?"skip":""}" role="tab" aria-selected="${on?"true":"false"}"
        data-wk-day="${esc(o.occurs_on)}" data-wk-inst="${esc(o.instance_id)}" aria-label="${esc(label)}${st.kind==="skipped"?", skipped":""}">
        ${esc(short)}<small>${st.kind==="skipped"?"Skipped":esc(fmtMin(Number(o.starts_min)))}</small>${st.kind==="moved"?'<span class="wk-dot" aria-hidden="true"></span>':""}
      </button>`}).join("")}
  </div>`}function scheduleCard(inst,label){const st=scheduleState(inst);const skipped=st.kind==="skipped";const rule=inst.rule_starts_min!=null?Number(inst.rule_starts_min):null;const eff=inst.starts_min!=null?Number(inst.starts_min):rule;const hhmmOf=m=>m==null?"":`${String(Math.floor(m/60)).padStart(2,"0")}:${String(m%60).padStart(2,"0")}`;const who=inst.schedule_set_by_name&&inst.schedule_set_at?`${st.kind==="skipped"?"Skipped":st.kind==="moved"?"Moved":"Set"} by ${inst.schedule_set_by_name}${inst.note?` \xB7 ${inst.note}`:""}`:"";return`
  <section class="card wk-sched">
    <div class="wk-msgh"><h2 class="eyebrow wk-inline">${icon("clock",14)} ${esc(label)}\u2019s schedule</h2>
      ${canSchedule()?`<button class="btn ghost xs ${skipped?"":"danger"}" id="wk-skip" data-skipped="${skipped?"1":"0"}">${skipped?"Put it back":"Skip this day"}</button>`:""}</div>
    ${st.line?`<div class="wk-sched-line ${st.kind==="skipped"?"skip":"moved"}">${esc(st.line)}</div>`:`<div class="wk-sched-line">On the standing schedule${rule!=null?`, ${esc(fmtMin(rule))}`:""}. Change it for this day only below.</div>`}
    ${who?`<div class="wk-sched-who">${esc(who)}</div>`:""}
    ${noticeLine(inst,st)}
    ${!skipped&&canSchedule()?`
    <div class="wk-field">
      <div class="wk-l">Wake-up time this day</div>
      <input class="ob-input wk-time" id="wk-sched-time" type="time" aria-describedby="wk-sched-err" value="${esc(hhmmOf(eff))}" aria-label="Wake-up time for ${esc(label)}" />
      <div class="ts wk-hint">Grace and close move with it. ${st.kind==="moved"?`<button class="btn ghost xs" id="wk-sched-reset">Back to ${esc(fmtMin(rule))}</button>`:"The standing rule stays as it is."}</div>
    </div>`:""}
    <div id="wk-sched-err" class="ts wk-err" aria-live="polite"></div>
  </section>`}function noticeLine(inst,st){if(st.kind==="standing"&&!inst.schedule_notified_at)return"";const told=inst.schedule_notified_at?Date.parse(inst.schedule_notified_at):NaN;const changed=inst.schedule_set_at?Date.parse(inst.schedule_set_at):NaN;const stale=!isFinite(told)||isFinite(changed)&&changed>told;const toldAt=isFinite(told)?new Date(told).toLocaleTimeString([],{hour:"numeric",minute:"2-digit"}):"";return`<div class="wk-sched-who" id="wk-notice">${stale?`${isFinite(told)?`${cap(CD.nouns)} were told ${esc(toldAt)}, before this change. `:`${cap(CD.nouns)} have not been told. `}${canSchedule()?`<button class="btn ghost xs" id="wk-tell">Tell ${CD.nouns}</button>`:""}`:`${cap(CD.nouns)} were told ${esc(toldAt)}.`}</div>`}function nextRollcallCard(){const rows=!NEXT.commitmentId?null:UPCOMING.forId===NEXT.commitmentId?UPCOMING.rows:VC.upcomingFor(NEXT.commitmentId);if(!rows)return"";const now=new Date().toISOString();const next=nextRollcall(rows,now);if(!next)return"";const today=todayISO();if(next.occurs_on===today&&wakeupPhase(next,now)!=="closed")return"";const st=scheduleState(next);const label=dayLabel(next.occurs_on,today);const armed=SKIP_ARMED===next.instance_id;return`
    <section class="card pad vc-board wk-homecard wk-nextcard">
      <h2 class="eyebrow wk-cardh">Next roll call \xB7 ${esc(label)}</h2>
      <div class="wk-ctx">${st.kind==="skipped"?"Skipped":`${esc(fmtMin(Number(next.starts_min)))}${st.kind==="moved"?" \xB7 moved for this day":""}`}${Number(next.total)?next.reachable!=null&&Number(next.reachable)<Number(next.total)?` \xB7 ${next.reachable} of ${next.total} can get the push`:` \xB7 ${next.total} will get it`:""}</div>
      ${next.message&&st.kind!=="skipped"?`<div class="wk-nextmsg">\u201C${esc(String(next.message).slice(0,160))}${String(next.message).length>160?"\u2026":""}\u201D</div>`:""}
      <div class="wk-nextacts">
        <button class="chip on" data-wk-day="${esc(next.occurs_on)}" data-wk-inst="${esc(next.instance_id)}">${st.kind==="skipped"?"Open":"Change"}</button>
        ${canSchedule()?st.kind==="skipped"?`<button class="chip" data-wk-unskip="${esc(next.instance_id)}">Put it back</button>`:`<button class="chip ${armed?"on":""}" data-wk-skip="${esc(next.instance_id)}">${armed?`Skip ${esc(label.toLowerCase())}, for sure`:"Skip"}</button>`:""}
      </div>
    </section>`}export function seedScheduleForHarness({commitmentId,upcoming}={}){UPCOMING.forId=commitmentId||null;UPCOMING.rows=Array.isArray(upcoming)?upcoming:null;UPCOMING.failed=false;NEXT.forBook="harness";NEXT.commitmentId=commitmentId||null;SKIP_ARMED=null}async function ensureNext(){const bid=bookId();if(!bid)return;if(NEXT.forBook!==bid){NEXT.forBook=bid;NEXT.commitmentId=null}if(!NEXT.commitmentId){const fromBoard=(VC.board||[]).find(b=>b.type==="morning_roll_call");if(fromBoard)NEXT.commitmentId=fromBoard.commitment_id;else{const rows=await loadCommitments(bid,CD.kind);const rule=(rows||[]).find(r=>r.type==="morning_roll_call"&&r.active!==false);if(rule)NEXT.commitmentId=rule.id}}if(NEXT.commitmentId){const rows=await loadUpcoming(NEXT.commitmentId,7);if(rows){UPCOMING.forId=NEXT.commitmentId;UPCOMING.rows=rows;UPCOMING.failed=false}}}const ACK_SRC={lockscreen:"from the lock screen",app:"in the app"};function wakeupRow(r,kind,inst,clock,phase){const dl=deadlineOf(inst);const src=r.source===SOURCE.OVERRIDE?" \xB7 coach override":r.source===SOURCE.ACCEPTED?" \xB7 tap time accepted":r.source&&ACK_SRC[r.source]?` \xB7 ${ACK_SRC[r.source]}`:"";const when=kind==="on"||kind==="late"?r.source===SOURCE.OVERRIDE?`Marked ${clock(r.acknowledged_at)}${src}`:r.source===SOURCE.ACCEPTED?`Tapped ${clock(r.device_tapped_at||r.acknowledged_at)}${src}`:`${clock(r.acknowledged_at)}${src}`:kind==="review"?`Tapped ${clock(r.device_tapped_at)} on their phone \xB7 reached us ${clock(r.acknowledged_at)}`:kind==="ex"?r.excused_reason?`Excused by coach: ${r.excused_reason}`:"Excused by coach":(!r.pastGrace?"No answer yet":`No answer by ${clock(dl)}`)+(r.can_push===false?" \xB7 no push on their phone":r.first_notified_at?` \xB7 push sent ${clock(r.first_notified_at)}`:phase!=="before"?" \xB7 no push reached them":"");const pill=kind==="on"?r.source===SOURCE.OVERRIDE?'<span class="status-pill b">Override \xB7 On standard</span>':'<span class="status-pill g">On standard</span>':kind==="late"?`<span class="status-pill a">Late${r.lateMin?` \xB7 +${r.lateMin} min`:""}</span>`:kind==="review"?'<span class="status-pill p">Needs review</span>':kind==="ex"?'<span class="status-pill muted">Excused</span>':r.verdict===VERDICT.MISSED?'<span class="status-pill r">Missed</span>':r.pastGrace?'<span class="status-pill r">Still out</span>':'<span class="status-pill muted">Pending</span>';const canPing=kind==="out"&&phase!=="closed"&&phase!=="before";const note=r.source===SOURCE.OVERRIDE&&r.correction_note?`<div class="ls wk-note-line">${esc(r.corrected_by_name||"Coach")}: \u201C${esc(r.correction_note)}\u201D</div>`:r.source===SOURCE.ACCEPTED&&r.reviewer_name?`<div class="ls wk-note-line">Accepted by ${esc(r.reviewer_name)}${r.review_note?`: \u201C${esc(r.review_note)}\u201D`:""}</div>`:r.review_resolution&&r.review_resolution!=="accepted"?`<div class="ls wk-note-line">Kept as ${esc(r.review_resolution)} by ${esc(r.reviewer_name||"coach")}</div>`:"";const acts=[kind==="review"?`<button class="chip" data-wk-resolve="accepted" data-wk-resp="${esc(r.response_id)}">Accept tap time</button>
      <button class="chip" data-wk-resolve="${phase==="closed"?"missed":"late"}" data-wk-resp="${esc(r.response_id)}">Keep ${phase==="closed"?"missed":"late"}</button>`:"",canPing?`<button class="chip" data-wk-ping="${esc(r.athlete_id)}" data-wk-inst="${esc(inst.instance_id)}">Ping</button>`:"",kind==="out"?`<button class="chip" data-wk-override="${esc(r.response_id)}">Override</button>`:""].filter(Boolean);return`
  <div class="lrow wk-row" data-wk-rowid="${esc(r.response_id)}">
    <div class="wk-rowtop"><div class="lt">${esc(r.name||"Athlete")}</div>${pill}</div>
    <div class="ls">${esc(when)}</div>
    ${note}
    ${r.disputed_at?`<div class="ls wk-dispute">Reported wrong by the ${CD.noun}${r.dispute_note?esc(`: ${r.dispute_note}`):""}</div>`:""}
    ${acts.length?`<div class="wk-rowacts">${acts.join("")}</div>`:""}
  </div>`}function wakeupSummaryCard(inst){if(SUMMARY.forId!==inst.commitment_id)return"";if(SUMMARY.failed){return`<h2 class="eyebrow">Recent history</h2>
    <div class="sidebox"><div class="req-icon b s38">${icon("clock",17)}</div>
      <div><div class="tt">History didn\u2019t load</div><div class="ts">This isn\u2019t an empty record. It retries when you reopen this board.</div></div></div>`}const rows=(SUMMARY.rows||[]).filter(o=>o.instance_id!==inst.instance_id&&o.instance_status!=="cancelled");if(!rows.length)return"";const s=summarizeOccurrences(rows);const shown=HIST_ALL?rows.slice(0,14):rows.slice(0,5);const day=iso=>{const d=new Date(String(iso)+"T12:00:00");return isNaN(d)?String(iso):d.toLocaleDateString([],{weekday:"short",month:"short",day:"numeric"})};const tail=o=>[Number(o.pending)?`${o.pending} pending`:"",Number(o.missed)?`${o.missed} missed`:"",Number(o.late)?`${o.late} late`:"",Number(o.review)?`${o.review} to review`:"",Number(o.excused)?`${o.excused} excused`:""].filter(Boolean).join(" \xB7 ");const tone=o=>Number(o.missed)||Number(o.pending)?"r":Number(o.review)?"p":Number(o.late)?"a":"g";return`
  <div class="wk-secth">
    <h2 class="eyebrow wk-inline">${icon("clock",14)} Recent history</h2>
    ${rows.length>5?`<button class="btn ghost xs" id="wk-hist-all">${HIST_ALL?"Show less":`View all ${rows.length}`}</button>`:""}
  </div>
  <section class="card rows">
    ${shown.map(o=>`
    <div class="lrow wk-hist" data-wk-day="${esc(o.occurs_on)}" data-wk-inst="${esc(o.instance_id)}" role="button" tabindex="0">
      <div class="lm"><div class="lt">${esc(day(o.occurs_on))}</div>
        <div class="ls">${Number(o.total)?`${Number(o.on_standard)+Number(o.late)} of ${o.total} answered`:"Nobody scheduled"}${Number(o.overrides)?` \xB7 ${o.overrides} override${Number(o.overrides)===1?"":"s"}`:""}</div></div>
      <div class="wk-histv ${tail(o)?tone(o):"g"}">${tail(o)?esc(tail(o)):"All in"}</div>
      ${icon("chevron",14,'class="ic-chevron"')}
    </div>`).join("")}
  </section>
  <div class="ts wk-hint">${esc(`Last ${s.occurrences} roll call${s.occurrences===1?"":"s"}: ${s.onStandard} On standard, ${s.late} Late, ${s.missed} Missed.`)}</div>`}const RING_C=2*Math.PI*27;function wakeupRing(done,total,tone){const frac=total?Math.max(0,Math.min(1,done/total)):0;return`<div class="wk-ring ${tone}" role="img" aria-label="${done} of ${total} accounted for">
    <svg viewBox="0 0 64 64" width="64" height="64" aria-hidden="true">
      <circle class="wk-ring-t" cx="32" cy="32" r="27"></circle>
      <circle class="wk-ring-v" cx="32" cy="32" r="27" stroke-dasharray="${(frac*RING_C).toFixed(2)} ${RING_C.toFixed(2)}"></circle>
    </svg>
    <div class="wk-ring-n">${done}<span>/${total}</span></div>
  </div>`}function wakeupBoard(inst,back){const now=new Date().toISOString();const off=offsetFor(inst,now);const clock=iso=>fmtAt(iso,off);const g=groupByVerdict(inst,now);const c=verdictCounts(inst,now);const phase=wakeupPhase(inst,now);const dl=deadlineOf(inst);const close=closesAtOf(inst);const out=g.pending.length+g.still_out.length;const title=inst.title||"Roll call";const ctx=[inst.audience_label||(CD.kind==="practice"?"All clients":"Entire team"),inst.starts_min!=null&&dl?`${fmtMin(inst.starts_min)} to ${clock(dl)}`:inst.starts_min!=null?fmtMin(inst.starts_min):""].filter(Boolean).join(" \xB7 ");const today=todayISO();const dayEyebrow=!inst.occurs_on?"Today":dayLabel(inst.occurs_on,today)||String(inst.occurs_on);const ahead=!!inst.occurs_on&&inst.occurs_on>today;const skipped=scheduleState(inst).kind==="skipped";const state=skipped?"Skipped":ahead?"Scheduled":phase==="before"?"Not open yet":phase==="open"?"In progress":phase==="late"?"Grace ended":!c.total?"Nobody on it":out||c.missed?"Closed":"Complete";const statusLine=skipped?"Nobody gets a roll call this day. Put it back below to send it.":ahead||phase==="before"?`Goes out ${clock(opensAtOf(inst))}. On standard until ${clock(dl)}. Closes ${clock(close)}.`:phase==="open"?`On standard until ${clock(dl)}. Closes ${clock(close)}.`:phase==="late"?`Late check-ins still count until ${clock(close)}.`:`Closed ${clock(close)}. Missed is final.`;const outLabel=phase==="closed"?"Missed":phase==="late"?"Still out":"Pending";const tone=c.review?"p":skipped?"r":(phase==="closed"||phase==="late")&&(out||c.missed)?"r":ahead||phase==="before"?"b":out?"a":"g";const reach=reachCounts(inst.rows||[]);const split=[reach&&reach.unreachable?`${reach.unreachable} can\u2019t get a push`:"",c.overrides?`${c.overrides} by coach override`:"",c.accepted?`${c.accepted} tap time accepted`:"",c.excused?`${c.excused} excused`:""].filter(Boolean).join(" \xB7 ");const attention=[...g.review,...g.still_out,...g.pending];const attnLabel=g.review.length&&!g.still_out.length&&!g.pending.length?"Needs your call":phase==="open"||phase==="before"?"Waiting on":"Needs attention";const attnTone=g.review.length?"p":phase==="open"||phase==="before"?"a":"r";const settled=[...g.on_standard,...g.late,...g.excused];const rowKind=r=>r.verdict===VERDICT.REVIEW?"review":r.verdict===VERDICT.ON_STANDARD?"on":r.verdict===VERDICT.LATE?"late":r.verdict===VERDICT.EXCUSED?"ex":"out";const setup=ahead||skipped;return`
  ${backHead(title,ctx,back,canSchedule()?{id:"wk-edit",label:"Edit this roll call",icon:"gear"}:null)}

  ${dayStrip(inst)}

  <section class="card pad wk-board">
    <div class="wk-hero">
      <div class="wk-heroL">
        <div class="wk-phase">${esc(dayEyebrow)}</div>
        <div class="wk-heroT">${esc(state)}</div>
        <div class="wk-status" id="wk-status-line">${esc(statusLine)}</div>
      </div>
      ${setup?"":wakeupRing(c.accountedFor,c.total,tone)}
    </div>
    ${setup?`<div class="wk-split">${skipped?"Nobody is scheduled.":`${c.total} will get it${inst.audience_label?`, ${esc(inst.audience_label)}`:""}.${reach&&reach.unreachable?` ${reach.unreachable} can\u2019t get a push.`:""}`}</div>`:`
    <div class="wk-stats">
      <div class="wk-stat ${c.onStandard?"g":""}"><b>${c.onStandard}</b><span>On standard</span></div>
      <div class="wk-stat ${c.late?"a":""}"><b>${c.late}</b><span>Late</span></div>
      <div class="wk-stat ${out&&phase!=="open"&&phase!=="before"?"r":""}"><b>${out}</b><span>${esc(outLabel)}</span></div>
    </div>
    ${split?`<div class="wk-split">${esc(split)}</div>`:""}`}
  </section>

  ${setup||phase==="before"?scheduleCard(inst,dayEyebrow):""}

  ${skipped?"":`<section class="card wk-msgcard">
    <div class="wk-msgh"><h2 class="eyebrow wk-inline">${icon("message",14)} Message for ${esc(dayEyebrow.toLowerCase())}</h2><button class="btn ghost xs" id="wk-msg-edit">${inst.message?"Change":"Add"}</button></div>
    ${inst.message?`<p class="wk-msgp">${esc(inst.message)}</p>`:`<div class="wk-hint wk-hint-flush">No message. The roll call goes out with the time only.</div>`}
    ${inst.message_override?`<div class="wk-hint">This day only. The next one uses your standing message.</div>`:""}
    <div id="wk-msg-form" hidden>
      <textarea class="ob-input wk-msg" id="wk-msg-ta" maxlength="1000" rows="3" aria-label="Message for this roll call">${esc(inst.message_override||inst.standing_message||inst.message||"")}</textarea>
      <div class="wk-hint">${ahead||phase==="before"?"Goes out with this roll call, in your name, exactly as written.":"Shows in the app now. A push already sent keeps its words."}</div>
      <div class="btn-row mt">
        <button class="btn primary sm" id="wk-msg-save">${ahead?"Save for this day":"Save for today"}</button>
        ${inst.message_override?`<button class="btn ghost sm" id="wk-msg-clear">Use standing message</button>`:""}
      </div>
      <div id="wk-msg-err" class="ts wk-err" aria-live="polite"></div>
    </div>
  </section>`}

  ${!setup&&attention.length?`
  <div class="wk-secth">
    <h2 class="eyebrow wk-inline ${attnTone}">${icon(attnTone==="a"?"clock":"alert",14)} ${esc(attnLabel)}</h2>
    <span class="status-pill ${attnTone==="r"?"r":attnTone==="p"?"p":"a"}">${attention.length}</span>
  </div>
  <section class="card rows">${attention.map(r=>wakeupRow(r,rowKind(r),inst,clock,phase)).join("")}</section>
  ${out&&phase!=="closed"&&phase!=="before"?`
  <button class="btn primary" id="vc-remind" data-inst="${esc(inst.instance_id)}">${icon("bell",18)} Ping ${out} ${outLabel==="Pending"?"pending":"still out"}</button>
  <div class="wk-pinghint" id="wk-ping-hint">Only who\u2019s still out gets it, with their own I\u2019M UP button. One ping every ten minutes.</div>`:""}`:""}

  ${setup&&!skipped&&attention.length+settled.length?`
  <details class="wk-roster">
    <summary>${icon("chevron",14)} <span class="wk-rostl">Who gets it</span> <span class="opt">\xB7 ${attention.length+settled.length}</span></summary>
    <section class="card rows" role="list">${[...attention,...settled].map(r=>`
      <div class="lrow" role="listitem"><div class="lm"><div class="lt">${esc(r.name||"Athlete")}</div>${r.verdict===VERDICT.EXCUSED?`<div class="ls">${esc(r.excused_reason||"Excused")}</div>`:""}</div>
        ${r.verdict===VERDICT.EXCUSED?'<span class="status-pill muted">Excused</span>':r.can_push===false?'<span class="status-pill muted">No push</span>':""}</div>`).join("")}</section>
  </details>`:""}

  ${!setup&&settled.length?`
  <details class="wk-roster"${attention.length?"":" open"}>
    <summary>${icon("chevron",14)} <span class="wk-rostl">${attention.length?"Everyone else":"Roster"}</span> <span class="opt">\xB7 ${settled.length}</span></summary>
    <section class="card rows">${settled.map(r=>wakeupRow(r,rowKind(r),inst,clock,phase)).join("")}</section>
  </details>`:""}

  ${setup?"":wakeupSummaryCard(inst)}
  <div class="wk-foot"></div>`}export function paintBoard(root,slotId="#vc-board-slot"){const slot=root.querySelector(slotId);if(!slot)return;const paint=()=>{if(slot.isConnected){slot.innerHTML=commitmentBoardCard();wireNextCard(slot)}};paint();const id=bookId();if(id)loadBoard(id,CD.kind).then(paint).then(ensureNext).then(paint)}function wireNextCard(slot){slot.querySelectorAll("[data-wk-day]").forEach(b=>b.addEventListener("click",async()=>{const day=b.getAttribute("data-wk-day");const instId=b.getAttribute("data-wk-inst");if(!day||!instId)return;BOARD_DAY_FOR.set(instId,day);const bid=bookId();if(bid)await loadBoard(bid,CD.kind,day,true);location.hash=`#coach-commitments/${instId}`}));const rearm=()=>{slot.innerHTML=commitmentBoardCard();wireNextCard(slot)};slot.querySelectorAll("[data-wk-skip]").forEach(b=>b.addEventListener("click",async()=>{const instId=b.getAttribute("data-wk-skip");if(SKIP_ARMED!==instId){SKIP_ARMED=instId;rearm();return}b.disabled=true;b.textContent="\u2026";const ok=await setInstanceSchedule(instId,{skipped:true});SKIP_ARMED=null;if(!ok){b.disabled=false;b.textContent="Couldn\u2019t skip. Try again";return}try{await notifyScheduleChange(instId)}catch{}await ensureNext();rearm()}));slot.querySelectorAll("[data-wk-unskip]").forEach(b=>b.addEventListener("click",async()=>{const instId=b.getAttribute("data-wk-unskip");b.disabled=true;b.textContent="\u2026";const ok=await setInstanceSchedule(instId,{skipped:false});if(!ok){b.disabled=false;b.textContent="Couldn\u2019t. Try again";return}try{await notifyScheduleChange(instId)}catch{}await ensureNext();rearm()}))}const STATUS_PILL={pending:["muted","Awaiting"],acknowledged:["g","In"],arrived:["g","Arrived"],completed:["g","Completed"],excused:["muted","Excused"],unverified:["b","Unverified"],missed:["r","No response"]};function athleteRow(r){const[cls,label]=STATUS_PILL[r.status]||["muted",r.status];const when=r.completed_at?`Completed ${hhmm(r.completed_at)}`:r.acknowledged_at?`Responded ${hhmm(r.acknowledged_at)}`:r.status==="excused"?r.excused_reason||"Excused":r.status==="unverified"?r.unverified_reason||"Couldn\u2019t verify":"No response yet";return`
  <div class="lrow" role="listitem" style="align-items:flex-start">
    <div class="lm" style="flex:1">
      <div class="lt">${esc(r.name||"Athlete")}</div>
      <div class="ls">${esc(when)}${r.corrected_by_name?esc(` \xB7 corrected by ${r.corrected_by_name}`):""}</div>
      ${r.disputed_at?`<div class="ls" style="color:var(--amber-bright);font-weight:700">Reported wrong by the ${CD.noun}${r.dispute_note?esc(`: ${r.dispute_note}`):""}</div>`:""}
    </div>
    <div style="display:flex;flex-direction:column;gap:6px;align-items:flex-end">
      <span class="status-pill ${cls}">${esc(label)}</span>
      <div style="display:flex;gap:6px">
        ${""}
        ${r.status==="pending"||r.status==="unverified"||r.status==="missed"?`<button class="chip" data-vc-mark="${esc(r.response_id)}">Mark in</button>`:""}
      </div>
    </div>
  </div>`}let BOARD_LOADED=false;export const coachCommitments={nav:"operator",tab:"home",render({sub}){const back=CD.kind==="practice"?"trainer":"coach-home";const inst=(VC.board||[]).find(b=>b.instance_id===sub)||(VC.board||[])[0];if(!inst){if(!bookId())return bookless("Roll call",bookBack());if(VC.boardError){return`${backHead("Roll call","Couldn\u2019t reach the server",back)}
        ${errorState({title:"Roll call didn't load",body:"This isn't a count of zero. We couldn't reach the server.",retryId:"vc-board-retry"})}`}if(!BOARD_LOADED){return`${backHead("Roll call","Loading",back)}${skeletonRows(3,"Loading the board")}`}return`${backHead("Roll call","Nothing scheduled today",back)}
      <div class="sidebox">
        <div class="req-icon b s38">${icon("clock",17)}</div>
        <div><div class="tt">No commitments today</div>
        <div class="ts">Schedule a morning roll call, a lift, or a study hall and you'll see live responses here, without counting replies in a group chat.</div></div>
      </div>
      ${canSchedule()?`<div style="height:14px"></div>
      <button class="btn" data-go="coach-commit-edit" style="width:100%">${icon("plus",18)} Schedule a commitment</button>`:""}`}if(inst.type==="morning_roll_call")return wakeupBoard(inst,back);const rows=inst.rows||[];const c=boardCounts(rows);const missing=missingFrom(rows);const responded=rows.filter(r=>!missing.includes(r));const ctx=[inst.audience_label||(CD.kind==="practice"?"All clients":"Entire team"),inst.linked_title&&inst.linked_starts_min!=null?`${inst.linked_title} at ${fmtMin(inst.linked_starts_min)}`:""].filter(Boolean).join(" \xB7 ");return`
    ${backHead(inst.title||TYPE_LABEL[inst.type]||"Commitment",ctx,back)}

    <section class="card pad">
      ${segBar(c.responded,c.total,`${c.responded} of ${c.total} responded`)}
      <div style="display:flex;align-items:baseline;gap:10px;padding-top:8px">
        <div style="font-size:var(--t-3xl);font-weight:800;letter-spacing:-.02em;color:${c.awaiting?"var(--text)":"var(--green-bright)"}">${c.responded} of ${c.total}</div>
        <div style="font-size:var(--t-base);font-weight:700;color:var(--text-2)">in</div>
        <div style="flex:1"></div>
        <span class="status-pill ${c.awaiting?"a":"g"}">${c.awaiting?`${c.awaiting} awaiting`:"All in"}</span>
      </div>
      ${inst.respond_by_at||c.leftEarly?`<div class="ts" style="padding-top:8px">${[inst.respond_by_at?`Responses due by ${esc(hhmm(inst.respond_by_at))}`:"",c.leftEarly?`${c.leftEarly} left early`:""].filter(Boolean).join(" \xB7 ")}</div>`:""}
    </section>

    ${missing.length?`
    <h2 class="eyebrow">Still waiting on ${missing.length}</h2>
    <section class="card" role="list" style="padding:2px 16px">${missing.map(r=>athleteRow(r)).join("")}</section>
    <div style="height:10px"></div>
    <button class="btn primary" id="vc-remind" style="width:100%">${icon("bell",18)} Remind ${missing.length} missing ${missing.length===1?CD.noun:CD.nouns}</button>
    <div class="ts" style="text-align:center;padding-top:8px">Only these ${missing.length} get the reminder. Nobody who already responded is pinged.</div>
    `:`
    <div class="sidebox" style="margin-top:12px">
      <div class="req-icon g s38">${icon("check",19)}</div>
      <div><div class="tt">Everyone is in</div>
      <div class="ts">No reminders to send and nobody to chase.</div></div>
    </div>`}

    ${responded.length?`
    <h2 class="eyebrow">Responded</h2>
    <section class="card" role="list" style="padding:2px 16px">${responded.map(r=>athleteRow(r)).join("")}</section>`:""}
    <div style="height:20px"></div>`},mount(root,{sub}){if(!ensureBook()){wireBookRetry(root);return}const id=bookId();const boardDay=sub&&BOARD_DAY_FOR.get(sub)||todayISO();if(id){const before=JSON.stringify(VC.board);loadBoard(id,CD.kind,boardDay).then(()=>{const first=!BOARD_LOADED;BOARD_LOADED=true;if(!root.isConnected)return;if(!first&&JSON.stringify(VC.board)===before)return;window.__render&&window.__render()})}const boardRetry=root.querySelector("#vc-board-retry");if(boardRetry)boardRetry.addEventListener("click",async()=>{boardRetry.disabled=true;const bid=bookId();if(bid)await loadBoard(bid,CD.kind,todayISO(),true);BOARD_LOADED=true;window.__render&&window.__render()});const remind=root.querySelector("#vc-remind");if(remind)remind.addEventListener("click",async()=>{remind.disabled=true;remind.textContent="Sending\u2026";const{sent,reason}=await remindMissing(remind.getAttribute("data-inst")||sub);if(sent)track(EVENTS.VC_REMINDED,{n:sent});remind.textContent=sent?`Ping sent to ${sent} ${sent===1?CD.noun:CD.nouns}`:reason==="rate_limited"?"Just pinged. Try again in a few minutes":reason==="not_authorized"?"You can\u2019t send reminders here":reason==="ok"?"Everyone is in":"Couldn\u2019t send. Try again";if(!sent&&reason==="failed")remind.disabled=false});const repaint=async()=>{const bid=bookId();if(bid)await loadBoard(bid,CD.kind,boardDay,true);window.__render&&window.__render()};const inst=(VC.board||[]).find(b=>b.instance_id===sub)||(VC.board||[])[0];if(inst&&inst.type==="morning_roll_call"&&SUMMARY.forId!==inst.commitment_id){SUMMARY.forId=inst.commitment_id;SUMMARY.rows=null;SUMMARY.failed=false;HIST_ALL=false;loadRollcallSummary(inst.commitment_id,14).then(rows=>{if(SUMMARY.forId!==inst.commitment_id)return;if(rows===null)SUMMARY.failed=true;else SUMMARY.rows=rows;if(root.isConnected)window.__render&&window.__render()})}if(inst&&inst.type==="morning_roll_call"){const beforeUp=JSON.stringify(UPCOMING.forId===inst.commitment_id?UPCOMING.rows:null);loadUpcoming(inst.commitment_id,7).then(rows=>{UPCOMING.forId=inst.commitment_id;if(rows===null){UPCOMING.failed=true;return}UPCOMING.rows=rows;UPCOMING.failed=false;if(root.isConnected&&JSON.stringify(rows)!==beforeUp)window.__render&&window.__render()})}const schedSay=m=>{const el=root.querySelector("#wk-sched-err");if(el)el.textContent=m};const tell=async()=>{try{await notifyScheduleChange(inst.instance_id)}catch{}};const tellBtn=root.querySelector("#wk-tell");if(tellBtn&&inst)tellBtn.addEventListener("click",async()=>{tellBtn.disabled=true;tellBtn.textContent="Sending\u2026";const{reason}=await notifyScheduleChange(inst.instance_id);if(reason==="failed"){tellBtn.disabled=false;tellBtn.textContent=`Tell ${CD.nouns}`;schedSay("Couldn\u2019t reach the server. Try again.");return}await repaint()});const schedTime=root.querySelector("#wk-sched-time");if(schedTime&&inst)schedTime.addEventListener("change",async()=>{const m=/^(\d{1,2}):(\d{2})$/.exec(schedTime.value||"");if(!m)return;schedTime.disabled=true;schedSay("");const ok=await setInstanceSchedule(inst.instance_id,{startsMin:Math.min(1439,+m[1]*60+ +m[2])});schedTime.disabled=false;if(!ok){schedSay("Couldn\u2019t change the time. It may have already started, or check your connection.");return}await tell();await repaint()});const schedReset=root.querySelector("#wk-sched-reset");if(schedReset&&inst)schedReset.addEventListener("click",async()=>{schedReset.disabled=true;schedSay("");const ok=await setInstanceSchedule(inst.instance_id,{resetTime:true});if(!ok){schedReset.disabled=false;schedSay("Couldn\u2019t reset. Try again.");return}await tell();await repaint()});const skipBtn=root.querySelector("#wk-skip");if(skipBtn&&inst)skipBtn.addEventListener("click",async()=>{const wasSkipped=skipBtn.getAttribute("data-skipped")==="1";if(!wasSkipped&&skipBtn.getAttribute("data-armed")!=="1"){skipBtn.setAttribute("data-armed","1");skipBtn.textContent="Skip it, for sure";return}skipBtn.disabled=true;skipBtn.textContent="\u2026";schedSay("");const ok=await setInstanceSchedule(inst.instance_id,{skipped:!wasSkipped});if(!ok){skipBtn.disabled=false;skipBtn.textContent=wasSkipped?"Put it back":"Skip this day";schedSay("Couldn\u2019t save. It may have already started, or check your connection.");return}await tell();await repaint()});if(inst&&inst.type==="morning_roll_call"){if(LIVE.stop){LIVE.stop();LIVE.stop=null}const bid=bookId();const before0=()=>JSON.stringify(VC.board);let last=before0();const w=subscribeBoard(inst.instance_id,async()=>{if(!root.isConnected)return;if(bid)await loadBoard(bid,CD.kind,boardDay,true);const nowJson=JSON.stringify(VC.board);const phaseNow=wakeupPhase((VC.board||[]).find(b=>b.instance_id===inst.instance_id)||inst,new Date().toISOString());if(nowJson!==last||phaseNow!==LIVE.phase){last=nowJson;LIVE.phase=phaseNow;if(root.isConnected)window.__render&&window.__render()}},()=>wakeupPhase(inst,new Date().toISOString())==="closed");LIVE.stop=()=>w.stop();LIVE.phase=wakeupPhase(inst,new Date().toISOString());const dog=setInterval(()=>{if(!root.isConnected){clearInterval(dog);if(LIVE.stop){LIVE.stop();LIVE.stop=null}}},5e3)}root.querySelectorAll("[data-wk-ping]").forEach(b=>b.addEventListener("click",async()=>{const instId=b.getAttribute("data-wk-inst");const athleteId=b.getAttribute("data-wk-ping");b.disabled=true;b.textContent="\u2026";const{sent,reason}=await pingAthlete(instId,athleteId);if(sent)track(EVENTS.VC_REMINDED,{n:1,single:true});b.textContent=sent?"Ping sent":reason==="rate_limited"?"Just pinged":reason==="ok"?"Already in":reason==="not_authorized"?"Not allowed":"Couldn\u2019t ping";if(!sent&&reason==="failed")b.disabled=false}));root.querySelectorAll("[data-wk-override]").forEach(b=>b.addEventListener("click",()=>{const respId=b.getAttribute("data-wk-override");const wrap=b.parentElement;if(!wrap)return;const box=document.createElement("div");box.className="wk-override";const input=document.createElement("input");input.className="input";input.maxLength=120;input.placeholder=`Why? (required, the ${CD.noun} sees it)`;input.setAttribute("aria-label","Override reason");const ok=document.createElement("button");ok.className="chip on";ok.textContent="Mark on standard";const cancel=document.createElement("button");cancel.className="chip";cancel.textContent="Cancel";const err=document.createElement("div");err.className="ts wk-err";ok.addEventListener("click",async()=>{const why=input.value.trim();if(!why){err.textContent="Give a reason. It goes on the record.";input.focus();return}ok.disabled=true;ok.textContent="\u2026";const done=await setResponse(respId,"acknowledged",why);if(!done){ok.disabled=false;ok.textContent="Mark on standard";err.textContent="Couldn\u2019t save. Try again.";return}await repaint()});cancel.addEventListener("click",()=>{window.__render&&window.__render()});box.append(input,ok,cancel,err);wrap.replaceChildren(box);input.focus()}));root.querySelectorAll("[data-wk-resolve]").forEach(b=>b.addEventListener("click",async()=>{const respId=b.getAttribute("data-wk-resp");const resolution=b.getAttribute("data-wk-resolve");const label=b.textContent;b.disabled=true;b.textContent="\u2026";const done=await resolveSyncReview(respId,resolution,null);if(!done){b.disabled=false;b.textContent=label;return}await repaint()}));const wkEdit=root.querySelector("#wk-edit");if(wkEdit&&inst)wkEdit.addEventListener("click",async()=>{wkEdit.disabled=true;const bid=bookId();let rows=RT.vcCommitments;if(!Array.isArray(rows)&&bid){rows=await loadCommitments(bid,CD.kind);RT.vcCommitments=rows}const row=(rows||[]).find(r=>r.id===inst.commitment_id);wkEdit.disabled=false;if(!row){location.hash="#coach-commit-manage";return}editWakeup(row);location.hash="#coach-wakeup-edit"});const histAll=root.querySelector("#wk-hist-all");if(histAll)histAll.addEventListener("click",()=>{HIST_ALL=!HIST_ALL;window.__render&&window.__render()});const msgEdit=root.querySelector("#wk-msg-edit");const msgForm=root.querySelector("#wk-msg-form");if(msgEdit&&msgForm)msgEdit.addEventListener("click",()=>{msgForm.hidden=!msgForm.hidden;msgEdit.setAttribute("aria-expanded",msgForm.hidden?"false":"true");if(!msgForm.hidden){const ta=root.querySelector("#wk-msg-ta");if(ta)ta.focus()}});const msgSay=m=>{const el=root.querySelector("#wk-msg-err");if(el)el.textContent=m};const msgSave=root.querySelector("#wk-msg-save");if(msgSave&&inst)msgSave.addEventListener("click",async()=>{const ta=root.querySelector("#wk-msg-ta");msgSave.disabled=true;msgSave.textContent="Saving\u2026";const ok=await setInstanceMessage(inst.instance_id,ta?ta.value:"");if(!ok){msgSave.disabled=false;msgSave.textContent="Save for today";msgSay("Couldn\u2019t save. Check your connection and try again.");return}await repaint()});const msgClear=root.querySelector("#wk-msg-clear");if(msgClear&&inst)msgClear.addEventListener("click",async()=>{msgClear.disabled=true;msgClear.textContent="\u2026";const ok=await setInstanceMessage(inst.instance_id,"");if(!ok){msgClear.disabled=false;msgClear.textContent="Use standing message";msgSay("Couldn\u2019t change it. Try again.");return}await repaint()});root.querySelectorAll("[data-wk-day]").forEach(row=>row.addEventListener("click",async()=>{const day=row.getAttribute("data-wk-day");const instId=row.getAttribute("data-wk-inst");if(!day||!instId)return;BOARD_DAY_FOR.set(instId,day);const bid=bookId();if(bid)await loadBoard(bid,CD.kind,day,true);location.hash=`#coach-commitments/${instId}`}));root.querySelectorAll("[data-vc-mark]").forEach(b=>b.addEventListener("click",async()=>{const label=b.textContent;b.disabled=true;b.textContent="\u2026";const ok=await setResponse(b.getAttribute("data-vc-mark"),"acknowledged",null);if(!ok){b.disabled=false;b.textContent=label;return}await repaint()}))}};const TYPES=["practice","strength","speed","team_meeting","study_hall","tutoring","class","rehab","nutrition"];const DOW=["Su","M","Tu","W","Th","F","Sa"];const STARTERS={morning_roll_call:["Everyone up? Ready to rise and conquer?","Feet on the floor. Let\u2019s go.","Up and moving. Today starts now."],study_hall:["Books open. Two hours, no phones."],rehab:["Rehab today. Don\u2019t skip it, it\u2019s how you get back."]};let DRAFT=null;const blankDraft=()=>({type:"practice",title:TYPE_LABEL.practice,message:"",action_label:"",audience_kind:"team",audience_value:null,repeat_days:[1,2,3,4,5],starts_min:285,respond_by_min:315,location_id:null,arrive_by_min:null,min_dwell_min:null,linked_commitment_id:null,reminder_offsets_min:[15,5],escalation:{}});const timeInput=(id,label,val)=>`
  <div style="flex:1">
    <label for="${id}" style="display:block;font-size:12.5px;font-weight:700;color:var(--text-2);margin-bottom:4px">${esc(label)}</label>
    <input class="ob-input" id="${id}" type="time" value="${esc(val==null?"":`${String(Math.floor(val/60)).padStart(2,"0")}:${String(val%60).padStart(2,"0")}`)}" />
  </div>`;const DOW_FULL=DAYS_SHORT;const daysLabel=days=>{const d=(days||[]).map(Number).sort();if(!d.length)return"Never";if(d.length===7)return"Every day";if(d.join()==="1,2,3,4,5")return"Weekdays";if(d.join()==="0,6")return"Weekends";return d.map(n=>DOW_FULL[n]).join(" \xB7 ")};export function editCommitment(row){DRAFT={id:row.id,type:row.type,title:row.title||"",message:row.message||"",action_label:row.action_label||"",audience_kind:row.audience_kind,audience_value:row.audience_value||null,repeat_days:Array.isArray(row.repeat_days)?row.repeat_days.map(Number):[],starts_min:row.starts_min,ends_min:row.ends_min,respond_by_min:row.respond_by_min,opens_min:row.opens_min,location_id:row.location_id||null,arrive_by_min:row.arrive_by_min,min_dwell_min:row.min_dwell_min,linked_commitment_id:row.linked_commitment_id||null,reminder_offsets_min:row.reminder_offsets_min||[15,5],escalation:row.escalation&&typeof row.escalation==="object"?{...row.escalation}:{},active:row.active!==false}}export const coachCommitManage={nav:"operator",tab:"home",render(){if(!bookId())return bookless("Commitments",bookBack());const back=CD.kind==="practice"?"trainer":"coach-home";const loaded=Array.isArray(RT.vcCommitments);const rows=RT.vcCommitments||[];const live=rows.filter(r=>r.active!==false);const paused=rows.filter(r=>r.active===false);const card=r=>`
      <div class="lrow" role="listitem" style="align-items:flex-start">
        <div class="lic" style="background:var(--blue-surface);color:var(--blue-bright)">${icon(r.type==="morning_roll_call"?"sun":"clock",17)}</div>
        <div class="lm" style="flex:1">
          <div class="lt">${esc(r.title||TYPE_LABEL[r.type]||"Commitment")}</div>
          <div class="ls">${esc(daysLabel(r.repeat_days))} \xB7 ${esc(fmtMin(r.starts_min))}${r.type==="morning_roll_call"&&graceMinOf(r)!=null?` \xB7 ${esc(String(graceMinOf(r)))} min grace`:""}${r.location_id?" \xB7 location verified":""}</div>
        </div>
        <div style="display:flex;flex-direction:column;gap:6px;align-items:flex-end">
          <button class="chip" data-vc-edit="${esc(r.id)}">Edit</button>
          <button class="chip" data-vc-toggle="${esc(r.id)}">${r.active===false?"Resume":"Pause"}</button>
        </div>
      </div>`;return`
    ${backHead("Commitments","Everything you have standing",back)}
    ${VC.commitmentsError&&!rows.length?errorState({title:"Couldn't load your commitments",body:"Nothing was deleted. Reconnect and your schedule loads right here.",retryId:"vc-manage-retry"}):!loaded?skeletonRows(3,"Loading your commitments"):!rows.length?emptyState({icon:"clock",title:"Nothing scheduled yet",body:"Schedule a morning roll call, a lift, or a study hall and it'll live here: editable, pausable, and never silently deleted.",compact:true}):""}
    ${live.length?`<h2 class="eyebrow">Running</h2>
      <section class="card" role="list" style="padding:2px 16px">${live.map(card).join("")}</section>`:""}
    ${paused.length?`<h2 class="eyebrow">Paused</h2>
      <section class="card" role="list" style="padding:2px 16px">${paused.map(card).join("")}</section>
      <div class="ts" style="padding-top:8px">Paused commitments stop appearing for ${CD.nouns} tomorrow. Everything already recorded against them stays exactly as it is.</div>`:""}
    <div style="height:14px"></div>
    ${ROLLCALL_OFF?`
    <div class="sidebox">
      <div class="req-icon b s38">${icon("sun",17)}</div>
      <div><div class="tt">Scheduling is off right now</div>
      <div class="ts">The roll call and commitment scheduling are switched off, so nothing new can be created and nothing is going out. Anything listed above is kept exactly as it was recorded.</div></div>
    </div>`:`
    <button class="btn primary" data-go="coach-wakeup-new">${icon("sun",18)} Roll call</button>
    <div class="wk-gap"></div>
    <button class="btn ghost" id="vc-new" style="width:100%">${icon("plus",18)} Schedule a commitment</button>`}
    <div style="height:20px"></div>`},mount(root){if(!ensureBook()){wireBookRetry(root);return}const id=bookId();const hadError=VC.commitmentsError;if(id)loadCommitments(id,CD.kind,true).then(rows=>{const changed=JSON.stringify(rows)!==JSON.stringify(RT.vcCommitments||null)||VC.commitmentsError!==hadError;RT.vcCommitments=rows;if(changed&&root.isConnected)window.__render&&window.__render()});const retry=root.querySelector("#vc-manage-retry");if(retry)retry.addEventListener("click",()=>{window.__render&&window.__render()});const create=root.querySelector("#vc-new");if(create)create.addEventListener("click",()=>{DRAFT=null;location.hash="#coach-commit-edit"});root.querySelectorAll("[data-vc-edit]").forEach(b=>b.addEventListener("click",()=>{const row=(RT.vcCommitments||[]).find(r=>r.id===b.getAttribute("data-vc-edit"));if(!row)return;if(row.type==="morning_roll_call"){editWakeup(row);location.hash="#coach-wakeup-edit";return}editCommitment(row);location.hash="#coach-commit-edit"}));root.querySelectorAll("[data-vc-toggle]").forEach(b=>b.addEventListener("click",async()=>{const row=(RT.vcCommitments||[]).find(r=>r.id===b.getAttribute("data-vc-toggle"));if(!row)return;b.disabled=true;b.textContent="\u2026";const owner=bookId();const ok=await setCommitmentActive({...row,team_id:CD.kind==="practice"?null:owner,practice_id:CD.kind==="practice"?owner:null},row.active===false);if(!ok){b.disabled=false;b.textContent=row.active===false?"Resume":"Pause";return}RT.vcCommitments=await loadCommitments(owner,CD.kind,true);window.__render&&window.__render()}))}};export const coachCommitEdit={nav:"operator",tab:"home",transient:true,render(){const back=CD.kind==="practice"?"trainer":"coach-home";if(!canSchedule()){return`${backHead("Schedule","Not available for your role",back)}
      <div class="sidebox">
        <div class="req-icon b s38">${icon("eye",17)}</div>
        <div><div class="tt">Scheduling is for the coaching staff</div>
        <div class="ts">You can see the board and every response for your scope. Ask the head coach if you should be able to schedule too.</div></div>
      </div>`}const d=DRAFT||(DRAFT=blankDraft());const rooms=CD.extras&&CD.extras.rooms||[];const groups=CD.extras&&CD.extras.groups||[];const starters=STARTERS[d.type]||[];return`
    ${backHead("Schedule a commitment","",back)}

    <h2 class="eyebrow">What is it</h2>
    <section class="card pad">
      <div class="chips-wrap" id="vc-type" style="display:flex;flex-wrap:wrap;gap:6px" role="radiogroup" aria-label="Commitment type">
        ${TYPES.map(t=>`<button class="chip ${d.type===t?"on":""}" role="radio" aria-checked="${d.type===t?"true":"false"}" data-type="${t}">${esc(TYPE_LABEL[t])}</button>`).join("")}
      </div>
      <div style="height:14px"></div>
      <label for="vc-title" style="display:block;font-size:12.5px;font-weight:700;color:var(--text-2);margin-bottom:4px">What the ${CD.nouns} see as the title</label>
      <input class="ob-input" id="vc-title" maxlength="60" value="${esc(d.title)}" placeholder="${esc(TYPE_LABEL[d.type])}" />
      <div style="height:14px"></div>
      <label for="vc-msg" style="display:block;font-size:12.5px;font-weight:700;color:var(--text-2);margin-bottom:4px">Your message <span style="color:var(--text-3);font-weight:600">\xB7 optional, your words</span></label>
      <textarea class="ob-input" id="vc-msg" maxlength="200" rows="2" style="min-height:60px;resize:vertical" placeholder="Say it how you'd say it in the room.">${esc(d.message)}</textarea>
      ${starters.length?`<div style="display:flex;flex-wrap:wrap;gap:6px;margin-top:8px">
        ${starters.map((s,i)=>`<button class="chip" data-starter="${i}">${esc(s.length>34?s.slice(0,32)+"\u2026":s)}</button>`).join("")}
      </div>
`:""}
      <div style="height:14px"></div>
      <label for="vc-action" style="display:block;font-size:12.5px;font-weight:700;color:var(--text-2);margin-bottom:4px">Button label</label>
      <input class="ob-input" id="vc-action" maxlength="24" value="${esc(d.action_label)}" placeholder="${d.type==="morning_roll_call"?"I\u2019m Up":"I\u2019m here"}" />
    </section>

    <h2 class="eyebrow">Who gets it</h2>
    <section class="card pad">
      <div style="display:flex;flex-wrap:wrap;gap:6px" id="vc-aud" role="radiogroup" aria-label="Who gets it">
        <button class="chip ${d.audience_kind==="team"?"on":""}" role="radio" aria-checked="${d.audience_kind==="team"?"true":"false"}" data-aud="team">${CD.kind==="practice"?"All clients":"Entire team"}</button>
        ${rooms.map(r=>`<button class="chip ${d.audience_value===r.id?"on":""}" role="radio" aria-checked="${d.audience_value===r.id?"true":"false"}" data-aud="room:${esc(r.id)}">${esc(r.label)}</button>`).join("")}
        ${groups.map(g=>`<button class="chip ${d.audience_value===g.id?"on":""}" role="radio" aria-checked="${d.audience_value===g.id?"true":"false"}" data-aud="group:${esc(g.id)}">${esc(g.name)}</button>`).join("")}
      </div>
    </section>

    <h2 class="eyebrow">When</h2>
    <section class="card pad">
      <div style="display:flex;gap:6px" id="vc-days" role="group" aria-label="Repeat on days">
        ${DOW.map((n,i)=>`<button class="chip ${d.repeat_days.includes(i)?"on":""}" role="checkbox" aria-checked="${d.repeat_days.includes(i)?"true":"false"}" aria-label="${DOW_FULL[i]}" data-day="${i}" style="flex:1;padding:8px 0">${n}</button>`).join("")}
      </div>
      <div style="height:14px"></div>
      <div style="display:flex;gap:10px">
        ${timeInput("vc-start","Appears / starts",d.starts_min)}
        ${timeInput("vc-respond","Respond by",d.respond_by_min)}
      </div>
      <div class="ts" style="padding-top:10px">A reminder goes out 15 and 5 minutes before the deadline, only to ${CD.nouns} who haven\u2019t responded.</div>
    </section>

    ${""}
    <h2 class="eyebrow">If they miss it <span class="opt">\xB7 optional</span></h2>
    <section class="card pad">
      <div class="vc-esc" id="vc-esc" role="group" aria-label="If they miss it">
        <button class="chip ${d.escalation&&d.escalation.breakthrough?"on":""}" role="checkbox" aria-checked="${d.escalation&&d.escalation.breakthrough?"true":"false"}" data-esc="breakthrough">Send a second, louder push</button>
        <button class="chip ${d.escalation&&d.escalation.notify_coach_on_miss?"on":""}" role="checkbox" aria-checked="${d.escalation&&d.escalation.notify_coach_on_miss?"true":"false"}" data-esc="notify_coach_on_miss">Tell me who missed</button>
      </div>
      <div class="ts mt">The louder push is time-sensitive and lands once, right after the deadline passes. "Tell me who missed" is one message to you naming everyone who never answered, not one per ${CD.noun}.</div>
    </section>

    <h2 class="eyebrow">Linked event <span class="opt">\xB7 optional</span></h2>
    <section class="card pad">
      <label for="vc-link" style="display:block;font-size:12.5px;font-weight:700;color:var(--text-2);margin-bottom:4px">What is this roll call for?</label>
      <select class="ob-input" id="vc-link">
        <option value="">Nothing, it stands alone</option>
        ${(RT.vcCommitments||[]).filter(c=>c.type!=="morning_roll_call").map(c=>`<option value="${esc(c.id)}" ${d.linked_commitment_id===c.id?"selected":""}>${esc(c.title)} \xB7 ${esc(fmtMin(c.starts_min))}</option>`).join("")}
      </select>
    </section>

    <div style="height:14px"></div>
    <button class="btn primary" id="vc-save" style="width:100%">${icon("check",19)} Schedule it</button>
    <div id="vc-save-err" class="ts" style="color:var(--red);text-align:center;min-height:16px"></div>
    <div style="height:10px"></div>
    <div class="ts" style="text-align:center">${cap(CD.nouns)} see this on Home when it opens. Responses land on your board live.</div>
    <div style="height:20px"></div>`},mount(root){ensureBook();const id=bookId();if(id){loadLocations(id,CD.kind).then(rows=>{if(root.isConnected&&rows.length)window.__render&&window.__render()});loadCommitments(id,CD.kind).then(rows=>{RT.vcCommitments=rows;if(root.isConnected&&rows.length)window.__render&&window.__render()})}const d=DRAFT||(DRAFT=blankDraft());const val=sel=>{const el=root.querySelector(sel);return el?el.value:""};const minOf=v=>{const m=/^(\d{1,2}):(\d{2})$/.exec(v||"");return m?Math.min(1439,+m[1]*60+ +m[2]):null};const capture=()=>{const errEl=root.querySelector("#vc-save-err");if(errEl)errEl.textContent="";d.title=val("#vc-title").trim();d.message=val("#vc-msg").trim();d.action_label=val("#vc-action").trim();const s=minOf(val("#vc-start"));if(s!=null)d.starts_min=s;d.respond_by_min=minOf(val("#vc-respond"));d.linked_commitment_id=val("#vc-link")||null};root.querySelectorAll("[data-type]").forEach(b=>b.addEventListener("click",()=>{capture();const t=b.getAttribute("data-type");if(!d.title||d.title===TYPE_LABEL[d.type])d.title=TYPE_LABEL[t];d.type=t;window.__render&&window.__render()}));root.querySelectorAll("[data-starter]").forEach(b=>b.addEventListener("click",()=>{capture();d.message=(STARTERS[d.type]||[])[+b.getAttribute("data-starter")]||d.message;window.__render&&window.__render()}));root.querySelectorAll("#vc-esc [data-esc]").forEach(b=>b.addEventListener("click",()=>{const k=b.getAttribute("data-esc");d.escalation={...d.escalation||{}};d.escalation[k]=!d.escalation[k];b.classList.toggle("on",!!d.escalation[k]);b.setAttribute("aria-checked",d.escalation[k]?"true":"false")}));root.querySelectorAll("[data-aud]").forEach(b=>b.addEventListener("click",()=>{capture();const[kind,value]=b.getAttribute("data-aud").split(":");d.audience_kind=kind;d.audience_value=value||null;window.__render&&window.__render()}));root.querySelectorAll("[data-day]").forEach(b=>b.addEventListener("click",()=>{capture();const n=+b.getAttribute("data-day");d.repeat_days=d.repeat_days.includes(n)?d.repeat_days.filter(x=>x!==n):d.repeat_days.concat(n).sort();window.__render&&window.__render()}));const save=root.querySelector("#vc-save");const sayErr=msg=>{const el=root.querySelector("#vc-save-err");if(el)el.textContent=msg};if(save)save.addEventListener("click",async()=>{if(save.disabled)return;capture();if(!d.title){sayErr("Give it a title first.");return}if(!d.repeat_days.length){sayErr("Pick at least one day.");return}const origLabel=save.innerHTML;save.disabled=true;save.textContent="Scheduling\u2026";const owner=bookId();const payload={...d,title:d.title,message:d.message||null,action_label:d.action_label||null,team_id:CD.kind==="practice"?null:owner,practice_id:CD.kind==="practice"?owner:null,timezone:Intl.DateTimeFormat().resolvedOptions().timeZone||"America/New_York"};const newId=await saveCommitment(payload);if(!newId){save.disabled=false;save.innerHTML=origLabel;sayErr("Couldn\u2019t save. Check your connection and try again.");return}track(EVENTS.VC_SCHEDULED,{type:d.type,audience:d.audience_kind,hasLocation:!!d.location_id});DRAFT=null;if(owner){RT.vcCommitments=await loadCommitments(owner,CD.kind,true);await loadBoard(owner,CD.kind,todayISO(),true)}location.hash="#coach-commit-manage"})}};
