import{icon}from"../icons.js";import{backHead,esc,logoMark,skeletonRows}from"../components.js";import*as roles from"../roles.js";import{refreshHealthConsent}from"./health-consent.js";const native=()=>typeof window!=="undefined"&&window.OnStandardNative||null;const healthN=()=>{const n=native();return n&&n.health?n.health:null};export const HK={probed:false,available:null,connected:false,osGranted:false,consent:null,isMinor:null,activity:null,recovery:null,busy:false,note:""};const hasActivity=a=>!!(a&&(a.steps!=null||a.distanceMeters!=null||a.activeMinutes!=null||a.workouts&&a.workouts.length));const hasRecovery=r=>!!(r&&(r.sleepHours!=null||r.hrvMs!=null||r.restingHr!=null));export async function probeHealth(){const h=healthN();try{HK.available=h&&h.available?!!await h.available():!!await roles.healthAvailable()}catch{HK.available=false}let osGranted=false;if(HK.available){try{osGranted=h&&h.connected?!!await h.connected():!!await roles.healthConnected()}catch{osGranted=false}}const c=typeof window!=="undefined"?window.sb:null;if(c){try{const{data:u}=await c.auth.getUser();const uid=u&&u.user&&u.user.id;if(uid){const{data}=await c.rpc("has_health_consent",{p_athlete:uid});HK.consent=data===true;const{data:ap}=await c.from("athlete_profiles").select("base_age").eq("athlete_id",uid).maybeSingle();const age=ap&&ap.base_age;HK.isMinor=age==null?true:Number(age)<18}}catch{}}HK.osGranted=osGranted;HK.connected=osGranted&&HK.consent!==false;if(HK.connected&&h&&h.readActivity){const to=new Date;const from=new Date(to);from.setHours(0,0,0,0);HK.activity=await h.readActivity(from.toISOString(),to.toISOString()).catch(()=>null)}else HK.activity=null;if(osGranted)HK.recovery=await roles.healthRead().catch(()=>null);else HK.recovery=null;HK.probed=true}export function hkLabel(){if(!HK.probed)return"Checking\u2026";if(HK.available===false)return"iPhone only";if(!HK.connected)return HK.osGranted&&hasRecovery(HK.recovery)?"Recovery only":"Not connected";return hasActivity(HK.activity)||hasRecovery(HK.recovery)?"Connected":"Connected, nothing shared yet"}const fmtSteps=n=>Number(n).toLocaleString();const fmtSleep=h=>{const H=Math.floor(h),M=Math.round((h-H)*60);return`${H}h${M?` ${M}m`:""}`};function readingLine(){const bits=[];const a=HK.activity,r=HK.recovery;if(a&&a.steps!=null)bits.push(`${fmtSteps(a.steps)} steps today`);if(a&&a.workouts&&a.workouts.length)bits.push(`${a.workouts.length} workout${a.workouts.length===1?"":"s"}`);if(r&&r.sleepHours!=null)bits.push(`${fmtSleep(r.sleepHours)} sleep last night`);return bits.join(" \xB7 ")}function statusCard(){if(HK.available===false)return`
    <section class="card pad hk-card">
      <div class="hk-status">
        <div class="hk-ic">${icon("heart",20)}</div>
        <div><div class="hk-t">Not on this phone</div>
        <div class="hk-s">Apple Health lives on iPhone. Here your standards verify by logging, and Recovery uses your nightly check-in.</div></div>
      </div>
    </section>`;const recOnly=!HK.connected&&HK.osGranted&&hasRecovery(HK.recovery);if(!HK.connected)return`
    <section class="card pad hk-card">
      <div class="hk-status">
        <div class="hk-ic">${icon(recOnly?"moon":"heart",20)}</div>
        <div><div class="hk-t">${recOnly?"Recovery only":"Not connected"}</div>
        <div class="hk-s">${recOnly?`Last night: ${esc(recoveryLine())}. Your activity standards are still verifying by hand; connect to let them check themselves.`:"Connect once and your activity standards check themselves. Last night's sleep shows up on Recovery for context."}</div></div>
      </div>
      <button class="btn primary hk-act" data-go="health-consent">${HK.isMinor===true&&HK.consent!==true?"Connect, with a guardian":"Connect Apple Health"}</button>
    </section>`;const on=hasActivity(HK.activity)||hasRecovery(HK.recovery);return`
    <section class="card pad hk-card">
      <div class="hk-status ${on?"on":"warn"}">
        <div class="hk-ic">${icon(on?"checkCircle":"alert",20)}</div>
        <div><div class="hk-t">${on?"Connected":"Connected, nothing shared yet"}</div>
        <div class="hk-s">${on?esc(readingLine())||"Reading. Your standards verify on their own.":"Apple never tells an app which categories you allowed, so we looked: nothing has reached OnStandard yet. Turn the categories on in the Health app, then check again."}</div></div>
      </div>
      ${on?"":`<button class="btn ghost hk-act" id="hk-recheck">Check again</button>`}
    </section>`}function readRow(ic,title,sub,val,isOn){return`<div class="lrow" role="listitem">
    <div class="lic">${icon(ic,17)}</div>
    <div class="lm"><div class="lt">${esc(title)}</div><div class="ls">${esc(sub)}</div></div>
    ${val?`<span class="lv ${isOn?"on":""}">${esc(val)}</span>`:""}
  </div>`}function recoveryLine(){const r=HK.recovery||{};const bits=[];if(r.sleepHours!=null)bits.push(`${fmtSleep(r.sleepHours)} sleep`);if(r.hrvMs!=null)bits.push(`${Math.round(r.hrvMs)} ms HRV`);if(r.restingHr!=null)bits.push(`${Math.round(r.restingHr)} bpm resting`);return bits.join(" \xB7 ")}function readsCard(){const con=HK.connected;const os=HK.osGranted;const act=hasActivity(HK.activity);const rec=hasRecovery(HK.recovery);const actVal=!con?"":act?"Reading":"No data yet";const recVal=!os?"":rec?"Reading":"No data yet";const recSub=rec?`Last night: ${recoveryLine()}. Shown for context; your score is still yours to earn.`:"Last night\u2019s sleep, HRV and resting heart rate. Shown on Recovery for context; the score is still yours to earn.";return`
    <h2 class="eyebrow">What OnStandard reads</h2>
    <section class="card rows hk-reads" role="list">
      ${readRow("bolt","Activity","Steps, walking and running distance, workouts. Verifies the standards your coach set.",actVal,act)}
      ${readRow("moon","Recovery",recSub,recVal,rec)}
      ${os&&!rec?`<div class="hk-foot"><button class="btn ghost" id="hk-rec" ${HK.busy?"disabled":""}>${HK.busy?"Asking\u2026":"Turn on recovery data"}</button></div>`:""}
      ${readRow("shield","Never written","OnStandard reads only. Nothing is ever written to Health, and your coach never sees raw health data.","",false)}
    </section>`}function stepsCard(){return`
    <h2 class="eyebrow">Change what Health shares</h2>
    <section class="card pad">
      <div class="cs-p hk-lead">Apple keeps these switches in the Health app, not in OnStandard. It takes four taps.</div>
      <ol class="hk-steps">
        <li class="hk-step"><div class="hk-tile health">${icon("heart",22)}</div><div class="hk-n">Open the <b>Health</b> app.</div></li>
        <li class="hk-step"><div class="hk-tile sys">${icon("user",22)}</div><div class="hk-n">Tap your <b>picture</b> in the top right.</div></li>
        <li class="hk-step"><div class="hk-tile sys">${icon("hand",22)}</div><div class="hk-n">Under Privacy, tap <b>Apps</b>.</div></li>
        <li class="hk-step"><div class="hk-tile app">${logoMark(26,"hkapp")}</div><div class="hk-n">Tap <b>OnStandard</b> and turn on Steps, Walking + Running Distance, Workouts, Sleep, Heart Rate Variability and Resting Heart Rate.</div></li>
      </ol>
      <button class="btn primary hk-act" id="hk-open">${icon("external",16)} Open the Health app</button>
      <div class="cs-p muted hk-fine">If it does not open, go to Settings, then Health, then Data Access &amp; Devices, then OnStandard.</div>
    </section>`}export default{tab:"profile",render(){const head=backHead("Apple Health","What it reads, and how to change it","settings");if(!HK.probed)return`${head}${skeletonRows(3,"Checking Apple Health")}`;const ios=HK.available!==false;return`${head}
    ${statusCard()}
    ${ios?readsCard():""}
    ${ios&&(HK.connected||HK.osGranted)?stepsCard():""}
    ${ios&&HK.connected?`
    <div class="hk-foot">
      <button class="btn ghost danger" id="hk-off" ${HK.busy?"disabled":""}>${HK.busy?"Disconnecting\u2026":"Disconnect Apple Health"}</button>
      <div class="cs-p muted hk-center">Disconnecting stops OnStandard reading. To cut access at the phone level too, turn the categories off in the Health app.</div>
    </div>`:`
    <div class="cs-p muted hk-center tall">${ios?"Connecting Health is separate from arrival check-ins. One does not switch on the other.":"Nothing to set up here on Android."}</div>`}
    ${HK.note?`<div class="cs-p muted hk-note" role="status">${esc(HK.note)}</div>`:""}`},async mount(root){if(!HK.probed){await probeHealth();if(root.isConnected&&window.__render)window.__render();return}const open=root.querySelector("#hk-open");if(open)open.addEventListener("click",()=>{const n=native();if(n&&n.openUrl){n.openUrl("x-apple-health://");HK.note=""}else{HK.note="Open the Health app from your home screen.";if(window.__render)window.__render()}});const recheck=root.querySelector("#hk-recheck");if(recheck)recheck.addEventListener("click",async()=>{recheck.disabled=true;recheck.textContent="Checking\u2026";HK.probed=false;await probeHealth();if(window.__render)window.__render()});const recBtn=root.querySelector("#hk-rec");if(recBtn)recBtn.addEventListener("click",async()=>{if(HK.busy)return;if(HK.isMinor===true&&HK.consent!==true){location.hash="#guardian";return}HK.busy=true;if(window.__render)window.__render();try{const h=healthN();if(h&&h.connectScoped)await h.connectScoped(["recovery"]).catch(()=>null);else await roles.healthConnect().catch(()=>null);HK.recovery=await roles.healthRead().catch(()=>null);if(!hasRecovery(HK.recovery))HK.note="Nothing came through yet. Check Sleep, Heart Rate Variability and Resting Heart Rate are on for OnStandard in the Health app.";else HK.note=""}catch{HK.note="Could not ask for recovery data. Try again."}HK.busy=false;if(window.__render)window.__render()});const off=root.querySelector("#hk-off");if(off)off.addEventListener("click",async()=>{if(HK.busy)return;HK.busy=true;if(window.__render)window.__render();try{const c=window.sb;const{data:u}=await c.auth.getUser();const uid=u&&u.user&&u.user.id;const{error}=await c.rpc("revoke_health_consent",{p_athlete:uid});if(error){HK.note="Could not disconnect. Check your connection and try again."}else{HK.connected=false;HK.consent=false;HK.activity=null;HK.recovery=null;HK.note="Disconnected. OnStandard is no longer reading Health.";refreshHealthConsent()}}catch{HK.note="Could not disconnect. Check your connection and try again."}HK.busy=false;if(window.__render)window.__render()})}};export function refreshAppleHealth(){HK.probed=false;HK.note=""}
