import{S,RT,act,tier,checkinProjection,checkinBestProjection,liveWeightPct}from"../state.js";import{DAY}from"../day.js";import{icon}from"../icons.js";import{backHead,esc}from"../components.js";import{recoveryCoachMessage}from"../recovery-intel.js";import{scoreMoveDial,playScoreMove}from"../score-move.js";import*as roles from"../roles.js";import{fmtDuration}from"../sleep.js";function checkinMove(){const mv=RT.lastMove;if(!mv||String(mv.what||"").toLowerCase()!=="recovery check-in")return null;return mv}function firstEver(){const hist=DAY.scoreHistory||[];return!hist.some(h=>h&&h.date&&h.date<String(DAY.date))}export const recoveryConfirm={tab:"home",hideTabs:true,transient:true,render(){const mv=checkinMove();const toTier=tier(mv?mv.to:S.score);const promoted=!!mv&&tier(mv.from).name!==toTier.name;return`
    <div class="confirm-wrap">
      ${""}
      <div class="big-check"><div class="core" style="background:linear-gradient(155deg, var(--purple), var(--purple-deep)); color:var(--ink-on-accent); box-shadow: 0 0 44px rgba(var(--purple-rgb),0.55), 0 10px 34px rgba(0,0,0,0.4)">${icon("moonStar",32)}</div></div>
      <div class="confirm-title">Check-in submitted</div>
      ${""}
      <div class="confirm-sub">${mv?"Recovery refreshed":"Counted in today\u2019s score"} \xB7 ${S.coach.hasCoach?`${esc(S.coach.nameMid)} can see your readiness`:"feeds tomorrow\u2019s readiness"}</div>

      ${""}
      ${mv?`${scoreMoveDial({from:mv.from,to:mv.to,uid:"rc"})}
      <div class="confirm-sub">Daily Score \xB7 +${mv.gain} pts</div>`:""}
      ${mv&&firstEver()?`<div class="confirm-sub">Your first check-in. Recovery is ${liveWeightPct("checkin")+liveWeightPct("recovery")}% of the score, and it is the part only you can report.</div>`:""}

      ${(()=>{const msg=recoveryCoachMessage({ci:DAY.ci,ciConfig:DAY.ciConfig,hasCoach:S.coach.hasCoach,coachName:S.coach.nameMid});return msg?`
      <div class="sidebox" style="margin-top:18px; text-align:left; width:100%">
        <div class="req-icon p s38">${icon("message",17)}</div>
        <div><div class="tt">AI Nutritionist</div>
        <div class="ts">${esc(msg)}</div></div>
      </div>`:""})()}
      ${""}
      ${promoted&&S.streakDays>0?`<div class="confirm-sub">You finished the day on standard. Day ${S.streakDays} locks at midnight.</div>`:""}

      ${S.nextMove?"":`
      <div style="height:20px"></div>
      <div class="day-done" style="width:100%; text-align:left">
        <div class="req-icon g" style="width:44px;height:44px">${icon("check",21)}</div>
        <div><div class="tt">Every requirement is in.</div>
        <div class="ts">That was the last one. Same again tomorrow.</div></div>
      </div>`}
    </div>
    <div style="height:22px"></div>
    <button class="btn primary" data-back="home">Done</button>
    <div style="height:10px"></div>
    <button class="btn ghost sm" data-go="progress">See the week</button>
    <div style="height:10px"></div>
    `},mount(root){const mv=checkinMove();if(mv)playScoreMove(root,{key:`move:checkin:${DAY.date}:${mv.from}-${mv.to}`,from:mv.from,to:mv.to})}};export default{tab:"home",hideTabs:true,transient:true,render(){if(RT.recoveryDone){return`
      ${backHead("Recovery check-in","Done for tonight")}
      <div class="state-demo" style="border-style:solid; border-color:var(--green-border)">
        <div class="sd-ic" style="background:var(--green-surface);color:var(--green-bright)">${icon("check",24)}</div>
        <div class="sd-t">Submitted tonight</div>
        <div class="sd-s">Recovery counted \xB7 scored ${S.components.now.recovery}. ${S.coach.hasCoach?`${esc(S.coach.name)} can see your readiness before tomorrow's practice.`:`It feeds tomorrow's readiness.`}</div>
      </div>`}const R=S.recovery;const P=checkinProjection();const best=checkinBestProjection();return`
    ${backHead("Recovery check-in","Before bed \xB7 Takes 20 seconds")}

    ${""}
    <section class="card" style="padding: 4px 18px 8px">
      ${""}
      ${R.fields.map(f=>{const ns=f.inverse?[5,4,3,2,1]:[1,2,3,4,5];const loEnd=f.inverse?f.hi:f.lo;const hiEnd=f.inverse?f.lo:f.hi;return`
        <div class="rec-field" data-ci-key="${f.key}"${f.inverse?' data-inverse="1"':""}>
          <div class="rec-top">
            <span class="rec-name">${f.k}</span>
            <span class="rec-ends">${loEnd} \u2192 ${hiEnd}</span>
          </div>
          ${""}
          ${f.key==="sleep"?'<div class="rec-anchor" id="rec-sleep-anchor" hidden></div>':""}
          <div class="chips5" data-toggle-group role="radiogroup" aria-label="${f.k}">
            ${ns.map(n=>`<div class="chip ${n===f.val?"on":""}" data-n="${n}" role="radio" aria-checked="${n===f.val}" aria-label="${f.k}: ${n} of 5, ${n===1?f.lo:n===5?f.hi:"between"}">${n}</div>`).join("")}
          </div>
        </div>`}).join("")}
    </section>
    <div style="font-size:var(--t-sm);font-weight:600;color:var(--text-3);margin-top:8px;padding:0 2px;line-height:1.5">Answers are self-reported. Your Recovery points come from answering every question, never from how high the answers are, so keep it honest.</div>

    <div style="height:14px"></div>
    <div class="sidebox">
      <div class="req-icon p s38">${icon("moonStar",18)}</div>
      ${""}
      <div><div class="tt" id="rec-gain">${best.gain>0?`Current: ${S.score} \xB7 Earn up to +${best.gain}<span data-proj-wrap hidden> \xB7 Projected: <span data-proj>${P.to}</span></span>`:"Refreshes your Recovery score tonight"}</div>
      <div class="ts">Same math as your Score Breakdown: your answers set the exact number. ${S.coach.hasCoach?`${esc(S.coach.name)} sees your readiness before tomorrow's practice.`:"Honest answers are the whole point."}</div></div>
    </div>


    <!-- Wearable connect: hidden unless Apple Health / Health Connect is actually available on
         this build (probed in mount): device sleep/HRV is shown for CONTEXT on #apple-health and
         never changes the score. Keeps zero reachable "coming soon" until the module is wired. -->
    <div id="rec-connect" class="sidebox" data-go="apple-health" role="button" style="display:none;margin-top:14px;cursor:pointer">
      <div class="req-icon b s38">${icon("moonStar",17)}</div>
      <div><div class="tt">Connect Apple Health</div><div class="ts">Bring last night's sleep, HRV &amp; resting HR in for context</div></div>
    </div>
    ${""}
    <div class="action-bar">
      <button class="btn recovery" id="rec-submit" disabled>
        ${icon("check",19)} <span id="rec-submit-label">Answer all ${R.fields.length} to submit</span>
      </button>
    </div>
    `},mount(root){const answers={};const fields=root.querySelectorAll("[data-ci-key]");const total=fields.length;const submit=root.querySelector("#rec-submit");const submitLabel=root.querySelector("#rec-submit-label");const projWrap=root.querySelector("[data-proj-wrap]");const refreshGate=()=>{const done=Object.keys(answers).length;const ready=done>=total;if(submit)submit.disabled=!ready;if(submitLabel)submitLabel.textContent=ready?"Submit Check-In":`${done} of ${total} answered`;if(projWrap)projWrap.hidden=!ready;if(ready){const proj=root.querySelector("[data-proj]");if(proj)proj.textContent=String(checkinProjection(answers).to)}};fields.forEach(field=>{const key=field.getAttribute("data-ci-key");const chips=field.querySelectorAll(".chip");chips.forEach(ch=>{const n=+ch.getAttribute("data-n");if(ch.classList.contains("on"))answers[key]=n*2;ch.addEventListener("click",()=>{chips.forEach(x=>{x.classList.remove("on");x.setAttribute("aria-checked","false")});ch.classList.add("on");ch.setAttribute("aria-checked","true");answers[key]=n*2;refreshGate()})})});refreshGate();if(submit)submit.addEventListener("click",()=>{if(Object.keys(answers).length<total)return;act.submitRecovery(answers);window.__go("recovery-confirm")});roles.healthAvailable().then(ok=>{if(!ok)return;const row=root.querySelector("#rec-connect");if(row)row.style.display=""}).catch(()=>{});roles.healthRead().then(sample=>{const el=root.querySelector("#rec-sleep-anchor");if(!el||!root.isConnected)return;const hours=sample&&sample.sleepHours;const text=fmtDuration(hours);if(!text)return;el.innerHTML=`<span class="rec-anchor-v">${esc(text)}</span><span class="rec-anchor-d">measured last night</span>`;el.hidden=false}).catch(()=>{})}};
