export function identityLine(day,teamName,school){const org=String(school||"").trim()||String(teamName||"").trim();return org?`${day} \xB7 ${org}`:day}
