export function identityLine(day,teamName,school){const org=String(teamName||"").trim()||String(school||"").trim();return org?`${day} \xB7 ${org}`:day}
