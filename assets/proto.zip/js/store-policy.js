import{icon}from"./icons.js";import{esc}from"./components.js";export const isIOSApp=()=>typeof window!=="undefined"&&window.__PLATFORM==="ios";export const canOpenExternalCheckout=()=>!isIOSApp();export function storeNotice(what,extra=""){return`<div class="sidebox">
    <div class="req-icon b s38">${icon("lock",17)}</div>
    <div><div class="tt">Not bought in the app</div>
    <div class="ts">${esc(what)} ${esc(extra)}</div></div>
  </div>`}
