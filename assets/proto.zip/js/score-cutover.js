export const SCORING_V2_CUTOVER="2026-08-16";export function cutoverIndex(dates,cutover=SCORING_V2_CUTOVER){const i=(dates||[]).findIndex(d=>d>=cutover);return i>0?i:-1}
