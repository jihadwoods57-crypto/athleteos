// Real per-account day state + the honest score, computed from real logged data (not demo
// constants). The formulas are a byte-exact port of the RN engine (src/core/scoring.ts +
// scoringProfiles.ts + commitment.ts) — proven equal by a parity test (scripts/score-parity).
//
// The pure compute functions (computeComponents / scoreFor / tierFor) touch no browser APIs so
// they can be imported by the Node parity test. All Supabase / localStorage I/O is inside
// functions guarded for a non-browser environment.

import {
  LEGACY_STYLE, knobsFor, weightsFor, resolveStyleKey,
  rangeAdherence, fuelingAdequacy, awarenessScore, answeredSignals,
} from './plan-style.js';
// score-band.js is dependency-free on purpose, so the parity test can still import this module
// under Node. It owns the tier thresholds; nothing here re-declares them.
import { tierFor, gradeFor } from './score-band.js';
// pass.js is dependency-free for the same reason score-band.js is: the parity/unit tests import
// this module under Node.
import { passCoverage, slotMedians, withPassCredit } from './pass.js';

/* ---------------- engine constants (ported exactly) ---------------- */
export { PROFILE_WEIGHTS } from './plan-style.js';
export const MEAL_KEYS = ['breakfast', 'lunch', 'snack', 'dinner'];
export const DEADLINE = { breakfast: 570, lunch: 840, snack: 1020, dinner: 1230 }; // minutes from midnight
/* The classic OPEN edge per slot — mirrors the CATALOG windows in requirements.js. A slot with
   no entry is open all day. Scoring never reads this: it only decides whether a row reads
   "Upcoming · Opens 6:00 PM" instead of its deadline. */
export const OPEN = { breakfast: 420, lunch: 720, dinner: 1080 };
const QUICK_G = [18, 30, 22]; // Greek yogurt / protein shake / turkey roll-ups (protein g)
const QUICK_K = [150, 160, 120]; // kcal, index-aligned with QUICK_G (mirrors constants.ts QUICK_FOODS)
const PROTEIN_TARGET = 180;
const CAL_TARGET = 3200;
/* Check-in keys the recovery sub-score averages. `digestion` and `cravings` (0142) are the
   check-in-scoped BODY SIGNALS a Guided/Intuitive plan tracks; like every key here they are
   gated by ciConfig, and both default OFF (DEFAULT_CICFG) — so an existing athlete's recovery
   number is byte-identical until a plan style turns them on. */
const CI_KEYS = ['energy', 'recovery', 'sleep', 'confidence', 'soreness', 'motivation', 'digestion', 'cravings'];
/* Keys whose HIGH value is the negative pole — the engine inverts them so the stored answer
   always stays honest to what was actually asked (5 chips of cravings = constant cravings). */
const CI_INVERSE = { soreness: true, cravings: true };

const clamp = (v, lo, hi) => Math.max(lo, Math.min(hi, v));

/* ---- change counter ----
   Bumped by every path that changes the live day (a mutator's persist, a cache read, the reset,
   the standard/goal/style setters, the server merge). state.js keys its derived-getter memo on
   this together with its own save() counter, so a memoised score can never outlive the day it
   was computed from. Read via dayRev(); nothing outside this module writes it. */
let DAY_REV = 0;
export function dayRev() { return DAY_REV; }
function touch() { DAY_REV++; }

function withinTrailingWeek(dateStr, todayStr) {
  if (!dateStr || !todayStr) return false;
  const a = new Date(dateStr + 'T00:00:00');
  const b = new Date(todayStr + 'T00:00:00');
  const diff = (b - a) / 86400000;
  return diff >= 0 && diff <= 6;
}

/** Gallery reversal (founder direction 2026-07-15, replacing Rule A): a logged slot counts
 *  toward score/streak regardless of live-vs-gallery capture — the integrity wall is now the
 *  photo-hash duplicate check (migration 0062), not a blanket live-only exclusion. The ONLY
 *  slot that doesn't score is one whose photo was flagged as a duplicate
 *  (`slotMacros[k].flagged === 'dup'`): it stays logged and visible (coach sees the flag) but
 *  earns nothing. Pure + Node-importable, like the other compute fns below. Fixtures that
 *  never set slotMacros meta are unaffected. */
export function mealScored(day, k) {
  return !!(day.meals && day.meals[k]) && !(day.slotMacros && day.slotMacros[k] && day.slotMacros[k].flagged === 'dup');
}

/* ---- Coach standard (0055 requirement_sets → the SCORED day; WS3 slice 2) ----
   A room standard reshapes the day: which meal slots exist, their deadlines, and the
   nutrition denominator (meals 1–6). Null = the shipped classic day (byte-identical:
   MEAL_KEYS slots, DEADLINE windows, denominator 4) — every existing test stays locked. */
let STD = null; // { mealsRequired, slots: [key...], deadlines: {key: minutes}, titles: {key: label} }
function seedStandardSlots() {
  if (!STD || !Array.isArray(STD.slots)) return;
  for (const k of STD.slots) {
    if (!Object.prototype.hasOwnProperty.call(DAY.meals, k)) DAY.meals[k] = false;
  }
}
export function setDayStandard(std) {
  STD = std && std.mealsRequired > 0 && Array.isArray(std.slots) && std.slots.length ? std : null;
  seedStandardSlots();
  touch();
}
export function dayStandard() { return STD; }
/** Apply the athlete's goal-derived scoring config to the live day: which profile grades them
 *  (athlete / general / gain) and the calorie + protein targets the general/gain curves measure
 *  against. Called from state.js once the profile hydrates; the classic athlete default stands
 *  until a real goal says otherwise. Not persisted in the `days` row — always re-derived from the
 *  profile, exactly like the coach standard. */
export function setDayGoalConfig(profile, proteinTarget, calTarget) {
  DAY.scoringProfile = (profile === 'general' || profile === 'gain') ? profile : 'athlete';
  if (proteinTarget > 0) DAY.proteinTarget = Math.round(proteinTarget);
  if (calTarget > 0) DAY.calTarget = Math.round(calTarget);
  touch();
}
/** A slot's deadline: the standard's window when set, else the classic map, else end of day. */
export function slotDeadline(k, std = STD) {
  if (std && std.deadlines && std.deadlines[k] != null) return std.deadlines[k];
  return DEADLINE[k] != null ? DEADLINE[k] : 1440;
}
/** A slot's OPEN edge: the standard's window when one governs, else the classic map, else null
 *  ("open all day"). Never returns an open time that isn't strictly BEFORE the slot's deadline —
 *  a coach who moves dinner to 5:00 PM must not leave a stale "Opens 6:00 PM" sitting on a window
 *  that has already closed. Display only; no scoring path reads it. */
export function slotOpen(k, std = STD) {
  const o = (std && std.opens && std.opens[k] != null) ? std.opens[k] : (OPEN[k] != null ? OPEN[k] : null);
  return (o != null && o < slotDeadline(k, std)) ? o : null;
}
/** Grace minutes for a slot — a meal logged within deadline+grace still counts on-time. A
 *  standard with no grace (every shipped standard + the classic day) is 0, so scoring stays
 *  byte-identical to the parity-locked engine. */
export function slotGrace(k, std = STD) {
  return (std && std.grace && typeof std.grace[k] === 'number') ? std.grace[k] : 0;
}
/** Credit a slot earns when logged past deadline+grace: half (shipped default), full (the coach
 *  forgives lateness), or none (a hard window). Exported so the score breakdown explains lateness
 *  with the SAME credit the score applies (T-01), never a hardcoded half. */
export function slotLateCredit(k, std = STD) {
  const p = std && std.latePolicy && std.latePolicy[k];
  return p === 'full' ? 1 : p === 'none' ? 0 : 0.5;
}
const scoredSlotKeys = (std = STD) => (std && std.slots ? std.slots : MEAL_KEYS);

function effectiveMeals(day, std = STD) {
  let n = 0;
  for (const k of scoredSlotKeys(std)) {
    if (!mealScored(day, k)) continue;
    const at = day.mealLoggedAt && day.mealLoggedAt[k];
    const onTime = at == null || at <= slotDeadline(k, std) + slotGrace(k, std);
    n += onTime ? 1 : slotLateCredit(k, std); // late → the standard's late policy (default: half)
  }
  return n;
}

function proteinToday(day, std = STD) {
  let p = 0;
  for (const k of scoredSlotKeys(std)) {
    // Evidence rule: a logged slot with no saved plate earns 0 protein (matches mealSlotMacros).
    // A duplicate-flagged slot earns 0 protein too (mealScored excludes it).
    if (mealScored(day, k) && day.slotMacros && day.slotMacros[k]) p += day.slotMacros[k].protein || 0;
  }
  const q = day.quickAdded || [];
  for (let i = 0; i < q.length; i++) if (q[i]) p += QUICK_G[i] || 0;
  return p;
}

/** Calories logged today — the SAME evidence rule as protein (only a plated, non-duplicate,
 *  scored slot counts), plus quick-add kcal. Feeds the calorie-target adherence the general/gain
 *  profiles are graded on. */
function kcalToday(day, std = STD) {
  let k = 0;
  for (const key of scoredSlotKeys(std)) {
    if (mealScored(day, key) && day.slotMacros && day.slotMacros[key]) k += day.slotMacros[key].kcal || 0;
  }
  const q = day.quickAdded || [];
  for (let i = 0; i < q.length; i++) if (q[i]) k += QUICK_K[i] || 0;
  return k;
}

/* Calorie-target adherence (0..1), two-sided: full within ±10% of target, linear falloff to 0 at
   ±40%. Over- AND under-eating both lose credit, so `general` can never reward an unsafe deficit.
   Byte-for-byte port of calorieAdherence in src/core/scoringProfiles.ts. */
function calorieAdherence(kcal, target) {
  if (!(target > 0)) return 0;
  const dev = Math.abs(kcal - target) / target;
  if (dev <= 0.1) return 1;
  if (dev >= 0.4) return 0;
  return (0.4 - dev) / 0.3;
}
/* One-sided calorie FLOOR (0..1) for a muscle-gain client: full at/above target, linear to 0 at
   60% of it. Eating ABOVE target is the point of a bulk, so overage is never penalized. */
function calorieFloorAdherence(kcal, target) {
  if (!(target > 0)) return 0;
  if (kcal >= target) return 1;
  const ratio = kcal / target;
  if (ratio <= 0.6) return 0;
  return (ratio - 0.6) / 0.4;
}

/* ---- Plan style (0142 → the SPECTRUM of structure; Structured / Guided / Intuitive) ----
   A third axis alongside the goal profile and the coach standard. The GOAL sets the direction
   (which way the calorie curve leans, what the targets are), the STANDARD reshapes the day
   (slots, windows, denominator), and the STYLE sets how tightly all of it is measured.

   Null = the shipped classic scoring, byte-identical: `structured` on the `legacy` formula IS
   the per-profile formula below, so every existing account and every parity test is untouched. */
let PSTYLE = null;   // resolved style key, or null for the shipped default
let PKNOBS = null;   // the resolved knob set (preset + any professional overrides)

/** Apply the athlete's resolved plan style to the live day. Mirrors setDayGoalConfig /
 *  setDayStandard: not persisted in the row, always re-derived on hydrate — except for the
 *  per-day STAMP (day.planStyle), which is written so history is never rescored. */
export function setDayPlanStyle(style, knobs) {
  PSTYLE = resolveStyleKey(style);
  PKNOBS = PSTYLE ? (knobs || knobsFor(PSTYLE, null)) : null;
  DAY.planStyle = PSTYLE;
  DAY.planKnobs = PKNOBS;
  touch();
}
export function dayPlanStyle() { return PSTYLE; }
export function dayPlanKnobs() { return PKNOBS; }

/** The style governing THIS day object: its own stamp first (so a reconstructed history day is
 *  graded by the style that actually governed it), then the live runtime, then the shipped
 *  default. Pure — a Node test can drive it with no runtime state. */
export function styleOf(day) {
  return resolveStyleKey(day && day.planStyle) || PSTYLE || LEGACY_STYLE;
}
/** The knobs governing THIS day object, same precedence. */
export function knobsOf(day) {
  if (day && day.planKnobs) return day.planKnobs;
  const s = styleOf(day);
  if (PKNOBS && s === PSTYLE) return PKNOBS;
  return knobsFor(s, null);
}

/** Hydration credit (0..1) against the day's target. 3.0 L is the shipped default; a coach
 *  standard's hydration item target (oz) overrides it via day.hydrationTargetL. */
const HYDRATION_TARGET_L = 3.0;
function hydrationFrac(day) {
  const t = day.hydrationTargetL > 0 ? day.hydrationTargetL : HYDRATION_TARGET_L;
  return clamp((day.hydrationL || 0) / t, 0, 1);
}

/** Plate-quality credit (0..1): the mean of the AI quality reads (0..100) already stored per
 *  scored slot by dayLogMeal. Slots with no quality read are simply not counted — a missing
 *  signal never costs the athlete. No plates read at all → falls back to meal consistency, so
 *  quality can never strand points on a day that was otherwise executed. */
function qualityFrac(day, std, mealsFrac) {
  let sum = 0, n = 0;
  for (const k of scoredSlotKeys(std)) {
    if (!mealScored(day, k)) continue;
    const q = day.slotMacros && day.slotMacros[k] && day.slotMacros[k].quality;
    if (typeof q === 'number' && isFinite(q)) { sum += clamp(q, 0, 100); n++; }
  }
  return n ? sum / (n * 100) : mealsFrac;
}

/** The shipped per-goal-profile nutrition formula — a byte-for-byte port of
 *  profileNutritionScore, UNCHANGED:
 *   - athlete: protein 65 + on-time meals 35 (the shipped formula).
 *   - general: calorie adherence 45 + protein 25 + meal consistency 30 (a lose/maintain client).
 *   - gain:    calorie floor 40 + protein 35 + meal consistency 25 (surplus + protein led).
 *  The platform owns these weights; the coach/trainer owns the targets (Scoring Contract).
 *  This is what `structured` scores on by default, which is what grandfathers every existing
 *  account: their number does not move on release day. */
function legacyNutritionScore(day, std, proteinFrac, mealsFrac) {
  const profile = day.scoringProfile || 'athlete';
  if (profile === 'general') {
    const ct = day.calTarget > 0 ? day.calTarget : CAL_TARGET;
    return Math.min(100, Math.round(calorieAdherence(kcalToday(day, std), ct) * 45 + proteinFrac * 25 + mealsFrac * 30));
  }
  if (profile === 'gain') {
    const ct = day.calTarget > 0 ? day.calTarget : CAL_TARGET;
    return Math.min(100, Math.round(calorieFloorAdherence(kcalToday(day, std), ct) * 40 + proteinFrac * 35 + mealsFrac * 25));
  }
  return Math.min(100, Math.round(proteinFrac * 65 + mealsFrac * 35));
}

/** Whether this day carries ANY nutrition evidence — a slot that actually SCORES (mealScored:
 *  logged AND not photo-reuse-flagged), across whatever slot set the governing coach standard
 *  uses, or a quick-add. This is the ONE shared gate `evidenceCeiling` and `partsNutritionScore`'s
 *  awareness credit must both read.
 *
 *  Two review rounds found two ways for a second hand-written "did they log food" check to drift
 *  from the real scoring path:
 *   (1) a raw `MEAL_KEYS.some(k => day.meals[k])` only ever sees the classic four slots. A 5- or
 *       6-meal coach standard scores `meal-5`/`meal-6` too (scoredSlotKeys(std), STD_SLOT_MAP in
 *       requirements.js) — those slots could earn real nutrition credit while this gate still saw
 *       nothing, erasing the whole score. Fixed by scanning `scoredSlotKeys(std)`, the SAME set
 *       `nutritionScore` scores, instead of the hardcoded classic four.
 *   (2) a raw `day.slotMacros` non-empty check counted a dup-flagged plate as evidence — reusing a
 *       photo bought nutrition credit the 0062 photo-hash wall exists specifically to deny. Fixed
 *       by routing every slot through `mealScored`, which already excludes `flagged: 'dup'`.
 *  `std` defaults to the module `STD`, exactly like `nutritionScore`/`computeComponents` — a
 *  caller with a specific standard in hand (or a Node test) can still pass one explicitly. */
export function hasNutritionEvidence(day, std = STD) {
  return scoredSlotKeys(std).some((k) => mealScored(day, k)) ||
    (Array.isArray(day.quickAdded) && day.quickAdded.some(Boolean));
}

/** The composition path (Guided, Intuitive, and any customized style): each enabled part earns
 *  its share of 100. The parts are already normalized to sum to 100 by knobsFor, and a part whose
 *  knob is off is already zeroed there — so this is a straight weighted sum with no stranded
 *  points. Which CURVE prices calories and protein is the style's own choice:
 *
 *    calorie: 'exact'    → the two-sided goal curve (Structured's tightness)
 *             'range'    → full credit inside the band, forgiving falloff (Guided)
 *             'adequacy' → a generous one-sided floor; over is never penalized (Intuitive)
 *    protein: 'exact'    → fraction of target      'range' → band credit      'off' → not scored
 */
function partsNutritionScore(day, std, knobs, proteinFrac, mealsFrac) {
  const parts = knobs.parts;
  const n = knobs.nutrition;
  const pt = day.proteinTarget > 0 ? day.proteinTarget : PROTEIN_TARGET;
  const ct = day.calTarget > 0 ? day.calTarget : CAL_TARGET;
  const kcal = kcalToday(day, std);
  const profile = day.scoringProfile || 'athlete';

  let calorieCredit = 0;
  if (n.calorie === 'exact') {
    calorieCredit = profile === 'gain' ? calorieFloorAdherence(kcal, ct) : calorieAdherence(kcal, ct);
  } else if (n.calorie === 'range') {
    calorieCredit = rangeAdherence(kcal, ct, n.calorieBand);
  } else if (n.calorie === 'adequacy') {
    calorieCredit = fuelingAdequacy(kcal, ct);
  }

  let proteinCredit = 0;
  if (n.protein === 'exact') proteinCredit = proteinFrac;
  else if (n.protein === 'range') proteinCredit = rangeAdherence(proteinToday(day, std), pt, n.proteinBand);

  // Awareness credit, with the meal-time prompt gone (2026-07-28). awarenessScore now returns a
  // constant 1 — the no-drop grandfather, see its header — but a day the athlete never touched
  // must still floor at 0. Before the removal an untouched day answered no signals and scored no
  // awareness; handing it 35 free points would invent engagement that didn't happen. So the
  // credit is gated on the athlete having logged FOOD today — a meal or a quick-add.
  // FOUNDER RULING (2026-08-09, Task 2 review): a check-in alone must NOT unlock awareness. It
  // used to (`mealsFrac > 0 || checkinReal(day)`), which meant Intuitive could earn ~47 nutrition
  // points off a check-in with nothing on the plate, well above what evidenceCeiling would allow
  // for a day with no nutrition evidence — the write-path clamp caught it, silently cutting the
  // athlete's own displayed score. Fixed at the source instead of raising the ceiling: awareness
  // now shares hasNutritionEvidence with evidenceCeiling, so a day with no food never has anything
  // to be "aware" of, on either the display or the write path.
  const engaged = hasNutritionEvidence(day, std);
  const awareCredit = n.awarenessScored && engaged
    ? awarenessScore(answeredSignals(day, checkinReal(day)), knobs, day.signalWeekRate)
    : 0;

  const total = parts.protein * proteinCredit
    + parts.calorie * calorieCredit
    + parts.timing * mealsFrac
    + parts.hydration * hydrationFrac(day)
    + parts.quality * qualityFrac(day, std, mealsFrac)
    + parts.awareness * awareCredit;
  return clamp(Math.round(total), 0, 100);
}

/** Style- and profile-aware nutrition sub-score (0..100). Routes to the legacy passthrough (the
 *  shipped formula, unchanged) or the parts composition — see knobsFor()'s `formula`. */
function nutritionScore(day, std = STD) {
  const pt = day.proteinTarget > 0 ? day.proteinTarget : PROTEIN_TARGET;
  const proteinFrac = pt > 0 ? Math.min(proteinToday(day, std), pt) / pt : 0;
  // Denominator = the coach standard's meal count (1–6) when one governs; classic 4 otherwise.
  const mealsFrac = clamp(effectiveMeals(day, std) / ((std && std.mealsRequired) || 4), 0, 1);
  const knobs = knobsOf(day);
  if (!knobs || !knobs.nutrition || knobs.nutrition.formula !== 'parts') {
    return legacyNutritionScore(day, std, proteinFrac, mealsFrac);
  }
  return partsNutritionScore(day, std, knobs, proteinFrac, mealsFrac);
}

/* v2: no weekly carry. Recovery reflects TONIGHT's answers or it contributes nothing — the score
   is what you did today. The old `ciLast` branch handed Monday's number back all week, which is
   how a day with zero logging still banked ~21 points. */
function recoveryParts(day) {
  if (!day.ciSubmitted) return { score: 86, isReal: false }; // display fallback; contributes 0
  let sum = 0, count = 0;
  for (const key of CI_KEYS) {
    if (!(day.ciConfig && day.ciConfig[key])) continue;
    const raw = day.ci ? day.ci[key] : undefined;
    if (typeof raw !== 'number' || !isFinite(raw)) continue;
    sum += CI_INVERSE[key] ? 10 - raw : raw; // soreness / cravings have inverse polarity
    count++;
  }
  if (count > 0) return { score: clamp(Math.round((sum / (count * 10)) * 100), 0, 100), isReal: true };
  return { score: 86, isReal: false };
}

function commitmentScore(ans) { return ans === 'yes' ? 100 : ans === 'partial' ? 60 : 0; }
/* v2: "checked in TONIGHT", not "sometime this week". The trailing-7-day branch made this a
   seven-day annuity — one check-in on Monday paid every day through Sunday. */
export function checkinReal(day) { return !!day.ciSubmitted; }

/* ---- Trust Pass credit (0196) ----------------------------------------------------------------
   A pass-covered slot has no logged meal, so the honest thing to score is the athlete's own
   trailing median for that slot. pass.js synthesizes it into a CLONE and this is the single seam
   where that clone enters the engine — nutritionScore and its six parts are untouched.

   THE PASS CONTEXT RIDES ON THE DAY, never on module scope. coach.js reconstructs another
   athlete's days through dayFromHistoryRow and scores them, so reading DAY.passes here would let
   a coach who happens to hold a pass credit it to their athlete — the same cross-athlete hazard
   the proteinTarget/std threading already closes. A day with no `passes` array is scored exactly
   as it was before 0196, which is every fixture and every reconstructed row. */
function scoringView(day, std = STD) {
  const passes = (day && day.passes) || null;
  const spends = (day && day.passSpends) || null;
  if (!passes || !passes.length) return { day, std };

  const coverage = passCoverage(day.date, passes, spends, (std && std.slots) || null);
  if (!coverage.size) return { day, std };

  // Every ${date}|${slot} a pass already covered in the loaded window. Excluding these is what
  // stops the median averaging its own output; see invariant 1 in pass.js.
  const coveredKeys = new Set();
  for (const r of day.scoreHistory || []) {
    for (const slot of passCoverage(r.date, passes, spends, (std && std.slots) || null)) {
      coveredKeys.add(`${r.date}|${slot}`);
    }
  }

  const medians = slotMedians(day.scoreHistory, (std && std.slots) || null, { coveredKeys });
  return withPassCredit(day, std, coverage, medians);
}

/** The four sub-scores. `recoveryContribution` is what the total uses (0 unless a real check-in
 *  backs it). Only nutrition depends on the standard (meal slots/windows/denominator); recovery,
 *  commitment, and check-in are standard-independent, so `std` only reaches nutritionScore. */
export function computeComponents(day, std = STD) {
  const v = scoringView(day, std);
  const rec = recoveryParts(v.day);
  return {
    nutrition: nutritionScore(v.day, v.std),
    recovery: rec.score,
    recoveryContribution: rec.isReal ? rec.score : 0,
    commitment: commitmentScore(v.day.dailyCommitment),
    checkin: checkinReal(v.day) ? 100 : 0,
  };
}

/** The headline mix for a day: its plan style crossed with its goal profile. Every style row is
 *  capped so the 0041 evidence ceiling still bounds the result (planStyleCaps.test.ts), and the
 *  `structured` row IS PROFILE_WEIGHTS — so a classic day weighs exactly what it always did. */
export function weightsForDay(day) {
  return weightsFor(styleOf(day), day.scoringProfile);
}

export function scoreFor(day, std = STD) {
  const w = weightsForDay(day);
  const c = computeComponents(day, std);
  return clamp(Math.round(w.nutrition * c.nutrition + w.recovery * c.recoveryContribution + w.commitment * c.commitment + w.checkin * c.checkin), 0, 100);
}

// gradeFor moved to score-band.js (the letter ladder shares the tier floors plus its own 70 step);
// re-exported below so existing importers keep working.
export { gradeFor };

/* ---------------- evidence ceiling (mirror of the server trigger) ---------------- */
// Keep the client score honest so the server clamp never has to silently lower it.
/** Mirror of the 0193 server ceiling: the most the evidence on a row can justify. Nutrition
 *  evidence unlocks 78 (the max across profiles); a real check-in unlocks recovery 12 + check-in
 *  12. A commitment answer unlocks nothing — it no longer scores. `hasNutritionEvidence` is the
 *  SAME check partsNutritionScore's awareness gate uses — see its comment for why that matters:
 *  a quick-add-only day must count here, or a real logged day gets clamped to a lower stored score
 *  than the one the athlete's own screen just showed them. `std` defaults to the module STD, same
 *  as `scoreFor`/`computeComponents`, so a 5-/6-meal coach standard's `meal-5`/`meal-6` slots are
 *  evidence here too — a hardcoded classic-four check would erase the whole score on that room. */
export function evidenceCeiling(day, std = STD) {
  // Runs on the SAME credited view scoreFor sees, or the two disagree the moment a pass is the
  // only nutrition evidence on the row: scoreFor credits the median while this reads the raw day,
  // sees no logged meal, and returns 0. clampedScore would then show the athlete a zero for the
  // day their reward was supposed to protect. Mirrors gate (d) of 0196's server ceiling.
  const v = scoringView(day, std);
  return (hasNutritionEvidence(v.day, v.std) ? 78 : 0) + (checkinReal(v.day) ? 24 : 0);
}
export function clampedScore(day) { return Math.min(scoreFor(day), evidenceCeiling(day)); }

/* ================= real per-account day state + Supabase I/O ================= */
// (browser-only below; the pure functions above stay Node-importable for the parity test.)

function todayISO() { const d = new Date(); return `${d.getFullYear()}-${String(d.getMonth() + 1).padStart(2, '0')}-${String(d.getDate()).padStart(2, '0')}`; }
export function addDaysISO(iso, n) { const d = new Date(iso + 'T00:00:00'); d.setDate(d.getDate() + n); return `${d.getFullYear()}-${String(d.getMonth() + 1).padStart(2, '0')}-${String(d.getDate()).padStart(2, '0')}`; }
export function minutesNow() { const d = new Date(); return d.getHours() * 60 + d.getMinutes(); }

const DEFAULT_CI = { energy: 8, recovery: 7, sleep: 8, confidence: 9, soreness: 4, motivation: 8, digestion: 7, cravings: 4 };
/* digestion/cravings default OFF: they only switch on when a plan style asks for them
   (styleCheckinConfig in state.js), so nobody's existing recovery number moves. */
const DEFAULT_CICFG = { energy: true, recovery: true, sleep: true, confidence: true, soreness: false, motivation: false, digestion: false, cravings: false };

export const DAY = {
  date: todayISO(),
  meals: { breakfast: false, lunch: false, snack: false, dinner: false },
  mealLoggedAt: {},
  slotMacros: {},
  quickAdded: [false, false, false],
  checkedTasks: {}, // standing NON-MEAL check items completed today { id: true } — tracked, not scored
  hydrationL: 0,
  dailyCommitment: null,
  commitmentFocus: null, // the athlete's written intention for today (rides the checkin jsonb)
  ci: { ...DEFAULT_CI },
  ciConfig: { ...DEFAULT_CICFG },
  ciSubmitted: false,
  ciLast: null,          // { date, recovery }
  proteinTarget: 180,
  calTarget: 3200,
  scoringProfile: 'athlete',
  planStyle: null,       // 0142 — the style governing today; STAMPED into the row so history is never rescored
  planKnobs: null,       // the resolved knob set (preset + professional overrides); re-derived, not persisted
  signals: {},           // { slotKey: { hunger, fullness, satisfaction } } — the 2-tap post-meal prompt
  signalWeekRate: null,  // 0..1 trailing-week signal answer rate, so one skipped day barely moves awareness
  hydrationTargetL: 0,   // 0 = the shipped 3.0 L default; a coach hydration item overrides it
  currentWeight: null,
  scoreHistory: [],      // [{date, score}] past days, for streak/trend
  // Trust Pass state (0196). Carried ON THE DAY rather than read from module scope by the scorer,
  // for the same reason proteinTarget is: coach.js reconstructs ANOTHER athlete's days and scores
  // them, and a coach who happens to hold a pass must never credit it to their athlete.
  passes: [],            // trust_passes rows overlapping the loaded window
  passSpends: [],        // pass_spends rows in the same window
  /* Lifetime count of distinct photo-logged days, read from the SAME rows 0196's grant_pass
     wall counts (meals where photo_path is not null) — so the eligibility screen shows the
     number the server will actually check, not a proxy bounded by however much history this
     device happens to hold. null = never fetched (offline); the passEligibleDays getter then
     falls back to the history proxy rather than showing a fabricated 0. */
  photoDays: null,
};

export function dayScore() { return scoreFor(DAY); }

/** Reconstruct a past day object from a scoreHistory row (its meals + checkin jsonb) so the
 *  SAME computeComponents that scores today can grade history — real category trends, no
 *  second formula. Rows fetched before the jsonb ride-along return null (callers skip them).
 *
 *  `cfg` overrides the nutrition targets/profile the reconstructed day is scored against.
 *  Default = the live device DAY's values (correct for the signed-in athlete's own history).
 *  A COACH viewing another athlete MUST pass that athlete's own {proteinTarget, calTarget,
 *  scoringProfile}, or nutrition would be graded against the coach device's targets — the
 *  cross-athlete hazard the std-threading also closes. Pair with an explicit std at the
 *  computeComponents/scoreFor call. */
export function dayFromHistoryRow(r, cfg) {
  if (!r || !r.meals || !r.checkin) return null;
  const ck = r.checkin || {};
  const c = cfg || {};
  return {
    date: r.date,
    meals: r.meals,
    mealLoggedAt: ck.mealLoggedAt || {},
    slotMacros: ck.slotMacros || {},
    quickAdded: r.quickAdded || [],
    hydrationL: r.hydrationL || 0,
    dailyCommitment: ck.commitment ?? null,
    ci: { energy: ck.energy, recovery: ck.recovery, sleep: ck.sleep, confidence: ck.confidence, soreness: ck.soreness, motivation: ck.motivation },
    ciConfig: { ...DEFAULT_CICFG },
    ciSubmitted: !!ck.submitted,
    ciLast: ck.ciLast && ck.ciLast.date ? ck.ciLast : null,
    proteinTarget: c.proteinTarget != null ? c.proteinTarget : DAY.proteinTarget,
    calTarget: c.calTarget != null ? c.calTarget : DAY.calTarget,
    scoringProfile: c.scoringProfile != null ? c.scoringProfile : DAY.scoringProfile,
    // The STAMP the row carried, not today's style: a day is always graded by the style that
    // actually governed it (founder decision — a style switch never rewrites history). Rows
    // written before 0142 have no stamp and fall through to the shipped classic scoring.
    planStyle: resolveStyleKey(r.planStyle) || null,
    planKnobs: c.planKnobs || null,
    signals: ck.signals || {},
    hydrationTargetL: c.hydrationTargetL || 0,
    currentWeight: r.weight ?? null,
    scoreHistory: [],
    // TRUST PASS: deliberately absent, so a reconstructed row scores exactly as it did before
    // 0196. Two reasons, and both need answering before this changes:
    //   1. cross-athlete. coach.js scores another athlete's days through here, so the passes
    //      would have to come from THAT athlete via `cfg`, never from the device's own DAY.
    //   2. the median would need a trailing window relative to THAT row's date. This object
    //      carries scoreHistory: [], and handing it the live history would let days AFTER the
    //      row leak into its own median.
    // Until both are solved, Progress and the coach breakdown show a covered day uncredited,
    // which is understating rather than inventing — the safe direction.
  };
}
/** "If you finish today" projection — all requirements done — for the reach/possible messaging. */
export function projectedDay(nowMin) {
  const p = JSON.parse(JSON.stringify(DAY));
  // Which scored slots are NOT yet really logged — only these can decay to a late projection.
  // Captured BEFORE the slots below are marked complete, which would erase the distinction.
  const unlogged = {};
  for (const k of scoredSlotKeys()) unlogged[k] = !mealScored(p, k);
  p.meals = { breakfast: true, lunch: true, snack: true, dinner: true };
  // A governing standard projects ITS slots complete (a 6-meal room's "possible" includes
  // meal-5/meal-6; a 2-meal room's projection is just its two).
  for (const k of scoredSlotKeys()) p.meals[k] = true;
  // Gallery slots score now (2026-07-15), so no flag-clearing is needed; a duplicate-flagged
  // slot stays excluded even in the projection — that meal honestly can't count.
  //
  // HONEST DECAY: an unlogged slot whose window has already closed can only be logged LATE
  // from here, so project it at the late half-credit instead of promising on-time credit the
  // athlete can no longer earn. Real stamps are never overwritten — actual punctuality wins.
  // Omit `nowMin` and the projection is byte-identical to before, so every existing caller
  // and the score-parity lock are unaffected.
  if (nowMin != null) {
    if (!p.mealLoggedAt) p.mealLoggedAt = {};
    for (const k of scoredSlotKeys()) {
      if (unlogged[k] && p.mealLoggedAt[k] == null && nowMin > slotDeadline(k)) p.mealLoggedAt[k] = nowMin;
    }
  }
  p.ciSubmitted = true;
  p.dailyCommitment = 'yes';
  return p;
}
export function dayComponents() { return computeComponents(DAY); }
// Re-exported so existing importers keep working; the ladder itself lives in score-band.js.
export { tierFor };

/** Honest streak with the council-ruled grace (roadmap #11).
 *
 *  - The run is consecutive qualifying (>= 80) HISTORY days ending yesterday, plus today
 *    once today's live score qualifies. An INCOMPLETE today never zeroes the run — the
 *    morning after a 10-day run reads "10", not "0" (the old behavior punished the exact
 *    moment retention is decided).
 *  - ONE sub-80 / missed day per rolling 7 is GRACED: the chain survives it but the graced
 *    day itself doesn't count. A second miss within 7 days of the last graced one ends the
 *    run — grace is a bridge, not a discount.
 *  - Days before the earliest history row are UNKNOWN, not misses: the walk stops there
 *    without burning grace (history hydrates ~60 days; an older run just reads as its
 *    visible tail — honest, never inflated).
 *
 *  Returns { days, todayCounted, graceDate } — graceDate is the most recent graced miss
 *  inside the run (null when the grace is intact). */
export function streakInfo(activationDate = /** @type {string | null} */ (null)) {
  const THRESH = 80;
  const byDate = {};
  let earliest = null;
  for (const h of DAY.scoreHistory || []) {
    byDate[h.date] = h.score;
    if (earliest === null || h.date < earliest) earliest = h.date;
  }
  const diffDays = (a, b) => Math.round((new Date(b + 'T12:00:00') - new Date(a + 'T12:00:00')) / 86400000);
  // First-day activation (no retroactive failure): the activation day is a partial day the athlete
  // is never scored on — it neither counts toward the streak nor breaks it. `activationDate` is a
  // 'YYYY-MM-DD'; null (existing users) leaves every rule below untouched.
  const isActivationDay = !!activationDate && DAY.date === activationDate;
  const todayCounted = !isActivationDay && dayScore() >= THRESH;
  let days = todayCounted ? 1 : 0;
  let graceDate = null;   // most recent graced miss (first one met walking backward)
  let lastGrace = null;   // for the rolling-7 rule
  let cursor = addDaysISO(DAY.date, -1);
  while (earliest !== null && cursor >= earliest) {
    // The activation day and everything before it predate accountability — stop the walk there
    // (never a miss, never burns grace, never counts).
    if (activationDate && cursor <= activationDate) break;
    const s = byDate[cursor];
    if (typeof s === 'number' && s >= THRESH) {
      days++;
      cursor = addDaysISO(cursor, -1);
      continue;
    }
    // a miss (below the bar, or a day with no row inside known history)
    if (lastGrace === null || diffDays(cursor, lastGrace) >= 7) {
      lastGrace = cursor;
      if (graceDate === null) graceDate = cursor;
      cursor = addDaysISO(cursor, -1);
      continue; // graced: chain survives, day doesn't count
    }
    break; // second miss inside the rolling week — the run honestly ends
  }
  return { days, todayCounted, graceDate };
}

/** Back-compat: the plain day count (now grace-aware and morning-safe). `activationDate`
 *  (a 'YYYY-MM-DD', or null) forwards the first-day exclusion to streakInfo. */
export function streakDays(activationDate = /** @type {string | null} */ (null)) { return streakInfo(activationDate).days; }

/* ---- offline cache (per user) ---- */
function cacheKey(userId) { return `onstd-day-${userId}-${DAY.date}`; }
function saveCache(userId) { touch(); try { localStorage.setItem(cacheKey(userId), JSON.stringify(DAY)); } catch { /* quota */ } }
/** Restore today's cached day onto DAY. True when the cache held TODAY for this user. */
function loadCache(userId) {
  touch();
  try {
    const j = JSON.parse(localStorage.getItem(cacheKey(userId)) || 'null');
    if (j && j.date === DAY.date) { Object.assign(DAY, j); return true; }
  } catch { /* ignore */ }
  return false;
}
/** The boot's first paint: reset to a fresh day and restore this user's cache for today, exactly
 *  the two steps loadDay() opens with, so router.js can draw the cached day BEFORE hydrateDay()'s
 *  network round trip. True when there was something to draw. loadDay() re-runs both steps and
 *  layers the server row on top, so calling this first changes nothing about the merge. */
export function primeDayFromCache(userId) {
  if (!userId || typeof localStorage === 'undefined') return false;
  dayResetLocal();
  DAY.date = todayISO();
  return loadCache(userId);
}

/* ---- Supabase read/write ---- */
/* Merge the server row into DAY without ever ERASING same-day local progress. Within one
   day the logged facts are monotonic — a meal, a submitted check-in, a commitment, sipped
   water don't un-happen — so booleans merge with OR and hydration with max. This is what
   makes an offline-logged day survive reconnect: without it, an older server row (meals all
   false) would overwrite the cache-restored local day and the logs would vanish. Returns
   true when the LOCAL day carries anything the server row doesn't (the caller then pushes
   the reconciled day back up). */
function projectRowToDay(row) {
  if (!row) return false;
  let localAhead = false;
  const rowMeals = row.meals || {};
  // Reconcile the classic slots PLUS any standard slots and any extra keys the server row
  // carries (a 6-meal room's meal-5/meal-6 ride the same jsonb).
  const slotSet = new Set([...MEAL_KEYS, ...(STD && STD.slots ? STD.slots : []), ...Object.keys(rowMeals)]);
  for (const k of slotSet) {
    if (DAY.meals[k] && !rowMeals[k]) localAhead = true;
    DAY.meals[k] = !!(DAY.meals[k] || rowMeals[k]);
  }
  const rowHydration = Number(row.hydration_l) || 0;
  if (DAY.hydrationL > rowHydration) localAhead = true;
  DAY.hydrationL = Math.max(DAY.hydrationL, rowHydration);
  if (Array.isArray(row.quick_added) && row.quick_added.length) {
    for (let i = 0; i < DAY.quickAdded.length; i++) {
      if (DAY.quickAdded[i] && !row.quick_added[i]) localAhead = true;
      DAY.quickAdded[i] = !!(DAY.quickAdded[i] || row.quick_added[i]);
    }
  } else if (DAY.quickAdded.some(Boolean)) localAhead = true;
  // Standing check-item completions merge as a UNION: a local tap outranks a server gap; a server
  // completion this device lacks is adopted. Tracked, not scored (never touches computeComponents).
  {
    const rc = (row.checked_tasks && typeof row.checked_tasks === 'object') ? row.checked_tasks : {};
    if (!DAY.checkedTasks) DAY.checkedTasks = {};
    for (const id of Object.keys(DAY.checkedTasks)) { if (DAY.checkedTasks[id] && !rc[id]) localAhead = true; }
    for (const id of Object.keys(rc)) { if (rc[id]) DAY.checkedTasks[id] = true; }
  }
  if (DAY.currentWeight != null && row.current_weight == null) localAhead = true;
  DAY.currentWeight = DAY.currentWeight ?? row.current_weight ?? null;
  // Body signals merge per slot as a UNION, local-wins-on-conflict — the same shape as the
  // check-item merge above. A pre-0142 row carries no `signals`, so this is a no-op for it.
  {
    const rs = (row.signals && typeof row.signals === 'object') ? row.signals : {};
    if (!DAY.signals) DAY.signals = {};
    for (const slot of Object.keys(rs)) {
      const local = DAY.signals[slot] || {};
      const remote = rs[slot] || {};
      for (const k of Object.keys(local)) { if (remote[k] == null) localAhead = true; }
      DAY.signals[slot] = { ...remote, ...local };
    }
  }
  const ck = row.checkin || {};
  // Check-in answers: a locally SUBMITTED check-in outranks unsubmitted server answers.
  if (DAY.ciSubmitted && !ck.submitted) {
    localAhead = true;
  } else {
    DAY.ci = { energy: ck.energy ?? DAY.ci.energy, recovery: ck.recovery ?? DAY.ci.recovery, sleep: ck.sleep ?? DAY.ci.sleep, confidence: ck.confidence ?? DAY.ci.confidence, soreness: ck.soreness ?? DAY.ci.soreness, motivation: ck.motivation ?? DAY.ci.motivation };
  }
  DAY.ciSubmitted = !!(DAY.ciSubmitted || ck.submitted);
  DAY.ciLast = ck.ciLast && ck.ciLast.date ? ck.ciLast : (typeof ck.ciLast === 'string' ? { date: ck.ciLast, recovery: ck.recovery ?? 0 } : DAY.ciLast);
  if (DAY.dailyCommitment && ck.commitment == null) localAhead = true;
  DAY.dailyCommitment = DAY.dailyCommitment ?? ck.commitment ?? null;
  DAY.commitmentFocus = DAY.commitmentFocus ?? ck.focus ?? null;
  // Logged-at times ride the same jsonb (they power on-time history + category trends).
  DAY.mealLoggedAt = { ...(ck.mealLoggedAt || {}), ...DAY.mealLoggedAt };
  // Plate meta merges per-slot: local slots win (they carry the freshest AI meta), server
  // fills the slots this device doesn't have.
  DAY.slotMacros = { ...(ck.slotMacros || {}), ...DAY.slotMacros };
  return localAhead;
}

/* The days columns the client may SELECT directly after 0103's column-split grant — everything
   except current_weight, which only the weight_series RPC returns. Keep in sync with the 0103
   grant list (and add any future days column to BOTH). */
export const DAY_SELECT_COLS = 'id,athlete_id,date,meals,hydration_l,tasks,checked_tasks,quick_added,checkin,score,grade,plan_style,signals,computed_at,updated_at';

/* Trailing-history windows. HISTORY_DAYS is how far back the day load reaches at all — the
   streak walk, Progress's 30-day consistency and the monthly report read that whole span, but
   only as {date, score, plan_style} (weight rides the weight_series RPC). HISTORY_HEAVY_DAYS
   bounds the jsonb ride-along (meals/checkin/quick_added/signals — checkin carries every slot's
   full AI macro meta, which is what made the old 60-day ride-along the heaviest payload behind
   painting today). Every consumer of the heavy fields is trailing-N: slotMedians' trailing-10
   evidence days, categoryTrends/progressInsight over the reconstructed recent past,
   signalWeekRate's trailing 7, and the pass-eligibility proxy, whose server policy caps
   eligibility_days at 30 (0196's check constraint) — so 35 covers them all with room. The one
   visible edge: a slot photo-logged fewer than 5 times in 35 days no longer reaches back 60 for
   a median, so a pass excuses it instead of crediting stale macros — understating, never
   inventing, same direction dayFromHistoryRow already chose. */
export const HISTORY_DAYS = 60;
export const HISTORY_HEAVY_DAYS = 35;

/** The athlete's weight-by-date map via the 0103 weight_series RPC (is_self always passes;
 *  a restricted viewer gets zero rows, never an error). Pre-apply fallback: before 0103 lands
 *  the RPC doesn't exist, so a direct column select (still granted then) keeps weight working —
 *  making the client safe to ship AHEAD of the migration, which the 0103 deploy order requires. */
export async function fetchWeightSeries(sb, userId, daysBack) {
  const m = new Map();
  if (!sb || !userId) return m;
  try {
    const { data, error } = await sb.rpc('weight_series', { athlete: userId, days_back: daysBack });
    if (!error && Array.isArray(data)) {
      for (const r of data) if (r && r.weight != null) m.set(String(r.date), r.weight);
      return m;
    }
  } catch { /* fall through to the pre-0103 path */ }
  try {
    const { data } = await sb.from('days').select('date,current_weight')
      .eq('athlete_id', userId).gte('date', addDaysISO(todayISO(), -daysBack)).not('current_weight', 'is', null);
    if (Array.isArray(data)) for (const r of data) if (r && r.current_weight != null) m.set(String(r.date), r.current_weight);
  } catch { /* offline / post-0103 without the RPC result — weight simply absent this load */ }
  return m;
}

/** Fetch DAY.passes / DAY.passSpends over the trailing `since..today` window. Shared by loadDay
 *  (as part of the normal day load) and reloadPassState (after a spend, when only the pass side
 *  needs a fresh read). A THROW MUST NOT BECOME []: an empty array is indistinguishable from "no
 *  pass", so swallowing a failure would silently drop a credit the athlete owns and re-score
 *  their day downward. On failure the previous value stands. */
async function fetchPassState(sb, userId, since) {
  try {
    const [{ data: ps, error: pErr }, { data: sp, error: sErr }] = await Promise.all([
      sb.from('trust_passes')
        .select('id,credits_total,covers_from,covers_until,expires_on,note,ended_at,created_at')
        .eq('athlete_id', userId).gte('expires_on', since),
      sb.from('pass_spends')
        .select('pass_id,day_date,slot')
        .eq('athlete_id', userId).gte('day_date', since),
    ]);
    if (!pErr && Array.isArray(ps)) DAY.passes = ps;
    if (!sErr && Array.isArray(sp)) DAY.passSpends = sp;
  } catch (e) { console.warn('[day] pass state fetch failed, keeping the last known', e && e.message); }
}

/** Re-read just the pass ledger, e.g. right after a spend — the server owns the count, and a
 *  refund trigger (the athlete logging the meal mid-flight) can have changed it without this
 *  device knowing. Cheaper than a full loadDay: no days/meals/weight round trip. */
export async function reloadPassState(userId) {
  const sb = window.sb;
  if (!sb || !userId) return;
  const since = addDaysISO(DAY.date, -HISTORY_DAYS);
  await fetchPassState(sb, userId, since);
  saveCache(userId);
}

export async function loadDay(userId) {
  // Reset to a fresh day FIRST — never merge the fetch onto a previous session's (or a
  // previous calendar day's) in-memory residue. Without this, a user with no server row
  // for today inherits whatever DAY held before (another account's meals/score on a shared
  // device, or yesterday's meals after midnight). The per-user+date cache below restores
  // this user's own state, and projectRowToDay layers the server row on top.
  dayResetLocal();
  DAY.date = todayISO();
  loadCache(userId); // instant offline paint
  const sb = window.sb;
  if (!sb || !userId) return;
  try {
    // Weight visibility (0103): days.current_weight left the direct SELECT grant — weight rides
    // its own permission-gated channel (the weight_series RPC; is_self always passes). Columns
    // are enumerated (never '*', which 42501s once the grant splits), the series is fetched in
    // parallel, and the weights are stitched back onto the fetched rows BEFORE any existing
    // processing — projectRowToDay, the history map, and every downstream consumer are unchanged.
    const since = addDaysISO(DAY.date, -HISTORY_DAYS);
    const heavySince = addDaysISO(DAY.date, -HISTORY_HEAVY_DAYS);
    const [{ data, error: dayErr }, { data: histNear, error: nearErr }, { data: histFar, error: farErr }, weights, { data: photoRows, error: photoErr }] = await Promise.all([
      sb.from('days').select(DAY_SELECT_COLS).eq('athlete_id', userId).eq('date', DAY.date).maybeSingle(),
      // meals + checkin jsonb ride along on the NEAR window so Progress can compute REAL
      // per-category trends (computeComponents over reconstructed past days) — never fabricated
      // category numbers. Near only: every reader of the heavy jsonb is trailing-N (see the
      // HISTORY_HEAVY_DAYS note above).
      sb.from('days').select('date,score,meals,checkin,hydration_l,quick_added,plan_style,signals').eq('athlete_id', userId).gte('date', heavySince).lt('date', DAY.date).order('date'),
      // The far tail stays in the window but travels light: date + score feed the streak walk,
      // Progress averages and the monthly report; plan_style feeds the style timeline. Far rows
      // reconstruct to null in dayFromHistoryRow (no meals/checkin), which its callers already
      // skip by design — trends read the recent past, never a truncated fabrication.
      sb.from('days').select('date,score,plan_style').eq('athlete_id', userId).gte('date', since).lt('date', heavySince).order('date'),
      fetchWeightSeries(sb, userId, HISTORY_DAYS),
      // Pass eligibility, from the horse's mouth: the SAME rows 0196's grant_pass wall counts
      // (lifetime, distinct days), so "N of M photo-logged days" can never go backwards just
      // because this fetch holds a bounded history window. One short column; failure is soft —
      // the getter falls back to the history proxy, never to a fabricated 0.
      sb.from('meals').select('day_date').eq('athlete_id', userId).not('photo_path', 'is', null),
    ]);
    // supabase-js RESOLVES failures into {error}; it does not throw. A resolved failure used to
    // leave `data` undefined — indistinguishable from "no row for today" — so projectRowToDay
    // never merged the server's day, `!data && hasLoggedAnything()` read the cache-restored
    // local day as AHEAD, and the reconnect-healing push below upserted meals/checkin WHOLESALE
    // over a server row this device never read: meals logged from another device erased by a
    // transient 5xx. A failed read must abort the whole merge-and-heal path, so throw into the
    // catch below (the instant offline paint from loadCache stands, and nothing is written).
    if (dayErr) throw dayErr;
    if (nearErr) throw nearErr;
    if (farErr) throw farErr;
    if (data && weights.has(String(data.date))) data.current_weight = weights.get(String(data.date));
    const localAhead = projectRowToDay(data) || (!data && hasLoggedAnything());
    // Far tail first, then near — both arrive date-ascending and the ranges don't overlap, so
    // the concat IS the ordered 60-day history every consumer has always read.
    const hist = [...(Array.isArray(histFar) ? histFar : []), ...(Array.isArray(histNear) ? histNear : [])];
    if (Array.isArray(histNear) || Array.isArray(histFar)) DAY.scoreHistory = hist.map((r) => ({
      date: r.date, score: r.score ?? 0, weight: weights.has(String(r.date)) ? weights.get(String(r.date)) : null,
      meals: r.meals || null, checkin: r.checkin || null,
      hydrationL: Number(r.hydration_l) || 0, quickAdded: Array.isArray(r.quick_added) ? r.quick_added : [],
      // The style STAMP each past day carried — Progress bands the timeline by it, and
      // dayFromHistoryRow grades each day by the style that actually governed it.
      planStyle: r.plan_style || null, signals: r.signals || null,
    }));
    // Distinct DAYS, not meals — a day with three photographed plates counts once, exactly as
    // grant_pass counts it. A failed read keeps the last known value; 0 is only ever real.
    if (!photoErr && Array.isArray(photoRows)) DAY.photoDays = new Set(photoRows.map((r) => String(r.day_date))).size;
    // Trust Pass state (0196). The pass window matches the FULL history window, and coverage
    // exclusion (coveredKeys in scoringView) reads only each history row's date — which the
    // light far rows still carry — so slotMedians keeps excluding previously-covered days
    // across all 60 days without a second round trip.
    await fetchPassState(sb, userId, since);
    saveCache(userId);
    // Reconnect healing: if this device's cached day carries progress the server row lacks
    // (offline logs, a push that never flushed before the app was killed), push the merged
    // day back up NOW — otherwise it would sit local-only until the next tap, and the coach
    // would read "not logged" for a day that was honestly logged.
    if (localAhead) await pushDay(userId, true);
  } catch (e) { console.warn('[day] loadDay failed', e && e.message); }
  finally { touch(); }
}

/** True when the in-memory day carries any real logged progress. */
function hasLoggedAnything() {
  return MEAL_KEYS.some((k) => DAY.meals[k]) || DAY.quickAdded.some(Boolean)
    || DAY.hydrationL > 0 || DAY.ciSubmitted || DAY.dailyCommitment != null || DAY.currentWeight != null
    || Object.keys(DAY.checkedTasks || {}).length > 0;
}

/** Flush a pending debounced push immediately (app going to background / being killed —
 *  the 1s debounce window must not lose the last action). No-op when nothing is pending. */
export function flushDayPush(userId) {
  if (!pushTimer || !userId) return;
  clearTimeout(pushTimer);
  pushTimer = null;
  void pushDay(userId, true);
}

let pushTimer = null;
/* Client half of the 0050 minor-consent gate: while blocked (a provable minor without verified
   guardian consent), real data stays ON-DEVICE — the server would reject the writes anyway, so
   we don't fire doomed requests. The cache still saves (nothing is lost; it syncs the moment
   consent verifies). state.js arms/disarms this from the hydrated consent status. */
let SYNC_BLOCKED = false;
export function setSyncBlocked(blocked) { SYNC_BLOCKED = !!blocked; }
export function isSyncBlocked() { return SYNC_BLOCKED; }

/* days.tasks writer (closes the coach-side done-ness gap): a registered provider returns the
   day's per-requirement completion as [{ id, done }] — the SAME requirement ids the coach's
   engines resolve (CATALOG ids like 'recovery', or coach-set meal-slot keys), derived from the
   exec engine's item states. state.js registers it because it owns the resolved standard +
   completion map; day.js stays free of that dependency (no circular import — the setSyncBlocked
   pattern). Before this, pushDay never wrote `tasks`, so every non-meal requirement read as
   never-done in status.js/Insights. Returns null when unregistered so pushDay never blocks and
   never clobbers the column with a stale empty array. */
let taskProvider = null;
export function setDayTaskProvider(fn) { taskProvider = typeof fn === 'function' ? fn : null; }
function currentTasks() {
  if (!taskProvider) return null;
  try {
    const t = taskProvider();
    if (!Array.isArray(t)) return null;
    // Only well-formed { id, done } entries — never a fabricated or malformed row. `dueAt` rides
    // along when the provider knows it (an ISO instant from the athlete's own clock): it is what
    // lets a server escalate an ABSENCE without owning a deadline engine of its own. Absent or
    // malformed, the entry is exactly the shape it has always been.
    return t.filter((x) => x && x.id != null).map((x) => {
      const row = { id: String(x.id), done: !!x.done };
      if (typeof x.dueAt === 'string' && !Number.isNaN(Date.parse(x.dueAt))) row.dueAt = x.dueAt;
      return row;
    });
  } catch { return null; }
}
/* Honest sync surface: the result of the LAST attempted day push — 'ok' | 'error' | null (none
   attempted yet). Home renders a quiet "not synced" pill off this instead of the old silent
   console.warn, so an athlete can't log all week into a void without knowing. */
export const SYNC = { last: null };

/* Self-retry for a failed push (2026-08-05, the offline-safe pass): the wake beats (foreground,
   reconnect) cover an athlete who LEFT, but one who logs and keeps the app open on a dead edge
   generated no beat — the meal-outbox postmortem exactly. Seconds-first, capped, and reset by
   any success; the honest "not synced" pill stays up the whole time. Browser only: the timer
   must never fire after a Node test ends. */
let pushRetryTimer = null, pushRetryCount = 0;
function armPushRetry(userId) {
  if (typeof window === 'undefined' || pushRetryTimer || pushRetryCount >= 6) return;
  const delay = Math.min(3000 * 2 ** pushRetryCount, 120_000);
  pushRetryCount++;
  pushRetryTimer = setTimeout(() => {
    pushRetryTimer = null;
    if (SYNC.last === 'error') void pushDay(userId, true);
  }, delay);
}

export function pushDay(userId, immediate) {
  saveCache(userId);
  if (pushTimer) { clearTimeout(pushTimer); pushTimer = null; }
  const doPush = async () => {
    // `window` is absent in Node (this module is imported directly by the jest/proto test suites),
    // and the debounced timer can fire after a test has finished — an unguarded reference threw
    // ReferenceError there, outside any test's catch, which reads like a suite crash.
    const sb = typeof window !== 'undefined' ? window.sb : null;
    if (!sb || !userId || SYNC_BLOCKED) return;
    const s = clampedScore(DAY);
    const tasks = currentTasks(); // [{id, done}] from the exec engine, or null if unavailable
    const row = {
      athlete_id: userId, date: DAY.date,
      meals: DAY.meals, hydration_l: DAY.hydrationL, quick_added: DAY.quickAdded,
      checked_tasks: DAY.checkedTasks,
      // current_weight is deliberately ABSENT: 0103's weight wall removed its SELECT grant, and
      // Postgres requires SELECT on every column an ON CONFLICT DO UPDATE references via
      // `excluded.` — with it in the row, the ENTIRE upsert 42501s and nothing ever syncs
      // (the 2026-08-05 "Waiting to sync" bug). Weight goes through the log_my_weight door
      // (dayLogWeight below), the write mirror of the weight_series read door.
      checkin: { ...DAY.ci, submitted: DAY.ciSubmitted, ciLast: DAY.ciLast, commitment: DAY.dailyCommitment, focus: DAY.commitmentFocus, mealLoggedAt: DAY.mealLoggedAt, slotMacros: DAY.slotMacros },
      score: s, grade: gradeFor(s),
      // The per-day STAMP: which style graded this day. Written every push so a style change
      // takes effect going forward and never rewrites a settled day. Null until a style resolves
      // (a pre-0142 account), which reads as the shipped classic scoring — exactly what it was.
      plan_style: DAY.planStyle || null,
      signals: DAY.signals || {},
      // Only include tasks when we actually derived them — the column defaults to '[]', and 0041's
      // evidence ceiling reads meals/checkin/trust_passes, NOT tasks, so this never moves a score.
      ...(tasks ? { tasks } : {}),
    };
    try {
      // supabase-js reports failures via {error}, it doesn't throw — check both paths so the
      // sync pill is honest for RLS/constraint rejections as well as network deaths.
      const { error } = await sb.from('days').upsert(row, { onConflict: 'athlete_id,date' });
      SYNC.last = error ? 'error' : 'ok';
      if (error) { console.warn('[day] pushDay failed', error.message); armPushRetry(userId); }
      else pushRetryCount = 0;
    } catch (e) { SYNC.last = 'error'; console.warn('[day] pushDay failed', e && e.message); armPushRetry(userId); }
  };
  if (immediate) return doPush();
  pushTimer = setTimeout(doPush, 1000); // debounce bursts of taps
}

export function dayResetLocal() {
  DAY.meals = { breakfast: false, lunch: false, snack: false, dinner: false };
  seedStandardSlots(); // a governing standard's extra slots (meal-5/meal-6) survive the reset
  DAY.mealLoggedAt = {}; DAY.slotMacros = {}; DAY.quickAdded = [false, false, false]; DAY.checkedTasks = {};
  DAY.hydrationL = 0; DAY.dailyCommitment = null; DAY.commitmentFocus = null; DAY.ci = { ...DEFAULT_CI }; DAY.ciConfig = { ...DEFAULT_CICFG };
  DAY.ciSubmitted = false; DAY.ciLast = null; DAY.currentWeight = null; DAY.scoreHistory = []; DAY.passes = []; DAY.passSpends = [];
  // The resolved style/knobs SURVIVE a local reset (they describe the athlete, not the day) —
  // state.js re-applies them on hydrate anyway. Today's captured signals do not.
  DAY.signals = {}; DAY.signalWeekRate = null;
  DAY.photoDays = null; // lifetime count is per ACCOUNT — never leak it across users on a shared device
  touch();
}


/* ---- mutators (each persists) ---- */
export function dayLogMeal(userId, key, macros, meta) {
  if (!DAY.meals.hasOwnProperty(key)) return;
  DAY.meals[key] = true;
  DAY.mealLoggedAt[key] = minutesNow();
  const m = { ...(DAY.slotMacros[key] || {}) };
  if (macros && typeof macros.protein === 'number') { m.protein = macros.protein || 0; m.kcal = macros.kcal || 0; m.carbs = macros.carbs || 0; m.fat = macros.fat || 0; }
  // Persist the AI plate meta (quality/foods/note + fiber/highlights/detectedRich) so meal-detail
  // survives reload — it rides through the checkin.slotMacros jsonb (pushDay/projectRowToDay).
  // Scoring reads only .protein.
  if (meta) {
    if (meta.quality != null) m.quality = meta.quality;
    // The DISH name ("Chicken, Rice & Broccoli") the model returns and insertMeal already writes to
    // meals.name for the coach. It was missing from this whitelist, so on the analyse-then-log path
    // it reached the server row and NOT the athlete's own day — the coach could see what their
    // athlete ate and the athlete could not. (The optimistic path got away with it by accident:
    // applyAnalysisResult writes slotMacros directly and always carried `name`.) Same class of
    // omission as `pending`/`pendingHash` above; a field that isn't listed here is a field that
    // does not survive a reload.
    if (meta.name) m.name = String(meta.name).slice(0, 80);
    if (Array.isArray(meta.foods)) m.foods = meta.foods.slice(0, 8);
    if (meta.note) m.note = meta.note;
    if (meta.userNote) m.userNote = String(meta.userNote).slice(0, 240); // athlete's review-step details (§5.5)
    if (meta.photoQ && typeof meta.photoQ.luma === 'number') m.photoQ = { luma: Math.round(meta.photoQ.luma), sharpness: Math.round((meta.photoQ.sharpness || 0) * 10) / 10 }; // measured capture quality
    if (meta.fiber != null) m.fiber = meta.fiber;
    if (Array.isArray(meta.highlights)) m.highlights = meta.highlights.slice(0, 3);
    if (Array.isArray(meta.detectedRich)) m.detectedRich = meta.detectedRich.slice(0, 8);
    if (meta.live === false) m.live = false;
    if (meta.source) m.source = meta.source;          // 'live' | 'gallery' | 'manual' | 'label'
    // LOG-FIRST, READ-AFTER (the optimistic photo path). These two were missing from this
    // whitelist, and their absence broke the entire flow in a way that looked like two unrelated
    // bugs:
    //   1. applyAnalysisResult's first guard is `if (!cur.pending) return false`, so a finished
    //      analysis could NEVER land — the meal sat at 0g protein / 0 kcal permanently, which is
    //      what "macros populating 0s when I clearly uploaded a meal" was.
    //   2. #analyzing watches `landed = !cur.pending`, which was true on the first tick, so the
    //      scan always bailed at its MIN_MS floor and read as "way too fast".
    // pendingHash is the anti-stale guard applyAnalysisResult checks second (a result may only
    // land on the slot whose photo produced it), so it is worthless without this one.
    if (meta.pending) m.pending = true;
    if (meta.pendingHash) m.pendingHash = meta.pendingHash;
    if (meta.analysis) m.analysis = String(meta.analysis).slice(0, 1200);
    // 0142 — the plan style the SERVER wrote this prose for. The client shows server prose only
    // when this matches its own resolved style, so an old deploy (no stamp) keeps suppressing.
    if (meta.styleApplied) m.styleApplied = String(meta.styleApplied);
    if (meta.takenAt) m.takenAt = meta.takenAt;       // EXIF capture time of a gallery pick
  }
  if (Object.keys(m).length) DAY.slotMacros[key] = m;
  pushDay(userId);
}
export function daySubmitCheckin(userId, ciValues) {
  if (ciValues) DAY.ci = { ...DAY.ci, ...ciValues };
  DAY.ciSubmitted = true;
  const rec = recoveryParts(DAY);
  DAY.ciLast = { date: DAY.date, recovery: rec.score };
  pushDay(userId);
}
export function daySetCommitment(userId, ans) { DAY.dailyCommitment = ans; pushDay(userId); }
export function daySetFocus(userId, text) { DAY.commitmentFocus = text || null; pushDay(userId); }
/* Tenths are kept (0179 widened days.current_weight to numeric(5,1)) — the stepper moves by
   0.1 and the typed input accepts decimals, so rounding to a whole pound here was silently
   discarding what the athlete actually entered. Range sanity lives in act.logWeight.
   The server write rides the 0181 log_my_weight definer door, NOT the pushDay upsert —
   current_weight has no SELECT grant (0103's wall), and an upsert that references it via
   `excluded.` is rejected wholesale. Failure is honest: it sets SYNC.last so the same
   "Waiting to sync" surface covers a weight that didn't land. */
export function dayLogWeight(userId, lb) {
  if (lb) DAY.currentWeight = Math.round(Number(lb) * 10) / 10;
  pushDay(userId);
  const sb = typeof window !== 'undefined' ? window.sb : null;
  if (sb && userId && !SYNC_BLOCKED && DAY.currentWeight != null) {
    sb.rpc('log_my_weight', { d: DAY.date, w: DAY.currentWeight })
      .then(({ error }) => { if (error) { SYNC.last = 'error'; console.warn('[day] log_my_weight failed', error.message); } })
      .catch((e) => { SYNC.last = 'error'; console.warn('[day] log_my_weight failed', e && e.message); });
  }
}
export function dayToggleQuick(userId, i) { DAY.quickAdded[i] = !DAY.quickAdded[i]; pushDay(userId); }
/* Complete (or un-complete) a standing NON-MEAL check requirement for today (lift / custom). Tracked,
   not scored: it rides into days.tasks so the coach sees it, but never touches computeComponents. */
export function dayCheckTask(userId, id, done = true) {
  if (!id) return;
  if (!DAY.checkedTasks) DAY.checkedTasks = {};
  if (done) DAY.checkedTasks[id] = true; else delete DAY.checkedTasks[id];
  pushDay(userId);
}

/** Insert a real row into the `meals` table (mirrors the RN insertMeal / mapMealToRow) so a coach
 *  can review and comment on the plate. The proto otherwise only writes `days`; coach review +
 *  meal_comments key on a real meal id. Best-effort — a failed insert never blocks logging.
 *  Returns the new meal id (string), the `{ dup: true }` sentinel when the 0062 photo-hash
 *  unique index rejected a reused photo (the caller flags the slot so it doesn't score), or
 *  null on any other failure. */
export async function insertMeal(userId, key, macros, meta, photoPath) {
  const sb = window.sb;
  if (!sb || !userId || SYNC_BLOCKED) return null;
  try {
    const m = meta || {};
    const legacyRow = {
      athlete_id: userId, day_date: DAY.date, type: key,
      photo_path: photoPath || null,
      name: m.name || (key.charAt(0).toUpperCase() + key.slice(1)),
      protein: (macros && macros.protein) || 0, kcal: (macros && macros.kcal) || 0,
      carbs: (macros && macros.carbs) || 0, fat: (macros && macros.fat) || 0,
      quality: m.quality != null ? m.quality : null,
      detected: Array.isArray(m.foods) ? m.foods : [],
      note: m.note || '',
      logged_at: new Date().toISOString(),
    };
    // 0062 integrity/analysis columns. photo_hash only rides with a real photo — the unique
    // index is per-athlete, so a null hash never collides.
    const row = {
      ...legacyRow,
      photo_hash: (typeof m.photoHash === 'string' && /^[0-9a-f]{64}$/.test(m.photoHash)) ? m.photoHash : null,
      source: m.source || null,
      analysis: m.analysis ? String(m.analysis).slice(0, 1200) : null,
      minutes_late: (typeof m.minutesLate === 'number' && isFinite(m.minutesLate))
        ? Math.max(0, Math.min(1440, Math.round(m.minutesLate))) : null,
      photo_taken_at: m.takenAt || null,
      // 0070: fiber history powers the "produce below target lately" pattern.
      fiber: (typeof m.fiber === 'number' && isFinite(m.fiber)) ? Math.max(0, Math.min(60, Math.round(m.fiber))) : null,
    };
    let { data, error } = await sb.from('meals').insert(row).select('id').maybeSingle();
    if (error && error.code === '23505') return { dup: true }; // photo reused — server wall held
    if (error) {
      // Pre-0062 DB (unknown column / stale schema cache): retry with the legacy shape so an
      // un-applied migration can never block logging a meal.
      ({ data, error } = await sb.from('meals').insert(legacyRow).select('id').maybeSingle());
    }
    if (error) { console.warn('[day] insertMeal failed', error.message); return null; }
    return data ? data.id : null;
  } catch (e) { console.warn('[day] insertMeal failed', e && e.message); return null; }
}

/** Upload a meal photo (raw base64 jpeg) to the private meal-photos bucket. Path MUST start with
 *  the athlete's id (storage RLS). A failed upload never blocks logging the meal — but it MUST
 *  report honestly. supabase-js storage does not throw: it resolves `{ error }`, and this
 *  function used to resolve undefined either way, so the outbox marked failed uploads done and
 *  the meals row pointed at an object that was never stored (the 2026-08-11 breakfast with no
 *  photo). Returns true ONLY on a confirmed store; false means "still owed — retry me". */
export async function uploadMealPhoto(userId, key, base64) {
  const sb = window.sb;
  if (!sb || !userId || !base64 || SYNC_BLOCKED) return false;
  try {
    const bin = atob(base64);
    const bytes = new Uint8Array(bin.length);
    for (let i = 0; i < bin.length; i++) bytes[i] = bin.charCodeAt(i);
    const { error } = await sb.storage.from('meal-photos').upload(`${userId}/${DAY.date}/${key}.jpg`, bytes, { contentType: 'image/jpeg', upsert: true }) || {};
    if (error) { console.warn('[day] photo upload failed', error.message); return false; }
    return true;
  } catch (e) { console.warn('[day] photo upload failed', e && e.message); return false; }
}
