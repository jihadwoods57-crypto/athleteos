/* OnStandard — Verified Commitments engine.
   PURE: no DOM, no Supabase, no clock, no locale. Every function takes what it needs as an
   argument — the same contract requirements.js and notify-plan.js hold — so node --test can
   exercise it directly and a CI box in UTC agrees with a laptop in New York.

   Vocabulary note (founder decision 2026-07-22): "commitment" is COACH-facing vocabulary. The
   athlete never sees the bare word — they see the coach's own title ("Morning Roll Call",
   "5 AM Club"), and the rollup is called Morning Readiness / Accountability. The shipped
   Daily Commitment (screens/commitment.js) is a DIFFERENT thing — its weight is permanently 0
   (the reflection is captured and shown to the coach, it just no longer scores) — and is
   deliberately untouched by this module.

   ⚠ Nothing here feeds the daily 0–100 score. Verified Commitments produces its own
   Accountability score (accountability() below). day.js is not imported and must not be. */
import { fmtMin } from './requirements.js';

export const TYPE_LABEL = {
  morning_roll_call: 'Morning Roll Call',
  practice:          'Practice',
  strength:          'Strength Workout',
  speed:             'Speed Session',
  team_meeting:      'Team Meeting',
  study_hall:        'Study Hall',
  tutoring:          'Tutoring',
  class:             'Class Commitment',
  rehab:             'Rehab',
  nutrition:         'Nutrition Appointment',
};

/* Render-time defaults ONLY. These are never persisted: the column stays null so the database
   remains honest about whether the coach actually chose the string. */
const DEFAULT_ACTION = {
  morning_roll_call: 'I’m Up',
  practice: 'I’m here', strength: 'I’m here', speed: 'I’m here',
  team_meeting: 'I’m here', study_hall: 'I’m here', tutoring: 'I’m here',
  class: 'I’m here', rehab: 'I’m here', nutrition: 'I’m here',
};

/* ---------------------------------------------------------------- time helpers */

/** The viewer's UTC offset in minutes (EDT = -240). Passed explicitly by tests; defaults to the
 *  device so screens don't have to thread it. */
export function localOffsetMin() { return -new Date().getTimezoneOffset(); }

/** The UTC offset of an IANA zone at a given instant, in minutes. Null for an unknown zone.
 *  DST-correct by construction, because it asks Intl what the wall clock actually reads there
 *  at that moment rather than assuming a fixed offset. */
export function zoneOffsetMin(tz, iso) {
  if (!tz) return null;
  try {
    const d = new Date(iso);
    if (isNaN(d)) return null;
    const parts = {};
    for (const p of new Intl.DateTimeFormat('en-US', {
      timeZone: tz, hourCycle: 'h23',
      year: 'numeric', month: '2-digit', day: '2-digit',
      hour: '2-digit', minute: '2-digit', second: '2-digit',
    }).formatToParts(d)) parts[p.type] = p.value;
    const asUTC = Date.UTC(+parts.year, +parts.month - 1, +parts.day,
      +parts.hour, +parts.minute, +parts.second);
    return Math.round((asUTC - d.getTime()) / 60000);
  } catch { return null; }
}

/** Which clock a commitment's times should be READ in. The coach set 5:15 AM meaning 5:15 in the
 *  team's zone, so a stamp must render in that zone too — otherwise an athlete on a road trip
 *  sees "Respond by 5:15 AM" (team wall clock, from respond_by_min) next to "Checked in at
 *  2:48 AM" (their phone), which reads like a bug even though both are technically true. */
export function offsetFor(row, nowISO, override) {
  if (typeof override === 'number') return override;
  const z = row && row.timezone ? zoneOffsetMin(row.timezone, nowISO || new Date().toISOString()) : null;
  return z == null ? localOffsetMin() : z;
}

/** Minute-of-day of an ISO instant, in the target zone. Null for a missing/invalid timestamp. */
export function localMin(iso, offMin) {
  const t = Date.parse(iso || '');
  if (!isFinite(t)) return null;
  const d = new Date(t + (offMin || 0) * 60000);
  return d.getUTCHours() * 60 + d.getUTCMinutes();
}

/** "4:48 AM" for an ISO instant, in the target zone. '' when absent. */
export function fmtAt(iso, offMin) {
  const m = localMin(iso, offMin);
  return m == null ? '' : fmtMin(m);
}

const addDays = (dateISO, n) => {
  const t = Date.parse(String(dateISO) + 'T12:00:00Z');
  return new Date(t + n * 86400000).toISOString().slice(0, 10);
};

/* ---------------------------------------------------------------- recurrence */

/** Noon anchor keeps the weekday stable regardless of the device's zone. */
const dowOf = (dateISO) => new Date(String(dateISO) + 'T12:00:00').getDay();

export function occursOn(c, dateISO) {
  if (!c || !Array.isArray(c.repeat_days) || !c.repeat_days.length) return false;
  if (c.starts_on && dateISO < c.starts_on) return false;
  if (c.ends_on && dateISO > c.ends_on) return false;
  return c.repeat_days.map(Number).includes(dowOf(dateISO));
}

/** When the card appears. Falls back to an hour before the response deadline (or the start
 *  time), floored at midnight so a 12:30 AM commitment never wraps onto the previous day. */
export function opensMinFor(c) {
  if (c && typeof c.opens_min === 'number') return c.opens_min;
  const anchor = (c && typeof c.respond_by_min === 'number') ? c.respond_by_min
               : (c && typeof c.starts_min === 'number') ? c.starts_min : 0;
  return Math.max(0, anchor - 60);
}

/* ---------------------------------------------------------------- wake-up verdict (0211)

   The mirror of rollcall_verdict() / rollcall_closes_at() / commitment_opens_at() in
   supabase/migrations/0211_wakeup_rollcall.sql. Same inputs, same order of resolution, so the
   athlete's card, the coach's board and the server's summary read one answer off one clock.
   Never read the environment: `nowISO` is always an argument. */
export const VERDICT = {
  ON_STANDARD: 'on_standard', LATE: 'late', PENDING: 'pending', MISSED: 'missed', EXCUSED: 'excused',
};
export const VERDICT_LABEL = {
  on_standard: 'On Standard', late: 'Late', pending: 'Pending', missed: 'Missed', excused: 'Excused',
};
/* A wake-up with no explicit close accepts a late answer for two hours after its deadline. */
export const ROLLCALL_LATE_WINDOW_MIN = 120;

const isoPlusMin = (iso, min) => {
  const t = Date.parse(iso || '');
  return isFinite(t) ? new Date(t + min * 60000).toISOString() : null;
};

/** The instant an answer is judged against. respond_by_at, else the start. */
export function deadlineOf(row) {
  return (row && (row.respond_by_at || row.starts_at)) || null;
}

/** When the roll call stops accepting answers. Server value first; the same fallback rule the
 *  SQL applies when it is absent (a pre-0211 payload). Null = never closes (non-roll-call types). */
export function closesAtOf(row) {
  const r = row || {};
  if (r.closes_at) return r.closes_at;
  if (r.ends_at) return r.ends_at;
  if (r.type === 'morning_roll_call') return isoPlusMin(deadlineOf(r), ROLLCALL_LATE_WINDOW_MIN);
  return null;
}

/** When the roll call opens. Server value first; else the opensMinFor() rule. */
export function opensAtOf(row) {
  const r = row || {};
  if (r.opens_at) return r.opens_at;
  if (typeof r.opens_min === 'number' && typeof r.starts_min === 'number') {
    return isoPlusMin(r.starts_at, r.opens_min - r.starts_min);
  }
  return isoPlusMin(deadlineOf(r), -60);
}

/** The coach's grace period in minutes, or null when the roll call has no deadline. */
export function graceMinOf(row) {
  const r = row || {};
  if (typeof r.grace_min === 'number') return r.grace_min;
  if (typeof r.respond_by_min === 'number' && typeof r.starts_min === 'number') return r.respond_by_min - r.starts_min;
  return null;
}

/** excused | on_standard | late | pending | missed. `deadlineISO` lets a board row (which carries
 *  no instance times) be judged against its instance. */
export function rollcallVerdict(row, nowISO, deadlineISO) {
  const r = row || {};
  if (r.status === 'excused') return VERDICT.EXCUSED;
  const dl = Date.parse(deadlineISO || deadlineOf(r) || '');
  if (r.acknowledged_at) {
    const at = Date.parse(r.acknowledged_at);
    return (!isFinite(dl) || at <= dl) ? VERDICT.ON_STANDARD : VERDICT.LATE;
  }
  const now = Date.parse(nowISO || '');
  if (!isFinite(dl) || !isFinite(now) || now < dl) return VERDICT.PENDING;
  return VERDICT.MISSED;
}

/** Whole minutes late, rounded up. Null unless the answer came after the deadline. */
export function lateMinutes(row, deadlineISO) {
  const r = row || {};
  const at = Date.parse(r.acknowledged_at || '');
  const dl = Date.parse(deadlineISO || deadlineOf(r) || '');
  if (!isFinite(at) || !isFinite(dl) || at <= dl) return null;
  return Math.ceil((at - dl) / 60000);
}

/** Where a wake-up roll call is on its own clock:
 *  'before' (not open yet) · 'open' (grace running) · 'late' (grace over, still accepting) · 'closed'. */
export function wakeupPhase(row, nowISO) {
  const r = row || {};
  const now = Date.parse(nowISO || '');
  const dl = Date.parse(deadlineOf(r) || '');
  const close = Date.parse(closesAtOf(r) || '');
  const open = Date.parse(opensAtOf(r) || '');
  if (isFinite(close) && now > close) return 'closed';
  if (isFinite(dl) && now >= dl) return 'late';
  if (isFinite(open) && now < open) return 'before';
  return 'open';
}

/** "On Standard" · "Late · 6 min" · "Missed" for a receipt line. */
export function verdictLine(row, nowISO, deadlineISO) {
  const v = rollcallVerdict(row, nowISO, deadlineISO);
  if (v === VERDICT.LATE) {
    const m = lateMinutes(row, deadlineISO);
    return m ? `Late · ${m} min` : 'Late';
  }
  return VERDICT_LABEL[v] || '';
}

/* ---------------------------------------------------------------- signals */

/** Which of the three signals this commitment actually asks for.
 *  A roll call IS the wake-up: pressing the button is the whole commitment, so it never asks for
 *  "completion". It asks for arrival only when the coach attached a location. */
export function signalsAsked(row) {
  if (!row) return { ack: false, arrival: false, completion: false };
  return {
    ack: row.respond_by_min != null || row.type === 'morning_roll_call',
    arrival: !!row.asks_arrival,
    completion: row.type !== 'morning_roll_call',
  };
}

const arrivedOnTime = (row) => row.arrived_at != null &&
  (!row.arrive_by_at || Date.parse(row.arrived_at) <= Date.parse(row.arrive_by_at));

/* ---------------------------------------------------------------- presence (0208)

   Arrival is a boundary CROSSING. Presence is whether the athlete was actually there for the
   stay the coach asked for. Until 0208 the product conflated them: commitments.min_dwell_min
   round-tripped through the coach's form and gated nothing, because nothing ever wrote
   commitment_responses.departed_at.

   The verdict is computed SERVER-side (commitment_presence, 0208) so the athlete read and the
   coach read cannot disagree, and so the exit debounce survives the app being killed. This
   client only reads it. */
export const PRESENCE = {
  NONE: 'none', PROVISIONAL: 'provisional', CONFIRMED: 'confirmed', LEFT_EARLY: 'left_early',
};

/** The server's verdict, with a deliberate degrade for payloads that predate 0208.
 *
 *  An older server sends no `presence` field at all. Reading that as anything other than
 *  'confirmed' would retroactively downgrade every arrival already on the record, so a missing
 *  verdict means exactly what it meant before this migration existed: they arrived, and there was
 *  no stay requirement anyone could check. Never invent 'left_early' from absence. */
export function presenceOf(row) {
  const r = row || {};
  if (r.arrived_at == null) return PRESENCE.NONE;
  const p = r.presence;
  return (p === PRESENCE.PROVISIONAL || p === PRESENCE.CONFIRMED || p === PRESENCE.LEFT_EARLY)
    ? p : PRESENCE.CONFIRMED;
}

/** Whether the arrival signal is EARNED, for scoring.
 *
 *  Founder ruling 2026-08-23: a sustained departure before the coach's minimum is a VERIFIED
 *  absence and it counts, which is what separates it from 'unverified' (a gap in evidence, always
 *  dropped from the denominator instead).
 *
 *  'provisional' deliberately still counts. Mid-session the answer genuinely is not known yet, and
 *  the alternative is a score that dips while an athlete is sitting in the room doing exactly what
 *  was asked, then silently recovers. Progress must never run backwards on an unresolved fact; it
 *  only moves when a real, sustained departure resolves it. */
const arrivalCounts = (row) => arrivedOnTime(row) && presenceOf(row) !== PRESENCE.LEFT_EARLY;

/* ---------------------------------------------------------------- stages */

// 'Checked in', not 'Acknowledged': the athlete never sees coach vocabulary (header rule in
// screens/roll-call.js), and the card's own confirm line already says "Checked in at 4:48 AM".
const STAGE_LABEL = { acknowledged: 'Checked in', arrived: 'Arrived', completed: 'Completed' };

/** One commitment's live view for the athlete. `nowISO` and `offMin` are arguments, never read
 *  from the environment.
 *
 *  Resolution order matters: 'cancelled', 'excused' and 'unverified' are checked BEFORE any
 *  deadline comparison, because a signal that could not be verified must never be silently
 *  converted into a failure. That is the honesty rule this whole feature rests on. */
export function deriveCommitment(row, nowISO, offMinOverride) {
  const r = row || {};
  const offMin = offsetFor(r, nowISO, offMinOverride);
  const asks = signalsAsked(r);
  const nowT = Date.parse(nowISO || '') || 0;
  const nowMin = localMin(nowISO, offMin);
  const at = (iso) => fmtAt(iso, offMin);

  const title = (r.title && String(r.title).trim()) || TYPE_LABEL[r.type] || 'Commitment';
  const actionLabel = (r.action_label && String(r.action_label).trim())
    || DEFAULT_ACTION[r.type] || 'Mark done';

  const contextLine = (r.linked_title && r.linked_starts_min != null)
    ? `${r.linked_title} at ${fmtMin(r.linked_starts_min)}`
    : (r.starts_min != null ? `At ${fmtMin(r.starts_min)}` : '');

  const deadlineLine = r.respond_by_min != null ? `Respond by ${fmtMin(r.respond_by_min)}`
    : r.arrive_by_min != null ? `Arrive by ${fmtMin(r.arrive_by_min)}` : '';

  const stages = [];
  if (asks.ack) stages.push({ key: 'acknowledged', label: STAGE_LABEL.acknowledged, done: !!r.acknowledged_at, at: at(r.acknowledged_at) });
  if (asks.arrival) stages.push({ key: 'arrived', label: STAGE_LABEL.arrived, done: !!r.arrived_at, at: at(r.arrived_at) });
  // The stay is its own stage whenever the coach asked for one (0208). Without this the strip
  // showed "Arrived / Completed" and a 45-minute requirement the coach genuinely cared about was
  // invisible to the athlete on the only screen they actually look at.
  if (asks.arrival && r.min_dwell_min) {
    const p = presenceOf(r);
    stages.push({
      key: 'stayed', label: `Stayed ${r.min_dwell_min}m`,
      done: p === PRESENCE.CONFIRMED,
      at: p === PRESENCE.LEFT_EARLY ? `left ${at(r.departed_at)}`
        : (p === PRESENCE.PROVISIONAL && r.arrived_at)
          ? `${Math.min(r.min_dwell_min, Math.max(0, Math.floor((nowT - Date.parse(r.arrived_at)) / 60000)))}/${r.min_dwell_min}m`
          : '',
    });
  }
  if (asks.completion) stages.push({ key: 'completed', label: STAGE_LABEL.completed, done: !!r.completed_at, at: at(r.completed_at) });

  const base = {
    ...r, title, actionLabel, contextLine, deadlineLine, stages,
    canAck: false, canArrive: false, canComplete: false, canDispute: false,
    collapsed: false, visible: true, confirmLine: '',
    statusColor: 'b',
    // Normalised, so no screen has to know how a pre-0208 payload degrades.
    presence: presenceOf(r),
    // The wake-up verdict (0211), judged on THIS clock rather than the server's read time, so a
    // deadline that passed while the card sat open is reflected on the next paint.
    verdict: rollcallVerdict(r, nowISO),
    lateMin: lateMinutes(r),
    closesAt: closesAtOf(r),
    graceMin: graceMinOf(r),
  };

  // A cancelled instance disappears. It is not a miss — the coach called it off.
  if (r.instance_status === 'cancelled') {
    return { ...base, stage: 'hidden', visible: false };
  }

  if (r.status === 'excused') {
    return { ...base, stage: 'excused', collapsed: true, statusColor: 'b',
      confirmLine: r.excused_reason ? `Excused: ${r.excused_reason}` : 'Excused' };
  }

  // Never 'missed'. A dead phone, a revoked permission or weak GPS is a gap in evidence,
  // not a failure of the athlete — and they get a one-tap way to say so.
  if (r.status === 'unverified') {
    return { ...base, stage: 'unverified', canDispute: true, statusColor: 'a',
      confirmLine: r.unverified_reason
        ? `Couldn’t verify: ${r.unverified_reason}`
        : 'Couldn’t verify' };
  }

  if (r.completed_at) {
    // A completion does not erase a verified early departure (0208). The receipt keeps the
    // verdict: completion earned, arrival forfeited, dispute still open. Without this branch,
    // tapping "Mark complete" on an amber card upgraded it to a clean green receipt while
    // accountability() still withheld the arrival weight — the card lied about the score.
    if (presenceOf(r) === PRESENCE.LEFT_EARLY) {
      const where = r.location_name || 'the facility';
      const left = at(r.departed_at);
      return { ...base, stage: 'completed', collapsed: true, statusColor: 'a', canDispute: true,
        confirmLine: left
          ? `Completed at ${at(r.completed_at)} · left ${where} at ${left}`
          : `Completed at ${at(r.completed_at)} · left ${where} early` };
    }
    return { ...base, stage: 'completed', collapsed: true, statusColor: 'g',
      confirmLine: `Completed at ${at(r.completed_at)}` };
  }

  if (r.arrived_at) {
    const where = r.location_name || 'the facility';

    // The coach asked for a minimum stay and it has not been met yet. Blue, not green: a session
    // still running is not a result. Painting it green and walking it back later is the one move
    // an honest record cannot make, so the settled colour is withheld until it IS settled.
    if (base.presence === PRESENCE.PROVISIONAL) {
      // The one number that governs the athlete's next N minutes: how much of the stay is
      // banked. Clamped both ways so clock skew can never print "48 of 45" or a negative.
      const doneMin = Math.min(r.min_dwell_min || 0,
        Math.max(0, Math.floor((nowT - Date.parse(r.arrived_at)) / 60000)));
      return { ...base, stage: 'arrived', statusColor: 'b',
        canComplete: asks.completion,
        confirmLine: r.min_dwell_min
          ? `At ${where} since ${at(r.arrived_at)} · ${doneMin} of ${r.min_dwell_min} min`
          : `At ${where} since ${at(r.arrived_at)}` };
    }

    // A sustained departure before the minimum. Verified absence, which the founder ruled counts
    // (2026-08-23) — and precisely because it counts, it is disputable. The grace in 0208 makes a
    // GPS wobble unlikely to reach here; `canDispute` is what covers the case where one does.
    if (base.presence === PRESENCE.LEFT_EARLY) {
      const left = at(r.departed_at);
      return { ...base, stage: 'left_early', statusColor: 'a',
        canComplete: asks.completion, canDispute: true,
        confirmLine: left ? `Left ${where} at ${left}` : `Left ${where} early` };
    }

    return { ...base, stage: 'arrived', statusColor: 'g',
      canComplete: asks.completion,
      confirmLine: `Arrived at ${where} at ${at(r.arrived_at)}` };
  }

  if (r.acknowledged_at) {
    // A late answer is a real answer and stays recorded, but the receipt says so: amber ink and
    // "Late · 6 min" instead of a clean green "Checked in". The colour is the verdict.
    const late = base.verdict === VERDICT.LATE;
    const confirm = late
      ? `Checked in at ${at(r.acknowledged_at)} · Late${base.lateMin ? ` · ${base.lateMin} min` : ''}`
      : `Checked in at ${at(r.acknowledged_at)}`;
    if (asks.arrival) {
      return { ...base, stage: 'awaiting_arrival', canArrive: true, statusColor: 'b', confirmLine: confirm };
    }
    return { ...base, stage: 'acknowledged', collapsed: true, statusColor: late ? 'a' : 'g',
      confirmLine: confirm };
  }

  // Nothing recorded yet — now the clock decides.
  const deadlineISO = r.respond_by_at || r.arrive_by_at || r.ends_at || r.starts_at;
  const deadlineT = Date.parse(deadlineISO || '');
  if (isFinite(deadlineT) && nowT > deadlineT) {
    const noResponse = deadlineLine
      // "No response by 5:15 AM" keeps the meridiem exactly as every other stamp prints it —
      // the old .toLowerCase() mangled the whole line into "respond by 5:15 am".
      ? `No response by ${deadlineLine.replace(/^(?:Respond|Arrive) by /, '')}`
      : 'No response';
    // Past the deadline but before the roll call CLOSES (0211): the athlete can still answer,
    // and the answer will be recorded as late. The button stays, relabelled so nobody mistakes
    // it for being on time. A roll call with no close (older types) goes straight to missed.
    const closeT = Date.parse(base.closesAt || '');
    if (asks.ack && isFinite(closeT) && nowT <= closeT) {
      return { ...base, stage: 'late_open', canAck: true, canDispute: true, statusColor: 'a',
        actionLabel: 'Check in now', confirmLine: noResponse };
    }
    return { ...base, stage: 'missed', canDispute: true, statusColor: 'a', confirmLine: noResponse };
  }

  const opens = opensMinFor(r);
  if (nowMin != null && nowMin < opens) {
    return { ...base, stage: 'hidden', visible: false };
  }

  return { ...base, stage: 'open', canAck: asks.ack,
    canArrive: !asks.ack && asks.arrival, statusColor: 'a' };
}

/* ---------------------------------------------------------------- coach board */

const RESPONDED = new Set(['acknowledged', 'arrived', 'completed']);

export function boardCounts(rows) {
  const list = Array.isArray(rows) ? rows : [];
  return {
    total: list.length,
    responded: list.filter(r => RESPONDED.has(r.status)).length,
    awaiting: list.filter(r => r.status === 'pending').length,
    excused: list.filter(r => r.status === 'excused').length,
    unverified: list.filter(r => r.status === 'unverified').length,
    // A verified early departure (0208). Counted separately so the coach's "9 of 11 in" line
    // can say who arrived but did not stay — otherwise the board contradicts the athlete's card.
    leftEarly: list.filter(r => r.arrived_at != null && presenceOf(r) === PRESENCE.LEFT_EARLY).length,
  };
}

/** The list the coach actually needs: who has not answered. Never rendered publicly.
 *  Keyed on the ANSWER, not the status: the escalation ladder marks every non-responder 'missed'
 *  at the deadline, which is precisely when the coach looks at this list. A status-only filter
 *  returned nobody from that moment on (the 0209 remind_missing bug, now closed here too). */
export function missingFrom(rows) {
  return (Array.isArray(rows) ? rows : [])
    .filter(r => !r.acknowledged_at && (r.status === 'pending' || r.status === 'missed'));
}

/** Board rows judged against their instance: each row gains `verdict` and `lateMin`. The board
 *  payload carries the deadline on the INSTANCE, not the row, which is why this takes both. */
export function boardVerdicts(inst, nowISO) {
  const i = inst || {};
  const dl = deadlineOf(i);
  return (Array.isArray(i.rows) ? i.rows : []).map((r) => ({
    ...r, verdict: rollcallVerdict(r, nowISO, dl), lateMin: lateMinutes(r, dl),
  }));
}

/** The four groups the roll-call board draws, in the order the coach reads them. Rows that are
 *  neither (unverified) ride with the group their answer implies. */
export function groupByVerdict(inst, nowISO) {
  const g = { on_standard: [], late: [], pending: [], missed: [], excused: [] };
  for (const r of boardVerdicts(inst, nowISO)) (g[r.verdict] || g.pending).push(r);
  return g;
}

/** Counts for the board header. `responded` = on standard + late. */
export function verdictCounts(inst, nowISO) {
  const g = groupByVerdict(inst, nowISO);
  const total = (Array.isArray(inst && inst.rows) ? inst.rows : []).length;
  return {
    total, onStandard: g.on_standard.length, late: g.late.length,
    pending: g.pending.length, missed: g.missed.length, excused: g.excused.length,
    responded: g.on_standard.length + g.late.length,
    counted: total - g.excused.length,
  };
}

/* ---------------------------------------------------------------- wake-up history (0211) */

/** The athlete's own wake-up record, newest first, one line per occurrence: the verdict, the
 *  stamp (in the team's clock) and how late. Pending ones are kept (today's, before its
 *  deadline) so the list never hides the one that is live. */
export function wakeupHistory(rows, nowISO, offMinOverride) {
  return (Array.isArray(rows) ? rows : [])
    .filter((r) => r && r.type === 'morning_roll_call' && r.instance_status !== 'cancelled')
    .sort((a, b) => (a.occurs_on < b.occurs_on ? 1 : a.occurs_on > b.occurs_on ? -1 : 0))
    .map((r) => {
      const off = offsetFor(r, nowISO, offMinOverride);
      return {
        instance_id: r.instance_id, occurs_on: r.occurs_on, title: r.title,
        verdict: rollcallVerdict(r, nowISO), lateMin: lateMinutes(r),
        at: r.acknowledged_at ? fmtAt(r.acknowledged_at, off) : '',
        due: deadlineOf(r) ? fmtAt(deadlineOf(r), off) : '',
      };
    });
}

/** Totals over a wake-up history, pending excluded (a live roll call is not a result yet). */
export function wakeupSummary(history) {
  const s = { total: 0, onStandard: 0, late: 0, missed: 0 };
  for (const h of (Array.isArray(history) ? history : [])) {
    if (h.verdict === VERDICT.PENDING || h.verdict === VERDICT.EXCUSED) continue;
    s.total++;
    if (h.verdict === VERDICT.ON_STANDARD) s.onStandard++;
    else if (h.verdict === VERDICT.LATE) s.late++;
    else if (h.verdict === VERDICT.MISSED) s.missed++;
  }
  return s;
}

/** Reduce the coach's rollcall_summary rows to one line: "Last 14 roll calls: 12 / 1 / 1". */
export function summarizeOccurrences(occ) {
  const s = { occurrences: 0, onStandard: 0, late: 0, missed: 0, total: 0 };
  for (const o of (Array.isArray(occ) ? occ : [])) {
    if (!o || o.instance_status === 'cancelled') continue;
    // A day still in progress (anyone pending) is not a result yet.
    if (Number(o.pending) > 0) continue;
    s.occurrences++;
    s.onStandard += Number(o.on_standard) || 0;
    s.late += Number(o.late) || 0;
    s.missed += Number(o.missed) || 0;
    s.total += Number(o.total) || 0;
  }
  return s;
}

/* ---------------------------------------------------------------- accountability
   Founder weighting: pressing the button is a SMALL signal, arriving on time is MODERATE,
   completing the commitment is the GREATEST. Separate from the daily 0–100 score. */

export const WEIGHTS = { ack: 10, arrival: 30, completion: 60 };

export function accountability(rows) {
  let earned = 0, possible = 0;
  for (const r of (Array.isArray(rows) ? rows : [])) {
    // 'excused' leaves the denominator entirely — it cannot be scored honestly either way.
    if (r.status === 'excused') continue;
    const asks = signalsAsked(r);
    // 'unverified' removes only the signals it could not verify. A missed WAKE-UP never
    // cascades into arrival or completion: each signal is weighed on its own.
    const verified = r.status !== 'unverified';
    if (asks.ack) {
      possible += WEIGHTS.ack;
      if (r.acknowledged_at) earned += WEIGHTS.ack;
    }
    if (asks.arrival && verified) {
      possible += WEIGHTS.arrival;
      if (arrivalCounts(r)) earned += WEIGHTS.arrival;
    }
    if (asks.completion && verified) {
      possible += WEIGHTS.completion;
      if (r.completed_at) earned += WEIGHTS.completion;
    }
  }
  // No data reports null, never a fake zero — an athlete with no commitments has not failed.
  return { earned, possible, pct: possible ? Math.round((earned / possible) * 100) : null };
}

/** The three lines the coach and athlete read, plus the overall percentage. */
export function morningReadiness(rows) {
  const list = Array.isArray(rows) ? rows : [];
  const pair = () => ({ done: 0, total: 0 });
  const wake = pair(), arrival = pair(), completion = pair();
  for (const r of list) {
    if (r.status === 'excused') continue;
    const asks = signalsAsked(r);
    const verified = r.status !== 'unverified';
    if (asks.ack) { wake.total++; if (r.acknowledged_at) wake.done++; }
    if (asks.arrival && verified) { arrival.total++; if (arrivalCounts(r)) arrival.done++; }
    if (asks.completion && verified) { completion.total++; if (r.completed_at) completion.done++; }
  }
  return { wake, arrival, completion, ...accountability(list) };
}

/** Did this athlete meet every signal their commitments asked for on this date? */
function dayIsClean(dayRows) {
  for (const r of dayRows) {
    if (r.status === 'excused') continue;
    const asks = signalsAsked(r);
    const verified = r.status !== 'unverified';
    if (asks.ack && !r.acknowledged_at) return false;
    if (asks.arrival && verified && !arrivalCounts(r)) return false;
    if (asks.completion && verified && !r.completed_at) return false;
  }
  return true;
}

/** Consecutive clean days ending today. A day with NO commitments is skipped, not counted and
 *  not a break — a Sunday with nothing scheduled must not end a streak the athlete earned. */
export function commitmentStreak(rows, todayISO, maxDays = 365) {
  const byDay = new Map();
  for (const r of (Array.isArray(rows) ? rows : [])) {
    if (!r || !r.occurs_on) continue;
    if (!byDay.has(r.occurs_on)) byDay.set(r.occurs_on, []);
    byDay.get(r.occurs_on).push(r);
  }
  let streak = 0;
  for (let i = 0; i < maxDays; i++) {
    const day = addDays(todayISO, -i);
    const dayRows = byDay.get(day);
    if (!dayRows || !dayRows.length) {
      // Stop walking once we're past every day we have data for.
      if (i > 0 && ![...byDay.keys()].some(k => k < day)) break;
      continue;
    }
    if (!dayIsClean(dayRows)) break;
    streak++;
  }
  return streak;
}

/* ---------------------------------------------------------------- reminders
   Automatic nudges go ONLY to athletes who have not responded — the coach never counts replies
   and never calls anyone out in a group chat.

   These entries carry stage 'commitment' and exemptFromCap, which notify-plan.js honours by
   scheduling them THROUGH quiet hours and outside the daily cap. That is deliberate: default
   quiet hours are 22:00–07:00, so a 4:45 AM roll call would otherwise be silently swallowed and
   the whole feature would quietly not work. This is a scheduled event the coach set, not a nudge
   the app invented — and the phone's own Do Not Disturb still wins. */
export function commitmentReminders(rows, todayISO) {
  const out = [];
  for (const r of (Array.isArray(rows) ? rows : [])) {
    if (!r || r.occurs_on !== todayISO) continue;
    if (r.status !== 'pending') continue;
    if (r.instance_status === 'cancelled') continue;
    const anchor = r.respond_by_min != null ? r.respond_by_min : r.starts_min;
    if (anchor == null) continue;
    const offsets = Array.isArray(r.reminder_offsets_min) ? r.reminder_offsets_min : [];
    for (const off of offsets) {
      const n = Number(off);
      if (!isFinite(n) || n < 0) continue;
      out.push({
        stage: 'commitment',
        exemptFromCap: true,
        at: Math.max(0, anchor - n),
        instanceId: r.instance_id,
        instance_id: r.instance_id,
        title: (r.title && String(r.title).trim()) || TYPE_LABEL[r.type] || 'Commitment',
        body: r.respond_by_min != null
          ? `Respond by ${fmtMin(r.respond_by_min)}.`
          : `Starts at ${fmtMin(anchor)}.`,
      });
    }
  }
  return out;
}
